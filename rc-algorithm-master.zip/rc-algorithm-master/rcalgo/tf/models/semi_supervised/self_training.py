import numpy as np
import tensorflow as tf
from rcalgo.tf.training.data.data import Data
from rcalgo.tf.training import training_utils
from rcalgo.tf.models.semi_supervised.semi_utils import kl_for_log_probs, compute_tsa_threshold
from rcalgo.tf.models.semi_supervised.base_semi_supervised import SemiSupervisor
from rcalgo.tf.metric.loss import my_sparse_cross_entropy_loss


class SelfTraining(SemiSupervisor):
    """
    """

    def __init__(self, execute_model, config, name="self_train", **kwargs):
        # linear_schedule, exp_schedule, log_schedule, None
        self.batch_size = config.get("batch_size", 32)
        self.sup_batch_size = self.batch_size
        self.unsup_ratio = config.get("unsup_ratio", 1)
        self.unsup_batch_size = self.batch_size * self.unsup_ratio
        self.num_train_steps = config.get("num_train_steps", 0)
        self.num_classes = config.get("num_classes", 2)

        self.global_step = tf.train.get_or_create_global_step()
        self.input_concat = None
        super().__init__(execute_model, config=config, name=name, **kwargs)
        self.execute_model.model_reuse = tf.AUTO_REUSE

    def create_inputs(self):
        text = tf.placeholder(dtype=tf.string, shape=[None], name='input_text')
        unsup = tf.placeholder(dtype=tf.string, shape=[None, self.unsup_ratio], name='unsup')
        labels = tf.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        pseudo_labels = tf.placeholder(dtype=tf.int32, shape=[None, self.unsup_ratio], name='pseudo_labels')
        return [text, unsup], [labels, pseudo_labels]

    def build_forward(self, **kwargs):
        inputs, labels = self.create_inputs()
        text, unsup = inputs
        sup_labels, pseudo_labels = labels
        unsup = tf.reshape(unsup, [self.unsup_batch_size])
        pseudo_labels = tf.reshape(pseudo_labels, [self.unsup_batch_size])
        with tf.variable_scope('SelfTrain', reuse=tf.AUTO_REUSE):
            sup_states, sup_outputs = self.execute_model.call(text, **kwargs)
            unsup_states, unsup_outputs = self.execute_model.call(unsup, **kwargs)

        loss = self.compute_loss([sup_states, unsup_states], [sup_labels, pseudo_labels])
        metrics = self.compute_metrics(sup_outputs, sup_labels)

        self.inputs = [text, unsup]
        self.outputs = [sup_outputs]
        self.labels = labels
        self.loss = loss
        self.metrics = metrics
        training_utils.create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)
        return self

    def compute_sup_loss(self, states, labels):
        sup_states = states[0]
        sup_labels = labels[0]
        with tf.variable_scope("sup_loss"):
            sup_loss_per_example = my_sparse_cross_entropy_loss(sup_labels, sup_states,
                                                                self.num_classes, label_smooth=0.0)
            sup_loss = tf.reduce_mean(sup_loss_per_example)
        return sup_loss

    def compute_unsup_loss(self, states, labels):
        unsup_states = states[1]
        pseudo_labels = labels[1]
        with tf.variable_scope("unsup_loss"):
            unsup_loss_per_example = my_sparse_cross_entropy_loss(pseudo_labels, unsup_states,
                                                                  self.num_classes, label_smooth=0.0)
            unsup_loss = tf.reduce_mean(unsup_loss_per_example)
        return unsup_loss


class SelfTrainData(Data):
    @property
    def sup_data_size(self):
        return int(len(self.datasets[0]))

    @property
    def unsup_data_size(self):
        return int(len(self.datasets[1]))

    def get_dataset_size(self):
        return self.sup_data_size

    def to_tf_dataset(self):
        self.build_schema()
        text, org_unsup, label, pseudo_label = self.data_schema
        if self.mode == "train":
            text_ds = tf.data.Dataset.from_tensor_slices(text)
            org_unsup_ds = tf.data.Dataset.from_tensor_slices(org_unsup)
            label_ds = tf.data.Dataset.from_tensor_slices(label)
            pseudo_label_ds = tf.data.Dataset.from_tensor_slices(pseudo_label)
            print(f"sup_data_size: {self.sup_data_size}, unsup_data_size: {self.unsup_data_size}")
            # since sup data and unsup data have different size,
            # they need to be repeat and shuffle seperately.
            total_ds = tf.data.Dataset.zip((text_ds.shuffle(self.sup_data_size, seed=0).repeat(),
                                            org_unsup_ds.shuffle(self.unsup_data_size, seed=1).repeat(),
                                            label_ds.shuffle(self.sup_data_size, seed=0).repeat(),
                                            pseudo_label_ds.shuffle(self.unsup_data_size, seed=1).repeat()))
            return total_ds.batch(self.batch_size).prefetch(tf.data.experimental.AUTOTUNE)
        else:
            return tf.data.Dataset.from_tensor_slices(self.data_schema).batch(self.batch_size)
