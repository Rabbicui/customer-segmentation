import tensorflow as tf
from rcalgo.tf.module.layer.basic import *

def vanilla_generator(gan, noise, training=None, reuse=None):
    """
    The generator takes the random data (usually the noise) as inputs and returns the
    outputs of the GAN.

    Concrete implementation should override this function

    Args:
        gan:            The gan_model object which contains all the properties
        noise:          A single Tensor representing noise.
        training:    If 'True', use batch norm
        reuse:          Whether reuse the variable scope
    Returns:
        The generated output (like the fake pics)
        The params for generator
    """
    g_h1 = my_full_connected(noise, gan.hidden_dim, act=tf.nn.relu, reuse=reuse,
                             layer_name='generator_fc_1',
                             add_bias=True, variables_collections=gan.G_TASK)
    g_prob = my_full_connected(g_h1, gan.input_dim, act=tf.nn.sigmoid, reuse=reuse,
                               layer_name='generator_fc_2',
                               add_bias=True, variables_collections=gan.G_TASK)
    return g_prob


def conv2d_generator(gan, noise, training=None, reuse=None):
    """
    Deconv Generator on MINST digits.
    """
    net = my_full_connected(noise, 1024, act=tf.nn.relu, reuse=reuse,
                            layer_name='generator_fc_1',
                            bn=True, training=training, add_bias=False,
                            variables_collections=gan.G_TASK)
    net = my_full_connected(net, 7*7*128, act=tf.nn.relu, reuse=reuse,
                            layer_name='generator_fc_2',
                            bn=True, training=training, add_bias=False,
                            variables_collections=gan.G_TASK)
    net = tf.reshape(net, [-1, 7, 7, 128])

    # deconv
    net = my_conv_2d_transpose(net, 64, [4, 4], strides=2, reuse=reuse,
                               layer_name='generator_conv2d_transpose_1',
                               bn=True, training=training,
                               variables_collections=gan.G_TASK)
    # net shape batch_size * 14 * 14 * 64
    net = my_conv_2d_transpose(net, 32, [4, 4], strides=2, reuse=reuse,
                               layer_name='generator_conv2d_transpose_2',
                               bn=True, training=training,
                               variables_collections=gan.G_TASK)
    # net shape batch_size * 28 * 28 * 32
    net = my_conv_2d(net, 1, [4, 4], reuse=reuse, layer_name='generator_conv2d', act=tf.tanh,
                     variables_collections=gan.G_TASK)

    # flatten
    # net shape batch_size * 28 * 28 * 1
    batch_size = net.get_shape()[0].value
    net = tf.reshape(net, [batch_size, -1])
    return net

