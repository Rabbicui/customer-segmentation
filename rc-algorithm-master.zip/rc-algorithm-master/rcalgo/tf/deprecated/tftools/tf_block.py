import tensorflow as tf
from .tf_act_func import swish, gelu, selu
from .tf_layer import *
from .tf_float_type import get_default_float_type

act_fns = {
    'relu': tf.nn.relu,
    'swish': swish,
    'gelu': gelu,
    'selu': selu
}

################################################  attention  block  ################################################
#https://github.com/tensorflow/models/blob/master/official/transformer/model/attention_layer.py
#https://github.com/OpenNMT/OpenNMT-tf/blob/master/opennmt/layers/transformer.py
def mask_attention_weights(input_tensor, epsilon=-1e9):
    """
    mask attention, only consider the left part
    """
    mask_n = shape_list(input_tensor)[-1]
    # Lower triangular with one
    mask = tf.linalg.band_part(tf.ones([mask_n, mask_n]), -1, 0)
    mask = tf.reshape(mask, [1, 1, mask_n, mask_n])
    # matrix broadcast
    return input_tensor*mask + epsilon*(1-mask)


def attention(query, key, value, attn_drop=0.1,
              training=False, scale=False, mask=True):
    """
    Scaled Dot-Product Attention

    """
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    #  key:    batch * n_head * n_state * n_word
    #  query:  batch * n_head * n_word * n_ state
    n_state = shape_list(query)[-1]
    weight = tf.matmul(query, key)
    if scale:
        weight = weight / tf.sqrt(tf.cast(n_state, get_default_float_type()))
    if mask:
        weight = mask_attention_weights(weight)
    attention = my_dropout(tf.nn.softmax(weight), attn_drop, training)
    attention_qkv = tf.matmul(attention, value)
    return attention_qkv


def split_states(input_tensor, n):
    shapes = shape_list(input_tensor)
    m = shapes[-1]
    new_shapes = shapes[:-1] + [n, m//n]
    return tf.reshape(input_tensor, new_shapes)


def merge_states(input_tensor):
    shapes = shape_list(input_tensor)
    new_shapes = shapes[:-2] + [np.prod(shapes[-2:])]
    return tf.reshape(input_tensor, new_shapes)


def split_heads(input_tensor, n_head, key_flag=False):
    if key_flag:
        return tf.transpose(split_states(input_tensor, n_head), [0, 2, 3, 1])
    else:
        return tf.transpose(split_states(input_tensor, n_head), [0, 2, 1, 3])


def merge_heads(input_tensor):
    return merge_states(tf.transpose(input_tensor, [0, 2, 1, 3]))


def multi_head_attention_v2(query, key, value, n_head, layer_name='multi_head_attention',
                            attn_drop=0.001, scale=False, mask=False,
                            scope=None, reuse=False, training=False):
    shapes = shape_list(query)
    n_state = shapes[-1]
    if len(shapes) == 2:
        query = tf.reshape(query, [-1, 1, n_state])

    if value is None:
        value = key
    assert n_state % n_head == 0
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        # the implementation here is very precise, use conv1d, everything is matrix matmul
        n_heads_query = split_heads(query, n_head)
        n_heads_key = split_heads(key, n_head, key_flag=True)
        n_heads_value = split_heads(value, n_head)
        attn = attention(n_heads_query, n_heads_key, n_heads_value, attn_drop=attn_drop,
                         training=training, scale=scale, mask=mask)
        attn = merge_heads(attn)
        # 之前这里有个bug，用的是tanh
        attn_conv = my_dropout(my_conv_1d(attn, 1, n_state, act=tf.identity),
                               attn_drop, training=training)
        return tf.reshape(attn_conv, [-1, n_state])


def multi_head_attention(input_tensor, n_state, n_head, layer_name='multi_head_attention',
                        attn_drop=0.1, scale=False, mask=True,
                        scope=None, reuse=False, training=False):
    assert n_state % n_head == 0

    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        # the implementation here is very precise, use conv1d, everything is matrix matmul
        c = my_conv_1d(input_tensor, 1, n_state*3, act=tf.identity)
        query, key, value = tf.split(c, 3, 2)
        n_heads_query = split_heads(query, n_head)
        n_heads_key = split_heads(key, n_head, key_flag=True)
        n_heads_value = split_heads(value, n_head)
        attn = attention(n_heads_query, n_heads_key, n_heads_value, attn_drop=attn_drop,
                         training=training, scale=scale, mask=mask)
        attn = merge_heads(attn)
        #之前这里有个bug，用的是tanh
        attn_conv = my_dropout(my_conv_1d(attn, 1, n_state, act=tf.identity),
                               attn_drop, training=training)
        return attn_conv


def ffn_mlp(input_tensor, n_state, layer_name='ffn_mlp', act=gelu, ffn_drop=0.1,
            training=False, scope=None, reuse=False):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        h = act(my_conv_1d(input_tensor, 1, n_state, act=tf.identity))
        re_input_tensor = my_dropout(my_conv_1d(h, 1, shape_list(
            input_tensor)[-1], act=tf.identity), ffn_drop, training)
        return re_input_tensor


def transformer_block(input_tensor, n_head,
                      attn_drop=0.1, scale=True, mask=True,
                      ffn_act=gelu, ffn_drop=0.1,
                      use_t2t_transformer=False,
                      layer_name='transform2_block', scope=None, reuse=False,
                      training=False):
    """
    https://arxiv.org/pdf/1801.10198.pdf
    
    """
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)
    #tensor2tensor中的实际顺序不太一样
    if use_t2t_transformer:
        fun_list = [my_layer_norm, tf.identity]
    else:
        fun_list = [tf.identity, my_layer_norm]
        
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        n_state = shape_list(input_tensor)[-1]
        m_head_attn = multi_head_attention(
            fun_list[0](input_tensor), n_state, n_head, attn_drop=attn_drop,
            scale=scale, mask=mask, training=training)
        m_head_attn_ln = fun_list[1](input_tensor+m_head_attn)
        m_head_attn_ln_ffn = ffn_mlp(
            fun_list[0](m_head_attn_ln), n_state*4, act=ffn_act, ffn_drop=ffn_drop, training=training)
        t_block = fun_list[1](m_head_attn_ln+m_head_attn_ln_ffn)
        return t_block
    
    
    
def conv_transformer_layer(input_tensor, num_layers, seq_len, conv_num_filters,
                           conv_length_list, combine_mode='ADD', output_reduce_size=0,
                           reverse=False, position_info=False, *args, **kwargs):
    """
    Position embedding + conv + transformer
    Main Args:
      input_tensor: the input tensor [batch, d1, d2 ...]
      num_layers: the number of transformer block
      seq_len: the seq length [batch]
      conv_num_filters:  conv parameter
      conv_length_list:  conv parameter
    Returns:
      A Tensor, Dimension: [batch, d1 * d2 * ..]
    """
    #翻转部分
    if reverse:
        state = array_ops.reverse_sequence(
            input=input_tensor, seq_lengths=seq_len, seq_axis=1, batch_axis=0)
    else:
        state = input_tensor
    #conv部分    
    try:
        state = multi_width_cnn_block(state, conv_num_filters, conv_length_list,
                                      combine_mode=combine_mode, padding='LEFT_SAME', act=tf.nn.relu)
    except ValueError:
        state = state
    batch, maxlen, hidden_size = shape_list(state)  
    #position embedding部分
    if position_info:
        state = state + position_embedding(maxlen, hidden_size, seq_len)
    #Transformer block
    for layer in range(num_layers):
        state = transformer_block(state, *args, **kwargs)
    #attempt to reduce output dimension
    if output_reduce_size < hidden_size and output_reduce_size != 0:
        #conv1d dim reduce
        state = my_conv_1d(state, 1, output_reduce_size, act=tf.identity)
        state = my_layer_norm(state) 
        state = transformer_block(state, *args, **kwargs)
        hidden_size = output_reduce_size
    #select
    flat_state = tf.reshape(state, [-1, hidden_size])
    gather_idx = tf.range(batch, dtype=tf.int32)*maxlen + \
        tf.cast(seq_len, tf.int32) - 1
    output = tf.gather(flat_state, gather_idx)
    #reverse the sequence
    if reverse:
        state = array_ops.reverse_sequence(
            state, seq_lengths=seq_len, seq_axis=1, batch_axis=0)
    #zero mask the seq
    mask = array_ops.sequence_mask(seq_len, maxlen, dtype=get_default_float_type())
    mask = array_ops.tile(array_ops.expand_dims(mask, [-1]), [1, 1, hidden_size])
    state *= mask
    return state, output


def bi_conv_transformer_layer(input_tensor, num_layers, seq_len, conv_num_filters,
                              conv_length_list, combine_mode, output_reduce_size=0, *args, **kwargs):
    with get_new_variable_scope('bidirectional_transformer') as rnn_scope:
        with get_new_variable_scope('transformer_fw') as rnn_scope:
            output_fw, output_state_fw = conv_transformer_layer(
                input_tensor, num_layers, seq_len, conv_num_filters,
                conv_length_list, combine_mode, output_reduce_size, reverse=False, *args, **kwargs)
        with get_new_variable_scope('transformer_bw') as rnn_scope:
            output_bw, output_state_bw = conv_transformer_layer(
                input_tensor, num_layers, seq_len, conv_num_filters,
                conv_length_list, combine_mode, output_reduce_size, reverse=True, *args, **kwargs)
        outputs = (output_fw, output_bw)
        output_states = (output_state_fw, output_state_bw)
        return (outputs, output_states)

################################################   Conv  block  ################################################
def multi_width_cnn_block(input_tensor, num_filters, conv_length_list=[2,3,4,5], combine_mode='ADD',
                          padding='VALID', act=tf.nn.relu, layer_name='mw_conv_block',
                          scope=None, reuse=False):

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    outputs = []
    if isinstance(conv_length_list, int):
        conv_length_list = [conv_length_list]
    if isinstance(conv_length_list, str):
        conv_length_list = np.fromstring(conv_length_list, dtype=np.int32, sep=',')
    with vscope as scope:
        for conv_length in conv_length_list:
            outputs.append(my_conv_1d(input_tensor, conv_length,
                                      num_filters, add_bias=True, bn=False,
                                      padding=padding, act=act))
        if padding != 'VALID':
            if combine_mode == 'ADD':
                return tf.add_n(outputs)
            elif combine_mode == 'CONCAT':
                return tf.concat(outputs, axis=2)
            elif combine_mode == 'POOL':
                return tf.reduce_max(outputs, axis=0)
            else:
                raise NotImplementedError
        else:
            return outputs

