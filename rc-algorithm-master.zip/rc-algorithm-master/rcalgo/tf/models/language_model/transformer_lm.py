import tensorflow as tf
from rcalgo.tf.models.language_model.base_lm import LanguageModel
from rcalgo.tf.module.encoder.transformer import conv_transformer_layer, bi_conv_transformer_layer
from rcalgo.tf.module.layer.activations import act_fns
from tensorflow.python.ops import array_ops


class TransformerLM(LanguageModel):
    def __init__(self, config, word_dict, **kwargs):
        super(TransformerLM, self).__init__(config, word_dict, **kwargs)
        self.conv_num_filters = config.get("conv_num_filters", 512)
        self.conv_length_list = config.get("conv_length_list", [2, 3, 4, 5])
        self.combine_mode = config.get("combine_mode", "ADD")  # must be in ['ADD', 'CONCAT', 'POOL']
        self.output_reduce_size = config.get("output_reduce_size", 0)
        self.n_head = config.get("n_head", 8)
        self.mask = config.get("mask", True)
        self.ffn_act = act_fns[config.get("transformer_func", "relu")]
        self.attn_drop = 1.0 - config.get("keep_prob", 1.0)
        self.ffn_drop = 1.0 - config.get("keep_prob", 1.0)

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        states, outputs = conv_transformer_layer(input_tensor=embedding,
                                                 num_layers=self.num_layers,
                                                 seq_len=seq_lengths,
                                                 conv_num_filters=self.conv_num_filters,
                                                 conv_length_list=self.conv_length_list,
                                                 combine_mode=self.combine_mode,
                                                 output_reduce_size=self.output_reduce_size,
                                                 n_head=self.n_head,
                                                 attn_drop=self.attn_drop,
                                                 mask=self.mask,
                                                 ffn_act=self.ffn_act,
                                                 ffn_drop=self.ffn_drop,
                                                 training=self.is_training)
        targets = tf.concat([sequence[:, 1:], tf.zeros_like(sequence[:, 0:1])], 1)
        return states, outputs, targets


class BiTransformerLM(TransformerLM):
    def __init__(self, config, word_dict, **kwargs):
        super(BiTransformerLM, self).__init__(config, word_dict, **kwargs)

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        bi_states, bi_outputs = bi_conv_transformer_layer(input_tensor=embedding,
                                                          num_layers=self.num_layers,
                                                          seq_len=seq_lengths,
                                                          conv_num_filters=self.conv_num_filters,
                                                          conv_length_list=self.conv_length_list,
                                                          combine_mode=self.combine_mode,
                                                          output_reduce_size=self.output_reduce_size,
                                                          n_head=self.n_head,
                                                          attn_drop=self.attn_drop,
                                                          mask=self.mask,
                                                          ffn_act=self.ffn_act,
                                                          ffn_drop=self.ffn_drop,
                                                          training=self.is_training)

        seqlen_exp_dim = array_ops.tile(tf.cast(array_ops.expand_dims(seq_lengths, [-1]), dtype=tf.float32),
                                        [1, bi_states[0].shape[-1].value * 2])
        outputs = tf.reduce_sum(tf.concat(bi_states, -1), axis=1) / seqlen_exp_dim
        targets_fw = tf.concat([sequence[:, 1:], tf.zeros_like(sequence[:, 0:1])], 1)
        targets_bw = tf.concat([tf.zeros_like(sequence[:, 0:1]), sequence[:, 0:-1]], 1)
        states = [bi_states[0], bi_states[1]]
        targets = [targets_fw, targets_bw]
        return states, outputs, targets
