import tensorflow as tf

from rcalgo.tf.utils.tf_func import get_new_variable_scope, add_weight_to_collection, fp32_storage_getter


class WordEmbedder(object):

    def __init__(self, vocab_size, embedding_size,
                 layer_name='embedding_layer', init_scale=1.0,
                 dtype=tf.float32, zero_pad=True,
                 scope=None, reuse=False, initializer=None,
                 variables_collections=None):
        """
        Build the embedder for multiple use
        """
        self.embedding_size = embedding_size
        vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
        with vscope as scope:
            # if zero pad, only assign (vocab_size-1) * embed_size Matrix
            # vocab_size = vocab_size - int(zero_pad)
            if initializer is None:
                # tf.contrib.layers.xavier_initializer()
                initializer = tf.random_uniform_initializer(
                    -init_scale, init_scale)
            self.embedding_table = tf.compat.v1.get_variable('embedding_table',
                                                             [vocab_size, embedding_size], dtype=dtype,
                                                             initializer=initializer)
            # 注释掉，tf的framework.function 988行，compute_shape会更改
            # embedding_table = convert_gradient_to_dense_tensor(embedding_table)
            add_weight_to_collection(self.embedding_table, variables_collections)

    def __call__(self, input_tensor, scale=False, embedding_size=None):
        """
        Reuse the embedding table to compute the tensor
        if the scale is True, embedding_size must be provided
        """
        input_embedding = tf.nn.embedding_lookup(self.embedding_table, input_tensor)
        if scale:
            input_embedding = input_embedding * (embedding_size ** 0.5)
        return input_embedding


def my_embedding_layer(input_tensor, vocab_size, embedding_size,
                       layer_name='embedding_layer', init_scale=1.0,
                       dtype=tf.float32, zero_pad=True, scale=False,
                       scope=None, reuse=False, initializer=None,
                       variables_collections=None):
    """
    Word Embedding Layer

    Main Args:
      input_tensor: the input sequence tensor [batch, maxlen]
      vocab_size:  vocabulary size for word embedding
      embedding_size: embedding size
      zero_pad: If True, all the values of the fist row (id 0)
        should be constant zeros.
      scale: If True. the outputs is multiplied by sqrt embedding_size
    Returns:
        A Tensor, Dimension: [batch, maxlen, embedding_size]
    """
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        # if zero pad, only assign (vocab_size-1) * embed_size Matrix
        vocab_size = vocab_size - int(zero_pad)
        if initializer is None:
            # tf.contrib.layers.xavier_initializer()
            initializer = tf.random_uniform_initializer(
                -init_scale, init_scale)
        embedding_table = tf.compat.v1.get_variable('embedding_table',
                                                    [vocab_size, embedding_size], dtype=dtype,
                                                    initializer=initializer)
        # 注释掉，tf的framework.function 988行，compute_shape会更改
        # embedding_table = convert_gradient_to_dense_tensor(embedding_table)
        if zero_pad:
            embedding_table = tf.concat((tf.zeros(shape=[1, embedding_size], dtype=dtype),
                                         embedding_table), 0)
        add_weight_to_collection(embedding_table, variables_collections)
        input_embedding = tf.nn.embedding_lookup(embedding_table, input_tensor)
        if scale:
            input_embedding = input_embedding * (embedding_size ** 0.5)
        return input_embedding
