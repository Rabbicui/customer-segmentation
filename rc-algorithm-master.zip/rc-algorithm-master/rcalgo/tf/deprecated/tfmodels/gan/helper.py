import tensorflow as tf
from tensorflow.contrib.seq2seq import Helper as TFHelper
from tensorflow.python.framework import tensor_shape

class MultinomialSoftmaxEmbeddingHelper(TFHelper):

    def __init__(self, embedding, start_tokens, end_token,
                 stop_gradient=False, use_finish=True):
        if callable(embedding):
            raise ValueError("`embedding` must be an embedding tensor or an "
                             "instance of subclass of `EmbedderBase`.")
        else:
            self._embedding = embedding
            self._embedding_fn = (
                lambda ids: tf.nn.embedding_lookup(embedding, ids))
        self._start_tokens = tf.convert_to_tensor(
            start_tokens, dtype=tf.int32, name="start_tokens")
        self._end_token = tf.convert_to_tensor(
            end_token, dtype=tf.int32, name="end_token")
        self._start_inputs = self._embedding_fn(self._start_tokens)
        self._batch_size = tf.size(self._start_tokens)
        self._stop_gradient = stop_gradient
        self._use_finish = use_finish

    @property
    def batch_size(self):
        return self._batch_size

    @property
    def sample_ids_dtype(self):
        return tf.int32

    @property
    def sample_ids_shape(self):
        return tensor_shape.TensorShape([])

    def initialize(self, name=None):
        finished = tf.tile([False], [self._batch_size])
        return (finished, self._start_inputs)

    def sample(self, time, outputs, state, name=None):
        """Returns `sample_id` which is softmax distributions over vocabulary
        with temperature `tau`. Shape = `[batch_size, vocab_size]`
        """
        probs = tf.nn.softmax(outputs)
        sample_ids = tf.cast(tf.reshape(tf.multinomial(probs, 1), [self.batch_size]), tf.int32)
        return sample_ids

    def next_inputs(self, time, outputs, state, sample_ids, name=None):
        if self._stop_gradient:
            sample_ids = tf.stop_gradient(sample_ids)
        if self._use_finish:
            # hard_ids = tf.argmax(sample_ids, axis=-1, output_type=tf.int32)
            finished = tf.equal(sample_ids, self._end_token)
        else:
            finished = tf.tile([False], [self._batch_size])
        next_inputs = self._embedding_fn(sample_ids)
        return (finished, next_inputs, state)