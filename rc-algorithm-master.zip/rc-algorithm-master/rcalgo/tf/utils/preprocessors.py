import numpy as np
from tqdm import tqdm_notebook as tqdm

from rcalgo.tf.utils.tokenizers import FullTokenizer


class BertSentencePreprocessor(object):
    def __init__(self, vocab_file=None, do_lower_case=False):
        if vocab_file is None:
            vocab_file = "/home/web_server/antispam/project/" \
                 "pretrained_models/chinese_L-12_H-768_A-12/vocab.txt"
        self.tokenizer = FullTokenizer(
            vocab_file=vocab_file, do_lower_case=do_lower_case)

    def process(self, texts, do_tokenize=True, max_seq_length=128):
        """Convert texts to features required by bert."""
        input_ids_list = []
        input_mask_list = []
        segment_ids_list = []

        for text in tqdm(texts):
            input_ids = self.convert_text_to_ids(text, do_tokenize, max_seq_length)
            input_mask = [1] * len(input_ids)
            segment_ids = [0] * len(input_ids)

            input_mask += [0] * (max_seq_length - len(input_ids))
            segment_ids += [0] * (max_seq_length - len(input_ids))
            input_ids += [0] * (max_seq_length - len(input_ids))

            assert len(input_ids) == max_seq_length
            assert len(input_mask) == max_seq_length
            assert len(segment_ids) == max_seq_length
            input_ids_list.append(input_ids)
            input_mask_list.append(input_mask)
            segment_ids_list.append(segment_ids)
        return np.array(input_ids_list), np.array(input_mask_list), np.array(segment_ids_list)

    def convert_text_to_ids(self, text, do_tokenize=True, max_seq_length=None):
        """Convert texts to token ids."""
        if do_tokenize:
            tokens = self.tokenizer.tokenize(text)
        else:  # 文本已经提前tokenize过了，传入的text是空格隔开的token，所以用split
            tokens = text.split()

        if max_seq_length is not None and len(tokens) > max_seq_length - 2:
            tokens = tokens[0:(max_seq_length - 2)]
        tokens = ["[CLS]"] + tokens + ["[SEP]"]
        ids = self.tokenizer.convert_tokens_to_ids(tokens)
        return ids

    def convert_text_to_ids_string(self, *args, **kwargs):
        """Convert text to token ids and concat them as string."""
        ids = self.convert_text_to_ids(*args, **kwargs)
        ids_str = " ".join([str(id_) for id_ in ids])
        return ids_str

    def convert_text_to_tokens(self, text):
        """Convert text to tokens."""
        tokens = self.tokenizer.tokenize(text)
        return tokens

    def convert_text_to_tokens_string(self, text, sep=" "):
        """Convert text to tokens and concat them as string."""
        tokens = self.convert_text_to_tokens(text)
        return sep.join(tokens)


class BertSentencePairPreprocessor(BertSentencePreprocessor):
    def __init__(self, vocab_file=None, do_lower_case=False):
        super(BertSentencePairPreprocessor, self).__init__(vocab_file, do_lower_case)

    def process(self, texts_a, texts_b=None, do_tokenize=True, max_seq_length=128):
        input_ids_list = []
        input_mask_list = []
        segment_ids_list = []

        if texts_b is None:
            return super(BertSentencePairPreprocessor, self).process(texts_a, do_tokenize, max_seq_length)

        for text_a, text_b in tqdm(list(zip(texts_a, texts_b))):
            input_ids, input_mask, segment_ids = self.convert_sentence_pair(text_a, text_b, do_tokenize, max_seq_length)
            input_ids_list.append(input_ids)
            input_mask_list.append(input_mask)
            segment_ids_list.append(segment_ids)
        return np.array(input_ids_list), np.array(input_mask_list), np.array(segment_ids_list)

    def convert_sentence_pair(self, text_a, text_b, do_tokenize=True, max_seq_length=None):
        if do_tokenize:
            tokens_a = self.tokenizer.tokenize(text_a)
            tokens_b = self.tokenizer.tokenize(text_b)
        else:
            tokens_a = text_a.split()
            tokens_b = text_b.split()

        while True:
            total_length = len(tokens_a) + len(tokens_b)
            if total_length <= max_seq_length - 3:
                break
            if len(tokens_a) > len(tokens_b):
                tokens_a.pop()
            else:
                tokens_b.pop()

        tokens = ['[CLS]'] + tokens_a + ['[SEP]'] + tokens_b + ['[SEP]']
        segment_ids = [0] * (len(tokens_a) + 2) + [1] * (len(tokens_b) + 1)
        input_ids = self.tokenizer.convert_tokens_to_ids(tokens)
        input_mask = [1] * len(input_ids)

        input_mask += [0] * (max_seq_length - len(input_ids))
        segment_ids += [0] * (max_seq_length - len(input_ids))
        input_ids += [0] * (max_seq_length - len(input_ids))

        assert len(input_ids) == max_seq_length
        assert len(input_mask) == max_seq_length
        assert len(segment_ids) == max_seq_length
        return input_ids, input_mask, segment_ids


class BertMLMPreprocessor(BertSentencePreprocessor):
    def __init__(self, vocab_file=None, do_lower_case=False):
        super(BertMLMPreprocessor, self).__init__(vocab_file, do_lower_case)

    def process(self, texts, do_tokenize=True, max_seq_length=128, masked_lm_probs=0.15,
                max_predictions_per_seq=10, label_is_token_type=False, labels=None):
        if label_is_token_type:
            if labels is None:
                raise ValueError("`labels` must be specified if `label_is_token_type` is True.")
            assert len(texts) == len(labels)

        input_ids_list = []
        input_mask_list = []
        token_type_ids_list = []
        masked_lm_positions_list = []
        masked_lm_ids_list = []
        masked_lm_weights_list = []

        for i, text in tqdm(enumerate(texts), total=len(texts)):
            label = labels[i] if label_is_token_type and labels else None
            input_ids, input_mask, token_type_ids, masked_lm_positions, masked_lm_ids, masked_lm_weights = self.extract_feature(
                text, do_tokenize, max_seq_length, masked_lm_probs, max_predictions_per_seq, label_is_token_type, label)
            input_ids_list.append(input_ids)
            input_mask_list.append(input_mask)
            token_type_ids_list.append(token_type_ids)
            masked_lm_positions_list.append(masked_lm_positions)
            masked_lm_ids_list.append(masked_lm_ids)
            masked_lm_weights_list.append(masked_lm_weights)
        return np.array(input_ids_list), np.array(input_mask_list), np.array(token_type_ids_list), np.array(
            masked_lm_positions_list), np.array(masked_lm_ids_list), np.array(masked_lm_weights_list)

    def extract_feature(self, text, do_tokenize=True, max_seq_length=128, masked_lm_probs=0.15,
                        max_predictions_per_seq=10, label_is_token_type=False, label=None):
        if do_tokenize:
            tokens_a = self.tokenizer.tokenize(text)
        else:  # 文本已经提前tokenize过了，传入的text是空格隔开的token，所以用split
            tokens_a = text.split()

        if max_seq_length is not None and len(tokens_a) > max_seq_length - 2:
            tokens_a = tokens_a[0:(max_seq_length - 2)]

        tokens = ["[CLS]"]
        token_type_ids = [label] if label_is_token_type and label else [0]

        for token in tokens_a:
            tokens.append(token)
            token_type_ids.append(label) if token_type_ids and label else token_type_ids.append(0)
        tokens.append("[SEP]")
        token_type_ids.append(label) if token_type_ids and label else token_type_ids.append(0)

        init_ids = self.tokenizer.convert_tokens_to_ids(tokens)
        (output_tokens, masked_lm_positions, masked_lm_ids) = self.create_masked_lm_predictions(tokens, masked_lm_probs,
                                                                                                max_predictions_per_seq)
        input_ids = self.tokenizer.convert_tokens_to_ids(output_tokens)
        input_mask = [1] * len(init_ids)
        # Zero-pad up to the sequence length
        while len(input_ids) < max_seq_length:
            init_ids.append(0)
            input_ids.append(0)
            input_mask.append(0)
            token_type_ids.append(0)

        assert len(init_ids) == max_seq_length
        assert len(input_ids) == max_seq_length
        assert len(input_mask) == max_seq_length
        assert len(token_type_ids) == max_seq_length

        masked_lm_weights = [1.0] * len(masked_lm_ids)
        while len(masked_lm_positions) < max_predictions_per_seq:
            masked_lm_positions.append(0)
            masked_lm_ids.append(0)
            masked_lm_weights.append(0.0)

        return input_ids, input_mask, token_type_ids, masked_lm_positions, masked_lm_ids, masked_lm_weights

    def create_masked_lm_predictions(self, tokens, masked_lm_probs, max_predictions_per_seq):
        cand_index = []
        for (i, token) in enumerate(tokens):
            if token == '[CLS]' or token == '[SEP]':
                continue
            cand_index.append(i)

        np.random.shuffle(cand_index)

        output_tokens = list(tokens)
        num_to_predict = min(max_predictions_per_seq, max(1, int(round(len(tokens) * masked_lm_probs))))

        masked_lms = []
        covered_indexes = set()
        for index in cand_index:
            if len(masked_lms) >= num_to_predict:
                break
            if index in covered_indexes:
                continue
            covered_indexes.add(index)
            masked_token = '[MASK]'
            output_tokens[index] = masked_token
            masked_lms.append((index, tokens[index]))

        assert len(masked_lms) <= num_to_predict
        masked_lms = sorted(masked_lms, key=lambda x: x[0])

        masked_lm_positions = []
        masked_lm_ids = []
        for index, token in masked_lms:
            masked_lm_positions.append(index)
            masked_lm_ids.append(self.tokenizer.convert_tokens_to_ids([token])[0])
        return output_tokens, masked_lm_positions, masked_lm_ids
