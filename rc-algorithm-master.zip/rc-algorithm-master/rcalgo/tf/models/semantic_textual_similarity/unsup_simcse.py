import tensorflow as tf

from rcalgo.tf.models.finetune.google_bert import BertIdSequenceClassificationModel
from rcalgo.tf.module.encoder.bert_encoder import BertModel
from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.module.layer.basic import my_dropout
from rcalgo.tf.utils.tf_func import shape_list


class UnsupSimCSE(BertIdSequenceClassificationModel):
    """
    SimCSE: Simple Contrastive Learning of Sentence Embeddings
    https://arxiv.org/abs/2104.08821
    """
    def create_inputs(self):
        input_ids_str = tf.compat.v1.placeholder(
            dtype=tf.string, shape=[None], name="input_ids_str")
        return input_ids_str, None

    def call(self, inputs, **kwargs):
        # split and cast to int
        input_ids = tf.compat.v1.strings.split(inputs, sep=" ")
        input_ids = tf.sparse.to_dense(input_ids, default_value="0")
        input_ids = tf.compat.v1.string_to_number(input_ids, tf.int32)

        # padding sequence
        paddings = tf.constant([[0, 0], [0, self.max_seq_length]])
        input_ids = tf.pad(input_ids, paddings, "CONSTANT")[:, 0:self.max_seq_length]
        sequence_lengths = tf.count_nonzero(input_ids, 1)

        # create input_mask and token_type_ids
        input_mask = tf.sequence_mask(sequence_lengths, maxlen=self.max_seq_length)
        token_type_ids = tf.zeros_like(input_ids)

        # 每个句子重复2次, batch数据[a,b,c] -> [a,a',b,b',c,c']
        new_input_ids = tf.keras.backend.repeat_elements(input_ids, 2, axis=0)
        new_input_mask = tf.keras.backend.repeat_elements(input_mask, 2, axis=0)
        new_token_type_ids = tf.keras.backend.repeat_elements(token_type_ids, 2, axis=0)

        is_training = get_or_create_is_training()

        real_input_ids = tf.cond(is_training, lambda: new_input_ids, lambda: input_ids)
        real_input_mask = tf.cond(is_training, lambda: new_input_mask, lambda: input_mask)
        real_token_type_ids = tf.cond(is_training, lambda: new_token_type_ids, lambda: token_type_ids)

        bert_model = BertModel(
            config=self.bert_config,
            input_ids=real_input_ids,
            input_mask=real_input_mask,
            token_type_ids=real_token_type_ids,
            use_one_hot_embeddings=self.use_one_hot_embeddings,
            scope=self.scope)
        output_layer = bert_model.get_pooled_output()

        output_layer = my_dropout(output_layer, rate=self.bert_config.hidden_dropout_prob,
                                  training=is_training)
        return output_layer, output_layer

    def compute_loss(self, states, labels):
        return self.compute_simcse_loss(states)

    def compute_metrics(self, predictions, labels):
        return tf.keras.metrics.categorical_accuracy(self.y_true, self.similarities)

    def compute_simcse_loss(self, states):
        """
        ref: https://github.com/bojone/SimCSE/blob/bce7175e9d87f45e6123d77d2080667ffa2915b4/eval.py#L126
        :param states:
        :return:
        """
        y_pred = states
        batch_size = shape_list(y_pred)[0]
        # 构造one-hot标签
        idxs = tf.range(batch_size)
        idxs_1 = idxs[None, :] # 原数据下标:[[0,1,2,3,4,5]]
        idxs_2 = (idxs + 1 - idxs % 2 * 2)[:, None] # 正例数据下标:[[1], [0], [3], [2], [5], [4]], 即奇数位置对应的正例在其前面，偶数位置对应的正例在其后面
        y_true = tf.equal(idxs_1, idxs_2) # one-hot的idxs_2
        y_true = tf.cast(y_true, tf.float32)

        y_pred = tf.nn.l2_normalize(y_pred, axis=1)
        similarities = tf.matmul(y_pred, tf.transpose(y_pred)) # 余弦相似度
        similarities = similarities - tf.eye(batch_size) * 1e12 # 对角线是自身的余弦相似度，需要去掉
        similarities = similarities * 20 # 温度系数 0.05
        self.y_true = y_true
        self.similarities = similarities
        loss = tf.keras.metrics.categorical_crossentropy(self.y_true, self.similarities, from_logits=True) # 以batch_size为类别数的多分类问题
        loss = tf.reduce_mean(loss)
        return loss


