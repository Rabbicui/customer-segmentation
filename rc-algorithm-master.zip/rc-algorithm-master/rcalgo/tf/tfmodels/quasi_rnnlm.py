import sys
import os
# sys.path.insert(0,'..')
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))

from .bi_rnnlm import *
from rcalgo.tf.module.layer.rnn import MultiBiQRNNLayer, MultiQRNNLayer


class QRNNLMModel(RNNLMModel):
    def __init__(self, config, graph, word_dict=None):
        super(QRNNLMModel, self).__init__(
            config, graph, word_dict)
        self.zoneout = config.zoneout if hasattr(config, 'zoneout') else 0.0
        self.conv_legnth = config.conv_legnth if hasattr(
            config, 'conv_legnth') else 2
        self.pool_type = config.pool_type if hasattr(
            config, 'pool_type') else 'ifo'
        self.activation = tf.nn.tanh

    def build_input_sequence(self, gpu_id=0, reuse=None):
        self._build_embedding_layer(gpu_id)
        with get_new_variable_scope('qrnn') as rnn_scope:
            m_qrnn = MultiQRNNLayer(self.num_layers, self.hidden_size, self.conv_legnth, pool_type=self.pool_type,
                                    zoneout=self.zoneout, training=self.training, use_residual=self.use_residual)
            self.state_list[gpu_id], self.rnn_output_list[gpu_id] = m_qrnn(self.input_embedding[gpu_id],
                                                                           self.split_seqLengths[gpu_id])
            self.output_list[gpu_id] = self.rnn_output_list[gpu_id]


class BiQRNNLMModel(BiRNNLMModel):
    def __init__(self, config, graph, word_dict=None):
        super(BiRNNLMModel, self).__init__(
            config, graph, word_dict)
        self.zoneout = config.zoneout if hasattr(config, 'zoneout') else 0.0
        self.conv_legnth = config.conv_legnth if hasattr(
            config, 'conv_legnth') else 2
        self.pool_type = config.pool_type if hasattr(
            config, 'pool_type') else 'ifo'
        self.activation = tf.nn.tanh

    def build_input_sequence(self, gpu_id=0, reuse=None):
        self._build_embedding_layer(gpu_id)
        with get_new_variable_scope('qrnn') as rnn_scope:
            bi_m_qrnn = MultiBiQRNNLayer(self.num_layers, self.hidden_size, self.conv_legnth, pool_type=self.pool_type,
                                         zoneout=self.zoneout, training=self.training, use_residual=self.use_residual)
            self.state_list[gpu_id], self.rnn_output_list[gpu_id] = bi_m_qrnn(self.input_embedding[gpu_id],
                                                                              self.split_seqLengths[gpu_id])
            self.output_list[gpu_id] = tf.concat(self.rnn_output_list[gpu_id], 1)
