import numpy as np
import pandas as pd
import math
import h5py
from multiprocessing import Queue
import multiprocessing


class DataIterator(object):
    def __init__(self, datasets, index_list, batch_size, max_batch_index=None):  # data is a list of np array
        self.datasets = datasets
        self.index_list = index_list
        self.batch_size = batch_size
        self.batch_index = 0
        self.batch_num = math.ceil(len(self.index_list) * 1.0 / self.batch_size)
        self.processed = 0
        self.max_batch_index = max_batch_index if max_batch_index is not None else self.batch_num - 1

    def __iter__(self):
        return self

    def __len__(self):
        return self.batch_num

    def __next__(self):
        if self.batch_index > self.max_batch_index:
            raise StopIteration()
        else:
            begin = (self.batch_index % self.batch_num) * self.batch_size
            self.batch_index += 1
            batch = self.index_list[begin: begin + self.batch_size]  # ignore values >= len(index_list)
            self.processed += len(batch)
            sorted_batch = sorted(batch.tolist())
            # sort index in case datasets is h5py.Dataset
            return self.batch_index - 1, [
                data[sorted_batch] if isinstance(data, np.ndarray) or isinstance(data, pd.Series) or isinstance(data,
                                                                                                                list) else data
                for data in self.datasets]

    def reset(self):
        self.batch_index = 0

    def processed_rows(self):
        return self.processed


class H5Worker(object):
    # the worker is responsible for read data from disk
    def __init__(self, limit, h5_datasets, h5_queues, batch_size, max_batch_index, batch_num,
                 index_list):
        self.process = multiprocessing.Process(target=self.run, args=(limit, h5_datasets, h5_queues,
                                                                      batch_size, max_batch_index,
                                                                      batch_num, index_list))
        self.process.start()

    def run(self, limit, h5_datasets, h5_queues, batch_size, max_batch_index, batch_num,
            index_list):
        finish_cnt = 0
        batch_idx_list = {i: 0 for i, _ in h5_datasets.items()}
        while True:
            for i, dataset in h5_datasets.items():
                queue = h5_queues[i]
                while queue.qsize() < limit and batch_idx_list[i] <= max_batch_index:
                    begin = (batch_idx_list[i] % batch_num) * batch_size
                    batch_idx_list[i] = batch_idx_list[i] + 1
                    batch = index_list[begin: begin + batch_size]
                    sorted_batch = sorted(batch)
                    batch = dataset[sorted_batch]
                    queue.put(batch)
                if batch_idx_list[i] > max_batch_index:
                    finish_cnt += 1
            if finish_cnt == len(h5_datasets):
                break


class H5DataIterator(DataIterator):
    def __init__(self, datasets, index_list, batch_size, max_batch_index=None, limit=5, thread_cnt=1):
        super(H5DataIterator, self).__init__(datasets, index_list, batch_size, max_batch_index)
        self.h5_dataset_delegate = {}
        # figure out the h5 dataset
        self.h5_datasets = {idx: d for idx, d in enumerate(datasets) if isinstance(d, h5py._hl.dataset.Dataset)}
        if len(self.h5_datasets) > 0:
            # start a new thread to read data in advance
            # if the data queue is full the reading thread will sleep for given time
            from itertools import islice
            size = int(len(self.h5_datasets) / thread_cnt)

            def chunks(data, size):
                it = iter(data)
                dicts = []
                for i in range(0, len(data), size):
                    dicts.append({k: data[k] for k in islice(it, size)})
                return dicts

            self.h5_dataset_delegate = {i: Queue() for i, _ in self.h5_datasets.items()}
            h5_dataset_splits = chunks(self.h5_datasets, size)
            self.readers = []
            for h5_dataset in h5_dataset_splits:
                h5_reader = H5Worker(limit, h5_dataset, self.h5_dataset_delegate, self.batch_size,
                                     self.max_batch_index, self.batch_num, self.index_list)
                self.readers.append(h5_reader)

    def close(self):
        for reader in self.readers:
            reader.process.terminate()
            reader.process.join()

    def __next__(self):
        if self.batch_index > self.max_batch_index:
            raise StopIteration()
        else:
            begin = (self.batch_index % self.batch_num) * self.batch_size
            self.batch_index += 1
            batch = self.index_list[begin: begin + self.batch_size]
            self.processed += len(batch)
            sorted_batch = sorted(batch)
            return self.batch_index - 1, [data[sorted_batch] if i not in self.h5_dataset_delegate
                                          else self.h5_dataset_delegate[i].get()
                                          for i, data in enumerate(self.datasets)]
