import numpy as np
import tensorflow as tf
from rcalgo.tf.training.data.data import Data
from rcalgo.tf.training import training_utils
from rcalgo.tf.models.semi_supervised.semi_utils import kl_for_log_probs, compute_tsa_threshold
from rcalgo.tf.models.semi_supervised.base_semi_supervised import SemiSupervisor


class UDA(SemiSupervisor):
    """
    Unsupervised Data Augmentation for Consistency Training.
    https://arxiv.org/pdf/1904.12848.pdf
    """
    def __init__(self, config, execute_model, name="uda", **kwargs):
        # linear_schedule, exp_schedule, log_schedule, None
        self.tsa_schedule = config.get("tsa_schedule", None)
        self.batch_size = config.get("batch_size", 32)
        self.sup_batch_size = self.batch_size
        self.unsup_ratio = config.get("unsup_ratio", 1)
        self.unsup_batch_size = self.batch_size * self.unsup_ratio
        self.num_train_steps = config.get("num_train_steps", 0)
        self.num_classes = config.get("num_classes", 2)
        self.uda_softmax_temp = config.get("uda_softmax_temp", -1)
        self.uda_confidence_thresh = config.get("uda_confidence_thresh", -1)
        self.global_step = tf.train.get_or_create_global_step()
        self.input_concat = None
        super(UDA, self).__init__(execute_model, config=config, name=name, **kwargs)

    def create_inputs(self):
        text = tf.placeholder(dtype=tf.string, shape=[None], name='input_text')
        org_unsup = tf.placeholder(dtype=tf.string, shape=[None, None], name='org_unsup')
        aug_unsup = tf.placeholder(dtype=tf.string, shape=[None, None], name='aug_unsup')
        label = tf.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return [text, org_unsup, aug_unsup], label

    def export_freeze_graph(self, *args, **kwargs):
        input_nodes = [self.input_concat]
        return self.trainer.export_freeze_graph(*args, input_nodes=input_nodes, **kwargs)

    def build_forward(self, **kwargs):
        inputs, labels = self.create_inputs()
        text, org_unsup, aug_unsup = inputs
        org_unsup = tf.reshape(org_unsup, [self.unsup_batch_size])
        aug_unsup = tf.reshape(aug_unsup, [self.unsup_batch_size])
        self.input_concat = tf.concat([text, org_unsup, aug_unsup], axis=0)

        states, outputs = self.execute_model.call(self.input_concat, **kwargs)

        loss = self.compute_loss(states, labels)
        metrics = self.compute_metrics(outputs[:self.batch_size],
                                       labels[:self.batch_size])

        self.inputs = inputs
        self.outputs = outputs
        self.labels = labels
        self.loss = loss
        self.metrics = metrics

        training_utils.create_task_in_graph(
            inputs, outputs, labels, loss, metrics, None, name=self.name)

    def compute_sup_loss(self, states, labels):
        with tf.variable_scope("sup_loss"):
            log_probs = tf.nn.log_softmax(states)
            sup_log_probs = log_probs[:self.sup_batch_size]
            one_hot_labels = tf.one_hot(labels, depth=self.num_classes, dtype=tf.float32)
            tgt_label_prob = one_hot_labels
            per_example_loss = -tf.reduce_sum(tgt_label_prob * sup_log_probs, axis=-1)
            loss_mask = tf.ones_like(per_example_loss, dtype=per_example_loss.dtype)
            correct_label_probs = tf.reduce_sum(
                one_hot_labels * tf.exp(sup_log_probs), axis=-1)

            if self.tsa_schedule:
                print(f"use tsa schedule: {self.tsa_schedule}")
                tsa_start = 1. / self.num_classes
                tsa_threshold = compute_tsa_threshold(
                    self.tsa_schedule, self.global_step, self.num_train_steps,
                    tsa_start, end=1)
                self.tsa_threshold = tf.math.minimum(1.0, tsa_threshold)
                larger_than_threshold = tf.greater(
                    correct_label_probs, self.tsa_threshold)
                loss_mask = loss_mask * (1 - tf.cast(larger_than_threshold, tf.float32))

            loss_mask = tf.stop_gradient(loss_mask)
            per_example_loss = per_example_loss * loss_mask
            sup_loss = (tf.reduce_sum(per_example_loss) /
                        tf.maximum(tf.reduce_sum(loss_mask), 1))
        return sup_loss

    def compute_unsup_loss(self, states, labels):
        unsup_loss_mask = None
        if self.unsup_ratio > 0:
            with tf.variable_scope("unsup_loss"):
                log_probs = tf.nn.log_softmax(states)
                ori_start = self.sup_batch_size
                ori_end = ori_start + self.unsup_batch_size
                aug_start = self.sup_batch_size + self.unsup_batch_size
                aug_end = aug_start + self.unsup_batch_size

                ori_log_probs = log_probs[ori_start: ori_end]
                aug_log_probs = log_probs[aug_start: aug_end]
                unsup_loss_mask = 1
                if self.uda_softmax_temp != -1:
                    tgt_ori_log_probs = tf.nn.log_softmax(
                        states[ori_start: ori_end] / self.uda_softmax_temp,
                        axis=-1)
                    tgt_ori_log_probs = tf.stop_gradient(tgt_ori_log_probs)
                else:
                    tgt_ori_log_probs = tf.stop_gradient(ori_log_probs)

                if self.uda_confidence_thresh != -1:
                    largest_prob = tf.reduce_max(tf.exp(ori_log_probs), axis=-1)
                    unsup_loss_mask = tf.cast(tf.greater(
                        largest_prob, self.uda_confidence_thresh), tf.float32)
                    unsup_loss_mask = tf.stop_gradient(unsup_loss_mask)

                per_example_kl_loss = kl_for_log_probs(
                    tgt_ori_log_probs, aug_log_probs) * unsup_loss_mask
                unsup_loss = tf.reduce_mean(per_example_kl_loss)
        else:
            unsup_loss = 0.
        # 暂时不返回unsup_loss_mask
        return unsup_loss


class UDAData(Data):
    @property
    def sup_data_size(self):
        return int(len(self.datasets[0]))
    
    @property
    def unsup_data_size(self):
        return int(len(self.datasets[1]))
        
    def to_tf_dataset(self):
        self.build_schema()
        text, org_unsup, aug_unsup, label = self.data_schema
        if self.mode == "train":
            text_ds = tf.data.Dataset.from_tensor_slices(text)
            org_unsup_ds = tf.data.Dataset.from_tensor_slices(org_unsup)
            aug_unsup_ds = tf.data.Dataset.from_tensor_slices(aug_unsup)
            label_ds = tf.data.Dataset.from_tensor_slices(label)
            print(f"sup_data_size: {self.sup_data_size}, unsup_data_size: {self.unsup_data_size}")
            # since sup data and unsup data have different size,
            # they need to be repeat and shuffle seperately.
            total_ds = tf.data.Dataset.zip((text_ds.shuffle(self.sup_data_size, seed=0).repeat(), 
                                org_unsup_ds.shuffle(self.unsup_data_size, seed=1).repeat(), 
                                aug_unsup_ds.shuffle(self.unsup_data_size, seed=1).repeat(), 
                                label_ds.shuffle(self.sup_data_size, seed=0).repeat()))
            return total_ds.batch(self.batch_size).prefetch(tf.data.experimental.AUTOTUNE)
        else:
            return tf.data.Dataset.from_tensor_slices(self.data_schema).batch(self.batch_size)
