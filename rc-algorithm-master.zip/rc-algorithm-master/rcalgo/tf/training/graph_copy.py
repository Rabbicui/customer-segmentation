import sys
from copy import deepcopy
import threading

import tensorflow as tf
from tensorflow import IndexedSlices
from tensorflow.python.distribute import values
from tensorflow.python.distribute.values import PerReplica
from tensorflow.python.framework import tensor_util
from tensorflow.python.ops import gen_dataset_ops, gen_resource_variable_ops
from tensorflow.python.ops.variables import *
from tensorflow.python.ops.gen_array_ops import _op_def_lib as op_def_lib

from rcalgo.tf.utils.logging import logger
from rcalgo.tf.optimizer import optimizer_utils
from rcalgo.tf.utils.hparams import HParams
from rcalgo.tf.training.training_utils import get_from_task_collection, add_to_task_collection, clear_task_collection

sys.path.append(os.path.join(os.path.abspath(
    os.path.dirname(__file__)), "../"))

temp_session_map = dict()  # graph -> (lock, session)
graph_lock = threading.Lock()


def get_temp_session(graph):
    global temp_session_map
    if graph not in temp_session_map:
        config = tf.compat.v1.ConfigProto(allow_soft_placement=True, log_device_placement=False)
        config.gpu_options.allow_growth = True
        temp_session_map[graph] = (threading.Lock(), tf.Session(graph=graph, config=config))
    return temp_session_map[graph]


def get_all_var_value_map(all_vars, graph):
    config = tf.compat.v1.ConfigProto(allow_soft_placement=True, log_device_placement=False)
    config.gpu_options.allow_growth = True
    sess_lock, temp_session = get_temp_session(graph)
    # print(f"all_vars: {all_vars}")
    with graph_lock:
        with graph.as_default():
            all_var_inits = [var.initialized_value() for var in all_vars]
    # print(f"all vars init: {all_var_inits}")
    with sess_lock:
        all_vars_values = temp_session.run(all_var_inits)
    var_value_map = dict(zip(all_vars, all_vars_values))
    return var_value_map


def copy_variable_as_mirrored(org_instance, to_graph, strategy, value):
    """Given a `Variable` instance from one `Graph`, initializes and returns
    a copy of it from another `Graph`, under the specified scope
    (default `""`).

    Args:
      org_instance: A `Variable` from some `Graph`.
      to_graph: The `Graph` to copy the `Variable` to.
      scope: A scope for the new `Variable` (default `""`).
      value: Initial value of the variable.

    Returns:
      The copied `Variable` from `to_graph`.

    Raises:
      TypeError: If `org_instance` is not a `Variable`.
    """

    if not isinstance(org_instance, VariableV1):
        raise TypeError(str(org_instance) + ' is not a Variable')

    new_name = org_instance.name[:org_instance.name.index(':')]
    collections = []
    for name, collection in org_instance.graph._collections.items():
        if org_instance in collection:
            collections.append(name)

    # See if it's trainable.
    trainable = (
            org_instance in org_instance.graph.get_collection(
        ops.GraphKeys.TRAINABLE_VARIABLES))

    # Initialize the new variable
    with to_graph.as_default(), strategy.scope():
        new_var = VariableV1(
            value,
            trainable,
            name=new_name,
            collections=collections,
            shape=org_instance.shape,
            validate_shape=False)

    return new_var


def copy_input_to_graph(input_tensor, data_batch, to_graph, scope='', name_mapping={}):
    scope_seg = f'{scope}/' if scope != '' else ''
    new_op_name = f"{scope_seg}{input_tensor.op.name}_plwd"
    val_dtype = input_tensor.dtype
    val_shape = input_tensor.shape

    collections = []
    for name, collection in input_tensor.graph._collections.items():
        if input_tensor in collection:
            collections.append(name)

    op_def = op_def_lib._ops.get("PlaceholderWithDefault", None).op_def
    attr_map = dict()
    attr_map['dtype'] = attr_value_pb2.AttrValue(type=val_dtype.as_datatype_enum)
    attr_map['shape'] = attr_value_pb2.AttrValue(shape=val_shape.as_proto())
    node_def = ops._NodeDef("PlaceholderWithDefault", new_op_name, attrs=attr_map)
    new_op = ops.Operation(node_def, to_graph, [data_batch], [val_dtype], None, [val_dtype], None, op_def)
    to_graph._record_op_seen_by_control_dependencies(new_op)
    for device_function in to_graph._device_functions_outer_to_inner:
        new_op._set_device(device_function(new_op))

    new_tensor = new_op.outputs[0]
    for collection in collections:
        if new_tensor not in to_graph.get_collection(collection):
            to_graph.add_to_collection(collection, new_tensor)
    name_mapping[input_tensor.name] = new_tensor.name
    return new_tensor


def copy_op_to_graph(org_instance, from_graph, to_graph, variables, scope='', name_mapping={}, **kwargs):
    scope_seg = '/' + scope if scope != '' else ''
    # if is a variable related tensor
    for var in variables:
        org_var_name = var.name.split('{}:'.format(scope_seg))[0]
        var_related_tensors = [
            '{}:0'.format(org_var_name),
            '{}/initial_value:0'.format(org_var_name),
            '{}/Assign:0'.format(org_var_name)
        ]
        var_read_tensor = [
            '{}/read:0'.format(org_var_name)
        ]
        if org_instance.name in var_related_tensors:
            logger.info("warning: tensors shouldn't be reached")
            return None
        if org_instance.name in var_read_tensor:
            with ops.name_scope(kwargs.get('read_var_name_scope')):
                read_var_tensor = gen_resource_variable_ops.read_variable_op(var.handle, var.dtype)
            name_mapping[org_instance.name] = read_var_tensor.name
            return read_var_tensor

    # Take action based on the class of the instance
    if isinstance(org_instance, ops.Tensor):

        if org_instance.name in name_mapping:
            # If an instance of the same name exists, return appropriately
            try:
                already_present = to_graph.as_graph_element(name_mapping[org_instance.name],
                                                            allow_tensor=True,
                                                            allow_operation=True)
                return already_present
            except:
                pass

        # Get the collections that the new instance needs to be added to.
        # The new collections will also be a part of the given scope.
        collections = []
        for name, collection in org_instance.graph._collections.items():
            if org_instance in collection:
                collections.append(name)

        # If it's a Tensor, it is one of the outputs of the underlying
        # op. Therefore, copy the op itself and return the appropriate
        # output.
        op = org_instance.op
        new_op = copy_op_to_graph(op, from_graph, to_graph, variables, scope, name_mapping, **kwargs)
        output_index = op.outputs.index(org_instance)
        new_tensor = new_op.outputs[output_index]
        # Add to collections if any
        for collection in collections:
            if new_tensor not in to_graph.get_collection(collection):
                to_graph.add_to_collection(collection, new_tensor)
        name_mapping[org_instance.name] = new_tensor.name
        return new_tensor

    elif isinstance(org_instance, ops.Operation):
        # check name conflicts
        new_name = org_instance.name
        if org_instance.name in name_mapping:
            new_name_pre = name_mapping[org_instance.name]
            # If an instance of the same name exists, return appropriately
            try:
                already_present = to_graph.as_graph_element(new_name_pre, allow_tensor=True, allow_operation=True)
                return already_present
            except Exception as e:
                logger.info(f"{e}")
                logger.info(f"new_name_pre: {new_name_pre}")
                logger.fatal("Fatal error")
                pass
        else:
            new_name = to_graph.unique_name(org_instance.name)
            name_mapping[org_instance.name] = new_name

        op = org_instance

        # If it has an original_op parameter, copy it
        if op._original_op is not None:
            new_original_op = copy_op_to_graph(op._original_op, from_graph, to_graph, variables, scope, name_mapping,
                                               read_var_name_scope=op.name)
        else:
            new_original_op = None

        # If it has control inputs, call this function recursively on each.
        new_control_inputs = [
            copy_op_to_graph(x, from_graph, to_graph, variables, scope, name_mapping, read_var_name_scope=op.name)
            for x in op.control_inputs
        ]

        # If it has inputs, call this function recursively on each.
        new_inputs = [
            copy_op_to_graph(x, from_graph, to_graph, variables, scope, name_mapping, read_var_name_scope=op.name) for x
            in
            op.inputs
        ]

        # Make a new node_def based on that of the original.
        # An instance of tensorflow.core.framework.node_def_pb2.NodeDef, it
        # stores String-based info such as name, device and type of the op.
        # Unique to every Operation instance.
        new_node_def = deepcopy(op.node_def)
        # Change the name
        new_node_def.name = new_name

        # handle colocate operations
        if '_class' in new_node_def.attr:
            org_colocate_ops = new_node_def.attr['_class'].list.s
            new_colocate_ops = []
            for val in org_colocate_ops:
                org_colocate_op_name = compat.as_str(val).split('@')[1]
                org_colocate_op = from_graph.get_operation_by_name(org_colocate_op_name)
                new_colocate_op = copy_op_to_graph(org_colocate_op, from_graph, to_graph, variables, scope,
                                                   name_mapping,
                                                   read_var_name_scope=org_colocate_op.name)
                new_colocate_ops.append(new_colocate_op)
            new_s = [compat.as_bytes("loc:@{}".format(op.name)) for op in new_colocate_ops]
            new_node_def.attr['_class'].list.CopyFrom(attr_value_pb2.AttrValue.ListValue(s=new_s))

        # Copy the other inputs needed for initialization
        output_types = op._output_types[:]
        input_types = op._input_types[:]

        # Make a copy of the op_def too.
        # Its unique to every _type_ of Operation.
        op_def = deepcopy(op.op_def)

        # Initialize a new Operation instance
        new_op = ops.Operation(new_node_def, to_graph, new_inputs, output_types,
                               new_control_inputs, input_types, new_original_op,
                               op_def)
        # Use Graph's hidden methods to add the op
        to_graph._record_op_seen_by_control_dependencies(new_op)
        # pylint: disable=protected-access
        for device_function in to_graph._device_functions_outer_to_inner:
            new_op._set_device(device_function(new_op))
        # pylint: enable=protected-access

        return new_op

    else:
        raise TypeError('Could not copy instance: ' + str(org_instance))


def get_replica_id():
    replica_id = tf.distribute.get_replica_context().replica_id_in_sync_group
    if isinstance(replica_id, ops.Tensor):
        replica_id = tensor_util.constant_value(replica_id)
    return replica_id


def get_global_step_var(copied_variables):
    for var in copied_variables:
        if 'global_step' in var.name:
            return var
    return None


# TODO: 让它更优雅
def _get_opt_params(from_graph, task):
    opt_params = get_from_task_collection(task, tf.compat.v1.GraphKeys.OPT_PARAMS, from_graph)
    config = tf.ConfigProto()
    config.gpu_options.allow_growth = True
    sess_lock, tmp_session = get_temp_session(graph=from_graph)
    with sess_lock:
        opt_str, loss_scaling, loss_scale_factor, \
        adam_epsilon, adam_beta1, adam_beta2, adam_wd, clip_gradient, clip_type = tmp_session.run(opt_params)
    return HParams({
        'optimizer': opt_str.decode('utf-8'),
        'loss_scaling': loss_scaling,
        'loss_scale_factor': loss_scale_factor,
        'adam_epsilon': adam_epsilon,
        'adam_beta1': adam_beta1,
        'adam_beta2': adam_beta2,
        'adam_wd': adam_wd,
        'clip_gradient': clip_gradient,
        'clip_type': clip_type.decode('utf-8')
    })


def _varname_hit_backlist(var):
    """
    check if var is associated with optimizer
    :param var:
    :return:
    """
    variable_name_blacklist = ['Adam_', 'GradientDescent_', 'AdamW_', 'RMSProp_', 'beta2_power', 'beta1_power']
    for seg in variable_name_blacklist:
        if seg in var.name:
            return True
    return False


def _build_per_replica_graph(from_graph, new_graph, copied_variables, data_batches, kwargs):
    replica_id = get_replica_id()
    scope = 'replica_{}'.format(replica_id) if replica_id != 0 else ''
    excluded_task_set = kwargs.get("excluded_task_set", [])
    name_mapping = dict()

    # copy optimizer
    opt = dict()
    tasks = get_from_task_collection(None, tf.compat.v1.GraphKeys.TASKS, from_graph)
    tasks = [task for task in tasks if task not in excluded_task_set]
    train_ops = []
    losses = []
    metrics = []

    for idx, task in enumerate(tasks):
        task_trainable_variables = get_from_task_collection(task, tf.compat.v1.GraphKeys.TVARS, new_graph)
        if task not in new_graph.get_collection(tf.compat.v1.GraphKeys.TASKS):
            new_graph.add_to_collection(tf.compat.v1.GraphKeys.TASKS, task)
        # construct inputs and targets
        if isinstance(task, bytes):
            task = task.decode("utf-8")
        org_inputs = get_from_task_collection(task, tf.compat.v1.GraphKeys.INPUTS, from_graph)
        org_targets = get_from_task_collection(task, tf.compat.v1.GraphKeys.TARGETS, from_graph)
        [
            copy_input_to_graph(org_input,
                                data,
                                new_graph,
                                scope,
                                name_mapping)
            for org_input, data in zip([*org_inputs, *org_targets], data_batches[idx])
        ]

        # copy loss
        loss = copy_op_to_graph(get_from_task_collection(task, tf.compat.v1.GraphKeys.LOSS, from_graph)[0],
                                from_graph,
                                new_graph,
                                copied_variables,
                                scope,
                                name_mapping)
        losses.append(loss)

        # copy accuracy
        metric = copy_op_to_graph(get_from_task_collection(task, tf.compat.v1.GraphKeys.METRICS, from_graph)[0],
                                  from_graph,
                                  new_graph,
                                  copied_variables,
                                  scope,
                                  name_mapping)
        metrics.append(metric)

        # table initializer
        [
            add_to_task_collection(None,
                                   tf.compat.v1.GraphKeys.TABLE_INITIALIZERS,
                                   copy_op_to_graph(initializer,
                                                    from_graph,
                                                    new_graph,
                                                    copied_variables,
                                                    scope,
                                                    name_mapping),
                                   new_graph)
            for initializer in get_from_task_collection(None, tf.compat.v1.GraphKeys.TABLE_INITIALIZERS, from_graph)
        ]

        # learning rate
        org_lr_vars = get_from_task_collection(task, tf.compat.v1.GraphKeys.LR_VARIABLES, from_graph)
        lr_vars = [copy_op_to_graph(lr_var, from_graph, new_graph, copied_variables, scope, name_mapping)
                   for lr_var in org_lr_vars]

        opt_params = _get_opt_params(from_graph, task)

        opt[task] = optimizer_utils.build_optimizer(task, lr_vars[0], opt_params)
        optimizer = optimizer_utils.GraphCopyOptimizerWrapper(
            opt[task], clip_type=opt_params.clip_type,
            max_clip_grad=opt_params.clip_gradient)
        train_op = optimizer.minimize(loss, task_trainable_variables,
                                      global_step=get_global_step_var(copied_variables))

        add_to_task_collection(task, tf.compat.v1.GraphKeys.TRAIN_OPS, train_op, new_graph)
        train_ops.append(train_op)

        # copy prediction

    # return train_ops
    return train_ops, losses, metrics


def build_train_graph(from_graph, strategy, **kwargs):
    """
    :param from_graph:
    :param strategy:
    :param kwargs:
        支持的参数：
        1. fix_lm_layer
        2. pretrained_model_scope
        3. excluded_task_set
    :return:
    """
    new_graph = tf.Graph()
    if 'excluded_task_set' not in kwargs:
        kwargs['excluded_task_set'] = ['pretrained_model/default']
    if 'pretrained_model_scope' not in kwargs:
        kwargs['pretrained_model_scope'] = 'pretrained_model'
    excluded_task_set = kwargs.get('excluded_task_set', [])
    logger.info(f"build_train_graph kwargs: {kwargs}")

    logger.info("build_train_graph: reconstructing variables...")
    # reconstruct variables
    all_vars = []
    all_org_vars = get_from_task_collection(None, tf.compat.v1.GraphKeys.GLOBAL_VARIABLES, from_graph)
    var_value_map = get_all_var_value_map(all_org_vars, from_graph)

    for var in all_org_vars:
        if not _varname_hit_backlist(var):
            all_vars.append(copy_variable_as_mirrored(var, new_graph, strategy, var_value_map[var]))

    with new_graph.as_default(), strategy.scope():
        inputs = []
        data_batches = [[] for _ in range(strategy.extended._device_map.num_replicas_in_graph)]
        tasks = get_from_task_collection(None, tf.compat.v1.GraphKeys.TASKS, from_graph)
        tasks = [task.decode("utf-8") if isinstance(task, bytes) else task for task in tasks]
        filtered_tasks = []
        for task in tasks:
            if task in excluded_task_set:
                logger.info("build_train_graph ({}): skip excluded tasks...".format(task))
            else:
                filtered_tasks.append(task)
        for task in filtered_tasks:
            logger.info("build_train_graph ({}): building inputs...".format(task))
            with tf.device("cpu:0"):
                logger.info(f"task: {task}, {type(task)}")
                input_iter_handle = tf.compat.v1.placeholder(shape=None, dtype=tf.string,
                                                             name='{}_input_iter'.format(task))
                incarnation_id = tf.compat.v1.placeholder(shape=None, dtype=tf.int64,
                                                          name='{}_input_iter_incarnation_id'.format(task))
                add_to_task_collection(task, tf.compat.v1.GraphKeys.INPUT_ITER, input_iter_handle, new_graph)
                add_to_task_collection(task, tf.compat.v1.GraphKeys.INPUT_ITER_INCARNATION_ID, incarnation_id,
                                       new_graph)
                multi_device_iterator = gen_dataset_ops.multi_device_iterator_from_string_handle(input_iter_handle)
                # construct inputs and targets
                org_inputs = get_from_task_collection(task, tf.compat.v1.GraphKeys.INPUTS, from_graph)
                org_targets = get_from_task_collection(task, tf.compat.v1.GraphKeys.TARGETS, from_graph)
                training_data_dtypes = (
                    *(input.dtype for input in org_inputs), *(target.dtype for target in org_targets))
                training_data_shapes = (
                    *(input.shape for input in org_inputs), *(target.shape for target in org_targets))
                [data_batches[i].append(
                    gen_dataset_ops.multi_device_iterator_get_next_from_shard(
                        multi_device_iterator,
                        i,
                        incarnation_id,
                        training_data_dtypes,
                        training_data_shapes,
                        "data_batch"))
                    for i in range(strategy.extended._device_map.num_replicas_in_graph)]
            per_replica_data_batch = values.regroup(strategy.extended._device_map, data_batches)
            inputs.append((multi_device_iterator, incarnation_id))

        logger.info("build_train_graph ({}): building per replica graph...".format(task))
        train_ops, losses, metrics = strategy.extended.call_for_each_replica(_build_per_replica_graph,
                                                                             args=[from_graph,
                                                                                   new_graph,
                                                                                   all_vars,
                                                                                   per_replica_data_batch,
                                                                                   kwargs])

        logger.info(f"train_ops: {train_ops}, losses: {losses}, metrics: {metrics}")

        for idx, task in enumerate(filtered_tasks):
            mean_loss = strategy.reduce(tf.distribute.ReduceOp.MEAN, losses[idx], axis=None)
            mean_metrics = strategy.reduce(tf.distribute.ReduceOp.MEAN, metrics[idx], axis=None)

            if strategy.extended._device_map.num_replicas_in_graph > 1:
                if isinstance(train_ops[idx], PerReplica):
                    train_op = strategy.group(train_ops[idx].values)
                else:
                    train_op = train_ops[idx]
            else:
                train_op = strategy.group(train_ops[idx])
            clear_task_collection(task, tf.compat.v1.GraphKeys.LOSS)
            add_to_task_collection(task, tf.compat.v1.GraphKeys.LOSS, mean_loss)
            clear_task_collection(task, tf.compat.v1.GraphKeys.METRICS)
            add_to_task_collection(task, tf.compat.v1.GraphKeys.METRICS, mean_metrics)
            clear_task_collection(task, tf.compat.v1.GraphKeys.TRAIN_OPS)
            add_to_task_collection(task, tf.compat.v1.GraphKeys.TRAIN_OPS, train_op)

    return new_graph
