import os

import numpy as np
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.optim
import torch.utils.data
import torch.utils.data.distributed
import torchvision.models as models
import torchvision.transforms as transforms
from tqdm import tqdm

import rcalgo.torch.image.classification.aug_utils as aug_utils
import rcalgo.torch.image.classification.backbone as bit_models
import rcalgo.torch.image.classification.semi_classifier.semi_utils as semi_helper
from rcalgo.torch.image.classification.semi_classifier.semi_data import UnlabeledCustomData
from rcalgo.torch.image.classification.semi_classifier.semi_utils import DataKeyRegistry as DK


class PseudoLabelsExporter(object):
    def __init__(self,
                 params: dict,
                 unlabeled_data: dict,
                 logger=None,
                 instance_name='PseudoLabelsExporter'):
        self.instance_name = instance_name
        config = semi_helper.insert_parameters_into_config(semi_helper.PseudoLabelConfig(), params)
        self.ob_config = config

        self.logger = logger
        self.logger.info(f'Runner: {self.instance_name}, Parameters: {config.__dict__}')

        self.check_data_integrality(unlabeled_data)
        self.unlabeled_data = unlabeled_data

        self.unlabeled_dataset, self.unlabeled_loader = self.build_data()
        self.backbone_model = self.create_model()
        self.init_model()
        self.backbone_model.cuda()

    def create_model(self):
        config = self.ob_config
        if config.arch.lower().startswith('bit'):
            self.logger.info(f'=> Creating BiT model {config.arch}, using BiT origin checkpoint.')
            model = bit_models.KNOWN_MODELS[config.arch](head_size=config.num_classes, zero_head=True)
            model.load_from(np.load(f"{config.arch}.npz"))
        else:
            self.logger.info(f"=> Creating model '{config.arch}', "
                             f"Using torchvision pretrained '{config.use_torchvision}'")
            model = models.__dict__[config.arch](pretrained=config.use_torchvision)
            if config.arch.lower().startswith('resnet'):
                dim_mlp = model.fc.weight.shape[1]
                model.fc = nn.Linear(dim_mlp, config.num_classes)
                model.fc.weight.data.normal_(mean=0.0, std=0.01)
                model.fc.bias.data.zero_()
            elif config.arch.lower().startswith('mobilenet'):
                dim_mlp = model.classifier[1].weight.shape[1]
                model.classifier[1] = nn.Linear(dim_mlp, config.num_classes)
                model.classifier[1].weight.data.normal_(mean=0.0, std=0.01)
                model.classifier[1].bias.data.zero_()
            else:
                raise ValueError(f'Wrong architecture {config.arch}')
        return model

    def init_model(self):
        config, model = self.ob_config, self.backbone_model
        assert config.resume and os.path.isfile(config.resume), f"=> no checkpoint found at '{config.resume}'"
        self.logger.info(f"=> [Resuming]: Loading checkpoint '{config.resume}'")

        if config.arch.lower().startswith('bit'):
            checkpoint = torch.load(config.resume, map_location="cpu")
            state_dict = checkpoint["model"]

            new_state_dict = dict()
            for k in list(state_dict.keys()):
                if k.startswith('module.'):
                    new_state_dict.__setitem__(k[len('module.'):], state_dict[k])

            msg = model.load_state_dict(new_state_dict, strict=False)
            self.logger.info(f'Missing keys: {msg.missing_keys}')
            assert len(set(msg.missing_keys)) == 0
            self.logger.info(f"=> [Resumed]: Loaded checkpoint '{config.resume}' (step {checkpoint['step']})")
        else:
            checkpoint = torch.load(config.resume)
            model.load_state_dict(checkpoint['state_dict'])
            self.logger.info(f"=> [Resumed]: Loaded checkpoint '{config.resume}' (epoch {checkpoint['epoch']})")

        self.ob_config, self.backbone_model = config, model
        self.backbone_model.eval()
        self.backbone_model.cuda()

    def build_data(self):
        config = self.ob_config

        _, val_aug, _ = aug_utils.get_standard_augmentations(mode=self.ob_config.aug_mode)
        unlabeled_dataset = UnlabeledCustomData(images=self.unlabeled_data[DK.image],
                                                transforms=transforms.Compose(val_aug))
        unlabeled_loader = torch.utils.data.DataLoader(unlabeled_dataset, batch_size=config.batch_size, shuffle=False,
                                                       num_workers=config.workers, pin_memory=True)
        return unlabeled_dataset, unlabeled_loader

    def run(self):
        config, model = self.ob_config, self.backbone_model
        model.eval()

        img_names, pred_labels = [], []
        with torch.no_grad():
            for (images, batch_img_names) in tqdm(self.unlabeled_loader):
                images = images.cuda()

                output = model(images)
                batch_labels = output.argmax(dim=1).cpu().numpy().tolist()

                img_names.extend(batch_img_names)
                pred_labels.extend(batch_labels)

        assert len(img_names) == len(pred_labels)
        return img_names, pred_labels

    def check_data_integrality(self, unlabeled_data):
        assert isinstance(unlabeled_data, dict)
        assert DK.image in unlabeled_data
        assert len(unlabeled_data[DK.image]) != 0
