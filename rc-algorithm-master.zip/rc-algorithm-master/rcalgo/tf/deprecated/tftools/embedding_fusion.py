import sys
import os
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../"))

import tensorflow as tf
from tftools.tf_block import transformer_block
from tftools.tf_func import shape_list
from tftools.tf_func import get_new_variable_scope
from tftools.tf_attention import self_position_attention
from tftools.tf_attention import pairwise_attention
from tftools.tf_attention import _build_attention_output
from tftools.tf_layer import my_full_connected
from tftools.tf_layer import relu_fc_layer
from tftools.tf_layer import my_dropout


def bilinear_fusion(t1, t2):
    """
    Bilinear fusion(outer product) see "Bilinear CNN Models for Fine-grained Visual Recognition"
    t1 shape of (batch_size , M)
    t2 shape of (batch_size , N)
    notes: huge feature space not recommended

    """
    batch = shape_list(t1)[0]
    dim1 = shape_list(t1)[-1]
    t1 = tf.reshape(t1, (-1, dim1, 1))
    dim2 = shape_list(t2)[-1]
    t2 = tf.reshape(t2, (-1, 1, dim2))
    # t shape of (batch, dim1, dim2)
    t = tf.matmul(t1, t2)
    # flatten
    t = tf.reshape(t, (batch, -1))
    # sqrt - l2 norm
    t = tf.multiply(tf.sign(t), tf.sqrt(tf.abs(t)+1e-12))
    return tf.nn.l2_normalize(t, dim=1)


def compact_bilinear_fusion(t1, t2, output_dim):
    """
    approximate bilinear fusion by using kernel method
    see "Compact Bilinear Pooling"
         and "Multimodal Compact Bilinear Pooling for Visual Question
    Answering and Visual Grounding."

    """
    dim1 = shape_list(t1)[-1]
    dim2 = shape_list(t2)[-1]

    h1 = tf.random.uniform(shape=(dim1,), minval=0, maxval=output_dim, dtype=tf.int64)
    h2 = tf.random.uniform(shape=(dim2,), minval=0, maxval=output_dim, dtype=tf.int64)
    s1 = 2 * tf.floor(tf.random.uniform(shape=(dim1,), minval=0, maxval=2)) - 1
    s2 = 2 * tf.floor(tf.random.uniform(shape=(dim2,), minval=0, maxval=2)) - 1

    # use trick here: create a sparse tensor here to do the partial add
    def _sketch_matrix(h, s, input_dim):
        # a sparse matrix of shape [input_dim, output_dim] for tensor sketch.
        indices = tf.cast(tf.reshape(tf.range(input_dim), [input_dim, 1]), dtype=tf.int64)
        indices = tf.concat([indices, tf.reshape(h, [input_dim, 1])], axis=1)
        sparse_sketch_matrix = tf.sparse_reorder(tf.SparseTensor(indices, s, [input_dim, output_dim]))
        return sparse_sketch_matrix

    sketch1 = _sketch_matrix(h1, s1, dim1)
    sketch2 = _sketch_matrix(h2, s2, dim2)

    sketch1 = tf.transpose(tf.sparse_tensor_dense_matmul(sketch1,
                                                         t1, adjoint_a=True,
                                                         adjoint_b=True))
    sketch2 = tf.transpose(tf.sparse_tensor_dense_matmul(sketch2,
                                                         t2, adjoint_a=True,
                                                         adjoint_b=True))
    pc1 = tf.complex(sketch1, tf.zeros_like(sketch1))
    pc2 = tf.complex(sketch2, tf.zeros_like(sketch2))
    conved = tf.fft(tf.fft(pc1) * tf.fft(pc2))
    conved = tf.real(conved)
    conved.set_shape([-1, output_dim])
    return conved


def lower_rank_fusion(rank, model_inputs, output_dim):
    """
       Lower rank Multi-modal fusion
       https://arxiv.org/pdf/1806.00064.pdf

       Args:
           rank:         the rank described in paper
           model_inputs: the input tensor for each sub-model
           output_dim:   the dimension of output
       Returns:
           A tensor with dim [batch, output_dim]
    """
    # we assume each input has same feature shape
    batch_size = shape_list(model_inputs[0])[0]
    # concat ones to keep each original feature info
    model_inputs = [tf.concat([i, tf.ones(shape=[batch_size, 1])], axis=-1) for i in
                    model_inputs]
    input_dim = model_inputs[0].get_shape()[-1].value
    vscope = get_new_variable_scope('lmf_fusion', None)
    fusions = []
    with vscope as score:
        for idx, model_input in enumerate(model_inputs):
            # broadcast
            model_input = tf.tile(model_input, [rank, 1])
            model_input = tf.reshape(model_input, [rank, batch_size, input_dim])
            weight = tf.get_variable('W' + str(idx), [rank, input_dim, output_dim],
                                     initializer=tf.truncated_normal_initializer(stddev=0.0001))
            # no bias here
            with tf.name_scope('fusion_factor'):
                fusion = tf.matmul(model_input, weight)
                fusions.append(fusion)
    # inner product fusions
    fusion_final = fusions[0]
    for i in range(1, len(fusions)):
        fusion_final = fusion_final * fusions[i]
    # fc layer the fusion_final  as shape of (rank, batch, output_dim) tranpose the view to (batch, rank, output_dim)
    fusion_final = tf.transpose(fusion_final, perm=(1, 0, 2))
    vscope = get_new_variable_scope('fusion_merge', None)
    with vscope as score:
        weight = tf.get_variable('W', [1, rank],
                                 initializer=tf.truncated_normal_initializer(stddev=0.0001))
        biases = tf.get_variable("B", [output_dim], initializer=tf.zeros_initializer())
        weight = tf.tile(weight, [batch_size, 1])
        weight = tf.reshape(weight, [batch_size, 1, rank])
        fusion_final = tf.matmul(weight, fusion_final)
        fusion_final = tf.reshape(fusion_final, [-1, output_dim]) + biases
    return fusion_final


def factorized_high_order_fusion(model_inputs, config):
    """
    Generalized Multimodal Factorized High-order Pooling
    https://arxiv.org/pdf/1708.03619.pdf#page=12&zoom=100,65,889
    Args:
        model_inputs: a list of input tensors
        config:
            output_dim:   output dim size
            k:            the k parameter in paper used for sum pooling when k=1 same as lmf
            order:            the order default == 2, if p > 2 the high order is implemented in cascading manner
            dropout, training, init_std
    Returns:   A tensor of (batch, output_dim)
    """
    output_dim = config.get("output_dim", None)
    k = config.get('k', 1)
    order = config.get('order', 2)
    dropout = config.get('dropout_rate', 0.5)
    training = config.get('training', None)
    init_std = config.get('init_std', 0.00001)
    proj_dim = output_dim * k

    exp_in = 1
    outputs = []
    for o in range(order):
        exp_out = None
        for i, input in enumerate(model_inputs):
            # the act won't be used here
            layer = my_full_connected(input, proj_dim, init_std=init_std,
                                      layer_name='mfp_order' + str(o) + '_input' +str(i),
                                      reuse=False, act=tf.identity,
                                      weights_initializer=tf.variance_scaling_initializer(scale=2.0,
                                                                                  mode='fan_in',
                                                                                  distribution='normal'))
            exp_out = layer if exp_out is None else exp_out * layer
        # add dropout here
        exp_out = my_dropout(exp_out, rate=dropout, training=training)
        # cascading to do high-order pooling
        # the implement and paper here are not same (dropout before * or after?)
        exp_out = exp_out * exp_in
        exp_in = exp_out

        # reshape exp_out to (batch, 1, proj_dim)
        exp_out = tf.reshape(exp_out, [-1, 1, proj_dim])
        # sum pooling --> avg pooling 1d with window size of k then * k
        z = tf.nn.avg_pool1d(exp_out, ksize=[1, 1, k], strides=[1, 1, k], padding='VALID')
        z = z * k
        # exp_out of shape (batch, 1, output_dim)
        z = tf.reshape(z, [-1, output_dim])
        # power norm + l2 norm
        # z = tf.nn.relu(z)
        # z = tf.multiply(tf.sign(z), tf.sqrt(tf.abs(z) + 1e-12))
        # z = tf.nn.l2_normalize(z, dim=1)

        # the exp shows this impl is better than the upper one
        z = tf.sqrt(tf.nn.relu(z)) - tf.sqrt(tf.nn.relu(-z))
        z = tf.nn.l2_normalize(z, dim=1)
        outputs.append(z)
    return tf.concat(outputs, axis=1)


def pre_fc(group, inputs, config, training=None, init_std=0.00001):
    if config.get('pre_fc_layer', False):
        pre_layers = []
        hidden_size = config['pre_fc_hidden_size']
        dropout = config['pre_fc_dropout_ratio']
        for i, input in enumerate(inputs):
            # same fc for each elem
            reuse = False if i == 0 else True
            layer = relu_fc_layer(input, hidden_size, layer_name=group + '_pre_fusion',
                                  reuse=reuse, init_std=init_std)
            layer = my_dropout(layer, rate=dropout, training=training)
            pre_layers.append(layer)
        return pre_layers
    return inputs


def pre_fusion(inputs, other_inputs, config):
    """
    Pre-fusion stage: merge embeddings from same group (source).
    Many to one by (attention pooling + max pooling + avg pooling)
    Args:
        inputs:         a list of embeddings, each shape (batch, embedding size)
        other_inputs:   a list of other embeddings from different source used to compute pairwise attention.
        config:         a dict for pre fusion configs
    Returns:
        A list of  merged embeddings of shape (batch, embedding size)
    """
    stacked_layers = tf.stack(inputs, axis=1)
    # apply max pooling and avg pooling fusion
    max_layer = None
    avg_layer = None
    if config.get('max_pooling', False):
        # max pooling over time
        max_layer = tf.reduce_max(stacked_layers, axis=1)
    if config.get('avg_pooling', False):
        # avg pooling over time
        avg_layer = tf.reduce_mean(stacked_layers, axis=1)

    # apply attention pooling
    cnt = len(inputs)
    unary_weight = None
    if config.get('unary_attention', False):
        unary_weight = self_position_attention(stacked_layers, shape_list(stacked_layers)[-1],
                                               softmax=False, attention_only=True)
    if config.get('pairwise_attention', False) and other_inputs is not None and len(other_inputs) > 0:
        # do pairwise attention
        pw_weights = []
        for g_input in other_inputs:
            if len(shape_list((g_input[0]))) < 3:
                # if the elements has shape of two (batch, emb) reshape to (batch, 1, emb)
                g_input = [tf.reshape(inp, (-1, 1, shape_list(inp)[-1])) for inp in g_input]
            # merge list of inputs to batch, g_input_cnt, emb)
            g_input = tf.concat(g_input, axis=1)
            # pairwise weight
            pw_weight = pairwise_attention(stacked_layers, g_input)[0]
            pw_weights.append(pw_weight)
        # merge weight shape (batch, input_cnt, weight_cnt)
        # 这里pairwise 的weight 和 unary的weight稍微有不一样，pw是直接tanh的结果， unary是tanh后+fc，得改下pw
        weights = [unary_weight] + pw_weights if unary_weight is not None else pw_weights
        weights = [tf.reshape(weight, (-1, cnt, 1)) for weight in weights]
        weights = tf.concat(weights, axis=-1)
        # multi weight ----> the final weight
        merged_weight = my_full_connected(tf.reshape(weights, (-1, shape_list(weights)[-1])), 1, act=tf.identity)
        merged_weight = tf.reshape(merged_weight, (-1, cnt))
    else:
        merged_weight = unary_weight
    attention_layer = None
    final_weight = merged_weight
    if merged_weight is not None:
        # apply weight to each input
        final_weight = tf.nn.softmax(merged_weight)
        attention_layer = _build_attention_output(final_weight, stacked_layers)
    return [max_layer, avg_layer, attention_layer], final_weight


def subnet_fusion(subnet_inputs, config, training=None, init_std=0.00001):
    """
        Merge embeddings from different subnet aka different source embedding
        1. block attention:   split the concat inputs into blocks, use the transformer arch to do do
                                fusion, self position attention is added so the final output would be
                                (batch_size, block_size)
        2. self_attention:    compute the weight for each subnet input and do weighted sum up.
                               # TODO this assumes that the subnet inputs are from the same embedding space
                               # TODO so it would be better to transform them into same embedding space in advance
        3. lower rank fusion   see function comments
        4. concat, add, fusion...
    Args:
        subnet_inputs: a list of subnet input
        config:        config for fusion
        training:      whether in training stage
        init_std:      init_std for fc layer

    Returns:   a tensor of shape (batch, embedding_size)
    """
    # fusion of inputs from different modal (source)
    concat_input = tf.concat(subnet_inputs, axis=-1)
    stack_input = tf.stack(subnet_inputs, axis=1)
    outputs = []
    if config.get('block_attention', True):
        l_block = block_attention_fusion(concat_input, config, training, init_std)
        outputs.append(l_block)
    if config.get('self_attention', False):
        l_self, _ = self_position_attention(stack_input, shape_list(stack_input)[-1])
        # if block_attention is used, we add fc layer to keep dims same
        if len(outputs) > 0:
            target_dim = shape_list(outputs[0])[-1]
        else:
            target_dim = shape_list(l_self)[-1]
        l_self = relu_fc_layer(l_self, target_dim, init_std=init_std)
        outputs.append(l_self)
    if config.get('lmf_fusion', False):
        rank = config['lmf_fusion_rank']
        target_dim = shape_list(outputs[0])[-1] if len(outputs) > 0 else shape_list(stack_input)[-1]
        l_lmf = lower_rank_fusion(rank, subnet_inputs, target_dim)
        outputs.append(l_lmf)
    if config.get('concat_fusion', False):
        l_concat = relu_fc_layer(concat_input, shape_list(concat_input)[-1] / 4, init_std=init_std)
        dropout = config['concat_fusion_dropout']
        l_concat = my_dropout(l_concat, rate=dropout, training=training)
        target_dim = shape_list(outputs[0])[-1] if len(outputs) > 0 else shape_list(l_concat)[-1]
        l_concat = relu_fc_layer(l_concat, target_dim, init_std=init_std)
        outputs.append(l_concat)
    if config.get('add_fusion', False):
        l_add = tf.reduce_sum(subnet_inputs, axis=1)
        target_dim = shape_list(outputs[0])[-1] if len(outputs) > 0 else shape_list(l_add)[-1]
        l_add = relu_fc_layer(l_add, target_dim, init_std=init_std)
        outputs.append(l_add)
    if config.get('mfp', False):
        config['output_dim'] = shape_list(subnet_inputs[0])[-1]
        l_mfp = factorized_high_order_fusion(subnet_inputs, config)
        target_dim = shape_list(outputs[0])[-1] if len(outputs) > 0 else shape_list(l_mfp)[-1]
        l_mfp = relu_fc_layer(l_mfp, target_dim, init_std=init_std)
        outputs.append(l_mfp)
    if len(outputs) > 1:
        return tf.concat(outputs, axis=-1)
    return outputs[0]


def block_attention_fusion(inputs, config, training=None, init_std=0.00001):
    # fc + transformer + position attention
    l = relu_fc_layer(inputs, shape_list(inputs)[-1], init_std=init_std)
    dropout = config.get('block_attention_fc_layer_dropout_ratio', 0)
    if dropout > 0:
        l = my_dropout(l, rate=dropout, training=training)

    dims = shape_list(l)[-1]
    # here we assume the dimension of each input is divisible by block size
    block_size = config['block_attention_size']
    l = tf.reshape(l, [-1, tf.to_int32(dims / block_size), block_size])
    n_layer = config['block_attention_n_layer']
    n_head = config['block_attention_n_head']
    attention_dropout = config['block_attention_transformer_attention_dropout']
    fc_dropout = config['block_attention_transformer_fc_dropout']
    for layer in range(n_layer):
        l = transformer_block(l, n_head, attn_drop=attention_dropout, ffn_drop=fc_dropout,
                               mask=False, training=training)
    if config.get('block_self_attention', True):
        size = config['block_self_attention_size']
        l, alphas = self_position_attention(l, size)
    else:
        l = tf.reshape(l, [-1, dims])
    return l