import tensorflow as tf

from rcalgo.tf.module import Module
from rcalgo.tf.utils.logging import logger


class TFCharSequencePreprocessor(Module):
    """Convert char sequence to id sequence.

    Note:
        这个实现跟旧的tf-library有一些diff, 在蒸馏时可能需要注意:
        1. 原来是先mark_boundary，再截取max_length，可能会把EOS给截取掉，
           这里改成了先截取再padding
        2. 原来SOS和EOS对应的id是最大的, 现在oov是id最大的(原来id的顺序是
           word_dict < oov < sos < eos，现在是word_dict < sos < eos < oov).
    """
    def __init__(self, word_dict, oov_buckets=1, mark_boundary=False, name=None):
        """Initialize vocabulary table."""
        super().__init__(name=name)
        invalid_keys = [k for k in word_dict.keys() if len(k) != 1]
        if len(invalid_keys) > 0:
            logger.warning("Key of word_dict should be unicode! %s" % invalid_keys)

        # -1 is just a placeholder for padding, no unicode will map to it
        self._padding_unicode = -1
        # -2 and -3 are placeholders for sos and eos flag
        self._sos_unicode = -2
        self._eos_unicode = -3

        self.word_dict = {ord(k): v for (k, v) in word_dict.items() if len(k) == 1}

        # add a placeholder for padding flag
        if 0 not in self.word_dict.values():
            self.word_dict[self._padding_unicode] = 0
        self.nb_words = len(self.word_dict)

        # mark boundary
        self.mark_boundary = mark_boundary
        if self.mark_boundary:
            self.word_dict[self._sos_unicode] = self.nb_words
            self.word_dict[self._eos_unicode] = self.nb_words + 1
            self.nb_words += 2

        kv_init = tf.lookup.KeyValueTensorInitializer(
            list(self.word_dict.keys()),
            list(self.word_dict.values()),
            key_dtype=tf.int64,
            value_dtype=tf.int64)

        self.word_table = tf.lookup.StaticVocabularyTable(
            kv_init,
            num_oov_buckets=oov_buckets)
        self.nb_words += oov_buckets

    def call(self, text, max_length=0, *args, **kwargs):
        """Convert text to padded id sequence.
        """
        if text.dtype != tf.string:
            raise TypeError("Input tensor should be tf.string!")
        text = tf.strings.regex_replace(text, '\\s+', '')
        unicodes = tf.strings.unicode_decode(text, input_encoding="UTF-8")

        # cut long sequence
        if max_length > 0:
            unicodes = (unicodes[:, 0:max_length-2] if self.mark_boundary
                        else unicodes[:, 0:max_length])

        # mark boundary if necessary
        if self.mark_boundary:
            sos = tf.fill([unicodes.nrows(), 1], self._sos_unicode)
            eos = tf.fill([unicodes.nrows(), 1], self._eos_unicode)
            unicodes = tf.concat([sos, unicodes, eos], axis=1)

        sequence_ids = self.word_table.lookup(
            tf.cast(unicodes.to_sparse(), dtype=tf.int64))
        sequence_ids = tf.sparse.to_dense(sequence_ids, default_value=0)

        # padding short sequence
        if max_length > 0:
            pad_lengths = max_length - tf.shape(sequence_ids)[-1]
            paddings = [[0, 0], [0, pad_lengths]]
            sequence_ids = tf.pad(sequence_ids, paddings, "CONSTANT")
            sequence_ids.set_shape([None, max_length])

        sequence_lengths = tf.count_nonzero(sequence_ids, 1)
        return sequence_ids, sequence_lengths

    @property
    def vocab_size(self):
        return self.nb_words
