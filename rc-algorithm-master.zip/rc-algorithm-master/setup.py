from setuptools import setup, find_packages


# 需要将那些包导入
exclude = ['rcalgo.tf.tfmodels*', 'rcalgo.tf.tftraining*', 'rcalgo.tf.moduls_v2*', '*.tests']
packages = find_packages(exclude=exclude)

# 第三方依赖
requires = [
    "tensorflow==1.14",
    "numpy",
    "pandas>=0.23.4",
    "tqdm",
    "horovod>=0.19.4",
    "jieba",
    "h5py",
    "sklearn",
    "mpi4py",
    "synonyms",
    "torch>=1.6.0",
    "torchvision>=0.7.0",
    "Pillow",
    "tensorboard>=1.15.0",
    "opencv-python",
    "boto3"
]

with open('README.md', 'r') as f:
    readme = f.read()

setup(
    name="rcalgo",  # 包名称
    use_scm_version=True,
    setup_requires=['setuptools_scm'],
    description="Kuaishou Antispam Algorithm",  # 包详细描述
    long_description=readme,   # 长描述，通常是readme，打包到PiPy需要
    author="Zhou Yalin",  # 作者名称
    author_email="zhouyalin@kuaishou.com",  # 作者邮箱
    url="https://git.corp.kuaishou.com/risk-control/rc-algorithm",   # 项目官网
    packages=packages,  # 项目需要的包
    python_requires=">=3.6",  # Python版本依赖
    install_requires=requires,  # 第三方库依赖
    include_package_data=True,
    zip_safe=False,  # 此项需要，否则卸载时报windows error
    entry_points={
        'console_scripts': [
            'rcalgo-main=rcalgo.tf.bin.main:main',
            's3-upload=rcalgo.tf.bin.s3_upload:main',
        ],
    },
    classifiers=[    # 程序的所属分类列表
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: Implementation :: CPython',
        'Programming Language :: Python :: Implementation :: PyPy'
    ],
)
