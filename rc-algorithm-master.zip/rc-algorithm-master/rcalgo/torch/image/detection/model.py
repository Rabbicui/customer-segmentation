import os
import sys
import yaml
import math
import argparse
import shutil

import torch
import torch.optim as optim
import torch.optim.lr_scheduler as lr_scheduler

from rcalgo.torch.image.detection.models.yolo import Model
from rcalgo.torch.image.detection.base import ObjectDetection
from rcalgo.torch.image.detection.utils import torch_utils
from rcalgo.torch.image.detection.utils.datasets import create_dataloader
from rcalgo.torch.image.detection.utils.general import check_img_size, compute_loss

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))


class YOLOV5(ObjectDetection):

    def __init__(self, config, *args, **kwargs):
        super().__init__(config)
        default_weight_path = '/home/web_server/antispam/project/objdet/yolov5s.pt'
        default_model_yaml_path = os.path.join(
            os.path.dirname(
                os.path.realpath(__file__)),
            'conf/yolov5s.yaml')
        default_hyp_yaml_path = os.path.join(
            os.path.dirname(
                os.path.realpath(__file__)),
            'conf/hyp.scratch.yaml')

        self.weight_path = config.get('weight_path', default_weight_path)
        self.model_yaml_path = config.get(
            'model_yaml_path', default_model_yaml_path)
        self.hyp_yaml_path = config.get('hyp_yaml_path', default_hyp_yaml_path)
        self.opt = argparse.Namespace(**config)
        with open(self.hyp_yaml_path) as f:
            self.hyp = yaml.load(f, Loader=yaml.FullLoader)  # load hyps

    def init_model(self):
        device = torch_utils.select_device(batch_size=self.batch_size)

        assert len(self.names) == self.classes, '%g names found for num class=%g dataset in config' % (
            len(self.names), self.classes)  # check

        if self.single_cls:
            self.classes, self.names = (1, ['item'])   # number classes, names

        # init model
        pretrained = self.weight_path.endswith('.pt')
        if pretrained:
            self.ckpt = torch.load(
                self.weight_path,
                map_location=device)  # load checkpoint
            if self.hyp.get('anchors'):
                self.ckpt['model'].yaml['anchors'] = round(
                    self.hyp['anchors'])  # force autoanchor

            model = Model(
                self.model_yaml_path or self.ckpt['model'].yaml,
                ch=3,
                nc=self.classes).to(device)  # create
            exclude = ['anchor'] if self.model_yaml_path or self.hyp.get('anchors') else [
            ]  # exclude keys
            self.state_dict = self.ckpt['model'].float(
            ).state_dict()  # to FP32
            self.state_dict = torch_utils.intersect_dicts(
                self.state_dict, model.state_dict(), exclude=exclude)  # intersect
            model.load_state_dict(self.state_dict, strict=False)  # load
            self.logger.info(
                'Transferred %g/%g items from %s' %
                (len(
                    self.state_dict), len(
                    model.state_dict()), self.weight_path))  # report
        else:
            model = Model(
                self.model_yaml_path,
                ch=3,
                nc=self.classes).to(device)  # create

        self.logger.info(
            "=> loaded pre-trained model '{}'".format(self.weight_path))

        return model

    def create_optimizer(self):
        # Optimizer
        nbs = 64  # nominal batch size
        # accumulate loss before optimizing
        accumulate = max(round(nbs / self.batch_size), 1)
        self.hyp['weight_decay'] *= self.batch_size * \
            accumulate / nbs  # scale weight_decay

        pg0, pg1, pg2 = [], [], []  # optimizer parameter groups
        for k, v in self.model.named_parameters():
            v.requires_grad = True
            if '.bias' in k:
                pg2.append(v)  # biases
            elif '.weight' in k and '.bn' not in k:
                pg1.append(v)  # apply weight decay
            else:
                pg0.append(v)  # all else

        if self.opt.adam:
            optimizer = optim.Adam(pg0, lr=self.hyp['lr0'], betas=(
                self.hyp['momentum'], 0.999))  # adjust beta1 to momentum
        else:
            optimizer = optim.SGD(
                pg0,
                lr=self.hyp['lr0'],
                momentum=self.hyp['momentum'],
                nesterov=True)

        # add pg1 with weight_decay
        optimizer.add_param_group(
            {'params': pg1, 'weight_decay': self.hyp['weight_decay']})
        optimizer.add_param_group({'params': pg2})  # add pg2 (biases)
        self.logger.info(
            'Optimizer groups: %g .bias, %g conv.weight, %g other' %
            (len(pg2), len(pg1), len(pg0)))
        del pg0, pg1, pg2

        return optimizer

    def create_dataloader(self, train_path, val_path):
        # Image sizes
        gs = int(max(self.model.stride))  # grid size (max stride)
        # verify imgsz are gs-multiples
        imgsz, imgsz_test = [check_img_size(x, gs) for x in self.img_size]
        if not os.path.exists(train_path) or not os.path.exists(val_path):
            raise Exception("train path or val path does not exist! ")

        # Trainloader
        train_loader, train_set = create_dataloader(train_path, imgsz, self.batch_size, gs, self.opt,
                                                    hyp=self.hyp, augment=True, workers=self.opt.workers)

        valid_loader, valid_set = create_dataloader(val_path, imgsz_test, self.batch_size, gs, self.opt,
                                                    hyp=self.hyp, augment=False, rect=True, rank=-1,
                                                    workers=self.opt.workers)  # testloader

        return train_loader, train_set, valid_loader, valid_set

    def create_scheduler(self, epochs):
        # Scheduler https://arxiv.org/pdf/1812.01187.pdf
        # https://pytorch.org/docs/stable/_modules/torch/optim/lr_scheduler.html#OneCycleLR
        def lf(x): return ((1 + math.cos(x * math.pi / epochs)) / 2) * \
            (1 - self.hyp['lrf']) + self.hyp['lrf']  # cosine
        scheduler = lr_scheduler.LambdaLR(self.optim, lr_lambda=lf)

        return scheduler

    def optional_resume(self, epochs, weights_dir, results_file):
        # Resume
        start_epoch, best_fitness = 0, 0.0
        pretrained = self.weight_path.endswith('.pt')
        if pretrained:
            # Optimizer
            if self.ckpt['optimizer'] is not None:
                self.optim.load_state_dict(self.ckpt['optimizer'])
                best_fitness = self.ckpt['best_fitness']

            # Results
            if self.ckpt.get('training_results') is not None:
                with open(results_file, 'w') as file:
                    # write results.txt
                    file.write(self.ckpt['training_results'])

            # Epochs
            start_epoch = self.ckpt['epoch'] + 1
            if self.opt.resume:
                assert start_epoch > 0, '%s training to %g epochs is finished, nothing to resume.' % (
                    self.weight_path, epochs)
                # save previous weights
                shutil.copytree(weights_dir, weights_dir.parent / f'weights_backup_epoch{start_epoch - 1}')

            if epochs < start_epoch:
                self.logger.info(
                    '%s has been trained for %g epochs. Fine-tuning for %g additional epochs.' %
                    (self.weight_path, self.ckpt['epoch'], epochs))
                epochs += self.ckpt['epoch']  # finetune additional epochs

            self.ckpt, self.state_dict = None, None

        return (start_epoch, best_fitness)

    def criterion(self, pred, targets):
        loss, loss_items = compute_loss(pred, targets, self.model)
        return loss, loss_items
