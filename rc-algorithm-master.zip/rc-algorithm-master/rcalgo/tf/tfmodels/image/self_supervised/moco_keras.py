import os

import tensorflow as tf
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))

from rcalgo.tf.tfmodels.image.base.base_model import BaseModel
from rcalgo.tf.tfmodels.image.base.keras_model_wrapper import KeraModelWrapper
from rcalgo.tf.tfmodels.image.base import models
from rcalgo.tf.tfmodels.image.utils import input_pipeline
from rcalgo.tf.tfmodels.image.utils.common import load_ckpt_weights
from rcalgo.tf.tfmodels.image.transfer import bit_hyperrule
from rcalgo.tf.tfmodels.image.base.models import ResnetWithMLP
import numpy as np
import math

try:
    import horovod.tensorflow.keras as hvd
    # HACK
    import horovod.tensorflow as hvd2
except ImportError:
    pass

"""
    Implementation of moco v2 with slight difference: here we use InfoMin augmentation. Crop+Color jitter
    + blur augmentation still haven't reached the sweet-spot.
    cifar moco: 
        
        '--name', 'kwai_moco',
        '--model', 'BiT-M-R50x1',
        '--batch', str(batch_size),
        '--eval_every', str(eval_every),
        '--save_path', './ckpt_horovod/kwai_moco',
        '--logdir', './kwai_moco',
        '--bit_pretrained_dir', '../transfer/big_transfer/pre_trained_models/',
        #'--base_lr', '0.001',
        '--temp', '0.07', 
        '--output_mlp', '128', 
        '--hidden_mlp', '2048', 
        '--epochs', '400', 
        '--base_lr', '0.05', 
        '--final_lr', '0.0006', 
        '--warmup_epochs', '0', 
        '--start_warmup', '0', 
        '--weight_decay', '0', 
        '--gpu_num', '8',
        '--crop_min_scale', '0.2',
        '--queue_size', '65536', 
    
    这里差不多写完了。跑了下好像效果还有点问题， 还没细挑，另外还有个问题是 我们如果用big transfer 的resnet 
    使用的是group norm 在 未加载 pretrain 权重的时候好像有点小问题。。这里需要继续debug
"""


def allgather(tensor, name):
    tensor = tf.identity(tensor, name=name + "_HVD")
    return hvd2.allgather(tensor)


def batch_shuffle(tensor):  # nx...
    total, rank = hvd.size(), hvd.rank()
    batch_size = tf.shape(tensor)[0]
    with tf.device('/cpu:0'):
        all_idx = tf.range(total * batch_size)
        shuffle_idx = tf.random.shuffle(all_idx)

        # TODO HACK HERE
        shuffle_idx = hvd2.broadcast(shuffle_idx, 0)
        my_idxs = tf.slice(shuffle_idx, [rank * batch_size], [batch_size])

    all_tensor = allgather(tensor, 'batch_shuffle_key')  # gn x ...
    return tf.gather(all_tensor, my_idxs), shuffle_idx


def batch_unshuffle(key_feat, shuffle_idxs):
    rank = hvd.rank()
    inv_shuffle_idx = tf.argsort(shuffle_idxs)
    batch_size = tf.shape(key_feat)[0]
    my_idxs = tf.slice(inv_shuffle_idx, [rank * batch_size], [batch_size])
    all_key_feat = allgather(key_feat, "batch_unshuffle_feature")  # gn x c
    return tf.gather(all_key_feat, my_idxs)


class MocoKeras(BaseModel):

    def _build_data(self, batch, train_data, test_data=None):
        args = self.args
        original_resolution = [320, 320]
        if 'resolution' in train_data:
            original_resolution = train_data['resolution']
        resize_size, crop_size = bit_hyperrule.get_resolution(original_resolution)
        data_train = input_pipeline.get_infomin_data(
            batch_size=batch,
            resize_size=resize_size,
            crop_size=crop_size,
            crop_min_scale=args.crop_min_scale,
            random_aug_mag=args.random_aug_mag,
            random_aug_num_layer=args.random_aug_num_layer,
            data=train_data)
        iterator = data_train.make_one_shot_iterator()
        batches = iterator.get_next()
        return batches, None, None, None

    def _build_model(self, num_classes):
        args = self.args
        # build the queue
        queue = QueueLayer(args.queue_size, args.output_mlp)

        # build model
        filters_factor = int(args.model[-1]) * 4
        query = tf.keras.Input(shape=(None, None, 3))
        key = tf.keras.Input(shape=(None, None, 3))
        units = models.NUM_UNITS[args.model]
        model = ResnetWithMLP(
            hidden_mlp=args.hidden_mlp,
            output_mlp=args.output_mlp,
            num_units=units,
            num_outputs=None,
            filters_factor=filters_factor,
            name="query_encoder",
            trainable=True,
            dtype=tf.float32,
            attention_params=None)

        model_ema = ResnetWithMLP(
            hidden_mlp=args.hidden_mlp,
            output_mlp=args.output_mlp,
            num_units=units,
            num_outputs=None,
            filters_factor=filters_factor,
            name="momentum_encoder",
            trainable=True,
            dtype=tf.float32,
            attention_params=None)

        # ema 的权重不训练使用 momentum 方式更新
        model_ema.trainable = False

        # compute the query embedding
        y = model(query)

        # do shuffle between gpu to avoid the batch norm problem
        shuffled_key, shuffle_idxs = batch_shuffle(key)
        shuffled_key.set_shape([self.batch_size, None, None, None])
        # compute the key embedding
        y_ema = model_ema(shuffled_key)
        y_ema = batch_unshuffle(y_ema, shuffle_idxs)
        # don't update the momentum encoder
        y_ema = tf.keras.backend.stop_gradient(y_ema)
        # compute the loss info and so on
        l_pos = tf.reshape(tf.einsum('nc,nc->n', y, y_ema), (-1, 1))  # nx1
        l_neg = queue(y)
        logits = tf.concat([l_pos, l_neg], axis=1)  # nx(1+k)
        logits = logits * (1 / args.temp)

        # update queue
        update_ops = list(queue.update(y_ema))

        # restore weights
        if args.ckpt_path is not None:
            load_ckpt_weights(args.ckpt_path)
        elif args.bit_pretrained_dir is not None:
            bit_model_file = os.path.join(args.bit_pretrained_dir, f'{args.model}.h5')
            model.load_weights(bit_model_file, by_name=True)
        # wrap inputs and outputs
        keras_model = KeraModelWrapper(model, inputs=[query, key], outputs=[logits])
        keras_model.add_update_ops(update_ops)
        keras_model.delegate.summary()
        return keras_model

    def _get_epochs(self, num_samples):
        return self.args.epochs

    def _build_custom_callbacks(self):
        total_steps = (self.num_samples // self.batch_size) * self.args.epochs
        warmup_steps = (self.num_samples // self.batch_size) * self.args.warmup_epochs
        return [WarmupAndCosineSched(self.args.base_lr, self.args.final_lr,
                                     self.args.start_warmup, warmup_steps, total_steps),
                UpdateMomentumEncoder(tf.compat.v1.keras.backend.get_session(),
                                      self.model.delegate.trainable_weights,
                                      self.model.delegate.non_trainable_weights)]

    def _build_loss(self):
        def moco_loss(y_true, y_predict):
            variables = self.model.delegate.trainable_weights

            def _penalty():
                # don't add l2 on batch norm and network besides the image part
                p_loss = self.args.l2_regular * tf.add_n(
                    [tf.nn.l2_loss(v) for v in variables if
                     'batch_normalization' not in v.name and 'group_normalization' not in v.name and 'bias' not in v.name])
                return p_loss

            labels = tf.zeros(self.batch_size, dtype=tf.int64)  # n
            loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=y_predict, labels=labels)
            loss = tf.reduce_mean(loss, name='xentropy-loss')
            return loss + _penalty()
        return [moco_loss]

    def _build_metric(self):
        def moco_accuracy(y_true, y_pred):
            labels = tf.zeros(self.batch_size, dtype=tf.int64)  # n
            acc = tf.reduce_mean(tf.cast(
                tf.equal(tf.math.argmax(y_pred, axis=1), labels), tf.float32), name='train-acc')
            return acc

        return [moco_accuracy]

    def _parse_serving_str(self, str_x, resize):
        return input_pipeline.parse_str(str_x, resize, False)


class QueueLayer(tf.keras.layers.Layer):

    def __init__(self, queue_size, output_mlp, name='queue'):
        super(QueueLayer, self).__init__(name=name)
        queue_init = tf.math.l2_normalize(
            tf.random.normal([queue_size, output_mlp]), axis=1)
        self.queue = tf.get_variable('queue', initializer=queue_init, trainable=False)
        self.queue_ptr = tf.get_variable(
            'queue_ptr',
            shape=None, initializer=tf.constant(0),
            dtype=tf.int32, trainable=False)
        self.queue_size = queue_size

    def call(self, inputs):
        return tf.einsum('nc,kc->nk', inputs, self.queue)  # nxK

    def update(self, y_ema):
        # TODO 这个地方 要不要收集所有的 gpu上的数据来update queue， 因为存在一种可能
        # TODO GPU 0 的batch 有 img A ，加入queue, GPU 1 再下个训练batch 也有img A, 这样 queue里有img A了，但是会作为negative sample
        item = allgather(y_ema, 'queue_gather')  # GN x C
        batch_size = tf.shape(item, out_type=tf.int32)[0]
        end_queue_ptr = self.queue_ptr + batch_size
        inds = tf.range(self.queue_ptr, end_queue_ptr, dtype=tf.int32)
        # do update the ptr and queue
        queue_ptr_update = tf.assign(self.queue_ptr, end_queue_ptr % self.queue_size)
        queue_update = tf.scatter_update(self.queue, inds, item)
        return queue_ptr_update, queue_update


class WarmupAndCosineSched(tf.keras.callbacks.Callback):

    def __init__(self, base_lr, final_lr, start_warmup, warmup_steps, total_steps):
        self.step = 0
        self.base_lr = base_lr
        warmup_lr_schedule = np.linspace(start_warmup, base_lr, warmup_steps)
        iters = np.arange(total_steps - warmup_steps)
        cosine_lr_schedule = np.array([final_lr + 0.5 * (base_lr - final_lr) * (
                    1 + math.cos(math.pi * t / (total_steps - warmup_steps)))
                                       for t in iters])
        self.lr_schedule = np.concatenate([warmup_lr_schedule, cosine_lr_schedule])

    def on_train_batch_begin(self, batch, logs=None):
        # 这边 继承 callback的子类 可以拿到  callback   和 model fit 绑定的模型 也就是 继承 Keras.Model 的子类
        lr = self.lr_schedule[self.step]
        tf.keras.backend.set_value(self.model.optimizer.lr, lr)
        self.step += 1


class UpdateMomentumEncoder(tf.keras.callbacks.Callback):
    momentum = 0.999

    def __init__(self, session, trainable_vars, nontrainable_vars):
        self.session = session
        all_vars = {v.name: v for v in trainable_vars}

        # find variables of encoder & momentum encoder
        self._var_mapping = {}  # var -> mom var
        momentum_prefix = "momentum_encoder/"
        for mom_var in nontrainable_vars:
            if momentum_prefix in mom_var.name:
                q_encoder_name = mom_var.name.replace(momentum_prefix, "query_encoder/")
                q_encoder_var = all_vars[q_encoder_name]
                assert q_encoder_var not in self._var_mapping
                if not q_encoder_var.trainable:  # don't need to copy EMA
                    continue
                self._var_mapping[q_encoder_var] = mom_var

        assign_ops = [tf.assign(mom_var, var) for var, mom_var in self._var_mapping.items()]
        self.assign_op = tf.group(*assign_ops, name="initialize_momentum_encoder")

        update_ops = [tf.assign_add(mom_var, (var - mom_var) * (1 - self.momentum))
                      for var, mom_var in self._var_mapping.items()]
        self.update_op = tf.group(*update_ops, name="update_momentum_encoder")

    def on_train_begin(self, logs=None):
        self.session.run(self.assign_op)

    def on_train_batch_end(self, batch, logs=None):
        self.session.run(self.update_op)


