import tensorflow as tf

from rcalgo.tf.modules_v2.base_module import Module
from rcalgo.tf.modules_v2 import initializers, activations
from rcalgo.tf.training.training_utils import get_or_create_is_training


class BatchNormalization(Module):
    """Batch Normalization.

    Paper: http://arxiv.org/abs/1502.03167

    TODO: 简单看了下，跟keras上的实现有一些差别，需要抽空对比一下
    """

    def __init__(self,
                 axis=-1,
                 decay=0.999,
                 epsilon=1e-3,
                 center=True,
                 scale=True,
                 beta_initializer='zeros',
                 gamma_initializer='ones',
                 name=None):
        super(BatchNormalization, self).__init__(name=name)
        self.axis = axis
        self.decay = decay
        self.epsilon = epsilon
        self.center = center
        self.scale = scale
        self.beta_initializer = initializers.get(beta_initializer)
        self.gamma_initializer = initializers.get(gamma_initializer)
        self.moving_mean_initializer = tf.constant_initializer(0.0)
        self.moving_variance_initializer = tf.constant_initializer(1.0)

    def build(self, input_shape):
        ndims = len(input_shape)

        if isinstance(self.axis, int):
            self.axis = [self.axis]
        self.axis = [ndims + x if x < 0 else x for x in self.axis]
        for x in self.axis:
            if x < 0 or x >= ndims:
                raise ValueError("Invalid axis: %d" % x)
        if len(self.axis) != len(set(self.axis)):
            raise ValueError('Duplicate axis: {}'.format(tuple(self.axis)))

        axis_to_dim = {x: input_shape[x] for x in self.axis}
        if len(self.axis) == 1:
            params_shape = (list(axis_to_dim.values())[0],)
        else:
            params_shape = [axis_to_dim[i] if i in axis_to_dim else 1
                            for i in range(ndims)]

        if self.scale:
            self.gamma = tf.Variable(
                self.gamma_initializer(shape=params_shape),
                dtype=self.dtype,
                name="gamma")
        else:
            self.gamma = None

        if self.center:
            self.beta = tf.Variable(
                self.beta_initializer(shape=params_shape),
                dtype=self.dtype,
                name="beta")
        else:
            self.beta = None

        self.moving_mean = tf.Variable(
            self.moving_mean_initializer(shape=params_shape),
            dtype=self.dtype,
            name="moving_mean",
            trainable=False)
        self.moving_variance = tf.Variable(
            self.moving_variance_initializer(shape=params_shape),
            dtype=self.dtype,
            name="moving_variance",
            trainable=False)

    def call(self, inputs, training=None):
        if training is None:
            training = get_or_create_is_training()

        input_shape = inputs.shape
        ndims = len(input_shape)

        broadcast_shape = [1] * ndims
        for dim in self.axis:
            broadcast_shape[dim] = input_shape.dims[dim].value

        def _broadcast(v):
            if (v is not None and len(v.shape) != ndims and
                    self.axis != [ndims - 1]):
                return tf.reshape(v, broadcast_shape)
            return v

        scale, offset = _broadcast(self.gamma), _broadcast(self.beta)

        def _batch_norm_training():
            """Batch norm on training stage."""
            reduction_axes = [i for i in range(ndims) if i not in self.axis]
            batch_mean, batch_variance = tf.nn.moments(inputs, reduction_axes)

            train_mean = tf.assign(
                self.moving_mean,
                self.moving_mean * self.decay + batch_mean * (1.0 - self.decay))
            train_variance = tf.assign(
                self.moving_variance,
                self.moving_variance * self.decay + batch_variance * (1.0 - self.decay))

            with tf.control_dependencies([train_mean, train_variance]):
                return tf.nn.batch_normalization(
                    inputs,
                    _broadcast(batch_mean),
                    _broadcast(batch_variance),
                    offset=offset,
                    scale=scale,
                    variance_epsilon=self.epsilon)

        def _batch_norm_inference():
            """Batch norm on inference stage."""
            return tf.nn.batch_normalization(
                inputs,
                _broadcast(self.moving_mean),
                _broadcast(self.moving_variance),
                offset=offset,
                scale=scale,
                variance_epsilon=self.epsilon)

        outputs = tf.cond(training, _batch_norm_training, _batch_norm_inference)
        outputs.set_shape(input_shape)
        return outputs


class LayerNormalization(Module):
    """Layer Normalization."""
    def __init__(self,
                 axis=-1,
                 epsilon=1e-3,
                 center=True,
                 scale=True,
                 beta_initializer='zeros',
                 gamma_initializer='ones',
                 name=None):
        super(LayerNormalization, self).__init__(name=name)
        self.axis = axis
        self.epsilon = epsilon
        self.center = center
        self.scale = scale
        self.beta_initializer = initializers.get(beta_initializer)  # rescale
        self.gamma_initializer = initializers.get(gamma_initializer)  # recenter

    def build(self, input_shape):
        ndims = len(input_shape)

        if isinstance(self.axis, int):
            self.axis = [self.axis]
        self.axis = [ndims + x if x < 0 else x for x in self.axis]
        for x in self.axis:
            if x < 0 or x >= ndims:
                raise ValueError("Invalid axis: %d" % x)
        if len(self.axis) != len(set(self.axis)):
            raise ValueError('Duplicate axis: {}'.format(tuple(self.axis)))

        params_shape = [input_shape[dim] for dim in self.axis]
        if self.scale:
            self.gamma = tf.Variable(
                self.gamma_initializer(shape=params_shape),
                dtype=self.dtype,
                name="gamma")
        else:
            self.gamma = None

        if self.center:
            self.beta = tf.Variable(
                self.beta_initializer(shape=params_shape),
                dtype=self.dtype,
                name="beta")
        else:
            self.beta = None

    def call(self, inputs):
        input_shape = inputs.shape
        ndims = len(input_shape)

        mean, variance = tf.nn.moments(inputs, self.axis, keep_dims=True)
        broadcast_shape = [1] * ndims
        for dim in self.axis:
            broadcast_shape[dim] = input_shape.dims[dim].value

        def _broadcast(v):
            if (v is not None and len(v.shape) != ndims and
                    self.axis != [ndims - 1]):
                return tf.reshape(v, broadcast_shape)
            return v

        scale, offset = _broadcast(self.gamma), _broadcast(self.beta)

        outputs = tf.nn.batch_normalization(
            inputs,
            mean,
            variance,
            offset=offset,
            scale=scale,
            variance_epsilon=self.epsilon)

        outputs.set_shape(input_shape)
        return outputs


def flatten(inputs):
    """Flatten a tensor."""
    input_shape = inputs.shape.as_list()
    if len(input_shape) > 2:
        outputs = tf.reshape(
            inputs,
            (input_shape[0] or tf.shape(inputs)[0], -1))
        return outputs
    return inputs


class Flatten(Module):
    """Flatten implemented as module."""

    def __init__(self, name=None):
        super(Flatten, self).__init__(name=name)

    def call(self, inputs):
        input_shape = inputs.shape.as_list()
        if len(input_shape) > 2:
            outputs = tf.reshape(
                inputs,
                (input_shape[0] or tf.shape(inputs)[0], -1))
            return outputs
        return inputs


class Dense(Module):
    """Full Connected Layer with activation function."""

    def __init__(self,
                 units,
                 activation='identity',
                 use_bias=True,
                 kernel_initializer=None,
                 bias_initializer="zeros",
                 use_bn=False,
                 name=None):
        super(Dense, self).__init__(name=name)
        self.units = int(units)
        self.activation = activations.get(activation)
        self.use_bias = use_bias
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.bias_initializer = initializers.get(bias_initializer)
        self.batch_norm = BatchNormalization() if use_bn else None

    def build(self, input_shape):
        if not input_shape or input_shape[-1] is None:
            raise ValueError('The last dimension of the inputs to `Dense` '
                             'should be defined. Found `None`.')
        last_dim = input_shape[-1]
        self.kernel = tf.Variable(
            self.kernel_initializer(shape=[last_dim, self.units]),
            dtype=self.dtype,
            name='kernel')
        if self.use_bias:
            self.bias = tf.Variable(
                self.bias_initializer(shape=[self.units]),
                dtype=self.dtype,
                name='bias')
        else:
            self.bias = None

    def call(self, inputs, training=None):
        # inputs = tf.cast(inputs, self._compute_dtype)
        rank = len(inputs.shape)
        if rank > 2:
            outputs = tf.tensordot(inputs, self.kernel, [[rank - 1], [0]])
        else:
            if isinstance(inputs, tf.sparse.SparseTensor):
                outputs = tf.sparse_tensor_dense_matmul(inputs, self.kernel)
            else:
                outputs = tf.matmul(inputs, self.kernel)
        if self.use_bias:
            outputs = tf.nn.bias_add(outputs, self.bias)

        if self.batch_norm is not None:
            outputs = self.batch_norm(outputs, training=training)

        if self.activation is not None:
            outputs = self.activation(outputs)
        return outputs


def dropout(inputs, rate=0.5, training=None, seed=None):
    """Dropout implemented as functon."""
    if training is None:
        training = get_or_create_is_training()

    def dropped_inputs():
        return tf.nn.dropout(inputs, seed=seed, rate=rate)  #

    outputs = tf.cond(training,
                      dropped_inputs,
                      lambda: tf.identity(inputs))
    return outputs


class Dropout(Module):
    """Applies Dropout to the input."""

    def __init__(self, rate, seed=None, name=None):
        super(Dropout, self).__init__(name=name)
        self.rate = rate
        self.seed = seed

    def call(self, inputs, training=None):
        if training is None:
            training = get_or_create_is_training()

        def dropped_inputs():
            return tf.nn.dropout(inputs, seed=self.seed, rate=self.rate)  #

        output = tf.cond(training,
                         dropped_inputs,
                         lambda: tf.identity(inputs))
        return output


class Highway(Module):
    """
    Highway Network (cf. http://arxiv.org/abs/1505.00387).

    t = sigmoid(Wy + b)
    z = t * g(Wy + b) + (1 - t) * y
    """

    def __init__(self,
                 activation='relu',
                 use_bias=True,
                 kernel_initializer=None,
                 bias_initializer='zeros',
                 name=None):
        super(Highway, self).__init__(name=name)
        self.activation = activations.get(activation)
        self.use_bias = use_bias
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.bias_initializer = initializers.get(bias_initializer)

    def build(self, input_shape):
        if not input_shape or input_shape[-1] is None:
            raise ValueError('The last dimension of the inputs to `Dense` '
                             'should be defined. Found `None`.')
        last_dim = input_shape[-1]
        self.linear = Dense(last_dim, activation='identity',
                            use_bias=self.use_bias,
                            kernel_initializer=self.kernel_initializer,
                            bias_initializer=self.bias_initializer)
        self.gate_linear = Dense(last_dim, activation='identity',
                                use_bias=self.use_bias,
                                kernel_initializer=self.kernel_initializer,
                                bias_initializer=self.bias_initializer)

    def call(self, inputs):
        linear_output = self.linear(inputs)
        gate = tf.math.sigmoid(self.gate_linear(inputs))
        hidden = self.activation(linear_output)
        output = gate * linear_output + (1.0 - gate) * inputs
        return output
