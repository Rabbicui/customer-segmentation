import math
import tensorflow as tf

from rcalgo.tf.modules_v2.base_module import Module
from rcalgo.tf.modules_v2 import initializers


class WordEmbedding(Module):
    """Word Embedding.

    TODO: 去掉了zero_pad, 需要看下对效果是否有负面影响
    """
    def __init__(self,
                 vocab_size,
                 embedding_size,
                 kernel_initializer=tf.random_uniform_initializer(-1.0, 1.0),
                 name=None):
        super(WordEmbedding, self).__init__(name=name)
        self.vocab_size = vocab_size
        self.embedding_size = embedding_size
        self.kernel_initializer = initializers.get(kernel_initializer)

    def build(self, input_shape):
        embedding_shape = (self.vocab_size, self.embedding_size)
        self.embedding = tf.Variable(
            self.kernel_initializer(embedding_shape, dtype=self.dtype),
            dtype=self.dtype,
            name='word_embedding')

    def call(self, inputs):
        if inputs.dtype != tf.int32 and inputs.dtype != tf.int64:
            inputs = tf.cast(inputs, tf.int32)
        input_embedding = tf.nn.embedding_lookup(self.embedding, inputs)
        return input_embedding


class PositionEmbedding(Module):
    """Encodes position with a lookup table."""

    def __init__(self,
                 max_position,
                 kernel_initializer=tf.random_uniform_initializer(-1.0, 1.0),
                 name=None):
        """Initializes the position encoder.

        Args:
          max_position: The maximum position to embed. Positions greater
            than this value will be set to :obj:`max_position`.
        """
        super(PositionEmbedding, self).__init__(name=name)
        self.max_position = max_position
        self.kernel_initializer = initializers.get(kernel_initializer)

    def build(self, input_shape):
        embedding_size = input_shape[-1]
        embedding_shape = (self.max_position, embedding_size)
        self.embedding = tf.Variable(
            self.kernel_initializer(embedding_shape, dtype=self.dtype),
            dtype=self.dtype,
            name='position_embedding')

    def call(self, word_embedding):
        """Compute position embeddings.

        Args:
            word_embedding: word embedding of sequence
        """
        input_shape = word_embedding.shape.as_list()
        if len(input_shape) != 3:
            raise ValueError("word_embedding should have three dimensions!")

        seq_length = input_shape[1]
        position_ids = tf.range(seq_length, dtype=tf.int32)
        position_ids = tf.expand_dims(position_ids, 0)
        output = tf.nn.embedding_lookup(self.embedding, position_ids)
        return output


def sinusoidal_position_embedding(word_embedding,
                                  min_timescale=1.0,
                                  max_timescale=1.0e4):
    """Sinusoidal positional encoding.

    code:
    https://github.com/tensorflow/models/blob/master/official/transformer/model/model_utils.py#L29:26

    Args:
        word_embedding: word embedding of sequence
        min_timescale: Minimum scale that will be applied at each position
        max_timescale: Maximum scale that will be applied at each position
    """
    input_shape = word_embedding.shape.as_list()
    ndims = len(input_shape)
    if ndims != 3:
        raise ValueError("word_embedding should have three dimensions!")
    length, embedding_size = input_shape[1], input_shape[2]

    position = tf.to_float(tf.range(length))
    num_timescales = embedding_size // 2
    log_timescale_increment = (
        math.log(float(max_timescale) / float(min_timescale)) /
        (tf.to_float(num_timescales) - 1))
    inv_timescales = min_timescale * tf.exp(
        tf.to_float(tf.range(num_timescales)) * -log_timescale_increment)
    scaled_time = tf.expand_dims(position, 1) * \
        tf.expand_dims(inv_timescales, 0)
    signal = tf.concat([tf.sin(scaled_time), tf.cos(scaled_time)], axis=1)
    signal = tf.expand_dims(signal, 0)
    return signal


class SinusoidalPositionEmbedding(Module):
    """Encodes positions with sine waves.  """

    def __init__(self,
                 min_timescale=1.0,
                 max_timescale=1.0e4,
                 name=None):
        super(SinusoidalPositionEmbedding, self).__init__(name=name)
        self.min_timescale = min_timescale
        self.max_timescale = max_timescale

    def call(self, word_embedding):
        outputs = sinusoidal_position_embedding(
            word_embedding, self.min_timescale, self.max_timescale)
        return outputs
