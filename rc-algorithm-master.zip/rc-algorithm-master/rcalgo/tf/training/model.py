import tensorflow.compat.v1 as tf
import horovod.tensorflow as hvd

from rcalgo.tf.training import context
from rcalgo.tf.training import training_utils
from rcalgo.tf.metric.loss import my_sparse_cross_entropy_loss
from rcalgo.tf.optimizer import optimizer_utils
from rcalgo.tf.module import Module
from rcalgo.tf.training.multi_worker_graph_copy_trainer import MultiWorkerGraphCopyTrainer
from rcalgo.tf.training.single_worker_graph_copy_trainer import SingleWorkerGraphCopyTrainer
from rcalgo.tf.training.horovod_trainer import HorovodTrainer
from rcalgo.tf.training.trainer import Task
from rcalgo.tf.utils.hparams import HParams
from rcalgo.tf.utils.logging import logger
from rcalgo.tf.utils import tf_collections


def functional_model(inputs=None,
                     outputs=None,
                     labels=None,
                     loss=None,
                     metrics=None,
                     train_op=None,
                     lr_variable=None,
                     tvars=None,
                     create_collections=True,
                     distribute="horovod",
                     name="functional"):
    """Functional api like keras.

    Note:
        You don't need to provided all the arguments of this function, many of them are
        not necessary.

    Args:
        inputs: inputs of the model
        outputs: predictions of the model, required for prediction()
        labels: targets used to calculate loss, required for train() or evaluate()
        loss: loss of the model, required for set_optimizer()
        metrics: required for evaluate()
        train_op: required for train()
        lr_variable: optional
        tvars: optional. if not provided, will use tf.trainable_variables() as default
        create_collections: whether to create task in graph collections
        name: name of the model, will be used as name scope prefix and collection prefix
    """
    model = Model(distribute=distribute, name=name)
    model.inputs = inputs
    model.outputs = outputs
    model.labels = labels
    model.loss = loss
    if metrics is None:
        metrics = []
    model.metrics = metrics
    model.train_op = train_op
    model.lr_variable = lr_variable
    model.tvars = tf.trainable_variables() if not tvars else tvars
    if create_collections:
        training_utils.create_task_in_graph(
            inputs, outputs, labels,
            loss, metrics, train_op,
            lr_variable, tvars,
            name=name)
    return model


class Model(Module):
    """Base class inherited by models.

    This class is an extension of Module. It provides interfaces
    for model training.
    """
    def __init__(self, config=None, distribute="horovod", name=None):
        super(Model, self).__init__(name=name)

        if config is None:
            config = {}
        logger.info(f"config: {config}")
        self.learning_rate = config.get("learning_rate", 0.0001)

        # build optimizer params
        self.opt_params = HParams({
            'optimizer': config.get('optimizer', 'adam'),
            'loss_scaling': config.get('loss_scaling', False),
            'loss_scale_factor': config.get('loss_scale_factor', 1000),
            'adam_epsilon': config.get('adam_epsilon', 1e-8),
            'adam_beta1': config.get('adam_beta1', 0.9),
            'adam_beta2': config.get('adam_beta2', 0.999),
            'adam_wd': config.get('adam_wd', 0.001),
            'clip_gradient': config.get('clip_gradient', 1.0),
            'clip_type': config.get('clip_type', 'none'),
        })

        # core attributes of the model
        # self.name = name
        self.inputs = None
        self.outputs = None
        self.labels = None
        self.loss = None
        self.metrics = None
        self.train_op = None
        self.lr_variable = None
        self.tvars = None
        self.extra_attrs = {}

        # functional model or subclassing model
        self._model_type = "functional"
        self._distribute = distribute

        # decide which distribute strategy to use.
        if distribute == "horovod":
            hvd.init()
            self.trainer = HorovodTrainer(
                config=config, default_task_name=self.name)
        elif distribute == "tf_distribute":
            self.trainer = SingleWorkerGraphCopyTrainer(
                default_task_name=self.name, **config)
        elif distribute == "multiworker_tf_distribute":
            self.trainer = MultiWorkerGraphCopyTrainer(
                default_task_name=self.name, **config)
        else:
            raise ValueError("distribute strategy should be one of the"
                             "following: horovod, tf_distribute, "
                             "multiworker_tf_distribute")

    def create_inputs(self):
        """Create placeholders used by the model.

        Returns:
            placeholder or list of placeholders: model inputs
            placeholder or list of placeholders: labels of the model
        """
        raise NotImplementedError

    def call(self, inputs):
        """Build the forward propagation graph.

        Args:
            inputs: tensor or list of tensors(in case of multiple inputs)

        Returns:
            tensor or list of tensors: logits of the model
            tensor or list of tensors: model predictions
        """
        raise NotImplementedError

    def compute_loss(self, logits, labels):
        """Compute loss of the model.

        Args:
            logits: logits of the model, same as the first return
                value of call()
            labels: labels of the model, same as the second return value
                of build_inputs()

        Returns:
            tensor: loss of the model
        """
        loss = tf.reduce_mean(my_sparse_cross_entropy_loss(labels, logits, 2))  # TODO: fix magic number
        return loss

    def compute_metrics(self, outputs, labels):
        """Compute metrics of the model.

        Note that is function should return `per_example_metric`, instead of
        reduced results.

        Args:
            outputs: predictions of the model, same as the second return
                value of call()
            labels: labels of the model, same as the second return value
                of build_inputs()

        Returns:
            tensor or list of tensors: the metrics of the model
        """
        accuracy = tf.cast(tf.nn.in_top_k(outputs, labels, k=1),  # TODO: fix magic number
                           dtype=tf.float32)
        return accuracy

    def create_optimizer(self):
        """Create model optimizer.

        Returns:
            tf.train.Optimizer: an optimizer instance
        """
        optimizer = optimizer_utils.build_optimizer(
            self.name, self.learning_rate, self.opt_params)
        return optimizer

    def filter_trainable_variables(self, tvars):
        """Trainable variables used by the optimizer.

        This interface is not intended to return all the trainable
        variables actually used by the model, because it is difficult
        to do this without tracking variables, but we are not tracking
        variables right now. So you can just return a superset of it.

        Returns:
            list of tensors: trainable variables of the model
        """
        return tvars

    def add_extra_attr(self, key, values):
        """Add an extra attribute to the model.

        This interface will also save the attribute to graph collection.

        Args:
            key (str): key of the attribute
            values (list of tensors): tensors to be saved
        """
        if not isinstance(values, list):
            values = [values]

        training_utils.add_task_extra_attr(self.name, key, values)
        self.extra_attrs[key] = values

    def add_extra_attrs(self, logits):
        """Add extra nodes to collections using add_extra_attr().

        Args:
            logits: logits of the model, same as the first return value
                of call()
        """
        pass

    def build_forward(self, **kwargs):
        """Build forward propagation."""
        self.inputs, self.labels = self.create_inputs()
        logits, self.outputs = self(self.inputs, **kwargs)  # self.call()
        self.loss = self.compute_loss(logits, self.labels)
        self.metrics = self.compute_metrics(self.outputs, self.labels)
        self.add_extra_attrs(logits)

        training_utils.create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)

    def _build_optimization(self):
        """Build optimization.

        Note:
            Horovod and graph copy are slightly different here.
        """
        # this two lines are needed for graph copy, because optimizer
        # is recreated while doing the copy
        training_utils.set_task_opt_params(self.name, self.opt_params)
        training_utils.set_task_learning_rate(self.name, self.learning_rate)

        optimizer = self.create_optimizer()
        self.set_optimizer(optimizer,
                           clip_type=self.opt_params.clip_type,
                           max_clip_grad=self.opt_params.clip_gradient)

    def build_model(self, clear_session=False, **kwargs):
        """Build the whole model, including forward propagation and
        optimization.

        Common use case:
            model = SomeSpecificModel(config, ...).build_model()
            model.train(data, ...)
        """
        if clear_session:
            context.clear_session()

        # build forward propagation
        self.build_forward(**kwargs)

        # set trainable variables
        self.tvars = self.filter_trainable_variables(tf.trainable_variables())
        training_utils.set_task_tvars(self.name, self.tvars)

        # build optimization
        self._build_optimization()

        # set model type
        self._model_type = "subclassing"
        return self

    def set_optimizer(self, optimizer, learning_rate=None,
                      clip_type=None, max_clip_grad=1.0, name=None,
                      **kwargs):
        """Update optimizer for the model.
        """
        if learning_rate is None:
            self.lr_variable = training_utils.get_lr_from_optimizer(optimizer)

        if self._distribute == "horovod":
            optimizer = optimizer_utils.HorovodOptimizerWrapper(
                optimizer, clip_type=clip_type,
                max_clip_grad=max_clip_grad, **kwargs)
        else:
            optimizer = optimizer_utils.GraphCopyOptimizerWrapper(
                optimizer, clip_type=clip_type,
                max_clip_grad=max_clip_grad, **kwargs)

        self.train_op = optimizer.minimize(self.loss, self.tvars, name=name)
        training_utils.set_task_train_op_and_lr(
            self.name, self.train_op, self.lr_variable)

    @classmethod
    def _create_model_from_meta_graph(cls,
                                      path,
                                      name=None,
                                      import_scope=None,
                                      distribute="horovod",
                                      clear_session=True):
        """Restore a model from metagraph, return saver as well."""
        if clear_session:
            context.clear_session()
        saver = tf.train.import_meta_graph(
            path, clear_devices=True, import_scope=import_scope)

        if name is None:
            name = tf.get_collection(tf.GraphKeys.CURRENT_TASK)
            if not name:
                raise ValueError("'name' argument is empty!")
            name = name[0]
            if isinstance(name, bytes):
                name = name.decode()
        logger.info(f"load task: {name}")

        task = Task(task_name=name)
        model = functional_model(
            task.inputs, task.outputs, task.targets,
            task.loss, task.metric, task.train_op,
            task.lr_variable, task.tvars,
            create_collections=False,
            name=name,
            distribute=distribute)

        model.extra_attrs = training_utils.get_task_extra_attrs(name=name)
        if model.loss is None or model.loss == []:
            raise ValueError(
                "failed to detect loss tensor from meta graph,"
                "this usually happen when argument "
                "`name` is not specified correctly.")
        return model, saver

    @classmethod
    def from_meta_graph(cls, *args, **kwargs):
        """Restore a model from metagraph."""
        model, saver = cls._create_model_from_meta_graph(*args, **kwargs)
        return model

    @classmethod
    def from_checkpoint(cls, path, *args, **kwargs):
        """Restore a model from checkpoint.

        This function will load meta graph and then restore checkpoint
        """
        model, saver = cls._create_model_from_meta_graph(
            "{}.meta".format(path), *args, **kwargs)
        model.trainer.restore_checkpoint_from_output(path, saver)
        return model

    @classmethod
    def from_frozen_pb(cls, path, name):
        """Restore a model from pb.
        """
        tf.get_default_graph().clear_collection("input_dict")
        tf.get_default_graph().clear_collection("output_dict")
        tf.train.import_meta_graph(path, clear_devices=True, import_scope=name)

        input_tensors = tf.get_collection("input_dict")
        output_tensors = tf.get_collection("output_dict")
        model = functional_model(inputs=input_tensors, outputs=output_tensors, name=name)
        return model

    def restore_checkpoint(self, path=None):
        self.trainer.restore_checkpoint_from_output(path)

    def restore_weights(self, path=None, tvars=None):
        """Restore weights from checkpoint.

        This function only restore weights of variables, others things like optimizer
        status will not be restored.
        """
        self.trainer.restore_variables_from_output(path, tvars=tvars)

    def train_and_evaluate(self, train_data, test_data, *args, **kwargs):
        """Train on train_data and evaluate on test_data."""
        self.trainer.train_and_evaluate(train_data, test_data, *args, **kwargs)

    def train(self, data, *args, **kwargs):
        """Split dataset into train_data and test_data, then train on it."""
        self.trainer.train(data, *args, **kwargs)

    def evaluate(self, data, **kwargs):
        """Evaluate on a dataset."""
        return self.trainer.evaluate(data, **kwargs)

    def predict(self, data, **kwargs):
        """Predict outputs on a dataset."""
        return self.trainer.predict(data, **kwargs)

    def train_on_batch(self, *args, **kwargs):
        """Train on a single batch."""
        return self.trainer.train_on_batch(*args, **kwargs)

    def test_on_batch(self, *args, **kwargs):
        """Test on a single batch."""
        return self.trainer.test_on_batch(*args, **kwargs)

    def predict_on_batch(self, *args, **kwargs):
        """Predict on a single batch."""
        return self.trainer.predict_on_batch(*args, **kwargs)

    def model_summary(self, *args, **kwargs):
        """Print information about model parameters."""
        return self.trainer.model_summary(*args, **kwargs)

    def export_freeze_graph(self, *args, **kwargs):
        """Export model as frozen pb."""
        return self.trainer.export_freeze_graph(*args, **kwargs)

    def dump_model(self, *args, **kwargs):
        """Dump model"""
        return self.trainer.dump_model(*args, **kwargs)

    def dump_checkpoint(self, *args, **kwargs):
        """Dump model to a checkpoint."""
        return self.trainer.dump_checkpoint(*args, **kwargs)


class DynaminModelWrapper(object):
    """
    在原始模型之外进行一层外包封装。
    动态地替换原模型的属性。
    """
    def __init__(self, execute_model):
        self.execute_model = execute_model  # 实际运行的模型
        self.overwrite_model_attr()

    def overwrite_model_attr(self):
        """模型优先使用wrapper模型的方法"""
        attr_names = [attr_name for attr_name in dir(self)
                      if not attr_name.startswith("__")]
        for attr_name in attr_names:
            if hasattr(self.execute_model, attr_name):
                logger.info(f"overwrite {attr_name} for original model {self.execute_model}")
                setattr(self.execute_model, attr_name, getattr(self, attr_name))

    def __getattr__(self, item):
        """若wrapper没有覆盖某属性，使用原模型的属性"""
        if hasattr(self.execute_model, item):
            return getattr(self.execute_model, item)
        else:
            raise AttributeError(f"{self} has not attribute {item} !")


class ModelWrapper(Model):
    def __init__(self, execute_model, **kwargs):
        self.execute_model = execute_model
        super(ModelWrapper, self).__init__(**kwargs)
