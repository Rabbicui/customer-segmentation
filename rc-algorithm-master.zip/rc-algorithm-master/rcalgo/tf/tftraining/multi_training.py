import os
import sys
import time

sys.path.append(os.path.join(os.path.abspath(
    os.path.dirname(__file__)), "../"))

from collections import defaultdict
from rcalgo.tf.tftraining.incremental_training import IncrementalTraining
from rcalgo.tf.tftraining.incremental_training import Task
from rcalgo.tf.utils.tf_func import replace_default_graph
from rcalgo.tf.utils.pretty_print import simplify_print

import numpy as np
import tensorflow as tf

try:
    __IPYTHON__
    from tqdm import tqdm_notebook as tqdm
except NameError:
    from tqdm import tqdm

class MultiTask(Task):

    STANDALONE_TYPE = 'standalone'
    JOINT_TYPE = 'joint'

    """
    A task which contains the train_steps and priority used for scheduling different tasks
    """
    def __init__(self, task_name, task_index):
        super(MultiTask, self).__init__(task_name, task_index)
        self.train_steps = tf.compat.v1.get_collection("{}_{}".format(task_name, tf.compat.v1.GraphKeys.TRAIN_STEPS))[0]
        self.priority = tf.compat.v1.get_collection("{}_{}".format(task_name, tf.compat.v1.GraphKeys.PRIORITY))[0]
        self.task_type = tf.compat.v1.get_collection("{}_{}".format(task_name, tf.compat.v1.GraphKeys.TASK_TYPE))[0]

    def __hash__(self):
        return hash(self.task_index)

    def __eq__(self, other):
        return other is not None and isinstance(other, Task) and self.task_index == other.task_index

    def __ne__(self, other):
        return not (self == other)

    def __str__(self):
        return self.task_name


class MultiDataIterator(object):
    def __init__(self, task_data_tuples, max_train_steps=None):
        """
        Args:
            task_data_tuples: A list of tuples. Each tuple is (task_name, train_batches, data_iterator)
                The data_iterator is ok to be None
            max_train_steps:
        """
        # compute the steps_count
        min_steps = sys.maxsize
        for data_tuple in task_data_tuples:
            if data_tuple[2] is not None:
                steps = len(data_tuple[2]) / data_tuple[1]     # len / train_batches
                min_steps = min(steps, min_steps)
        if max_train_steps is not None:
            min_steps = min(min_steps, max_train_steps)

        self.step_cnt = min_steps
        self.step_index = 0
        self.task_data_tuples = task_data_tuples

    def __iter__(self):
        return self

    def __len__(self):
        return self.step_cnt

    def __next__(self):
        """
        The next function returns a data mapping: key:task_name value:a list of batch, the size is
        based on given train_steps
        """
        if self.step_index >= self.step_cnt:
            raise StopIteration()
        else:
            res = {}
            for t in self.task_data_tuples:
                name = t[0]
                cnt = t[1]
                iterator = t[2]
                if iterator is not None:
                    # the DataIterator returns a tuple of idx, data
                    data = [next(iterator)[1] for _ in range(cnt)]
                else:
                    data = [None for _ in range(cnt)]
                res[name] = data
            self.step_index += 1
            return self.step_index, res

class MultiTraining(IncrementalTraining):
    """
    Specified training procedure for Multi tasks (e.g. GAN)
    """

    def __init__(self, model_input_dir, model_name, model_output_dir=None,
                 session=None, graph=None, learning_rates=None,
                 lr_annealing=True, lr_annealing_value=1.5, lr_annealing_stop_value=1e-5,
                 logs_dir="./logs", save_checkpoint=False, clear_devices=False, debug_mode=False):
        super(MultiTraining, self).__init__(model_input_dir, model_name, model_output_dir,
                                            session, graph, learning_rates, lr_annealing,
                                            lr_annealing_value, lr_annealing_stop_value,
                                            logs_dir, save_checkpoint, clear_devices, debug_mode)

    @replace_default_graph
    def _get_tasks(self, task_names):
        task_collection = [name.decode() if isinstance(name, bytes) else name for name in
                           tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TASKS)]
        if not task_names:
            task_names = [task_collection[0]]  # None treated as default, the 0th of task_names
        elif not isinstance(task_names, list):
            task_names = [task_names]
        return [MultiTask(task_name=name, task_index=task_collection.index(name)) for name in task_names]

    @replace_default_graph
    def _get_all_tasks(self):
        task_collection = [name.decode() if isinstance(name, bytes) else name for name in
                           tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TASKS)]
        return [MultiTask(task_name=name, task_index=task_collection.index(name)) for name in
                task_collection]

    def _run_epoch(self, named_data_iter, tasks, summary_step, max_train_steps=None, mode="train"):
        """
        Run the epoch. There will multi tasks each with different train steps and priority

        Args:
            named_data_iter:   A dict of data iter , key: task_name   value:DataIterator
            tasks:             A list of MultiTask
            summary_step:      No summary in this version
            mode:              Train or test

        Returns:
            The epoch_loss and epoch_metric for each task
        """
        batch_loss = defaultdict(list)
        batch_metric = defaultdict(list)
        # summary_flag = True if self.summary_op is not None and summary_step > 0 else False

        # sort tasks based on priority
        ranked_tasks = sorted(tasks, key=lambda t: t.priority)

        # we define the meaning of step here: each step will run each task given times
        # To visualize the training process, we wrap the data iterators into a composite one
        # build the MultiDataIterator
        tuples = []
        for task in ranked_tasks:
            if mode == 'train':
                tuples.append((task.task_name, task.train_steps, named_data_iter.get(task.task_name)))
            else:
                # in test the default step is 1
                tuples.append((task.task_name, 1, named_data_iter.get(task.task_name)))
        if mode == 'train':
            multi_data_iter = MultiDataIterator(tuples, max_train_steps)
        else:
            multi_data_iter = MultiDataIterator(tuples, sys.maxsize)

        # begin train process
        data_tqdm = tqdm(multi_data_iter, leave=False)
        task_processed_rows = {t: 0 for t in ranked_tasks}
        for idx, multi_batch in data_tqdm:
            for task in ranked_tasks:
                data_batches = multi_batch[task.task_name]
                for batch in data_batches:
                    # run each batch
                    # the batch could be None e.g. the generator in GAN don't need input
                    if batch is not None:
                        feed_key = task.inputs + task.targets  # merge two list
                        feed_dict = dict(zip(feed_key, batch))
                        batch_size = len(batch)
                    else:
                        feed_dict = {}
                        # here we don't need to specify the true batch_size
                        # each batch size should be same in internal graph
                        batch_size = 1
                    if self.is_training_op is not None:
                        feed_dict[self.is_training_op] = mode == "train"
                    if mode == "train":
                        lr_value, _, loss, metric = self.session.run([task.lr_variable,
                                                                      task.train_op, task.loss, task.metric],
                                                                     feed_dict=feed_dict)
                    else:  # mode == "test"
                        lr_value, loss, metric = self.session.run([task.lr_variable, task.loss, task.metric],
                                                        feed_dict=feed_dict)

                    task_processed_rows[task] += batch_size
                    avg_loss = np.mean(loss)
                    batch_loss[task].append(avg_loss * batch_size)
                    avg_metric = np.mean(metric)
                    batch_metric[task].append(avg_metric)

                data_tqdm.set_description_str("task:{}, lr_value: {}, loss:{:.4f}, metric:{:.4f}".format(
                    task.task_name, lr_value, avg_loss, avg_metric))

        epoch_loss = dict(
            (k, np.array(v).sum() / task_processed_rows[k]) for (k, v) in batch_loss.items())
        epoch_metric = dict(
            (k, np.array(v).sum() / task_processed_rows[k]) for (k, v) in batch_metric.items())
        return epoch_loss, epoch_metric

    @replace_default_graph
    def train(self, data_mapping, standalone_n_epochs=None, joint_n_epochs=1,
              task_names=None, on_epoch_finished_callbacks=None):
        tasks = self._filter_task(task_names)
        print('number of standalone train epochs: {}'.format(standalone_n_epochs))
        print('number of joint train epochs: {}'.format(joint_n_epochs))
        print('tasks: {}'.format(tasks))
        if on_epoch_finished_callbacks is None:
            on_epoch_finished_callbacks = []
        elif not isinstance(on_epoch_finished_callbacks, list):
            on_epoch_finished_callbacks = [on_epoch_finished_callbacks]

        # run standalone tasks first
        standalone_tasks = [task for task in tasks if task.task_type == MultiTask.STANDALONE_TYPE]
        standalone_tasks = sorted(standalone_tasks, key=lambda t: t.priority)
        for task in standalone_tasks:
            n_epochs = standalone_n_epochs[task.task_name]
            print('run standalone task {}'.format(task))
            self._run_epochs(n_epochs, [task], data_mapping, on_epoch_finished_callbacks)

        joint_tasks = [task for task in tasks if task.task_type == MultiTask.JOINT_TYPE]
        # run joint_tasks
        print('run joint tasks {}'.format(joint_tasks))
        self._run_epochs(joint_n_epochs, joint_tasks, data_mapping, on_epoch_finished_callbacks)

    def _run_epochs(self, n_epochs, tasks, data_mapping, on_epoch_finished_callbacks):
        if tasks is None or len(tasks) == 0:
            return
        for epoch in range(n_epochs):
            start_time = time.time()

            # create data iterators
            data_iter_mapping = self._create_data_mapping(tasks, data_mapping, 'train')
            epoch_train_loss, epoch_train_metric = self._run_epoch(data_iter_mapping, tasks,
                                                                   self.summary_step, mode="train")
            end_time = time.time()
            print("epoch {} train time(sec): {}".format(epoch, end_time - start_time))
            # todo best for each
            if self.best_train_metric is None or self._is_all_larger(epoch_train_metric,
                                                                     self.best_train_metric):
                self.best_train_metric = epoch_train_metric

            start_time = time.time()
            data_iter_mapping = self._create_data_mapping(tasks, data_mapping, 'test')
            epoch_test_loss, epoch_test_metric = self._run_epoch(data_iter_mapping, tasks,
                                                                 self.summary_step, mode="test")
            end_time = time.time()
            print("epoch {} test time(sec): {}".format(epoch, end_time - start_time))
            if self.save_checkpoint:
                self.dump_checkpoint(self._get_dump_path(epoch=epoch))
            if self.best_test_metric is None or self._is_all_larger(epoch_test_metric,
                                                                    self.best_test_metric):
                self.best_test_metric = epoch_test_metric
                if self.save_checkpoint:
                    self.dump_checkpoint()

            simplify_print({
                "epoch_index": epoch,
                "train_loss": dict((k.task_name, v) for (k, v) in epoch_train_loss.items()),
                "train_metric": dict((k.task_name, v) for (k, v) in epoch_train_metric.items()),
                "validate_loss": dict((k.task_name, v) for (k, v) in epoch_test_loss.items()),
                "validate_metric": dict(
                    (k.task_name, v) for (k, v) in epoch_test_metric.items()),
                "best_train_metric": dict(
                    (k.task_name, v) for (k, v) in self.best_train_metric.items()),
                "best_validate_metric": dict(
                    (k.task_name, v) for (k, v) in self.best_test_metric.items())
            })

            for callback in on_epoch_finished_callbacks:
                callback(self, epoch)
            if self.lr_annealing and self.prev_test_loss is not None and all(task in self.prev_test_loss.keys() for task in tasks):
                self._try_adjust_lr(epoch_test_loss, self.prev_test_loss)
            self.prev_test_loss = epoch_test_loss
            learning_rates = self.session.run([t.lr_variable for t in tasks])
            if self.lr_annealing and any(
                    lr_value < self.lr_annealing_stop_value for lr_value in learning_rates):
                break

    def _create_data_mapping(self, tasks, data_mapping, mode):
        # create data iterators
        data_iter_mapping = {}
        for t in tasks:
            name = t.task_name
            data = data_mapping.get(name)
            if data is not None:
                data_iter_mapping[name] = data.create_iterator(mode=mode)
        return data_iter_mapping
