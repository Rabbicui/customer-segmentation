import tensorflow as tf

def load_ckpt_weights(path):
    sess = tf.compat.v1.keras.backend.get_session()
    with sess.graph.as_default():
        ckpt_vars = tf.train.list_variables(path)
        ckpt_vars = set([var_shape[0] for var_shape in ckpt_vars])
        all_vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES)
        all_vars = [var for var in all_vars if var.name.split(':')[0] in ckpt_vars]
        saver = tf.compat.v1.train.Saver(all_vars)
        saver.restore(sess, path)

