from PIL import Image
from PIL import ImageFile
from torch.utils.data import Dataset
import os

ImageFile.LOAD_TRUNCATED_IMAGES = True


class LabeledCustomData(Dataset):
    def __init__(self, images, labels, transforms=None):
        assert len(images) == len(labels) != 0 and os.path.exists(images[0])

        n_len = len(images)
        samples = [(images[i], labels[i]) for i in range(n_len)]

        self.records = samples
        self.dataset_len = len(self.records)

        self.transforms = transforms

    def __len__(self):
        return self.dataset_len

    def __getitem__(self, item):
        record = self.records[item]
        img_name = record[0]
        label = record[1]
        with Image.open(img_name) as img:
            img = img.convert('RGB')

        if self.transforms is not None:
            try:
                preprocess = self.transforms
                img = preprocess(img)
            except Exception as e:
                print(f"Cannot transform image: {img_name}, Error info: {e}")

                import sys
                sys.exit(0)
            return img, label
        return img, label


class UnlabeledCustomData(Dataset):
    def __init__(self, images, transforms=None):
        assert len(images) > 0 and os.path.exists(images[0])

        self.records = images
        self.dataset_len = len(self.records)

        self.transforms = transforms

    def __len__(self):
        return self.dataset_len

    def __getitem__(self, item):
        img_name = self.records[item]

        with Image.open(img_name) as img:
            img = img.convert('RGB')

        if self.transforms is not None:
            try:
                preprocess = self.transforms
                img = preprocess(img)
            except Exception as e:
                print(f"Cannot transform image: {img_name}, Error info: {e}")
            return img, img_name
        return img, img_name
