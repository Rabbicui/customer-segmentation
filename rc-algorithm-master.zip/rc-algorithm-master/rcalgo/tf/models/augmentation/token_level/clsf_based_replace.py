import sys
import os
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))
    
from rcalgo.tf.models.augmentation.token_level.base_token_replace import TokenReplace
import tensorflow as tf
import jieba
import numpy as np


class ClassifierBasedReplace(TokenReplace):
    def __init__(self, clsf, sentences, need_cut):
        """
        主要参考对抗样本生成中基于贪心的词替换方法
        依赖给定任务的分类模型计算词的重要性判断：词替换前后分类模型的概率值变化，变化越大说明被替换的词越重要
        :param clsf:
        :param sentences:
        :param need_cut:
        """
        super(ClassifierBasedReplace, self).__init__(sentences, need_cut)
        self.sentences = sentences
        self.clsf = clsf

        self.orig_probs_list = clsf.get_probs(self.sentences)  # 原数据的分类预测概率
        self.reset_token_list()
        self.reset_random_prob()

    def _replace_tokens(self, idx, tokens, token_prob, times):
        ret_tokens = []
        importance = self.compute_score(self.orig_probs_list[idx], tokens)
        for i in range(times):
            new_tokens = []
            replace_probs = self.get_replace_probs(tokens, token_prob, importance)
            for j in range(len(tokens)):
                if self.get_random_prob() < replace_probs[j]:
                    new_tokens.append(self.get_random_token())
                else:
                    new_tokens.append(tokens[j])
            ret_tokens.append("".join(new_tokens))
        return ret_tokens

    def get_replace_probs(self, tokens, token_prob, importance):
        replace_prob = []
        for i, word in enumerate(tokens):
            replace_prob.append(importance[i])
        replace_prob = np.array(replace_prob)
        # 重要性越高被替换概率越小，这里加一个0.1的bias保证当前分类器下最重要的词也有被替换的机会
        replace_prob = np.max(replace_prob) - replace_prob + 0.1
        replace_prob = (replace_prob / replace_prob.sum() * token_prob * len(tokens))
        return replace_prob

    def replace(self, token_prob=0.1, times=1):
        ret_texts = []
        for i, text in enumerate(self.sentences):
            aug_texts = []
            if self.need_cut:
                tokens = list(jieba.cut(text))
            else:
                tokens = list(text)
            aug_texts.extend(self._replace_tokens(i, tokens, token_prob, times))
            ret_texts.append(aug_texts)
            if i % 100 == 0:
                print("has processed %d lines" % i)
        return ret_texts

    def reset_token_list(self):
        """Generate many random tokens at the same time and cache them."""
        self.token_list = list(self.vocab.keys())
        self.token_ptr = len(self.token_list) - 1
        np.random.shuffle(self.token_list)

    def detokenizer(self, tokens):
        return "".join(tokens)

    def compute_score(self, orig_probs, orig_tokens):
        return [0.0 for _ in range(len(orig_tokens))]


class TextFoolerReplace(ClassifierBasedReplace):
    """
     Is BERT Really Robust? A Strong Baseline for Natural Language Attack on Text Classification and Entailment. Di Jin, Zhijing Jin, Joey Tianyi Zhou, Peter Szolovits. AAAI 2020.
        `[pdf] <https://arxiv.org/pdf/1907.11932v4>`__
        `[code] <https://github.com/jind11/TextFooler>`__
    词重要性的计算方法：
    Iwi = Fy(X) - Fy(X\wi) , if F(X) = F(X\wi) == y;
    Iwi = (Fy(X) - Fy(X\wi)) + (Fy*(X\wi) - Fy*(X)), if F(X) = y, F(X\wi) = y* and y ≠ y*
    """
    def __init__(self, clsf, sentences, need_cut):
        super(TextFoolerReplace, self).__init__(clsf, sentences, need_cut)

    def compute_score(self, orig_probs, orig_tokens):
        orig_prob_max = np.max(orig_probs)
        orig_pred_label = np.argmax(orig_probs)

        leave_1_texts = [orig_tokens[:ii] + [' '] + orig_tokens[ii+1: ] for ii in range(len(orig_tokens))]
        leave_1_probs = self.clsf.get_probs([self.detokenizer(text) for text in leave_1_texts])
        leave_1_probs_argmax = np.argmax(leave_1_probs, axis=1)

        importance = orig_prob_max - leave_1_probs[:, orig_pred_label].squeeze() + \
                     (leave_1_probs_argmax != orig_pred_label).astype(np.float) * (np.max(leave_1_probs, axis=1) - orig_probs.squeeze()[leave_1_probs_argmax])
        return importance


class PWWSReplace(ClassifierBasedReplace):
    """
    Generating Natural Language Adversarial Examples through Probability Weighted Word Saliency. Shuhuai Ren, Yihe Deng, Kun He, Wanxiang Che. ACL 2019.
        `[pdf] <https://www.aclweb.org/anthology/P19-1103.pdf>`__
        `[code] <https://github.com/JHL-HUST/PWWS/>`__
    论文中计算词的显著性即重要性的方法：
    Swi = Fy(X) - Fy(X\wi) 替换的wi用UNK表示
    """
    def __init__(self, clsf, sentences, need_cut):
        super(PWWSReplace, self).__init__(clsf, sentences, need_cut)

    def compute_score(self, orig_probs, orig_tokens):
        orig_prob_max = np.max(orig_probs)
        orig_pred_label = np.argmax(orig_probs)

        leave_1_texts = [orig_tokens[:ii] + ['<UNK>'] + orig_tokens[ii + 1:] for ii in range(len(orig_tokens))]
        leave_1_probs = self.clsf.get_probs([self.detokenizer(text) for text in leave_1_texts])

        importance = orig_prob_max - leave_1_probs[:, orig_pred_label]
        return importance


class DeepWordBugReplace(ClassifierBasedReplace):
    """
    Black-box Generation of Adversarial Text Sequences to Evade Deep Learning Classifiers. Ji Gao, Jack Lanchantin, Mary Lou Soffa, Yanjun Qi. IEEE SPW 2018.
        `[pdf] <https://ieeexplore.ieee.org/document/8424632>`__
        `[code] <https://github.com/QData/deepWordBug>`__
    论文中计算词的重要性有三种方法，计算词消失后的loss向量
    1. Temporal Score(TS)：
    TS(wi) = F(w1, w2, ..., wi-1, wi) - F(w1, w2, ..., wi-1)
    2. Temporal Tail Score(TTS):
    TTS(wi) = F(wi, wi+1, wi+2, ..., wn) - F(wi+1, wi+2, ..., wn)
    3. Combined Score:
    Combined Score = TS + a * TTS
    """
    def __init__(self, clsf, sentences, need_cut, score_type='combine'):
        super(DeepWordBugReplace, self).__init__(clsf, sentences, need_cut)
        self.score_type = score_type

    def temporal_score(self, orig_probs, orig_tokens):
        orig_pred_label = np.argmax(orig_probs)

        leave_1_texts = [orig_tokens[: i + 1] for i in range(len(orig_tokens))]
        leave_1_probs = self.clsf.get_probs([self.detokenizer(text) for text in leave_1_texts])

        importance = []
        for i in range(len(orig_tokens)):
            if i == 0:
                importance.append(abs(leave_1_probs[0][orig_pred_label]))
            else:
                importance.append(abs(leave_1_probs[i][orig_pred_label] - leave_1_probs[i-1][orig_pred_label]))
        return np.array(importance)

    def temporal_tail_score(self, orig_probs, orig_tokens):
        orig_pred_label = np.argmax(orig_probs)

        leave_1_texts = [orig_tokens[i:] for i in range(len(orig_tokens))]
        leave_1_probs = self.clsf.get_probs([self.detokenizer(text) for text in leave_1_texts])

        importance = []
        for i in range(len(orig_tokens)):
            if i == len(orig_tokens) - 1:
                importance.append(abs(leave_1_probs[i][orig_pred_label]))
            else:
                importance.append(abs(leave_1_probs[i][orig_pred_label] - leave_1_probs[i+1][orig_pred_label]))
        return np.array(importance)

    def combine_score(self, orig_probs, orig_tokens):
        '''这里不再引入参数a，直接取均值'''
        ts = self.temporal_score(orig_probs, orig_tokens)
        tts = self.temporal_tail_score(orig_probs, orig_tokens)
        return (ts + tts) / 2.0

    def compute_score(self, orig_probs, orig_tokens):
        if self.score_type == 'ts':
            return self.temporal_score(orig_probs, orig_tokens)
        elif self.score_type == 'tts':
            return self.temporal_tail_score(orig_probs, orig_tokens)
        else:
            return self.combine_score(orig_probs, orig_tokens)


class Classifier(object):
    def __init__(self, cls_frozen_pb_path, input_index, output_index):
        """
        reload classifier model from frozen pb
        :param cls_frozen_pb_path: pb path
        :param input_index:
        :param output_index:
        """
        self.session, self.input_tensor, self.output_tensor = self.restore_model_from_pb(cls_frozen_pb_path,
                                                                                         input_index, output_index)

    @staticmethod
    def restore_model_from_pb(frozen_pb_path, input_index, output_index):
        gpu_options = tf.GPUOptions(allow_growth=True, per_process_gpu_memory_fraction=0.5)
        config = tf.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True)
        session = tf.Session(config=config, graph=tf.Graph())
        with session.graph.as_default():
            tf.train.import_meta_graph(frozen_pb_path)
            session.run(tf.tables_initializer())
            input_tensor_names = [var.name for var in tf.get_collection("input_dict")]
            output_tensor_names = [var.name for var in tf.get_collection("output_dict")]
            input_tensor = input_tensor_names[input_index]
            output_tensor = output_tensor_names[output_index]
        return session, input_tensor, output_tensor

    def get_probs(self, texts):
        probs = []
        batch_size = 128
        for i in range(0, len(texts), batch_size):
            outputs = self.session.run(self.output_tensor, feed_dict={self.input_tensor: texts[i: i + batch_size]})
            probs.extend(outputs)
        return np.array(probs)


def test():
    default_pb_path = '/your/path/to/classifier/frozen.pb'
    clsf = Classifier(cls_frozen_pb_path=default_pb_path,
                      input_index=0, output_index=-1)
    sentences = ['B账号违规申诉', '账号被处理', '用户表示自己没有发违规内容', '我都不知道因为啥给我封死了']
    # clsf_based_rep = TextFoolerReplace(clsf, sentences, need_cut=False)
    # clsf_based_rep = PWWSReplace(clsf, sentences, need_cut=False)
    clsf_based_rep = DeepWordBugReplace(clsf, sentences, need_cut=False, score_type='combine')
    texts = clsf_based_rep.replace(token_prob=0.2, times=1)
    print(texts)


if __name__ == '__main__':
    test()
