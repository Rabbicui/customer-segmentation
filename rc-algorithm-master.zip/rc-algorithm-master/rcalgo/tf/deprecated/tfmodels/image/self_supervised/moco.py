import numpy as np
import os
import tensorflow as tf

from tensorpack.callbacks import (
    Callback, EstimatedTimeLeft, ModelSaver, ThroughputTracker)
from tensorpack.dataflow import DataFromList

from tensorpack.input_source import QueueInput
from tensorpack.models import BatchNorm, l2_regularizer, regularize_cost
from tensorpack.tfutils import argscope, varreplace
from tensorpack.tfutils.summary import add_moving_summary
from tensorpack.train import (
    HorovodTrainer, ModelDesc, TrainConfig, launch_train_with_config)
from tensorpack.utils import logger

# import horovod.tensorflow as hvd
import sys
from rcalgo.tf.tfmodels.image.utils.aug_tools import distorted_bounding_box_crop
import horovod.tensorflow as hvd
from rcalgo.tf.tfmodels.image.self_supervised import resnet_model
from tftools.tf_layer import my_full_connected

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../"))

def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict

d1 = unpickle('../data/data_batch_1')
d2 = unpickle('../data/data_batch_2')
d3 = unpickle('../data/data_batch_3')
d4 = unpickle('../data/data_batch_4')
d5 = unpickle('../data/data_batch_5')
l1 = np.array(d1[b'labels'])
l2 = np.array(d2[b'labels'])
l3 = np.array(d3[b'labels'])
l4 = np.array(d4[b'labels'])
l5 = np.array(d5[b'labels'])
labels = np.concatenate([l1, l2, l3, l4, l5], axis=0)
def to_array(data):
    images = []
    i = 0
    for img in data[b'data']:
        red = img[0:1024].reshape([32, 32, 1])
        blue = img[1024:2048].reshape([32, 32, 1])
        black = img[2048:].reshape([32, 32, 1])
        images.append(np.concatenate([red, blue, black], axis=2))
    images = np.array(images)
    return images

d1 = to_array(d1)
d2 = to_array(d2)
d3 = to_array(d3)
d4 = to_array(d4)
d5 = to_array(d5)

local_batch_size = 64
images = np.concatenate([d1,d2,d3,d4,d5], axis=0)

list_images = []
for i in range(0, int(len(images) / local_batch_size) * local_batch_size, local_batch_size):
    list_images.append([images[i: i+local_batch_size]])

print('len ' + str(len(images)))
def color_distortion2(image, s=1.0):
    # image is a tensor with value range in [0, 1].
    # s is the strength of color distortion.
    def color_jitter(x):
        # one can also shuffle the order of following augmentations
        # each time they are applied.
        x = tf.image.random_brightness(x, max_delta=0.8 * s)
        x = tf.image.random_contrast(x, lower=1 - 0.8 * s, upper=1 + 0.8 * s)
        x = tf.image.random_saturation(x, lower=1 - 0.8 * s, upper=1 + 0.8 * s)
        x = tf.image.random_hue(x, max_delta=0.2 * s)
        x = tf.clip_by_value(x, 0, 1)
        return x

    def color_drop(x):
        x = tf.image.rgb_to_grayscale(x)
        x = tf.tile(x, [1, 1, 3])
        return x

    def random_apply(func, inp, prob):
        n = tf.random.uniform(shape=[], dtype=tf.float32)
        r = tf.cond(n <= prob, lambda: func(inp), lambda: inp)
        return r

    # randomly apply transformation with probability p.
    image = random_apply(color_jitter, image, 0.8)
    image = random_apply(color_drop, image, 0.2)
    return image

BASE_LR = 0.05

def allgather(tensor, name):
    tensor = tf.identity(tensor, name=name + "_HVD")
    return hvd.allgather(tensor)


def batch_shuffle(tensor):  # nx...
    total, rank = hvd.size(), hvd.rank()
    batch_size = tf.shape(tensor)[0]
    with tf.device('/cpu:0'):
        all_idx = tf.range(total * batch_size)
        shuffle_idx = tf.random.shuffle(all_idx)
        shuffle_idx = hvd.broadcast(shuffle_idx, 0)
        my_idxs = tf.slice(shuffle_idx, [rank * batch_size], [batch_size])

    all_tensor = allgather(tensor, 'batch_shuffle_key')  # gn x ...
    return tf.gather(all_tensor, my_idxs), shuffle_idx


def batch_unshuffle(key_feat, shuffle_idxs):
    rank = hvd.rank()
    inv_shuffle_idx = tf.argsort(shuffle_idxs)
    batch_size = tf.shape(key_feat)[0]
    my_idxs = tf.slice(inv_shuffle_idx, [rank * batch_size], [batch_size])
    all_key_feat = allgather(key_feat, "batch_unshuffle_feature")  # gn x c
    return tf.gather(all_key_feat, my_idxs)


class MOCOModel(ModelDesc):
    def __init__(self, batch_size, feature_dims=(128,), temp=0.07):
        self.batch_size = batch_size
        self.feature_dim = feature_dims[-1]
        # NOTE: implicit assume queue_size % (batch_size * GPU) ==0
        self.queue_size = 65536
        self.temp = temp
        self.image_shape = 32

    def inputs(self):
        return [tf.TensorSpec([self.batch_size, self.image_shape, self.image_shape, 3], tf.uint8,
                              'query')]

    def data_augmentation(self, query):
        # the key part to the self supervised learning
        # random cropping (with flip) and color distortion and gaussian blur
        def image_aug(inp):
            bbox = tf.constant([0.0, 0.0, 1.0, 1.0], dtype=tf.float32, shape=[1, 1, 4])
            cropped_inp, _ = distorted_bounding_box_crop(inp, bbox,
                                                         area_range=[0.2, 1],
                                                         aspect_ratio_range=[3 / 4, 4 / 3])
            cropped_inp = tf.image.resize_bicubic([cropped_inp], [self.image_shape, self.image_shape])[0]
            cropped_inp = tf.image.random_flip_left_right(cropped_inp)
            color_inp = color_distortion2(cropped_inp, s=0.5)
            # set kernel_size to 1/10 of hidth
            kernel_size = int(32 / 10)
            if kernel_size % 2 == 0:
                kernel_size += 1
            color_inp.set_shape([32, 32, 3])
            blur_inp = color_inp
            return blur_inp

        aug1 = tf.map_fn(image_aug, query, dtype=tf.float32)
        aug2 = tf.map_fn(image_aug, query, dtype=tf.float32)
        return aug1, aug2

    def net_forward(self, data):
        with tf.variable_scope('./backbone'):
            backbone = resnet_model.Model(resnet_size=50,
                                          bottleneck=True,
                                          num_classes=2,
                                          num_filters=64,
                                          kernel_size=3,
                                          conv_stride=1,
                                          first_pool_size=3,
                                          first_pool_stride=2,
                                          block_sizes=[3, 4, 6, 3],
                                          block_strides=[1, 2, 2, 2],
                                          resnet_version=1,
                                          data_format='channels_first',
                                          dtype=resnet_model.DEFAULT_DTYPE)
            embeddings = backbone(data, True, classify=False)
        with tf.variable_scope('./linear'):
            embeddings = my_full_connected(embeddings, 2048, act=tf.nn.relu, layer_name='non_linear_projection',
                                           weights_initializer=tf.random_normal_initializer(stddev=0.01))
            embeddings = my_full_connected(embeddings, 128, act=tf.identity, weights_initializer=tf.random_normal_initializer(stddev=0.01), layer_name='linear_projection')
        return embeddings

    def build_graph(self, query):
        # setup queue
        queue_init = tf.math.l2_normalize(
            tf.random.normal([self.queue_size, self.feature_dim]), axis=1)
        queue = tf.get_variable('queue', initializer=queue_init, trainable=False)
        queue_ptr = tf.get_variable(
            'queue_ptr',
            [], initializer=tf.zeros_initializer(),
            dtype=tf.int64, trainable=False)
        tf.add_to_collection(tf.GraphKeys.MODEL_VARIABLES, queue)
        tf.add_to_collection(tf.GraphKeys.MODEL_VARIABLES, queue_ptr)

        query = query / 255
        # aug image
        query, key = self.data_augmentation(query)
        #query = query / 255
        #key = key / 255

        # query encoder
        q_feat = self.net_forward(query)  # NxC
        q_feat = tf.math.l2_normalize(q_feat, axis=1)

        # key encoder
        shuffled_key, shuffle_idxs = batch_shuffle(key)
        shuffled_key.set_shape([self.batch_size, None, None, None])
        with tf.variable_scope("momentum_encoder"), \
             varreplace.freeze_variables(skip_collection=True), \
             argscope(BatchNorm, ema_update='skip'):  # don't maintain EMA (will not be used at all)
            # set in inference model, won't update the batch norm
            key_feat = self.net_forward(shuffled_key)
        key_feat = tf.math.l2_normalize(key_feat, axis=1)  # NxC
        key_feat = batch_unshuffle(key_feat, shuffle_idxs)
        key_feat = tf.stop_gradient(key_feat)

        # loss
        l_pos = tf.reshape(tf.einsum('nc,nc->n', q_feat, key_feat), (-1, 1))  # nx1
        l_neg = tf.einsum('nc,kc->nk', q_feat, queue)  # nxK
        logits = tf.concat([l_pos, l_neg], axis=1)  # nx(1+k)
        logits = logits * (1 / self.temp)
        labels = tf.zeros(self.batch_size, dtype=tf.int64)  # n
        loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits, labels=labels)
        loss = tf.reduce_mean(loss, name='xentropy-loss')

        acc = tf.reduce_mean(tf.cast(
            tf.equal(tf.math.argmax(logits, axis=1), labels), tf.float32), name='train-acc')

        # update queue (depend on l_neg)
        with tf.control_dependencies([l_neg]):
            queue_push_op = self.push_queue(queue, queue_ptr, key_feat)
            tf.add_to_collection(tf.GraphKeys.UPDATE_OPS, queue_push_op)

        wd_loss = regularize_cost("^((?!batch_norm).)*$", l2_regularizer(0.000003), name='l2_regularize_loss')
        add_moving_summary(acc, loss, wd_loss)
        total_cost = tf.add_n([loss, wd_loss], name='cost')
        return total_cost

    def push_queue(self, queue, queue_ptr, item):
        # queue: KxC
        # item: NxC
        item = allgather(item, 'queue_gather')  # GN x C
        batch_size = tf.shape(item, out_type=tf.int64)[0]
        end_queue_ptr = queue_ptr + batch_size

        inds = tf.range(queue_ptr, end_queue_ptr, dtype=tf.int64)
        with tf.control_dependencies([inds]):
            queue_ptr_update = tf.assign(queue_ptr, end_queue_ptr % self.queue_size)
        queue_update = tf.scatter_update(queue, inds, item)
        return tf.group(queue_update, queue_ptr_update)

    def optimizer(self):
        # cosine LR in v2
        #gs = tf.train.get_or_create_global_step()
        #total_steps = int(len(images) / local_batch_size) * 250
        #lr = BASE_LR * 0.5 * (1 + tf.cos(gs / total_steps * np.pi))
        return tf.compat.v1.train.AdamOptimizer(0.0003)
        #tf.summary.scalar('learning_rate-summary', lr)
        #opt = tf.train.MomentumOptimizer(lr, 0.9, use_nesterov=True)
        #return opt

class UpdateMomentumEncoder(Callback):
    _chief_only = False  # execute it in every worker
    momentum = 0.999

    def _setup_graph(self):
        nontrainable_vars = tf.get_collection(tf.GraphKeys.MODEL_VARIABLES)
        all_vars = {v.name: v for v in tf.global_variables() + tf.local_variables()}
        logger.info("all  nontrainable vars." + str(nontrainable_vars))

        # find variables of encoder & momentum encoder
        self._var_mapping = {}  # var -> mom var
        momentum_prefix = "momentum_encoder/"
        for mom_var in nontrainable_vars:
            if momentum_prefix in mom_var.name:
                q_encoder_name = mom_var.name.replace(momentum_prefix, "")
                q_encoder_var = all_vars[q_encoder_name]
                assert q_encoder_var not in self._var_mapping
                if not q_encoder_var.trainable:  # don't need to copy EMA
                    continue
                self._var_mapping[q_encoder_var] = mom_var

        logger.info(f"Found {len(self._var_mapping)} pairs of matched variables.")

        assign_ops = [tf.assign(mom_var, var) for var, mom_var in self._var_mapping.items()]
        self.assign_op = tf.group(*assign_ops, name="initialize_momentum_encoder")

        update_ops = [tf.assign_add(mom_var, (var - mom_var) * (1 - self.momentum))
                      for var, mom_var in self._var_mapping.items()]
        self.update_op = tf.group(*update_ops, name="update_momentum_encoder")

    def _before_train(self):
        logger.info("Copying encoder to momentum encoder ...")
        self.assign_op.run()

    def _trigger_step(self):
        self.update_op.run()


def get_config(model):
    nr_tower = 8
    batch = local_batch_size
    logger.info("Running on {} towers. Batch size per tower: {}".format(nr_tower, batch))

    callbacks = [
        ThroughputTracker(8 * local_batch_size),
        UpdateMomentumEncoder()
    ]

    data = QueueInput(DataFromList(list_images),
                      queue=tf.FIFOQueue(2000, [tf.uint8], [[batch, 32, 32, 3]]))

    callbacks.extend([
        ModelSaver(),
        EstimatedTimeLeft(),
    ])

    return TrainConfig(
        model=model,
        data=data,
        callbacks=callbacks,
        steps_per_epoch=int(len(images) / local_batch_size),
        max_epoch=250,
    )


hvd.init()
model = MOCOModel(batch_size=local_batch_size, feature_dims=(2048, 128), temp=0.1)
if hvd.rank() == 0:
    logdir = './cifar_10'
    logger.set_logger_dir(logdir, 'n')
logger.info("Rank={}, Local Rank={}, Size={}".format(hvd.rank(), hvd.local_rank(), hvd.size()))

config = get_config(model)
trainer = HorovodTrainer(average=True)
launch_train_with_config(config, trainer)
