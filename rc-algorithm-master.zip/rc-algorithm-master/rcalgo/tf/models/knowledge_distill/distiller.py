import re
import tensorflow as tf

from rcalgo.tf.training import Model, context
from rcalgo.tf.training import training_utils

from .adaptors import BasicAdaptor
from .losses import SoftTargetCrossEntropyLoss, TinyBertLoss


class GeneralDistiller(Model):
    """Knowledge Distillation."""
    def __init__(self, config,
                 teacher, student, student_variable_scope,
                 adaptor_t=BasicAdaptor(), adaptor_s=BasicAdaptor(),
                 loss_func=TinyBertLoss(),
                 name="distiller", **kwargs):
        super(GeneralDistiller, self).__init__(config=config, name=name, **kwargs)

        self.teacher = teacher
        self.student = student
        self.student_variable_scope = student_variable_scope

        self.adaptor_t = adaptor_t
        self.adaptor_s = adaptor_s

        self.loss_func = loss_func

        # build model directly for convenience
        self.build_model(**kwargs)

    def compute_loss(self, features_t, features_s):
        return self.loss_func(features_t, features_s)

    def filter_trainable_variables(self, tvars):
        """Variables of teacher should be fixed."""
        regex_student = re.compile(self.student_variable_scope)
        regex_distiller = re.compile("distiller_scope")
        tvars = [
            var for var in tvars
            if regex_student.match(var.name) or regex_distiller.match(var.name)
        ]
        return tvars

    def build_forward(self):
        """Build distiller
        """
        if isinstance(self.teacher.inputs, (list, tuple)):
            teacher_inputs = self.teacher.inputs
        else:
            teacher_inputs = [self.teacher.inputs]

        if isinstance(self.student.inputs, (list, tuple)):
            student_inputs = self.student.inputs
        else:
            student_inputs = [self.student.inputs]

        self.inputs = teacher_inputs + student_inputs
        self.labels = self.student.labels
        self.outputs = self.student.outputs
        self.metrics = self.student.metrics

        with tf.variable_scope("distiller_scope"):
            features_t = self.adaptor_t(self.teacher)
            features_s = self.adaptor_s(self.student)
            self.loss = self.compute_loss(features_t, features_s)  # distill loss

        self.add_extra_attrs(features_t, features_s)
        training_utils.create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)

    def _build_optimization(self, *args, **kwargs):
        """Use optimization of base class."""
        super()._build_optimization(*args, **kwargs)

    def add_extra_attrs(self, features_t, features_s):
        """Add extra nodes to graph collections."""
        pass


class TinyBertDistiller(GeneralDistiller):
    """A distiller using tinybert_loss as loss function."""
    def __init__(self, config,
                 teacher, student, student_variable_scope,
                 adaptor_t=BasicAdaptor, adaptor_s=BasicAdaptor,
                 name="tiny_bert_distiller", **kwargs):
        super(TinyBertDistiller, self).__init__(
            config=config, teacher=teacher, student=student,
            student_variable_scope=student_variable_scope,
            adaptor_t=adaptor_t, adaptor_s=adaptor_s,
            loss_func=TinyBertLoss(), name=name, **kwargs)
