import tensorflow as tf

from rcalgo.tf.utils.logging import logger

from .projections import linear_projection


def mse(labels, preds):
    assert preds.shape.as_list() == labels.shape.as_list()
    # reduce_axis = [i for i in range(1, len(preds.shape))]
    # per_example_loss = tf.reduce_mean(
    #     tf.square(labels - preds), axis=reduce_axis)
    loss = tf.reduce_mean(tf.square(labels - preds))
    return loss


def cross_entropy(logits, labels, num_labels):
    log_probs = tf.nn.log_softmax(logits, axis=-1)
    one_hot_labels = tf.one_hot(labels, depth=num_labels, dtype=tf.float32)
    per_example_loss = -tf.reduce_sum(one_hot_labels * log_probs, axis=-1)
    loss = tf.reduce_mean(per_example_loss)
    return loss


def soft_target_cross_entropy(logits_t, logits_s, temperature=1.0):
    logits_t = logits_t / temperature
    logits_s = logits_s / temperature
    teacher_probs = tf.nn.softmax(logits_t, axis=-1)
    student_likelihood = tf.nn.log_softmax(logits_s, axis=-1)
    per_example_loss = -tf.reduce_sum(teacher_probs * student_likelihood, axis=-1)
    loss = tf.reduce_mean(per_example_loss)
    return loss


class BaseKDLoss(object):
    def __call__(self, *args, **kwargs):
        return self.call(*args, **kwargs)

    def call(self, logits_t, logits_s):
        raise NotImplementedError


class MSELoss(BaseKDLoss):
    def call(labels, preds):
        return mse(labels, preds)


class CrossEntropyLoss(BaseKDLoss):
    def __init__(self, num_labels):
        self.num_labels = num_labels

    def call(self, logits, labels):
        return cross_entropy(logits, labels, self.num_labels)


def SoftTargetCrossEntropyLoss(BaseKDLoss):
    def __init__(self, temperature=1.0):
        self.temperature = temperature

    def call(self, logits_t, logits_s):
        return soft_target_cross_entropy(logits_t, logits_s, self.temperature)


class TinyBertLoss(BaseKDLoss):
    def __init__(self, emb_loss_weight=1.0, attn_loss_weight=1.0,
                 hidden_loss_weight=1.0, logits_loss_weight=1.0,
                 pred_loss_ratio=0.1):
        self.emb_loss_weight = emb_loss_weight
        self.attn_loss_weight = attn_loss_weight
        self.hidden_loss_weight = hidden_loss_weight
        self.logits_loss_weight = logits_loss_weight
        self.pred_loss_ratio = pred_loss_ratio

    def call(self, results_t, results_s):
        """Implement of tiny bert loss."""
        distill_loss = 0.0

        if self.logits_loss_weight > 0:
            with tf.name_scope("logits_distill"):
                logits_loss = soft_target_cross_entropy(
                    results_t["logits"], results_s["logits"])
                distill_loss += logits_loss * self.logits_loss_weight

        if self.emb_loss_weight > 0:
            with tf.variable_scope("embedding_distill"):
                embedding_t = results_t["embedding"]
                embedding_s = results_s["embedding"]
                if embedding_t.shape[0].value == embedding_s.shape[0].value:
                    embedding_s = linear_projection(
                        embedding_s,
                        embedding_t.shape[-1].value,
                        name="embedding_projection")
                    emb_loss = mse(embedding_t, embedding_s)
                    distill_loss += emb_loss * self.emb_loss_weight
                else:
                    logger.warning("Shape of embedding matrix is not consistent"
                                   "between teacher and student, will skip"
                                   "embedding distill loss!")

        if self.hidden_loss_weight > 0:
            with tf.variable_scope("hidden_layer_distill"):
                hiddens_t = results_t["hidden_layers"]
                hiddens_s = results_s["hidden_layers"]
                teacher_layer_num = len(hiddens_t)
                student_layer_num = len(hiddens_s)
                assert teacher_layer_num % student_layer_num == 0
                layers_per_block = int(teacher_layer_num / student_layer_num)

                hiddens_t = [hiddens_t[i * layers_per_block + layers_per_block - 1]
                             for i in range(student_layer_num)]

                new_hiddens_s = []
                for i, (layer_t, layer_s) in enumerate(zip(hiddens_t, hiddens_s)):
                    layer_s = linear_projection(layer_s, layer_t.shape[-1].value,
                                                name="mapping_weight_%s" % i)
                    new_hiddens_s.append(layer_s)

                loss_list = []
                for teacher_layer, student_layer in zip(hiddens_t, new_hiddens_s):
                    loss_list.append(mse(teacher_layer, student_layer))
                hidden_loss = tf.add_n(loss_list)
                distill_loss += hidden_loss * self.hidden_loss_weight

        # attention layer loss
        if self.attn_loss_weight > 0:
            with tf.variable_scope("attention_distill"):
                attentions_t = results_t["attentions"]
                attentions_s = results_s["attentions"]
                teacher_layer_num = len(attentions_t)
                student_layer_num = len(attentions_s)
                assert teacher_layer_num % student_layer_num == 0
                layers_per_block = int(teacher_layer_num / student_layer_num)

                new_attentions_t = [attentions_t[i * layers_per_block + layers_per_block - 1]
                                    for i in range(student_layer_num)]
                loss_list = []
                for teacher_att, student_att in zip(new_attentions_t, attentions_s):
                    teacher_att = tf.where(teacher_att < -1e2,
                                           tf.zeros_like(teacher_att),
                                           teacher_att)
                    student_att = tf.where(student_att < -1e2,
                                           tf.zeros_like(student_att),
                                           student_att)
                    loss_list.append(mse(teacher_att, student_att))
                attn_loss = tf.add_n(loss_list)
                distill_loss += attn_loss * self.attn_loss_weight

        if self.pred_loss_ratio > 0:
            distill_loss = (1 - self.pred_loss_ratio) * distill_loss + \
                self.pred_loss_ratio * results_s['loss']
        return distill_loss
