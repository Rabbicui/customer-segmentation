import horovod.tensorflow as hvd
import numpy as np
import tensorflow as tf
from tensorflow.core.protobuf import config_pb2
from tensorflow.python.framework import ops
from tensorflow.python.framework import composite_tensor
from tensorflow.python.framework import tensor_util
from tensorflow.python.framework import dtypes as dtypes_module
from tensorflow.python.ops import math_ops, array_ops, state_ops, control_flow_ops
from tensorflow.python.ops import variables as variables_module
from tensorflow.python.util import nest
import threading
import weakref

from rcalgo.tf.utils.logging import logger


_SESSION = threading.local()

_INITIALIZED_VARIABLES = weakref.WeakKeyDictionary()
_INITIALIZED_TABLES = weakref.WeakKeyDictionary()

_GPU_ID_OFFSET = 0


def _initialize_variables(sess):
    global _INITIALIZED_VARIABLES
    initialized_vars = _INITIALIZED_VARIABLES.setdefault(sess, weakref.WeakSet())

    global_vars = tf.global_variables()
    global_vars = [var for var in global_vars if var not in initialized_vars]
    if not global_vars:
        return

    is_not_initialized = sess.run([tf.is_variable_initialized(var) for var in global_vars])
    not_initialized_vars = [v for (v, f) in zip(global_vars, is_not_initialized) if not f]

    if len(not_initialized_vars) > 0:
        sess.run(tf.variables_initializer(not_initialized_vars))

    for var in not_initialized_vars:
        initialized_vars.add(var)


def _initialize_tables(sess):
    global _INITIALIZED_TABLES
    initialized_tables = _INITIALIZED_TABLES.setdefault(sess, weakref.WeakSet())

    table_initializers = tf.get_collection(tf.GraphKeys.TABLE_INITIALIZERS)
    not_initialized_tables = [var for var in table_initializers
                              if var not in initialized_tables]
    if len(not_initialized_tables):
        sess.run(not_initialized_tables)
        for var in not_initialized_tables:
            initialized_tables.add(var)


def _get_session():
    global _SESSION
    global _GPU_ID_OFFSET
    default_session = ops.get_default_session()
    if default_session is not None:
        session = default_session
    else:
        hvd.init()
        if getattr(_SESSION, 'session', None) is None:
            config = tf.ConfigProto(
                allow_soft_placement=True, log_device_placement=False)
            config.gpu_options.allow_growth = True
            if hvd.size() > 1:
                config.gpu_options.visible_device_list = str(
                    _GPU_ID_OFFSET + hvd.local_rank())  # horovod
            _SESSION.session = tf.Session(config=config)

        session = _SESSION.session
    return session


def get_tmp_session():
    config = tf.ConfigProto(allow_soft_placement=True, log_device_placement=False)
    config.gpu_options.allow_growth = True
    return tf.Session(config=config)


def get_session(init_variables=True):
    session = _get_session()
    if init_variables:
        _initialize_variables(session)
        _initialize_tables(session)
    return session


def set_session(session):
    global _SESSION
    _SESSION.session = session


def clear_session():
    global _SESSION
    global _INITIALIZED_VARIABLES
    global _INITIALIZED_TABLES

    tf.reset_default_graph()
    if hasattr(_SESSION, "session") and _SESSION.session:
        _INITIALIZED_VARIABLES.pop(_SESSION.session, None)
        _INITIALIZED_TABLES.pop(_SESSION.session, None)
        _SESSION.session = None


def set_gpu_id_offset(gpu_id):
    global _GPU_ID_OFFSET
    _GPU_ID_OFFSET = gpu_id


def cast_variables_to_tensor(tensors):
    def _cast_variables_to_tensor(tensor):
        if isinstance(tensor, variables_module.Variable):
            return array_ops.identity(tensor)
        return tensor

    return nest.map_structure(_cast_variables_to_tensor, tensors)


# 这是从keras复制过来的代码，这里自己定义一遍主要是因为keras的
# 把get_session()写死在代码里了, 默认只是用tf.keras.backend.get_session()
# 我们这里需要用自己的get_session(), 顺便也方便调试
class GraphExecutionFunction(object):
    """Runs a computation graph.

    It's possible to pass arguments to `tf.Session.run()` via `session_kwargs`.
    In particular additional operations via `fetches` argument and additional
    tensor substitutions via `feed_dict` arguments. Note that given
    substitutions are merged with substitutions from `inputs`. Even though
    `feed_dict` is passed once in the constructor (called in `model.compile()`)
    we can modify the values in the dictionary. Through this feed_dict we can
    provide additional substitutions besides Keras inputs.

    Arguments:
            inputs: Feed placeholders to the computation graph.
            outputs: Output tensors to fetch.
            updates: Additional update ops to be run at function call.
            name: A name to help users identify what this function does.
            session_kwargs: Arguments to `tf.Session.run()`:
                                            `fetches`, `feed_dict`, `options`, `run_metadata`.
    """

    def __init__(self, inputs, outputs, updates=None, name=None,
                 **session_kwargs):
        updates = updates or []
        if not isinstance(updates, (list, tuple)):
            raise TypeError('`updates` in a Keras backend function '
                            'should be a list or tuple.')

        self._inputs_structure = inputs
        self.inputs = nest.flatten(inputs, expand_composites=True)
        self._outputs_structure = outputs
        self.outputs = cast_variables_to_tensor(
                nest.flatten(outputs, expand_composites=True))
        # TODO(b/127668432): Consider using autograph to generate these
        # dependencies in call.
        # Index 0 = total loss or model output for `predict`.
        with ops.control_dependencies([self.outputs[0]]):
            updates_ops = []
            for update in updates:
                if isinstance(update, tuple):
                    p, new_p = update
                    updates_ops.append(state_ops.assign(p, new_p))
                else:
                    # assumed already an op
                    updates_ops.append(update)
            self.updates_op = control_flow_ops.group(*updates_ops)
        self.name = name
        # additional tensor substitutions
        self.feed_dict = session_kwargs.pop('feed_dict', None)
        # additional operations
        fetches = session_kwargs.pop('fetches', [])
        # if not isinstance(self.fetches, list):
        #     self.fetches = [self.fetches]
        self.set_fetches(fetches)
        self.run_options = session_kwargs.pop('options', None)
        self.run_metadata = session_kwargs.pop('run_metadata', None)
        # The main use case of `fetches` being passed to a model is the ability
        # to run custom updates
        # This requires us to wrap fetches in `identity` ops.
        # self.fetches = [array_ops.identity(x) for x in self.fetches]
        self.session_kwargs = session_kwargs
        # This mapping keeps track of the function that should receive the
        # output from a fetch in `fetches`: { fetch: function(fetch_output) }
        # A Callback can use this to register a function with access to the
        # output values for a fetch it added.
        # self.fetch_callbacks = {}

        if session_kwargs:
            raise ValueError('Some keys in session_kwargs are not supported at this '
                             'time: %s' % (session_kwargs.keys(),))

        self._callable_fn = None
        self._feed_arrays = None
        self._feed_symbols = None
        self._symbol_vals = None
        self._fetches = None
        self._session = None
        self._fetches_results = None

    def _make_callable(self, feed_arrays, feed_symbols, symbol_vals):
        """Generates a callable that runs the graph.

        Arguments:
            feed_arrays: List of input tensors to be fed Numpy arrays at runtime.
            feed_symbols: List of input tensors to be fed symbolic tensors at runtime.
            symbol_vals: List of symbolic tensors to be fed to `feed_symbols`.
            session: Session to use to generate the callable.

        Returns:
            Function that runs the graph according to the above options.
        """
        session = get_session()  # 这里用get_session()就可以了
        # Prepare callable options.
        callable_opts = config_pb2.CallableOptions()
        # Handle external-data feed.
        for x in feed_arrays:
            callable_opts.feed.append(x.name)
        if self.feed_dict:
            for key in sorted(self.feed_dict.keys()):
                callable_opts.feed.append(key.name)
        # Handle symbolic feed.
        for x, y in zip(feed_symbols, symbol_vals):
            connection = callable_opts.tensor_connection.add()
            if x.dtype != y.dtype:
                y = math_ops.cast(y, dtype=x.dtype)
            from_tensor = ops._as_graph_element(y)
            if from_tensor is None:
                from_tensor = y
            connection.from_tensor = from_tensor.name    # Data tensor
            connection.to_tensor = x.name    # Placeholder
        # Handle fetches.
        for x in self.outputs + self.fetches:
            callable_opts.fetch.append(x.name)
        # Handle updates.
        callable_opts.target.append(self.updates_op.name)
        # Handle run_options.
        if self.run_options:
            callable_opts.run_options.CopyFrom(self.run_options)
        # Create callable.
        callable_fn = session._make_callable_from_options(callable_opts)
        # Cache parameters corresponding to the generated callable, so that
        # we can detect future mismatches and refresh the callable.
        self._callable_fn = callable_fn
        self._feed_arrays = feed_arrays
        self._feed_symbols = feed_symbols
        self._symbol_vals = symbol_vals
        self._fetches = list(self.fetches)
        self._session = session

    def set_fetches(self, fetches):
        self._fetches_structure = fetches
        self.fetches = cast_variables_to_tensor(
                nest.flatten(fetches, expand_composites=True))
        self.fetches = [array_ops.identity(x) for x in self.fetches]

    @property
    def fetches_results(self):
        structured_results = nest.pack_sequence_as(
                self._fetches_structure,
                self._fetches_results,
                expand_composites=True)
        return structured_results
    """
    def _call_fetch_callbacks(self, fetches_output):
        for fetch, output in zip(self._fetches, fetches_output):
            if fetch in self.fetch_callbacks:
                self.fetch_callbacks[fetch](output)
    """

    def _eval_if_composite(self, tensor):
        """Helper method which evaluates any CompositeTensors passed to it."""
        # We need to evaluate any composite tensor objects that have been
        # reconstructed in 'pack_sequence_as', since otherwise they'll be output as
        # actual CompositeTensor objects instead of the value(s) contained in the
        # CompositeTensors. E.g., if output_structure contains a SparseTensor, then
        # this ensures that we return its value as a SparseTensorValue rather than
        # a SparseTensor.
        if isinstance(tensor, composite_tensor.CompositeTensor):
            return self._session.run(tensor)
        else:
            return tensor

    def __call__(self, inputs):
        inputs = nest.flatten(inputs, expand_composites=True)

        session = get_session(init_variables=False)  # 这里只检查session, 一般不需要initialize
        feed_arrays = []
        array_vals = []
        feed_symbols = []
        symbol_vals = []
        for tensor, value in zip(self.inputs, inputs):
            if value is None:
                continue

            if tensor_util.is_tensor(value):
                # Case: feeding symbolic tensor.
                feed_symbols.append(tensor)
                symbol_vals.append(value)
            else:
                # Case: feeding Numpy array.
                feed_arrays.append(tensor)
                # We need to do array conversion and type casting at this level, since
                # `callable_fn` only supports exact matches.
                tensor_type = dtypes_module.as_dtype(tensor.dtype)
                array_vals.append(np.asarray(value,
                                             dtype=tensor_type.as_numpy_dtype))

        if self.feed_dict:
            for key in sorted(self.feed_dict.keys()):
                array_vals.append(
                        np.asarray(self.feed_dict[key], dtype=key.dtype.base_dtype.name))

        # Refresh callable if anything has changed.
        if (self._callable_fn is None or feed_arrays != self._feed_arrays or
                symbol_vals != self._symbol_vals or
                feed_symbols != self._feed_symbols or self.fetches != self._fetches or
                session != self._session):
            try:
                self._make_callable(feed_arrays, feed_symbols, symbol_vals)
            except tf.errors.UnimplementedError as e:
                logger.error(f"{e}")
                raise ValueError(f"可能是输入数据有误.\n需要的输入：{feed_symbols}\n"
                                 f"目前输入：{symbol_vals}")

        fetched = self._callable_fn(*array_vals,
                                    run_metadata=self.run_metadata)
        # self._call_fetch_callbacks(fetched[-len(self._fetches):])
        self._fetches_results = fetched[len(self.outputs):]

        output_structure = nest.pack_sequence_as(
                self._outputs_structure,
                fetched[:len(self.outputs)],
                expand_composites=True)
        # We need to evaluate any composite tensor objects that have been
        # reconstructed in 'pack_sequence_as', since otherwise they'll be output as
        # actual CompositeTensor objects instead of the value(s) contained in the
        # CompositeTensors. E.g., if output_structure contains a SparseTensor, then
        # this ensures that we return its value as a SparseTensorValue rather than
        # a SparseTensor.
        return nest.map_structure(self._eval_if_composite, output_structure)
