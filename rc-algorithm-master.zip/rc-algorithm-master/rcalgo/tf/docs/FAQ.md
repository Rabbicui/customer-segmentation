## FAQ

### 怎么debug？

目前debug上没有做太多额外的支持，所以debug方式跟普通tensorflow的代码差不多，可以找到报错的位置，用pdb设置一下断点，然后把相关的信息打印出来看一下。

debug过程中可能会碰到一个问题，就是不知道模型在哪个graph上。

目前horovod的逻辑是使用全局graph和全局session，获取方式如下：

```python
# 获取全局session
from rcalgo.tf.training import context
sess = context.get_session()

# 获取全局graph
graph = sess.graph  # 方法一
graph = tf.get_default_graph()  # 方法二
```



### 为什么要用全局graph和全局session？

主要是因为我们使用tensorflow是很少会碰到需要多graph和多session的场景，因为：

1. 如果多个模型之间相互关联，那么它们只能实现在同一个graph里面，这时候多graph也派不上用场
2. 如果多个模型之间没有关联，那么它们通常可以实现到不同的文件里面，没必要在同一块代码中处理

采用全局graph和全局session，可以使下面的场景变得更容易：

1. 一个任务涉及多个模型，比如GAN，我们在创建模型的时候就不用关心graph和session的细节了，直接定义需要的多个模型即可，它们的节点和权重都是共享的。
2. 模型分多步构建的情况：比如bert finetune，用全局graph和全局session，我们就可以先构建bert，再restore权重，再在后面加入prediction层。就是随时增加节点，随时用，不用再像之前一样，先构建好整个graph，然后global variable initialize，然后再做其他操作。

同时我们提供了一些方式来手动指定session，主要有两种：

```python
# 方式一
with tf.Session() as sess:
  do something  # code in this scope will redirect session to sess
  
# 方式二
from rcalgo.tf.training import context
sess = tf.Session()  # 如果要使用keras的session，就sess = tf.keras.backend.get_session()
context.set_session(sess)
```



### Jupyter notebook中多次执行相同的代码，会报“节点已存在”的错误？

这是因为现在使用全局的graph和全局的session，多次往同一个graph里写同样的代码，就会出现重复，解决办法是执行之前手动clear一下session：

```python
from rcalgo.tf.training import context
context.clear_session()
```



### 怎么实现多输入和多输出？

Module和Model的多输入、多输出总体来说实现思路时一样的，就是用list来代替原来单个的tensor，具体来说：

##### 1. Module的多输入和多输出

对于多输入的情况，需要把inputs使用一个list来代替，list中存放输入的多个tensor

对于多输出的情况，call函数直接返回多个tensor即可

```python
# Module definition
class CustomModule(Module):
  def call(self, inputs):
    tensor1, tensor2 = inputs[0], inputs[1]
    return tensor1, tensor2  # same as "return (x1, x2)"
  
# Usage
input1 = tf.placeholder(dtype=tf.string, shape=[None])
input2 = tf.placeholder(dtype=tf.string, shape=[None])
module = CustomModule()
output1, output2 = module([input1, input2])
```

##### 2. Model的多输入和多输出

model和module不同的地方在于model的call函数返回的是两个值，一个是logits, 一个是predictions，所以要实现多输出，不能直接返回多个值，而是要把logits或者prediction返回成list

```python
class CustomModel(Model):
  def create_inputs(self):
    input1 = tf.placeholder(dtype=tf.string, shape=[None])
		input2 = tf.placeholder(dtype=tf.string, shape=[None])
    label1 = tf.placeholder(dtype=tf.string, shape=[None])
    label2 = tf.placeholder(dtype=tf.string, shape=[None])
    return [input1, input2], [label1, label2]
  
  def call(inputs, **kwargs):
    # 这里的inputs就是上面create_inputs返回的第一个参数，是一个list
    input1, input2 = inputs[0], inputs[1]
    logits1, logits2 = some_process()  # 模型输出的logits，用于计算loss
    output1, output2 = some_other_process()  # 模型的prediction，作为inference时的输出
    return [logits1, logits2], [output1, output2]
    
  def compute_loss(logits, labels):
    # 这里的logits是上面call函数返回的第一个参数， labels是create_inputs返回的第二个参数
    loss = ...
    return loss
  
  def compute_metrics(outputs, labels):
    # 这里的outputs是上面call函数返回的第二个参数，labels是create_inputs返回的第二个参数
    metric1 = ...
    metric2 = ...
    return [metric1, metric2]  # 这里支持多个metrics
```



### 怎么fix variables？

subclassing api提供了一个`filter_trainable_variables()`接口，在这里把不参与训练的variable给过滤掉就可以了。例如：

```python
def filter_trainable_variables(self, tvars):
  """Fix pretrained variables."""
  regex = re.compile("finetune_prediction")
  tvars = [var for var in tvars if regex.match(var.name)]
  return tvars
```

对于functional api，可以在调用`functional_model()`的时候传入tvars参数.



### Model和Module是什么关系？

如果看一下Model类的实现，会发现Module是Model的基类:

```python
class Module(tf.Module):
  def __init__():
    
  def call():
    

class Model(Module):
  def __init__():
  
  def create_inputs(self):
    
  def call(self, inputs):
    
  def compute_loss(self, logits, labels):
    
  def compute_metrics(self, outputs, labels):
```

Module只会在graph进行一些操作，给定一个输入，得到相应的输出，它无法定义模型的placeholder，也无法定义loss、metrics，同时也不具备训练相关的组件。

Model在Module的基础上，加入了训练相关的接口，包括定义placeholder，定义loss、metrics、optimizer等。

Model也可以直接当做Module来使用，我们在实现时进行了一些优化，不会造成很多额外的资源开销。

|                 | Module | Model |
| --------------- | ------ | ----- |
| 前向计算        | Yes    | Yes   |
| 定义placeholder |        | Yes   |
| 定义loss        |        | Yes   |
| 定义metrics     |        | Yes   |
| 定义optimizer   |        | Yes   |
| 训练            |        | Yes   |
| 保存/读入模型   |        | Yes   |



### subclassing api和functional api应该怎么选择？

functional api提供了最灵活的功能，几乎对用户没有任何限制，只要构好图并指定一下输入、输出、train_op等，就可以开始(分布式)训练。缺点是functional api实现的模型不太方便复用。

subclassing api把模型的构建分成了inputs, call, loss, metrics等几个独立的阶段，实现某个模型的变种只需要继承该类并把对应的函数重写一下即可，对代码复用比较友好。

所以推荐在初步实验阶段使用functional api，在把模型集成到tf-library时实现成subclassing的形式。另外要实现诸如knowledge distill， semi-supervised等框架类的功能时，建议基于subclassing api实现。



### subclassing api无法满足我的需求该怎么办？

subclassing api只是把模型的构建过程分成了常见的几个阶段而已，目前的create_inputs, call, compute_loss, compute_metrics并不是唯一的划分方式，如果想采用其他的划分方式，或者对这些接口的参数进行调整，只要重写一下build_forward函数即可。

subclassing api中的build_forward()函数：

```python
def build_forward(self, **kwargs):
  """Build forward propagation."""
  self.inputs, self.labels = self.create_inputs()
  logits, self.outputs = self(self.inputs, **kwargs)
  self.loss = self.compute_loss(logits, self.labels)
  self.metrics = self.compute_metrics(self.outputs, self.labels)
  self.add_extra_attrs(logits)
  
  training_utils.create_task_in_graph(
    self.inputs, self.outputs, self.labels, self.loss,
    self.metrics, name=self.name)
```

training_utils.create_task_in_graph()的作用是把模型的输入、输出、loss、metrics等信息写入到graph collection中，真正训练的时候就是从collection中获取这些信息的。

如果想对subclassing api进行调整，只要修改这段代码即可，只要确保inputs, labels, outputs, loss, metrics都能被正确的指定即可，这一点跟functional api类似。



### 怎么实现learning rate schedule？

subclassing api提供了create_optimizer()接口，这个接口的返回值是一个optimizer，可以在构建这个optimizer时加上learning rate schedule的逻辑。

例如实现一个简单的三角学习率：
$$
learning\_rate = d^{-0.5}_{model} * min(step\_num^{0.5},  step\_num * warmup\_steps ^{-1.5})
$$
对应的代码如下：

```python
D_MODEL = 256
WARMUP_STEPS = 1000

def create_optimizer(self):
  d_model = tf.cast(D_MODEL, tf.float32)
  global_step = tf.train.get_or_create_global_step()
  arg1 = tf.math.rsqrt(global_step)
  arg2 = global_step * (WARMUP_STEPS ** -1.5)
  learning_rate = tf.math.rsqrt(D_MODEL) * tf.math.minimum(arg1, arg2)
  optimizer = tf.train.AdamOptimizer(learning_rate)
  return optimizer
```



### Horovod和Graph Copy怎么选择？

这两种trainer背后的实现方式差别很大，但是最终暴露的接口比较类似，因为都是使用ring allreduce算法，所以性能也相差不大。

**两者在使用上有一些细微的差别，总结起来就是horovod更灵活，graph copy更方便。**

horovod更灵活体现在构图时和训练时使用的是同一个graph和session，没有做copy，所以相比graph copy约束更少，只要保证optimizer使用hvd.DistributedOptimizer进行了wrap，单卡能做的所有事情在horovod中都能做，而且不需要额外的适配。Graph copy因为构图时和训练时使用的不是同一张图，因此为了保证两个图相互同步，内含了一些约束，某些特殊用法可能会不支持。

graph copy更方便体现在它运行脚本的时候不需要使用mpirun，因此可以直接在jupyter notebooke中开发和运行。另一方面，horovod因为是多进程运行，如果不手动限制，每个进程都会打印一遍输出，保存文件也是每个进程都会保存一次，因此写代码时候需要额外注意，graph copy则没有这个问题。




### 为什么module里没有看到Module的子类，只看到一些函数？
因为之前的老代码是以函数的形式实现的，通过get_variable的reuse机制来实现variable的复用，目前重构并没有对这部分进行重写，所以都还是以函数的形式存在。

如果有兴趣可以一起实现实现一下，实现过程中可以参考[OpenNMT-tf](https://github.com/OpenNMT/OpenNMT-tf)



### module什么时候实现成类，什么时候实现成函数？

建议是如果module里需要增加variable，就以类的形式实现，方便variable的复用。如果module只是做一些变换，不涉及新的variable，可以实现成类，也可以实现成函数。



### Horovod怎么在jupyter notebook里面使用？

可以在jupyter中开发并且支持单卡运行，如果要多卡运行的话需要在命令行里使用mpirun命令启动py脚本。

另外jupytext这个插件可以将.py文件在notebook中打开，并且支持.py与.ipynb文件绑定，会使开发更加方便。

kml上这个镜像已经将jupytext打包进去了: kml-antispam/kuaishou-base-gpu:rc-faiss-1.6.3-condatf-1.14-cuda-10.1



### Horovod怎么限制使用特定的GPU：

有两种方式：

1. 在命令行里面指定：

```shell
CUDA_VISIBLE_DEVICES="3,4,5,6" horovodrun -np 4 python your_script.py
```

2. 在代码里指定：

```python
from rcalgo.tf.training import context
context.set_gpu_id_offset(3) # 从gpu3开始
```

