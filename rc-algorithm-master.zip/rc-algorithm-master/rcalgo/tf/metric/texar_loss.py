import tensorflow as tf
from rcalgo.tf.utils.tf_func import label_smoothing
from texar.tf.losses.losses_utils import mask_and_reduce


def sequence_sparse_softmax_cross_entropy(labels,
                                          logits,
                                          sequence_length,
                                          label_smooth=0.0,
                                          nb_class=0,
                                          average_across_batch=True,
                                          average_across_timesteps=True,
                                          sum_over_batch=False,
                                          sum_over_timesteps=False,
                                          time_major=False,
                                          name=None):
    with tf.name_scope(name, "sequence_sparse_softmax_cross_entropy"):
        if label_smooth > 0.0:
            if nb_class == 0:
                raise ValueError('if using label smoothing, please input the nb_class for one_hot')
            else:
                labels = label_smoothing(tf.one_hot(labels, depth=nb_class), label_smooth)
                losses = tf.nn.softmax_cross_entropy_with_logits_v2(labels=labels,
                                                                    logits=logits)
        else:
            losses = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels, logits=logits)

        losses = mask_and_reduce(
            losses,
            sequence_length,
            rank=2,
            average_across_batch=average_across_batch,
            average_across_timesteps=average_across_timesteps,
            sum_over_batch=sum_over_batch,
            sum_over_timesteps=sum_over_timesteps,
            time_major=time_major)

        return losses


def sequence_sigmoid_cross_entropy(labels,
                                   logits,
                                   sequence_length,
                                   label_smooth=0.0,
                                   average_across_batch=True,
                                   average_across_timesteps=True,
                                   sum_over_batch=False,
                                   sum_over_timesteps=False,
                                   time_major=False,
                                   name=None):

    with tf.name_scope(name, "sequence_sigmoid_cross_entropy"):
        if label_smooth > 0.0:
            labels = label_smoothing(labels, label_smooth)
        losses = tf.nn.sigmoid_cross_entropy_with_logits(labels=labels, logits=logits)

        losses = mask_and_reduce(
            losses,
            sequence_length,
            rank=2,
            average_across_batch=average_across_batch,
            average_across_timesteps=average_across_timesteps,
            sum_over_batch=sum_over_batch,
            sum_over_timesteps=sum_over_timesteps,
            time_major=time_major)

        return losses

