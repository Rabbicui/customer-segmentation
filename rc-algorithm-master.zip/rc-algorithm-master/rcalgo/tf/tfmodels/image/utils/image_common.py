# coding: utf-8

import argparse
import logging
import logging.config
import os
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))


def bit_parser(parser):
    parser.add_argument("--name", required=True,
                        help="Name of this run. Used for monitoring and checkpointing.")
    parser.add_argument("--model", type=str, default=None,
                        help="Which variant to use; BiT-M gives best results.")
    parser.add_argument("--logdir", required=True,
                        help="Where to log training info (small).")
    parser.add_argument("--bit_pretrained_dir", default=None,
                        help="Where to search for pretrained BiT models.")
    parser.add_argument("--ckpt_path", default=None,
                        help="Path for load checkpoint file. If set, the bit pretrain model will be ignored")
    parser.add_argument("--in_block_attention_module", type=str, default=None,
                        help="current choices: cbam")
    parser.add_argument("--cbam_ratio", type=int, default=8,
                        help="")
    parser.add_argument("--cbam_kernel_size", type=int, default=7,
                        help="")
    parser.add_argument("--out_block_attention_module", type=str, default=None,
                        help="choices: lta")
    parser.add_argument("--lta_attention_flags",
                        help="a list of booleans")
    parser.add_argument("--batch", type=int, default=512,
                        help="Batch size.")
    parser.add_argument("--batch_split", type=int, default=1,
                        help="Number of batches to compute gradient on before updating weights.")
    parser.add_argument("--gpu_num", type=int, default=1,
                        help="gpu count for run")
    parser.add_argument("--base_lr", type=float, default=0.003,
                        help="Base learning-rate for fine-tuning. Most likely default is best.")
    parser.add_argument("--eval_every", type=int, default=None,
                        help="Run prediction on validation set every so many steps."
                             "Will always run one evaluation at the end of training.")
    parser.add_argument("--save_path", type=str, default=None,
                        help="save path for ckpt")
    parser.add_argument("--save_checkpoint", type=bool, default=True,
                        help="whether save checkpoint or only the weights.")
    parser.add_argument("--clipvalue", type=int, default=2,
                        help="gradients clip")
    parser.add_argument("--weight_decay", type=float, default=0,
                        help="weight decay")
    return parser

def uda_parser(parser):
    parser.add_argument("--unsup_ratio", type=int, default=7,
                        help="the batch size for unsup part is ratio * batch_size.")
    parser.add_argument("--uda_softmax_temp", type=float, default=-1,
                        help="The temperature of the Softmax when making prediction on unlabeled,"
                             "-1 mean no effect")
    parser.add_argument("--uda_confidence_thresh", type=float, default=-1,
                        help="The threshold on predicted probability on unsupervised data. If set, "
                             "UDA loss will only be calculated on unlabeled examples whose largest "
                             "probability is larger than the threshold")
    parser.add_argument("--ent_min_coeff", type=float, default=0,
                        help="")
    parser.add_argument("--unsup_coeff", type=float, default=1,
                        help="The coefficient on the UDA loss.")
    parser.add_argument("--aug_magnitude", type=int, default=10,
                        help="The temperature of the Softmax when making prediction on unlabeled,"
                             "-1 mean no effect")
    parser.add_argument("--aug_num_layers", type=int, default=1,
                        help="Num of augs used sequentially for rand augumentation. ")
    parser.add_argument("--lr_decay", type=str, default='bit_schedule', choices=['cosine', 'bit_schedule'],
                        help="decay options")
    parser.add_argument("--lr_decay_steps", type=int, default=-1, help="decay steps")
    parser.add_argument("--train_steps", type=int, default=-1, help="total train steps, "
                                                                    "if not specified, "
                                                                    "default settings will be used")
    return parser

def swav_parser(parser):
    # data para
    parser.add_argument("--nmb_crops", type=int, default=[2, 6], nargs="+",
                        help="list of number of crops (example: [2, 6])")
    parser.add_argument("--size_crops", type=int, default=[224, 96], nargs="+",
                        help="crops resolutions (example: [224, 96])")
    parser.add_argument("--min_scale_crops", type=float, default=[0.14, 0.05], nargs="+",
                        help="argument in RandomResizedCrop (example: [0.14, 0.05])")
    parser.add_argument("--max_scale_crops", type=float, default=[1, 0.14], nargs="+",
                        help="argument in RandomResizedCrop (example: [1., 0.14])")

    # model
    parser.add_argument("--crops_for_assign", type=int, nargs="+", default=[0, 1],
                        help="list of crops id used for computing assignments")
    parser.add_argument("--temperature", default=0.1, type=float,
                        help="temperature parameter in training loss")
    parser.add_argument("--epsilon", default=0.05, type=float,
                        help="regularization parameter for Sinkhorn-Knopp algorithm")
    parser.add_argument("--sinkhorn_iterations", default=3, type=int,
                        help="number of iterations in Sinkhorn-Knopp algorithm")
    parser.add_argument("--hidden_mlp", default=2048, type=int,
                        help="hidden dimension")
    parser.add_argument("--output_mlp", default=128, type=int,
                        help="feature dimension")
    parser.add_argument("--nmb_prototypes", default=3000, type=int,
                        help="number of prototypes")
    parser.add_argument("--queue_length", type=int, default=0,
                        help="length of the queue (0 for no queue)")
    parser.add_argument("--epoch_queue_starts", type=int, default=15,
                        help="from this epoch, we start using a queue")

    # opt
    parser.add_argument("--epochs", default=100, type=int,
                        help="number of total epochs to run")
    parser.add_argument("--batch_size", default=256, type=int,
                        help="batch size per gpu, i.e. how many unique instances per gpu")
    # parser.add_argument("--base_lr", default=4.8, type=float, help="base learning rate")
    parser.add_argument("--final_lr", type=float, default=0, help="final learning rate")
    parser.add_argument("--freeze_prototypes_niters", default=313, type=int,
                        help="freeze the prototypes during this many iterations from the start")
    parser.add_argument("--wd", default=1e-6, type=float, help="weight decay")
    parser.add_argument("--warmup_epochs", default=10, type=int, help="number of warmup epochs")
    parser.add_argument("--start_warmup", default=0, type=float,
                        help="initial warmup learning rate")
    return parser

def moco_parser(parser):
    parser.add_argument("--hidden_mlp", default=2048, type=int,
                        help="hidden dimension")
    parser.add_argument("--output_mlp", default=128, type=int,
                        help="feature dimension")
    parser.add_argument("--temp", default=0.07, type=float,
                        help="temperature parameter in training loss")
    parser.add_argument("--queue_size", default=65536, type=int,
                        help="negative sample size")
    parser.add_argument("--epochs", default=100, type=int,
                        help="number of total epochs to run")
    parser.add_argument("--final_lr", type=float, default=0, help="final learning rate")
    parser.add_argument("--wd", default=1e-6, type=float, help="weight decay")
    parser.add_argument("--warmup_epochs", default=0, type=int, help="number of warmup epochs")
    parser.add_argument("--start_warmup", default=0, type=float,
                        help="initial warmup learning rate")
    parser.add_argument("--start_warmup", default=0, type=float,
                        help="initial warmup learning rate")
    parser.add_argument("--crop_min_scale", default=0.2, type=float,
                        help="min crop scale for random cropping")
    parser.add_argument("--random_aug_mag", default=10, type=int,
                        help="random augument magnitude")
    parser.add_argument("--random_aug_num_layer", default=2, type=int,
                        help="random augument layers")
    parser.add_argument("--l2_regular", default=0.000003, type=float,
                        help="l2 weight regular")

    return parser


def parser_for_bit():
    parser = argparse.ArgumentParser(description="Fine-tune BiT-M model.")
    return bit_parser(parser)


def parser_for_uda():
    parser = parser_for_bit()
    return uda_parser(parser)

def parser_for_swav():
    parser = parser_for_bit()
    return swav_parser(parser)

def parser_for_moco():
    parser = parser_for_bit()
    return moco_parser(parser)


def setup_logger(args):
    """Creates and returns a fancy logger."""
    # return logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s")
    # Why is setting up proper logging so !@?#! ugly?
    os.makedirs(os.path.join(args.logdir, args.name), exist_ok=True)
    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": {
                "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            },
        },
        "handlers": {
            # "stderr": {
            #     "level": "INFO",
            #     "formatter": "standard",
            #     "class": "logging.StreamHandler",
            #     "stream": "ext://sys.stderr",
            # },
            "logfile": {
                "level": "DEBUG",
                "formatter": "standard",
                "class": "logging.FileHandler",
                "filename": os.path.join(args.logdir, args.name, "train.log"),
                "mode": "a",
            }
        },
        "loggers": {
            "": {
                # "handlers": ["stderr", "logfile"],
                "handlers": ["logfile"],
                "level": "DEBUG",
                "propagate": True
            },
        }
    })
    logger = logging.getLogger(__name__)
    logger.flush = lambda: [h.flush() for h in logger.handlers]
    logger.info(args)
    return logger
