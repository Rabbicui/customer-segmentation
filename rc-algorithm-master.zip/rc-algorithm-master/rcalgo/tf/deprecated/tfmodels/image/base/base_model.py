# coding: utf-8

import os

import tensorflow as tf
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))

from rcalgo.tf.tfmodels.image.utils import image_common, input_pipeline

HOROVOD_SUPPORT = False
try:
    import horovod.tensorflow.keras as hvd
    HOROVOD_SUPPORT = True
except ImportError:
    pass

print(HOROVOD_SUPPORT)


class MultiGPUCheckpoint(tf.keras.callbacks.ModelCheckpoint):

    def set_model(self, model):
        if isinstance(model.layers[-2], tf.keras.Model):
            self.model = model.layers[-2]
        else:
            self.model = model


class CheckpointDumper(tf.keras.callbacks.Callback):

    def __init__(self, save_path, session):
        super(CheckpointDumper, self).__init__()
        self.save_path = save_path
        self.session = session

    def on_epoch_end(self, epoch, logs=None):
        saver = tf.compat.v1.train.Saver()
        saver._max_to_keep = 0
        saver.saver_def.max_to_keep = 0
        directory = os.path.dirname(self.save_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        save_path = saver.save(self.session, self.save_path + '-epoch' + str(epoch) + '.ckpt')
        print("Model checkpoint saved in file: {}".format(save_path))


class BaseModel(object):

    """
    The base model for image.
    The subclass need to override:
        1. _build_data
        2. _build_model
        3. _get_epochs

        If custom callbacks is needed, build and return in _build_custom_callbacks
    """

    def __init__(self, args):
        # set up env
        self.args = args
        self.horovod_multi_train = True if args.gpu_num > 1 and HOROVOD_SUPPORT else False
        self.keras_multi_train = True if args.gpu_num > 1 and not HOROVOD_SUPPORT else False
        if self.horovod_multi_train:
            # set horovod env
            hvd.init()
            config = tf.ConfigProto()
            config.gpu_options.allow_growth = True
            config.gpu_options.visible_device_list = str(hvd.local_rank())
            tf.keras.backend.set_session(tf.Session(config=config))

        # set logger
        tf.io.gfile.makedirs(args.logdir)
        self.logger = image_common.setup_logger(args)

        self.num_classes = None
        self.num_samples = None
        self.batch_size = args.batch // args.gpu_num if self.horovod_multi_train else args.batch

    def _horovod_and_rank_x(self):
        # a helper function to decide whether in horovod mode and rank > 0
        return self.horovod_multi_train and hvd.rank() != 0

    def _build_data(self, batch, train_data, test_data=None):
        """
        Returns:
            (tf train_data, tf test_data, resize_size, crop_size)

        """
        raise NotImplementedError

    def _build_model(self, num_classes):
        # build the main model here
        raise NotImplementedError

    def _get_epochs(self, num_samples):
        raise NotImplementedError

    def _build_opt(self):
        # a basic sgd loss with momentum
        optimizer = tf.keras.optimizers.SGD(lr=self.args.base_lr, momentum=0.9)
        if self.horovod_multi_train:
            optimizer = hvd.DistributedOptimizer(optimizer)
        return optimizer

    def _build_loss(self):
        # a basic cross entropy loss for classification
        return tf.keras.losses.CategoricalCrossentropy(from_logits=True)

    def _build_metric(self):
        return ['accuracy']

    def _build_callbacks(self):
        # set callbacks
        args = self.args
        # build the basic callback
        if args.save_checkpoint:
            ckpt_callback = CheckpointDumper(args.save_path,
                                             tf.compat.v1.keras.backend.get_session())
        else:
            if self.keras_multi_train:
                ckpt_callback = MultiGPUCheckpoint(args.save_path, save_weights_only=False,
                                                   verbose=1)
            else:
                ckpt_callback = tf.keras.callbacks.ModelCheckpoint(filepath=args.save_path,
                                                                   save_weights_only=True,
                                                                   verbose=1)
        callbacks = []
        if self.horovod_multi_train:
            # sync callback
            callbacks.append(hvd.callbacks.BroadcastGlobalVariablesCallback(0))
            if hvd.rank() == 0:
                # only rank 0 save checkpoint
                callbacks.append(ckpt_callback)
        else:
            # other case save directly
            callbacks.append(ckpt_callback)

        callbacks.append(tf.keras.callbacks.CSVLogger(args.logdir + '/epoch_output.log'))

        # build the custom callback
        custom_callbacks = self._build_custom_callbacks()
        callbacks += custom_callbacks
        return callbacks

    def _build_custom_callbacks(self):
        # build new callbacks here
        return []

    def _compatible_to_serving(self, model, resize):
        with tf.compat.v1.keras.backend.get_session().graph.as_default():
            str_x = tf.keras.Input(shape=(), dtype=tf.string)
            im_x = input_pipeline.parse_str(str_x, resize)
            new_y = model(im_x)
            # new_y is the logits
            new_y = tf.nn.softmax(new_y) + 1e-8
            tf.add_to_collection('input_dict', str_x)
            tf.add_to_collection('output_dict', new_y)

    def run(self, train_data, test_data=None):
        args = self.args
        # build data
        data_train, data_test, resize, crop_size = self._build_data(self.batch_size,
                                                                    train_data, test_data)
        self.num_samples = len(train_data['label'])
        self.num_classes = train_data['num_classes']

        model = self._build_model(self.num_classes)

        # compatible to tf-library style
        self._compatible_to_serving(model, resize)

        # if run in keras multi train mode
        if self.keras_multi_train:
            model = tf.keras.utils.multi_gpu_model(model, args.gpu_num)

        opt = self._build_opt()
        loss = self._build_loss()
        metric = self._build_metric()

        # compile model
        model.compile(optimizer=opt, loss=loss, metrics=metric)

        # build callbacks
        callbacks = self._build_callbacks()

        verbose = 1
        if self._horovod_and_rank_x():
            verbose = 0
        steps_per_epoch = args.eval_every

        # train
        history = model.fit(
            data_train,
            steps_per_epoch=steps_per_epoch,
            epochs=self._get_epochs(self.num_samples),
            validation_data=data_test,  # here we are only using
            validation_steps=len(test_data['label']) // args.batch,
            # this data to evaluate our performance
            callbacks=callbacks,
            verbose=verbose
        )

        # save to logger
        if not self._horovod_and_rank_x():
            if 'val_acc' in history.history:
                h = history.history['val_acc']
            else:
                h = history.history['val_accuracy']
            for epoch, accu in enumerate(h):
                self.logger.info(
                    f'Epoch: {epoch}, '
                    f'Step: {epoch * args.eval_every}, '
                    f'Test accuracy: {accu:0.3f}')
