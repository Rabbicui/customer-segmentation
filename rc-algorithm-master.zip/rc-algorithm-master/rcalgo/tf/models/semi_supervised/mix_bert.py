import tensorflow as tf
import copy
from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.module.layer.basic import my_dropout
from rcalgo.tf.module.encoder.bert_encoder import BertModel as BertEncoder
from rcalgo.tf.module.encoder.bert_encoder import get_shape_list, embedding_lookup, \
    embedding_postprocessor, transformer_model, get_activation, \
    create_attention_mask_from_input_mask, create_initializer
from rcalgo.tf.models.finetune.google_bert import BertClassificationModel, BertIdSequenceClassificationModel


class MixBertEncoder(BertEncoder):
    def __init__(self, config,
                 mix_lambda,
                 split_layer_num,
                 max_seq_length,
                 input_a_ids,
                 input_b_ids,
                 input_a_mask=None,
                 input_b_mask=None,
                 token_type_ids_a=None,
                 token_type_ids_b=None,
                 use_one_hot_embeddings=False,
                 scope=None):
        config = copy.deepcopy(config)

        input_a_shape = get_shape_list(input_a_ids, expected_rank=2)
        batch_size_a = input_a_shape[0]
        seq_length_a = input_a_shape[1]

        input_b_shape = get_shape_list(input_b_ids, expected_rank=2)
        batch_size_b = input_b_shape[0]
        seq_length_b = input_b_shape[1]

        seq_length_mix = tf.maximum(seq_length_a, seq_length_a)
        if input_a_mask is None:
            #input_a_mask = tf.ones(shape=[batch_size_a, seq_length_a], dtype=tf.int32)
             seq_lens_a = tf.count_nonzero(input_a_ids, 1)
             input_a_mask = tf.sequence_mask(seq_lens_a, maxlen=max_seq_length)

        if token_type_ids_a is None:
            token_type_ids_a = tf.zeros(shape=[batch_size_a, seq_length_a], dtype=tf.int32)

        if input_b_mask is None:
            #input_b_mask = tf.ones(shape=[batch_size_b, seq_length_b], dtype=tf.int32)
            seq_lens_b = tf.count_nonzero(input_b_ids, 1)
            input_b_mask = tf.sequence_mask(seq_lens_b, maxlen=max_seq_length)

        if token_type_ids_b is None:
            token_type_ids_b = tf.zeros(shape=[batch_size_b, seq_length_b], dtype=tf.int32)

        input_ids = tf.concat([input_a_ids, input_b_ids], axis=0)
        print(f"input_ids: {input_ids}")
        with tf.variable_scope(scope, default_name="bert"):
            with tf.variable_scope("embeddings"):
                # Perform embedding lookup on the word ids.
                (self.embedding_output, self.embedding_table) = embedding_lookup(
                    input_ids=input_ids,
                    vocab_size=config.vocab_size,
                    embedding_size=config.hidden_size,
                    initializer_range=config.initializer_range,
                    word_embedding_name="word_embeddings",
                    use_one_hot_embeddings=use_one_hot_embeddings)

                embedding_output_a, embedding_output_b = tf.split(self.embedding_output, 2)
                # Add positional embeddings and token type embeddings, then layer
                # normalize and perform dropout.
                embedding_output_a = embedding_postprocessor(
                    input_tensor=embedding_output_a,
                    use_token_type=True,
                    token_type_ids=token_type_ids_a,
                    token_type_vocab_size=config.type_vocab_size,
                    token_type_embedding_name="token_type_embeddings",
                    use_position_embeddings=True,
                    position_embedding_name="position_embeddings",
                    initializer_range=config.initializer_range,
                    max_position_embeddings=config.max_position_embeddings,
                    dropout_prob=config.hidden_dropout_prob,
                    layer_norm_name="LayerNorm")

                embedding_output_b = embedding_postprocessor(
                    input_tensor=embedding_output_b,
                    use_token_type=True,
                    token_type_ids=token_type_ids_b,
                    token_type_vocab_size=config.type_vocab_size,
                    token_type_embedding_name="token_type_embeddings",
                    use_position_embeddings=True,
                    position_embedding_name="position_embeddings",
                    initializer_range=config.initializer_range,
                    max_position_embeddings=config.max_position_embeddings,
                    dropout_prob=config.hidden_dropout_prob,
                    layer_norm_name="LayerNorm")

            with tf.variable_scope("encoder"):
                # This converts a 2D mask of shape [batch_size, seq_length] to a 3D
                # mask of shape [batch_size, seq_length, seq_length] which is used
                # for the attention scores.
                attention_mask_a = create_attention_mask_from_input_mask(
                    input_a_ids, input_a_mask)
                attention_mask_b = create_attention_mask_from_input_mask(
                    input_b_ids, input_b_mask)
                attention_mask_mix = tf.ones(shape=[batch_size_a, seq_length_mix, seq_length_mix], dtype=tf.int32)

                # Run the stacked transformer.
                # `sequence_output` shape = [batch_size, seq_length, hidden_size].
                all_encoder_layers_a, all_encoder_attentions_a = transformer_model(
                    input_tensor=embedding_output_a,
                    attention_mask=attention_mask_a,
                    hidden_size=config.hidden_size,
                    num_hidden_layers=split_layer_num,
                    num_attention_heads=config.num_attention_heads,
                    intermediate_size=config.intermediate_size,
                    intermediate_act_fn=get_activation(config.hidden_act),
                    hidden_dropout_prob=config.hidden_dropout_prob,
                    attention_probs_dropout_prob=config.attention_probs_dropout_prob,
                    initializer_range=config.initializer_range,
                    do_return_all_layers=True)

                all_encoder_layers_b, self.all_encoder_attentions_b = transformer_model(
                    input_tensor=embedding_output_b,
                    attention_mask=attention_mask_b,
                    hidden_size=config.hidden_size,
                    num_hidden_layers=split_layer_num,
                    num_attention_heads=config.num_attention_heads,
                    intermediate_size=config.intermediate_size,
                    intermediate_act_fn=get_activation(config.hidden_act),
                    hidden_dropout_prob=config.hidden_dropout_prob,
                    attention_probs_dropout_prob=config.attention_probs_dropout_prob,
                    initializer_range=config.initializer_range,
                    do_return_all_layers=True)

                # merge
                transformer_output_merge = mix_lambda * all_encoder_layers_a[-1] + \
                                           (1 - mix_lambda) * all_encoder_layers_b[-1]

                all_encoder_layers_mix, all_encoder_attentions_mix = transformer_model(
                    input_tensor=transformer_output_merge,
                    attention_mask=attention_mask_mix,
                    hidden_size=config.hidden_size,
                    num_hidden_layers=config.num_hidden_layers - split_layer_num,
                    num_attention_heads=config.num_attention_heads,
                    intermediate_size=config.intermediate_size,
                    intermediate_act_fn=get_activation(config.hidden_act),
                    hidden_dropout_prob=config.hidden_dropout_prob,
                    attention_probs_dropout_prob=config.attention_probs_dropout_prob,
                    initializer_range=config.initializer_range,
                    do_return_all_layers=True)

            self.all_encoder_layers, self.all_encoder_attentions = all_encoder_layers_mix, all_encoder_attentions_mix
            self.sequence_output = all_encoder_layers_mix[-1]
            # The "pooler" converts the encoded sequence tensor of shape
            # [batch_size, seq_length, hidden_size] to a tensor of shape
            # [batch_size, hidden_size]. This is necessary for segment-level
            # (or segment-pair-level) classification tasks where we need a fixed
            # dimensional representation of the segment.
            with tf.variable_scope("pooler"):
                # We "pool" the model by simply taking the hidden state corresponding
                # to the first token. We assume that this has been pre-trained
                first_token_tensor = tf.squeeze(self.sequence_output[:, 0:1, :], axis=1)
                self.pooled_output = tf.layers.dense(
                    first_token_tensor,
                    config.hidden_size,
                    activation=tf.tanh,
                    kernel_initializer=create_initializer(config.initializer_range))


class MixBertModel(BertIdSequenceClassificationModel):
    def __init__(self, config=None, **kwargs):
        """
        MixBert is designed for MixText, thus it's not supposed to run by itself.
        Args:
            config: dict. model config.
            **kwargs: kwargs for Bert.
        """
        if config is None:
            config = {}
        super().__init__(config, **kwargs)

    def call(self, input_ids, is_mix, split_layer_num=None, mix_lambda=None, **kwargs):
        # split and cast to int
        input_ids = tf.compat.v1.strings.split(input_ids, sep=" ")
        input_ids = tf.sparse.to_dense(input_ids, default_value="0")
        input_ids = tf.compat.v1.string_to_number(input_ids, tf.int32)
        # padding sequence
        paddings = tf.constant([[0, 0], [0, self.max_seq_length]])
        input_ids = tf.pad(input_ids, paddings, "CONSTANT")[:, 0:self.max_seq_length]

        with tf.variable_scope("MixText", reuse=tf.AUTO_REUSE):
            if is_mix:
                input_a_ids, input_b_ids = tf.split(input_ids, 2)
                bert_model = MixBertEncoder(
                    config=self.bert_config,
                    mix_lambda=mix_lambda,
                    split_layer_num=split_layer_num,
                    max_seq_length=self.max_seq_length,
                    input_a_ids=input_a_ids,
                    input_b_ids=input_b_ids,
                    use_one_hot_embeddings=self.use_one_hot_embeddings)
            else:
                sequence_lengths = tf.count_nonzero(input_ids, 1)
                input_mask = tf.sequence_mask(sequence_lengths, maxlen=self.max_seq_length)
                token_type_ids = tf.zeros_like(input_ids)
                bert_model = BertEncoder(
                    config=self.bert_config,
                    input_ids=input_ids,
                    input_mask=input_mask,
                    token_type_ids=token_type_ids,
                    use_one_hot_embeddings=self.use_one_hot_embeddings)
            output_layer = bert_model.get_pooled_output()
            is_training = get_or_create_is_training()
            output_layer = my_dropout(output_layer, rate=self.bert_config.hidden_dropout_prob,
                                      training=is_training)
            hidden_size = output_layer.shape[-1].value
            output_weights = tf.get_variable(
                "output_weights", [self.num_classes, hidden_size],
                initializer=tf.truncated_normal_initializer(stddev=0.02))
            output_bias = tf.get_variable(
                "output_bias", [self.num_classes],
                initializer=tf.zeros_initializer())

        logits = tf.matmul(output_layer, output_weights, transpose_b=True)
        logits = tf.nn.bias_add(logits, output_bias)
        probabilities = tf.nn.softmax(logits, axis=-1)
        log_probs = tf.nn.log_softmax(logits, axis=-1)

        embedding = bert_model.get_embedding_table()
        hidden_layers = bert_model.get_all_encoder_layers()
        attentions = bert_model.get_all_encoder_attentions()
        return [logits, embedding, hidden_layers, attentions], probabilities
