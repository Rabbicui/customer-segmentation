import sys
import os
import math

from rcalgo.tf.module.layer.basic import my_dropout, my_full_connected, my_conv_1d

sys.path.append("../")
sys.path.append("../../")
from rcalgo.tf.tftraining.tf_object import *
from .text_basic_model import *
from rcalgo.tf.utils.tf_float_type import get_default_float_type
import tensorflow as tf


class MemoryQAModel(TextModel):
    def __init__(self, config, graph, word_dict=None):
        super(MemoryQAModel, self).__init__(config, graph, word_dict)
        self.nhop = config.nhop
        self.lindim = int(math.floor(config.linear_ratio * self.embedding_size))
        self.tower_attentions = [[] for i in range(0,self.gpu_num)]
        self.labels = config.labels
        self.question_slots = config.question_slots

    def build_input(self):
        self.build_text_input()
        with tf.name_scope('input'):
            inputQuestion = tf.compat.v1.placeholder(tf.int32, [None], name="question")
            if self.labels == 1:
                inputLabel = tf.compat.v1.placeholder(tf.int32, [None], name='label')
            else:
                inputLabel = tf.compat.v1.placeholder(
                    get_default_float_type(), [None, self.labels], name='label')
            self._add_to_graph_inputs(inputQuestion)
            self._add_to_graph_targets(inputLabel)
            self.split_inputQuestion = tf.split(inputQuestion, self.gpu_num, 0)
            self.input_dict['question'] = self.split_inputQuestion[0]
            self.split_inputLabel = tf.split(inputLabel, self.gpu_num, 0)
        with tf.name_scope('state_array'):
            self.hid_list = [[] for i in range(0,self.gpu_num)]

    def build_multiple_conv(self, input_embedding, num_filters_per_sizes, filter_sizes, pool_sizes, add_mean_pooling):
        print('input:', input_embedding.shape)
        last_conv = input_embedding
        for idx, conv_length in enumerate(filter_sizes):
            with get_new_variable_scope('conv') as conv_scope:
                conv = my_conv_1d(last_conv, conv_length, num_filters_per_sizes[idx], add_bias=True, bn=False,
                                  padding='VALID', act=tf.nn.relu)
                print(conv.shape)
            if pool_sizes[idx] is not None and pool_sizes[idx] > 0:
                with tf.name_scope("MaxPoolingLayer"):
                    pool = tf.nn.max_pool2d(tf.expand_dims(conv, -1),
                                          ksize=[1, pool_sizes[idx], 1, 1], strides=[1, pool_sizes[idx], 1, 1],
                                          padding='VALID', name="pool")
                    print('pool:', pool.shape)
                    last_conv = tf.squeeze(pool, [3])

            elif pool_sizes[idx] == -1:
                with tf.name_scope("MaxPoolingOverTimeLayer"):
                    last_conv = tf.reduce_max(conv, axis=1)
                    print('max:', last_conv.shape)
                    if add_mean_pooling:
                        mean_conv = tf.reduce_sum(conv, axis=1)/(tf.count_nonzero(
                            tf.reduce_sum(conv, axis=-1), axis=1, keepdims=True, dtype=get_default_float_type()) + 1e-8)
                        print('mean:', mean_conv.shape)
                        last_conv = tf.concat([last_conv, mean_conv], axis=1)
            else:
                last_conv = conv
            print(last_conv.shape)
        return last_conv

    def build_memory(self, filter_sizes, num_filters_per_sizes, pool_sizes, add_mean_pooling=True, gpu_id=0, **args):
        with get_new_variable_scope('memory') as memory_scope:
            with get_new_variable_scope('key') as key_scope:
                key_embedding = my_embedding_layer(self.split_inputX[gpu_id], self.nb_words, self.embedding_size, layer_name='key_embedding', init_scale=self.init_scale, zero_pad=True)
                key_conv = self.build_multiple_conv(key_embedding, num_filters_per_sizes, filter_sizes, pool_sizes, add_mean_pooling)
            key_input = key_conv

            question_embedding = my_embedding_layer(self.split_inputQuestion[gpu_id], self.question_slots, self.embedding_size, layer_name='question_embedding', init_scale=self.init_scale)
            with get_new_variable_scope('value') as value_scope:
                value_embedding = my_embedding_layer(self.split_inputX[gpu_id], self.nb_words, self.embedding_size, layer_name='value_embedding',init_scale=self.init_scale, zero_pad=True)
                value_conv = self.build_multiple_conv(value_embedding, num_filters_per_sizes, filter_sizes, pool_sizes, add_mean_pooling)
            value_input = value_conv
        with tf.name_scope('hidden_state'):
            self.hid_list[gpu_id].append(question_embedding)
        with get_new_variable_scope('memory_hops') as hops_scope:
            with get_new_variable_scope('hops_h') as scope:
                H = tf.compat.v1.get_variable('W',[self.embedding_size, self.embedding_size],
                                    initializer = tf.random_normal_initializer(0.0,self.init_std))
            for h in range(self.nhop):
                hid3dim = tf.reshape(self.hid_list[gpu_id][-1], [-1, 1, self.embedding_size])
                key_output = tf.matmul(hid3dim, key_input, adjoint_b=True)
                key_output_norm = tf.nn.softmax(key_output)
                #add the attention_distribution
                self.tower_attentions[gpu_id] = key_output_norm
                value_output = tf.matmul(key_output_norm, value_input)
                value_output_2dim = tf.reshape(value_output, [-1, self.embedding_size])
                hop_output = tf.add(tf.matmul(self.hid_list[gpu_id][-1], H), value_output_2dim)
                #linear relu for a part of hidden unit
                if self.lindim == self.embedding_size:
                    self.hid_list[gpu_id].append(hop_output)
                elif self.lindim == 0:
                    self.hid_list[gpu_id].append(tf.nn.relu(hop_output))
                else:
                    F = tf.slice(hop_output, [0, 0], [-1, self.lindim])
                    G = tf.slice(hop_output, [0, self.lindim], [-1, self.embedding_size-self.lindim])
                    K = tf.nn.relu(G)
                    self.hid_list[gpu_id].append(tf.concat([F, K],1))


    def build_prediction(self, type='self', accK=1, nb_class=None, fully_layers=[512],
                         dropout_keep_prob=0.9, gpu_id=0, **args):
        if type == 'self':
            nb_class = self.nb_words
        elif nb_class == None:
            raise Exception("nb_class must be given")
        with get_new_variable_scope('prediction') as pred_scope:
            last_layer = self.hid_list[gpu_id][-1]
            for idx, fc in enumerate(fully_layers):
                flatten = my_full_connected(last_layer, fc, act=tf.nn.relu)
                #last_flatten = flatten
                last_layer = my_dropout(flatten, rate=(
                    1-dropout_keep_prob), training=self.training)

            prediction = my_full_connected(last_layer, nb_class,
                                           add_bias=False, layer_name='fc',
                                           act=tf.identity, init_std=self.init_std)
            self.tower_prediction_results.append(tf.nn.softmax(prediction))
            self.params = tf.compat.v1.trainable_variables()
        with tf.name_scope('train'):
            ce_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.split_inputLabel[gpu_id], logits=prediction))
            grads, capped_gvs = my_compute_grad(self.opt, ce_loss, self.params,
                                                clip_type = 'clip_value',
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            accuracy = tf.to_float(tf.nn.in_top_k(prediction, self.split_inputLabel[gpu_id],k=accK))
        self._add_to_tower_list(grads, capped_gvs, ce_loss, accuracy)

    @replace_default_graph
    def build_model(self, type='self', accK=1, nb_class=None, export_attention=False, **args):
        self.build_input()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=(idx!=0))
                    with gpu_scope as gpu_scope:
                        self.build_memory(gpu_id=idx, **args)
                        self.build_prediction(type=type,accK=accK,nb_class=nb_class,gpu_id=idx, **args)
        self.build_model_aggregation()
        if export_attention:
            self.prediction_results = [self.prediction_results, tf.concat(self.tower_attentions,0)]
        self._add_to_graph_outputs(self.prediction_results)
        self.output_dict['attention'] = self.tower_attentions[0]
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT, self.output_dict['attention'])
