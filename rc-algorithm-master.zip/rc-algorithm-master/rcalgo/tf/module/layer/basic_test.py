import numpy as np
from tensorflow.python.eager import context
from tensorflow.python.framework import test_util
from tensorflow.python.ops import random_ops, array_ops, variables
from tensorflow.python.platform import test

from rcalgo.tf.module.layer.basic import my_full_connected, my_dropout


class MyFullyConnectedTest(test.TestCase):

    @test_util.run_in_graph_and_eager_modes
    def testCall(self):
        inputs = random_ops.random_uniform((5, 4), seed=1)
        outputs = my_full_connected(inputs, 2)
        self.assertListEqual([5, 2], outputs.get_shape().as_list())


class MyDropoutTest(test.TestCase):

    @test_util.run_in_graph_and_eager_modes
    def testCall(self):
        inputs = array_ops.ones((5, 3))
        dropped = my_dropout(inputs, training=True)
        if not context.executing_eagerly():
            self.evaluate(variables.global_variables_initializer())
        np_output = self.evaluate(dropped)
        self.assertAlmostEqual(0., np_output.min())
        dropped = my_dropout(inputs, training=False)
        np_output = self.evaluate(dropped)
        self.assertAllClose(np.ones((5, 3)), np_output)


if __name__ == '__main__':
    test.main()
