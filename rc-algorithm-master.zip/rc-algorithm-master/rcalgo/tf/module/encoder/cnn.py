import tensorflow as tf
from rcalgo.tf.module.layer.basic import my_conv_1d, my_dropout, my_flatten, my_full_connected
from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.utils.tf_func import get_new_variable_scope


def text_cnn_encoder(input_tensor, training, max_conv_len=3, num_filters=128, 
                     dropout_keep_prob=0.5, reuse=False):
    pooled_outputs = []
    for conv_length in range(1, max_conv_len + 1):
        with get_new_variable_scope(f"my_conv_no.{conv_length}", reuse=reuse) as conv_scope:
            conv = my_conv_1d(input_tensor, conv_length, num_filters, add_bias=True, bn=False,
                              padding='VALID', act=tf.nn.relu, reuse=reuse)
            # pool = tf.nn.max_pool2d(tf.expand_dims(conv, -1),
            #                      ksize=[1, self.maxlen - conv_length + 1, 1, 1],
            #                      strides=[1, 1, 1, 1], padding='VALID', name="pool")
            # using reduce_max repalce max_pool(max_pool over time)
            pool = tf.reduce_max(conv, axis=1)
            pooled_outputs.append(pool)

    num_filters_total = num_filters * len(pooled_outputs)
    # axis = 3 if using max_pool
    output_tensor = tf.concat(pooled_outputs, 1)
    # concat_pool_flat = tf.reshape(concat_pool, [-1, num_filters_total])
    # Add dropout
    with tf.name_scope("dropout"):
        output_tensor = my_dropout(output_tensor, rate=(1 - dropout_keep_prob), training=training)

    return output_tensor


def text_deep_cnn_encoder(input_tensor,
                          training,
                          num_filters_per_size=64,
                          filter_sizes=[7, 7, 3, 3, 3, 3],
                          pool_sizes=[3, 3, None, None, None, 3],
                          fully_layers=[128, 128],
                          dropout_keep_prob=0.5,
                          add_mean_pooling=True):
    last_conv = input_tensor
    for idx, conv_length in enumerate(filter_sizes):
        # using same for short text
        with get_new_variable_scope('conv') as conv_scope:
            conv = my_conv_1d(last_conv, conv_length, num_filters_per_size, add_bias=True, bn=False,
                              padding='VALID', act=tf.nn.relu)
        if pool_sizes[idx] is not None and pool_sizes[idx] > 0:
            with tf.name_scope("MaxPoolingLayer"):
                pool = tf.nn.max_pool2d(tf.expand_dims(conv, -1),
                                        ksize=[1, pool_sizes[idx], 1, 1], strides=[1, pool_sizes[idx], 1, 1],
                                        padding='VALID', name="pool")
                last_conv = tf.squeeze(pool, [3])

        elif pool_sizes[idx] == -1:
            with tf.name_scope("MaxPoolingOverTimeLayer"):
                last_conv = tf.reduce_max(conv, axis=1)
                if add_mean_pooling:
                    mean_conv = tf.reduce_sum(conv, axis=1) / (tf.count_nonzero(
                        tf.reduce_sum(conv, axis=-1), axis=1, keepdims=True, dtype=get_default_float_type()) + 1e-8)
                    last_conv = tf.concat([last_conv, mean_conv], axis=1)
        else:
            last_conv = conv
    last_flatten = my_flatten(last_conv)
    for idx, fc in enumerate(fully_layers):
        flatten = my_full_connected(last_flatten, fc, act=tf.nn.relu)
        # last_flatten = flatten
        last_flatten = my_dropout(flatten, rate=(1 - dropout_keep_prob), training=training)
    return last_flatten
