import numpy as np

# case 1: 常见普通分类场景
config = {
    # 必要参数
    "num_classes": 2,   # 分类个数
    "train_size_larger_than_100w": True,  # 训练数据集 是否大于100w? 将对不同的数据集采用默认不同的参数大小配置
    "embedding_cnt": 6,   # 总共有多少个embedding输入
    # 每个输入对应类别的名字，名字叫啥不关键，同一个源(上有模型)的embedding，保证是同一个名字就行
    "embedding_groups": ['moco_image', 'moco_image', 'moco_image', 'mmu_image', 'text', 'text'],
    # 每个输入的长度，需要和 embedding_groups 一一对应
    "embedding_sizes": [2048, 2048, 2048, 2048, 1024, 1024],
    #

    # 可选参数:
    "lr": 0.0003,
    "group_with_max_weight_info": []  # 哪些group需要输出最大的权重信息
}

# config 解释:
# 有6个embedding 输入
#   其中 前三个是 来自KwaiMoco 的图像 embedding （所以前三个用同一个名字表示)
#   第四个是 mmu的单帧图像embedding 和 Moco embedding不是同一个模型输出，所以不同名字
#   五六是 同一个模型生成的不同文本embedding
# embedding_size 表示embedding 长度 和embedding_groups 一一对应

from rcalgo.tf.models import EmbeddingFusion

moco_image1 = np.ones((100, 1024))
moco_image2 = np.ones((100, 1024))
moco_image3 = np.ones((100, 1024))
mmu_image1 = np.ones((100, 1024))
text1 = np.ones((100, 1024))
text2 = np.ones((100, 1024))
label = np.ones(100)

model = EmbeddingFusion(config)
model.build_model()
model.train(
    [moco_image1, moco_image2, moco_image3, mmu_image1, text1, text2, label],  # 输入数据需要和config 中给定的 group 顺序一致
    batch_size=256,  # batch size
    test_size=0.1,  # 训练数据中0.1的比例作为验证集
    epochs=20,      # 训练的轮数
    checkpoint_dir="./multimodal",  # checkpoint保存目录(默认保存最近5轮的checkpoint)
    checkpoint_name="test")  # checkpoint文件名



# case 2: 一个group有多个输入数据，如视频9帧截图，多个文本，违规识别场景下，如果想要输出 9帧截图具体哪一帧是最有问题的，可以在config中限定
new_config = {
    "group_with_max_weight_info": ['moco_image', 'text']   # 输出 图像group（3帧)里以及文本对分类结果影响最大的信息 (index + 权重)
}

config.update(new_config)
# 重新构建模型训练
model = EmbeddingFusion(config)
model.build_model()
model.train(
    [moco_image1, moco_image2, moco_image3, mmu_image1, text1, text2, label],  # 输入数据需要和config 中给定的 group 顺序一致
    batch_size=256,  # batch size
    test_size=0.1,  # 训练数据中0.1的比例作为验证集
    epochs=20,      # 训练的轮数
    checkpoint_dir="./multimodal",  # checkpoint保存目录(默认保存最近5轮的checkpoint)
    checkpoint_name="test")  # checkpoint文件名



# 模型输出outputs，此时会包含对应的信息:
#    outputs = 【logits  +  max_weight_index_of_group + max_weight_of_group]
# 说明:   比如违规检测 输入  第一帧是有问题的(即moco_image1)   同时 text2 是有问题的
#    outputs = [probs(分类概率), 0 （moco_image1 在moco_image group的位置是第一个),  1 (text2 在text group的index 是第二个),  moco_image1 的权重 0.a,   text2 的权重 0.b]

# case 3: 特定数据，比如 用户维度的违规计数，需要做一些预处理 (比如 norm)
#   1. 可以在输入数据前先预处理（这里需要考虑到 线上预测时后续也需要做预处理）
#   2. 在模型侧end 2 end 做预处理， 流程会稍微麻烦点
#
# 模型侧end 2 end 方式
# 新增 group: user
new_config = {
    "embedding_cnt": 7,
    "embedding_groups": ['moco_image', 'moco_image', 'moco_image', 'mmu_image', 'text', 'text', 'user'],
    "embedding_sizes": [2048, 2048, 2048, 2048, 1024, 1024, 512],

    # 在extra_info 里加入对应的辅助信息
    "extra_info": {
        "user_std": 0.03,
        "user_mean": 0.5
    }
}
class MyEmbeddingFusion(EmbeddingFusion):
    def preprocess_input(self, group, group_input_tensors):
        # group 是对应的group name
        # group_input_tensors: a list for  group input
        if group == 'user':
            std = self.get_extra_info_tensor_by_name("user_std")
            mean = self.get_extra_info_tensor_by_name("user_mean")
            return [(inp - mean) / std for inp in group_input_tensors]
        return group_input_tensors




