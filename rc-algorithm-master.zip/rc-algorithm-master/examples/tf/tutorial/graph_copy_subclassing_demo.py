# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.6.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# +
import sys, os
current_ipynb_path = os.getcwd()

print(current_ipynb_path)
sys.path.insert(0, "../../")

import pandas as pd
import tensorflow as tf

from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.models.classifier.text_classifier import TextCNN
# -

# 1. load data
data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
train_data = pd.read_csv(data_dir + 'train.csv')
test_data = pd.read_csv(data_dir + 'test.csv')
# count word dict
tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=2)
word_dict = tokenizer.word2idx

# +
# 2. create model
config = {
    "learning_rate": 0.01,

    "num_classes": 2,
    "max_seq_len": 100,
    "embedding_size": 256,
    "num_layers": 2,
    "conv_num_filters": 256,
    "keep_prob": 0.5,
    
    "gpu_id": 0,
    "gpu_num": 2,

    "model_output_dir": "./saved_models",
    "model_name": "cnn"
}

model = TextCNN(config, word_dict, name="default", distribute="tf_distribute")
model.build_model()
print(model.model_summary())

# -

model.train([train_data['text'], train_data['label']],
            batch_size=512,
            test_size=0.1,
            epochs=5,
            hooks=[])

# export model
model_path = "./saved_models/manually_saved_checkpoint.ckpt"
model.dump_checkpoint(model_path)
model.dump_model("./saved_models", "1", multi_replica_ckpt_path=model_path)
model.export_freeze_graph("./saved_models", "2", multi_replica_ckpt_path=model_path)


