import os
import random

import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.nn.parallel
import torch.optim
import torch.utils.data
import torch.utils.data.distributed
import torchvision.models as models
import torchvision.transforms as transforms

import rcalgo.torch.image.classification.aug_utils as aug_utils
import rcalgo.torch.image.classification.semi_classifier.semi_utils as semi_helper
import rcalgo.torch.image.classification.utils as utils
from rcalgo.torch.image.classification.bases import Finetune
from rcalgo.torch.image.classification.semi_classifier.semi_data import LabeledCustomData
from rcalgo.torch.image.classification.semi_classifier.semi_utils import DataKeyRegistry as DK


class FewShotFinetuneModel(Finetune):
    def __init__(self,
                 params: dict,
                 runner_name='FewShotFinetune'):

        super(FewShotFinetuneModel, self).__init__(params)

        ob_config = semi_helper.insert_parameters_into_config(semi_helper.FinetuneConfig(), params)
        self.ob_config = ob_config

        self.runner_name = runner_name
        self.logger.info(f'Runner: {self.runner_name}, Parameters: {ob_config.__dict__}')

        self.parallel = 'DataParallel'  # None

        self.setup_seed(self.ob_config.seed)

        self.stored_model_name = 'model_best.pth.tar'

    def run(self, train_data, test_data, ckpt_dir, ckpt_name, batch_size=256, total_epoch=300):
        self.train(train_data, test_data, ckpt_dir, ckpt_name, batch_size=batch_size, total_epoch=total_epoch)
        # self.some_process()
        return os.path.join(ckpt_dir, ckpt_name, self.stored_model_name)

    def new_lr(self, step, train_size, *args, **kwargs):
        # batch_size = kwargs.get('batch_size', self.ob_config.batch_size)
        # lr = utils.get_lr(step, train_size, base_lr=self.lr, batch_size=batch_size)
        lr = self.lr
        return lr

    def create_optimizer(self, model, lr, momentum, weight_decay=0):
        optimizer = torch.optim.SGD(model.parameters(), lr, momentum=momentum, weight_decay=weight_decay)
        return optimizer

    def build_data(self, train_data, test_data, batch_size):
        config = self.ob_config
        self.check_data_integrality(train_data, test_data)

        train_aug, val_aug, _ = aug_utils.get_standard_augmentations(mode=config.aug_mode)
        train_dataset = LabeledCustomData(images=train_data[DK.image],
                                          labels=train_data[DK.label],
                                          transforms=transforms.Compose(train_aug))
        val_dataset = LabeledCustomData(images=test_data[DK.image],
                                        labels=test_data[DK.label],
                                        transforms=transforms.Compose(val_aug))

        train_loader = torch.utils.data.DataLoader(train_dataset,
                                                   batch_size=batch_size,
                                                   shuffle=True,
                                                   num_workers=config.workers,
                                                   pin_memory=True)
        val_loader = torch.utils.data.DataLoader(val_dataset,
                                                 batch_size=batch_size,
                                                 shuffle=False,
                                                 num_workers=config.workers,
                                                 pin_memory=True)
        return train_dataset, val_dataset, train_loader, val_loader

    def init_model(self):
        # TODO: implement details in subClass
        raise NotImplementedError()

    def save_model(self, model, optimizer, step, filename, epoch, best_acc1, *args, **kwargs):
        config = self.ob_config

        filename = os.path.join(os.path.dirname(filename), self.stored_model_name)
        trace_fn = filename.replace('.pth.tar', '_trace')

        if self.parallel is None:
            state = {'epoch': epoch + 1,
                     'arch': config.arch,
                     'best_acc1': best_acc1,
                     'state_dict': model.state_dict(),
                     'optimizer': self.optimizer.state_dict(), }
            trace_model = model

        elif self.parallel == 'DataParallel':
            inner_model = model.module
            state = {'epoch': epoch + 1,
                     'arch': config.arch,
                     'best_acc1': best_acc1,
                     'state_dict': inner_model.state_dict(),
                     'optimizer': self.optimizer.state_dict(), }
            trace_model = inner_model
        elif self.parallel == 'DistributedDataParallel':
            raise NotImplementedError()
        else:
            raise ValueError()

        semi_helper.save_checkpoint(state, is_best=True, best_checkpoint_path=filename, printf=self.logger.info)
        utils.script_tracing(utils.ModelWrapper(trace_model), trace_fn, example=torch.rand([1, 3, 224, 224]))

    def setup_seed(self, seed):
        if seed:
            random.seed(seed)
            torch.manual_seed(seed)
            cudnn.deterministic = True

    def check_data_integrality(self, train_data, val_data):
        assert isinstance(train_data, dict) and isinstance(val_data, dict)
        assert DK.image in train_data and DK.image in val_data
        assert DK.label in train_data and DK.label in val_data

        assert len(train_data[DK.image]) == len(train_data[DK.label]) != 0
        assert len(val_data[DK.image]) == len(val_data[DK.label]) != 0


class KwaiMocoFinetuneModel(FewShotFinetuneModel):
    def __init__(self, config, runner_name):
        super(KwaiMocoFinetuneModel, self).__init__(params=config, runner_name=runner_name)

    def init_model(self):
        config, logger = self.ob_config, self.logger

        logger.info(f"=> Creating model '{config.arch}', Using torch vision pretrained {config.use_torchvision}")
        model = models.__dict__[config.arch](pretrained=config.use_torchvision)

        logger.info("Creating optimizer ...")
        optimizer = self.create_optimizer(model, self.lr, 0.9)

        if config.resume:
            config, model, optimizer = semi_helper.resume_previous_checkpoint(config, model, optimizer,
                                                                              printf=logger.info)
        elif config.pretrained:
            config, model = semi_helper.load_pretrained_checkpoint(config, model, printf=logger.info)

        if config.arch.lower().startswith('resnet'):
            dim_mlp = model.fc.weight.shape[1]
            model.fc = nn.Linear(dim_mlp, config.num_classes)
            model.fc.weight.data.normal_(mean=0.0, std=0.01)
            model.fc.bias.data.zero_()
        elif config.arch.lower().startswith('mobilenet'):
            dim_mlp = model.classifier[1].weight.shape[1]
            model.classifier[1] = nn.Linear(dim_mlp, config.num_classes)
            model.classifier[1].weight.data.normal_(mean=0.0, std=0.01)
            model.classifier[1].bias.data.zero_()

        self.ob_config, self.model, self.optimizer = config, model, optimizer

# class BiTFinetuneModel(FewShotFinetuneModel):
#     # TODO: waiting
#     def __init__(self, config: semi_helper.FinetuneConfig, train_data: dict, val_data: dict):
#         super(BiTFinetuneModel, self).__init__(config=config,
#                                                train_data=train_data,
#                                                val_data=val_data)
