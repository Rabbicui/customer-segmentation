# 目标检测模型数据标注
目前支持yolov5的检测模型，并同步生成线上可用的tracing格式。

# 标注数据方法

## 1. 使用开源的标注工具
labelImg
* 参考[labelImg的使用方法](https://github.com/tzutalin/labelImg)，标注成yolo格式的数据
* 参考[Train-Custom-Data](https://github.com/ultralytics/yolov5/wiki/Train-Custom-Data)，转换成模型需要的格式
* 转化之后的图片数据格式参考object_detection_demo.py中的训练和验证集

## 2. 使用现有标注平台
MMU标注平台
* 可以找MMU相关产品同学 wb_wangyushuang，产品同学会全力支持
* 根据产品提供的文档等准备数据，进行标注
* 将标注平台的数据转化成模型需要的数据

## 3. 后续我们会提供基于以上两种方式的转化脚本
欢迎kim提供宝贵意见：zhangheng07, hanjifei


