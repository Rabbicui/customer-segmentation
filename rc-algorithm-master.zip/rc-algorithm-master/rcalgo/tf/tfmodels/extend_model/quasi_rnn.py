import os
import sys
# sys.path.insert(0,'..')
from rcalgo.tf.module.layer.basic import my_conv_1d, my_dropout
from rcalgo.tf.utils.tf_func import get_new_variable_scope

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../"))

from rcalgo.tf.tftraining.tf_object import *
from rcalgo.tf.utils.tf_float_type import get_default_float_type

from tensorflow.python.ops import rnn_cell, array_ops
from tensorflow.python.ops.rnn import bidirectional_dynamic_rnn, dynamic_rnn


class QRNN_pooling(rnn_cell.RNNCell):
    def __init__(self, out_fmaps, pool_type):
        self.__pool_type = pool_type
        self.__out_fmaps = out_fmaps

    @property
    def state_size(self):
        return self.__out_fmaps

    @property
    def output_size(self):
        return self.__out_fmaps

    def __call__(self, inputs, state, scope=None):
        pool_type = self.__pool_type
        with tf.compat.v1.variable_scope(scope or "QRNN-{}-pooling".format(pool_type)):
            if pool_type == 'f':
                # extract Z activations and F gate activations
                Z, F = tf.split(inputs, 2, axis=1)
                output = tf.multiply(F, state) + tf.multiply(tf.sub(1., F), Z)
                return output, output
            elif pool_type == 'fo':
                Z, F, O = tf.split(inputs, 3, axis=1)
                new_state = tf.multiply(F, state) + \
                    tf.multiply(tf.sub(1., F), Z)
                output = tf.multiply(O, new_state)
                return output, new_state
            elif pool_type == 'ifo':
                Z, I, F, O = tf.split(inputs, 4, axis=1)
                new_state = tf.multiply(F, state) + tf.multiply(I, Z)
                output = tf.multiply(O, new_state)
                return output, new_state
            else:
                raise ValueError('Pool type must be either f, fo or ifo')


class QuasiResidualWrapper(rnn_cell.ResidualWrapper):
    def __init__(self, cell, residual_fn=None):
        super(QuasiResidualWrapper, self).__init__(cell, residual_fn)

    def __call__(self, inputs, state, scope=None):
        outputs, new_state = self._cell(inputs, state, scope=scope)
        res_outputs = inputs[:, 0:tf.shape(outputs)[1]] + outputs
        return (res_outputs, new_state)

class QRNN_layer(object):
    """
    Quasi-Recurrent Neural Network Layer
    (cf. https://arxiv.org/abs/1611.01576)
    """

    def __init__(self, hidden_size, conv_length=2,
                 activation=tf.nn.tanh, pool_type='ifo',
                 zoneout=0, training=False,
                 use_residual=False, name='QRNN'):
        """
        hidden_size: the dimension of this layer
        conv_length:: conv length of Quasi-RNN
        pool_type: can be f, fo, or ifo
        zoneout: > 0 means apply zoneout with p = 1 - zoneout
        use_residual: residual connection
        """
        if isinstance(training, bool):
            training = tf.convert_to_tensor(training)

        self.hidden_size = hidden_size
        self.conv_length = conv_length
        self.activation = activation
        self.pool_type = pool_type
        self.zoneout = zoneout
        self.training = training
        self.use_residual = use_residual
        self.name = name

    def convolution(self, input_tensor, conv_length, hidden_size, pool_type, zoneout_, activation, training):
        """
        Applies 1D convolution along time-dimension (T) assuming input
        tensor of dim (batch_size, T, n) and returns
        (batch_size, T, out_fmaps)
        zoneout: regularization (dropout) of F gate
        """
        z = my_conv_1d(input_tensor, conv_length, hidden_size,
                       add_bias=False, padding='VALID', act=activation)
        gates = []
        # compute gates convolutions
        for gate_name in pool_type:
            g = my_conv_1d(input_tensor, conv_length, hidden_size,
                           add_bias=False, padding='VALID', act=tf.nn.sigmoid)
            if zoneout_ > 0 and gate_name == 'f':
                # g = zoneout((1. - g), 1. - zoneout_)
                g = 1. - my_dropout((1. - g), zoneout_, training)
            gates.append(g)
        return z, gates

    def __call__(self, inputs, sequence_length):
        with get_new_variable_scope(self.name) as rnn_scope:
            # ensure the same length
            extend_inputs = tf.concat(
                [tf.zeros_like(inputs[:, 0:(self.conv_length-1), :], dtype=get_default_float_type()), inputs], 1)
            Z, gates = self.convolution(extend_inputs, self.conv_length, self.hidden_size,
                                        self.pool_type, self.zoneout, self.activation, self.training)
            T = tf.concat([Z] + gates, 2)
            #pooling cell, similar to rnn but more fast
            pool_cell = QRNN_pooling(self.hidden_size, self.pool_type)
            #zero state
            initial_state = pool_cell.zero_state(
                batch_size=tf.shape(inputs)[0], dtype=get_default_float_type())
            #if self.use_residual:
            #    pool_cell = QuasiResidualWrapper(pool_cell)
            # encapsulate the pooling in the iterative dynamic_rnn
            H, last_C = tf.nn.dynamic_rnn(pool_cell, T, sequence_length,
                                          initial_state=initial_state)
            if self.use_residual:
                if inputs.get_shape()[-1].value == H.get_shape()[-1].value:
                    #print('residual connection')
                    H = inputs + H
            return H, last_C



class MultiQRNNLayer(QRNN_layer):
    """
    Stack Quasi-RNN with residual connection (densely connection)
    """
    def __init__(self, num_layers, *args, **kwargs):
        super(MultiQRNNLayer, self).__init__(*args, **kwargs)
        self.num_layers = num_layers

    def __call__(self, inputs, sequence_length):
        qrnn_h = inputs
        for i in range(self.num_layers):
            use_residual = True if i != 0 else self.use_residual
            qrnn_ = QRNN_layer(self.hidden_size, conv_length=self.conv_length,
                               activation=self.activation, pool_type=self.pool_type,
                               zoneout=self.zoneout, training=self.training,
                               use_residual=use_residual, name='QRNN_layer{}'.format(i))
            qrnn_h, last_state = qrnn_(qrnn_h, sequence_length)
        return qrnn_h, last_state


class MultiBiQRNNLayer(MultiQRNNLayer):
    """
    Stack Bidirection Quasi-RNN with residual connection (densely connection)
    """
    def __init__(self, *args, **kwargs):
        super(MultiBiQRNNLayer, self).__init__(*args, **kwargs)
        self.mqrnn_fw = MultiQRNNLayer(*args, **kwargs)
        self.mqrnn_bw = MultiQRNNLayer(*args, **kwargs)

    def __call__(self, inputs, sequence_length):
        with get_new_variable_scope('bidirectional_qrnn') as rnn_scope:
            # forward qrnn
            with get_new_variable_scope('qrnn_fw') as rnn_scope:
                output_fw, output_state_fw = self.mqrnn_fw(
                    inputs, sequence_length)
            with get_new_variable_scope('qrnn_bw') as rnn_scope:
                # inverse input sequence
                inputs_reverse = array_ops.reverse_sequence(
                    input=inputs, seq_lengths=sequence_length, seq_axis=1, batch_axis=0)
                tmp, output_state_bw = self.mqrnn_bw(
                    inputs_reverse, sequence_length)
                output_bw = array_ops.reverse_sequence(
                    tmp, seq_lengths=sequence_length, seq_axis=1, batch_axis=0)
            outputs = (output_fw, output_bw)
            output_states = (output_state_fw, output_state_bw)
            return (outputs, output_states)
