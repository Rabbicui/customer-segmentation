import tensorflow as tf
from rcalgo.tf.models.semi_supervised.adversarial_training import AdversarialTextClassificationModel, AdversarialTraining


class AdversarialTrainingTest(tf.test.TestCase):

    def test_AdversarialTraining(self):
        batch_size = 32
        unsup_ratio = 3
        gpu_num = 2
        num_epochs = 220
        num_train_steps = num_epochs * 50 // (batch_size * gpu_num)
        print(f"num_train_steps: {num_train_steps}")
        config = {
            # uda config
            "unsup_coeff": 1.5,  # unsup loss coeff
            "tsa_schedule": "linear_schedule",  # linear_schedule, exp_schedule, log_schedule, None
            "batch_size": batch_size,
            "unsup_ratio": unsup_ratio,  # unsup data ratio
            "num_train_steps": num_train_steps - 200,  # num of train steps is needed for tas threshold calcuation

            # model config
            "learning_rate": 0.003,

            "num_classes": 2,
            "max_seq_len": 100,
            "embedding_size": 128,
            "num_layers": 2,
            "conv_num_filters": 256,
            "keep_prob": 0.5,

            "gpu_id": 0,
            "gpu_num": gpu_num,

            "model_output_dir": "./saved_models",
            "model_name": "cnn"
        }
        tf.compat.v1.reset_default_graph()
        tf.compat.v1.reset_default_graph()
        adv_model = AdversarialTextClassificationModel(config=config, word_dict={}, name="default",
                                                       distribute="tf_distribute")
        adv_training = AdversarialTraining(config, adv_model, name='adv_training')
        adv_training.build_model()
        print(adv_training.model_summary())


if __name__ == "__main__":
    tf.test.main()
