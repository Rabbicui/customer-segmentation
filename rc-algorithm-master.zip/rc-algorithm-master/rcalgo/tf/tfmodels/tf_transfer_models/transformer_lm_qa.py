import tensorflow as tf

from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.utils.tf_func import get_new_variable_scope
from rcalgo.tf.utils.tf_func import shape_list
from rcalgo.tf.utils.tf_func import replace_default_graph
from rcalgo.tf.metric.loss import l2_loss
from rcalgo.tf.module.layer.basic import my_dropout
from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.module.layer.attention import query_key_value_attention
from .transfer_model import TransferTFModel

class TransformerLMQA(TransferTFModel):
    def __init__(self, config, graph):
        super(TransformerLMQA, self).__init__(config, graph)
        with self.graph.as_default():
            self.original_trainable_variables = tf.compat.v1.trainable_variables()
        self.labels = config.labels if hasattr(config, 'labels') else 1
        self.p_coef = config.p_coef if hasattr(config, 'p_coef') else 0
        print('p_coef:', self.p_coef)

        self.fix_lm_layer = config.fix_lm_layer
        self.embedding_size = config.embedding_size
        self.attention_size = config.attention_size
        self.output_matrix_dim = config.output_matrix_dim
        self.attention_type = config.attention_type

        self.input_question_embedding = {}
        self.question_slots = config.question_slots
        self.init_std = config.init_std
        self.init_scale = config.init_scale
        self.tower_attentions = [[] for i in range(0, self.gpu_num)]


    def _penalty(self):
        p_loss = self.p_coef * l2_loss()
        return p_loss


    def build_input(self):
        self._add_to_graph_inputs(tf.compat.v1.get_collection("default_inputs"))
        with tf.name_scope('input'):
            if self.labels == 1:
                self.inputLabel = tf.compat.v1.placeholder(tf.int32, [None], name="label")
            else:
                self.inputLabel = tf.compat.v1.placeholder(
                    get_default_float_type(), [None, self.labels], name='label')
            self._add_to_graph_targets(self.inputLabel)
            self.split_inputLabel = tf.split(self.inputLabel, self.original_tower_num, 0)

            self.inputQuestion = tf.compat.v1.placeholder(tf.int32, [None], name="question")
            self._add_to_graph_inputs(self.inputQuestion)
            self.split_inputQuestion = tf.split(self.inputQuestion, self.original_tower_num, 0)
            self._add_to_graph_input_dict(self.split_inputQuestion[0])

        with tf.name_scope('states_array'):
            self.pool_flat_drop_list = [[] for i in range(0, self.gpu_num)]


    def build_classification_model(self, gpu_id=0, reuse=None, dropout_keep_prob=0.5):
        _, sequence_len, hidden_size = shape_list(self.original_outputs[gpu_id])
        with get_new_variable_scope('embedding') as embedding_scope:
            self.input_question_embedding[gpu_id] = my_embedding_layer(self.split_inputQuestion[gpu_id],
                                                                       self.question_slots, hidden_size,
#                                                                        self.question_slots, self.embedding_size,
                                                                       layer_name='question_embedding_layer',
                                                                       zero_pad=False,
                                                                       init_scale=self.init_scale)
        with tf.name_scope('attention') as scope:
            last_flatten, alphas = query_key_value_attention(self.input_question_embedding[gpu_id],
                                                            self.original_outputs[gpu_id],
                                                            attention_type=self.attention_type)
        self.tower_attentions[gpu_id] = alphas
        self.pool_flat_drop_list[gpu_id] = my_dropout(
            last_flatten, rate=(1-dropout_keep_prob), training=self.training)


    @replace_default_graph
    def build_model(self, num_classes=2, accK=1, *args, **kwargs):
        self.build_input()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('{}{}'.format(self.device_str, gpu_id)):
                with tf.name_scope('Tower_{}'.format(idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_classification_model(
                            gpu_id=idx, reuse=reuse, *args, **kwargs)
                        self.build_prediction(
                            gpu_id=idx, num_classes=num_classes, accK=accK)
        self.build_model_aggregation()
        self._add_to_graph_outputs(self.prediction_results)
