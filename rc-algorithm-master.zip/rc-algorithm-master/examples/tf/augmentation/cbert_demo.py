import tensorflow as tf
from rcalgo.tf.utils.preprocessors import BertMLMPreprocessor
import os
import pandas as pd
import horovod.tensorflow as hvd
from rcalgo.tf.models.augmentation.conditional_bert.cbert import ConditionalBERT
import numpy as np

config = {
    "max_predictions_per_seq": 10,
    "masked_lm_probs": 0.15,
    "acck_k": 5,
    "type_vocab_size": 15,
    "pred_top_k": 100,
    "max_seq_length": 128,
    "epochs": 10,
    "test_size": 0.1,
    "batch_size": 32,
    "warmup_proportion": 0.1,
    "num_hidden_layers": 12,
    "learning_rate": 0.0002,
    "vocab_file": "/home/web_server/antispam/project/pretrained_models/"
                  "chinese_L-12_H-768_A-12/vocab.txt",
    "checkpoint_file": "/home/web_server/antispam/project/pretrained_models/"
                       "chinese_L-12_H-768_A-12/bert_model.ckpt"
}


def main(_):
    # load data
    data_dir = "/home/web_server/antispam/project/da_datasets/clue_tnews"
    train_path = os.path.join(data_dir, 'train_1w.csv')
    train_df = pd.read_csv(train_path, header=0)
    train_texts = train_df['text'].astype(str).tolist()
    train_labels = train_df['label'].astype(int).tolist()
    preprocessor = BertMLMPreprocessor(config['vocab_file'])
    input_ids, input_mask, label_type_ids, masked_lm_positions, masked_lm_ids, masked_lm_weights = preprocessor.process(
        train_texts, do_tokenize=True, max_seq_length=config['max_seq_length'],
        masked_lm_probs=config['masked_lm_probs'], max_predictions_per_seq=config['max_predictions_per_seq'],
        label_is_token_type=True, labels=train_labels)

    # compute num_train_steps and num_warmup_steps
    hvd.init()
    n_examples = int(len(train_texts) * (1 - config["test_size"]))
    config["num_train_steps"] = int(n_examples * config["epochs"] / config["batch_size"] / hvd.size())
    config["num_warmup_steps"] = int(config["num_train_steps"] * config["warmup_proportion"])
    print(config)

    # define model
    model = ConditionalBERT(config).build_model()
    tvars = [var for var in model.tvars if "token_type_embeddings" not in var.name]
    print(f'tvars size:{len(tvars)}')
    print(tvars)
    # 这里需要注意一下，BERT预训练的模型`token_type_embeddings`权重维度是[2,768]，其中token_type_vocab_size是2
    # 如果我们的分类任务类别个数大于2，在restore权重的时候这个权重只能重新初始化，从头开始学习，否则会报错
    model.restore_weights(config["checkpoint_file"], tvars)
    print('model trainable variable size:', len(model.tvars))
    print(model.tvars)
    print(model.model_summary())

    # 1. train model
    train_data = [input_ids, input_mask, label_type_ids, masked_lm_positions, masked_lm_ids, masked_lm_weights]
    model.train(train_data,
                batch_size=config["batch_size"],
                test_size=config["test_size"],
                epochs=config["epochs"],
                checkpoint_dir="./saved_models",
                checkpoint_name="cbert",
                hooks=[])

    # 2. predict
    model.restore_weights('./saved_models/best_model/cbert-epoch7.ckpt')
    example_size = 8
    example_data = list(
        zip(input_ids, input_mask, label_type_ids, masked_lm_positions, masked_lm_ids, masked_lm_weights))[
                   :example_size]
    example_input_data = [list(t) for t in zip(*example_data)]
    pred_res = model.predict(example_input_data, batch_size=128)

    # pred_res 是一个2维的list，
    # pred_res[0] 是原始sofmax结果：[batch_size, max_predictions_per_seq, vocab_size]
    # pred_res[1]是取topk的词表位置: [batch_size, max_predictions_per_seq, pred_top_k]
    pred_res = np.reshape(pred_res[1], [example_size, config['max_predictions_per_seq'], -1])
    print(pred_res.shape)

    example_texts = train_texts[:example_size]
    example_labels = train_labels[:example_size]
    # 预测结果后处理，将id转换为token，得到生成的增强文本
    total_out = process_pred_result(preprocessor, example_texts, example_input_data, pred_res,
                                    topk=10)  # [exmaple_size, topk]
    print(total_out[0])


def process_pred_result(preprocessor, test_texts, test_data, pred_res, topk=10):
    input_ids, input_mask, label_type_ids, masked_lm_positions, masked_lm_ids, masked_lm_weights = test_data
    total_out = []
    for k in range(topk):
        cur_out = []
        for i in range(len(pred_res)):
            raw_text = test_texts[i]
            pred_token = preprocessor.tokenizer.tokenize(test_texts[i])
            pred_token = list(map(lambda x: x if x != '[UNK]' else ' ', pred_token))
            for j in range(len(pred_res[i])):
                topk_token = preprocessor.tokenizer.convert_id_to_token(pred_res[i][j][k])
                position = masked_lm_positions[i][j]
                if position == 0:
                    continue
                pred_token[position - 1] = topk_token if topk_token != '[UNK]' else ' '
            pred_text = ''.join(pred_token)
            cur_out.append(pred_text)
        total_out.append(cur_out)
    total_out = np.array(total_out)
    total_out = np.transpose(total_out)
    return total_out


if __name__ == '__main__':
    tf.app.run()
