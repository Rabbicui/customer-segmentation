import glob
import horovod.tensorflow as hvd
import os
import shutil
from collections import defaultdict
from rcalgo.tf.training import context
from rcalgo.tf.training import Model
from rcalgo.tf.training import training_utils
from rcalgo.tf.module.layer.basic import relu_fc_layer
from rcalgo.tf.module.layer.basic import my_full_connected
from rcalgo.tf.models.multi_modal.fusion.data_util import *
from rcalgo.tf.models.multi_modal.fusion.fusion_config import *
from rcalgo.tf.models.multi_modal.fusion.fusion_util import *
from tqdm import tqdm


class EmbeddingFusion(Model):

    def __init__(self, config, use_new_config=False, model_name=MFP_MODEL, **kwargs):
        super().__init__(config=config, **kwargs)
        self.learning_rate = config.get('lr', 0.0003)
        self.num_classes = config.get("num_classes", 2)
        self.group_output_max_weight_info = config.get('group_with_max_weight_info', None)
        self.model_name = model_name
        if self.group_output_max_weight_info is None:
            self.group_output_max_weight_info = []

        # 额外信息
        # 对于一些数据需要辅助信息：
        # 比如 对于 用户embedding 需要在模型里来做 norm，norm的std 和mean 则需要保存在图里（预测时候需要保持一致）
        # 这些信息会被当成常量保存
        self.extra_infos = config.get('extra_info', {})

        if use_new_config:
            # use mfp_model config as default which inferences faster (3X times or more when batch_size = 512) than
            # the old large data config and achieves higher acc in many tasks, sometimes block_model would also achieve
            # higher recall than mfp_model when precision is as high as 0.99+, but block_model is slower than mfp_model
            if self.model_name == MFP_MODEL:
                self.prefusion_configs = MFP_MODEL_PREFUSION_CONFIGS
                self.subnet_fusion_config = MFP_MODEL_SUBNET_FUSION_CONFIGS
            elif self.model_name == BLOCK_MODEL:
                self.prefusion_configs = BLOCK_MODEL_PREFUSION_CONFIGS
                self.subnet_fusion_config = BLOCK_MODEL_SUBNET_FUSION_CONFIGS
            else:
                raise ValueError(f'model name {self.model_name} error, must be mfp_model or block_model')
        else:
            self.large_data = config.get('train_size_larger_than_100w', False)
            self.subnet_fusion_config = DEFAULT_SUBNET_FUSION_CONFIGS \
                if self.large_data else SMALL_DEFAULT_SUBNET_FUSION_CONFIGS
            self.prefusion_configs = DEFAULT_PREFUSION_CONFIGS \
                if self.large_data else SMALL_DEFAULT_PREFUSION_CONFIGS

        self.embedding_cnt = config['embedding_cnt']
        self.embedding_sizes = config['embedding_sizes']
        assert self.embedding_cnt == len(self.embedding_sizes)
        # to generalize the usage, the group definition is used here same source embeddings
        # (like multiple frames from video) formed as a group. Then we don't need to consider what
        # the embedding really means.
        self.embedding_groups = config['embedding_groups']
        # add pairwise attention config
        self.pairwise_group_dict = config.get('pairwise_group_dict', {})

        self.idx_2_group_map = dict()
        for idx, g in enumerate(self.embedding_groups):
            self.idx_2_group_map[idx] = g

    def get_extra_info_tensor_by_name(self, name):
        return self.extra_tensors[name]

    def preprocess_input(self, group, group_input_tensors):
        # 目前默认只支持对数据进行归一化操作，需用户在 extra_info 中配置 {group}_std 和 {group}_mean 这两个参数
        # 例如若需要对 user 这个模态/group做归一化，对应的配置为，其中 user_scale 和 user_mean 是已经提前计算好的值
        # "extra_info": {
        #     "user_std": user_scale,
        #     "user_mean": user_mean,
        # }
        # 也可自行重写该方法
        # task related pre-process for input
        # in our demo: we normalize the user features
        """
             if group == 'user':
                # config 里的 extra info 应该已经放入了对应的这边做norm 所需要的信息
                std = self.get_extra_info_tensor_by_name("user_std")
                mean = self.get_extra_info_tensor_by_name("user_mean")
                return [(inp - mean) / std for inp in group_input_tensors]
                return group_input_tensors
        """
        if group + '_std' in self.extra_infos and group + '_mean' in self.extra_infos:
            std = self.get_extra_info_tensor_by_name(group + '_std')
            mean = self.get_extra_info_tensor_by_name(group + '_mean')
            return [(inp - mean) / std for inp in group_input_tensors]
        return group_input_tensors

    ##############################################################################################

    def create_inputs(self):
        group_inputs_map = defaultdict(list)
        raw_inputs = []
        for idx, size in enumerate(self.embedding_sizes):
            g = self.idx_2_group_map[idx]
            # build placeholder for each embedding group, we don't care what the embedding really means
            pl = tf.placeholder(tf.float32, [None, size], name=g + '_' + str(idx))
            raw_inputs.append(pl)
            group_inputs_map[g].append(pl)

        input_label = tf.placeholder(tf.int32, [None], name='label')

        # create constants for extra infos
        self.extra_tensors = {}
        for name, value in self.extra_infos.items():
            t = tf.constant(value, dtype=tf.float32, name=name)
            self.extra_tensors[name] = t

        return raw_inputs, group_inputs_map, input_label

    def call(self, group_inputs_map, **kwargs):
        # pre-process procedure this is defined by specific task
        # 针对每个不同的group 可能需要做一些预处理工作，比如 用户的embedding，可能需要做 norm
        group_inputs_map = {group_name: self.preprocess_input(group_name, group_inputs)
        for group_name, group_inputs in group_inputs_map.items()}

        # pre_fc
        configs = {}
        pre_fc_layers_map = {}
        for group, inputs in group_inputs_map.items():
            group_prefusion_config = self.prefusion_configs['multi'] \
                if len(inputs) > 1 else self.prefusion_configs['single']
            configs[group] = group_prefusion_config
            pre_fc_layers_map[group] = pre_fc(group, inputs, group_prefusion_config, training_utils.get_or_create_is_training())

        # pre-fusion procedure
        pre_fusion_layers_map = {}
        group_max_weights_idx = {}
        group_max_weights = {}
        for group, inputs in pre_fc_layers_map.items():
            pw_other_inputs = []
            config = configs[group]
            if self.pairwise_group_dict.get(group, None) is not None:
                # we use dict type config for pairwise attention so that each group would have its own pairwise groups
                # config example:
                # {
                #     "pairwise_group_dict": {
                #         "user" :  "img,text",
                #         "img"  :  "text,speech"
                #     }
                # }
                pw_groups = self.pairwise_group_dict[group]
                pw_groups = [g.strip() for g in pw_groups.split(',')]
                # here we use pre_fc_layer output as input instead of the original input
                pw_other_inputs = [pre_fc_layers_map[g] for g in pw_groups]
            layers, weights = pre_fusion(inputs, pw_other_inputs, config)

            # 保存对应group最大的权重信息
            if weights is not None and group in self.group_output_max_weight_info:
                weight_max_idx = tf.math.argmax(weights, axis=1)
                group_max_weights_idx[group] = weight_max_idx
                group_max_weights[group] = tf.math.reduce_max(weights, axis=1)

            layers = [l for l in layers if l is not None]
            if len(layers) > 1:
                # do concat
                pre_fusion_layers_map[group] = tf.concat(layers, axis=-1)
            elif len(layers) == 0:
                # no pre fusion so use the original inputs
                pre_fusion_layers_map[group] = tf.concat(inputs, axis=-1)
            else:
                pre_fusion_layers_map[group] = layers[0]

        # pre_fusion_layers: group ---> embedding since in pre-fusion layer we will merge embeddings
        # from same source to one embedding
        # post fc layer
        layers_after_pre_fusion = []
        for group, layer in pre_fusion_layers_map.items():
            config = configs[group]
            if config.get('post_fc_layer', False):
                size = config['post_fc_hidden_size']
                layer = relu_fc_layer(layer, size, 0.0001)
                post_dropout = config['post_fc_dropout_ratio']
                if post_dropout > 0:
                    # apply dropout
                    layer = my_dropout(layer, rate=post_dropout, training=training_utils.get_or_create_is_training())
            layers_after_pre_fusion.append(layer)

        # subnet-fusion procedure
        embedding = subnet_fusion(layers_after_pre_fusion, self.subnet_fusion_config , training_utils.get_or_create_is_training())
        logits = my_full_connected(embedding, self.num_classes)
        prediction = tf.nn.softmax(logits)
        return logits, group_max_weights_idx, group_max_weights, prediction

    def add_extra_attrs(self, infos):
        self.add_extra_attr("logits", infos[0])
        self.add_extra_attr("max_weight_idxs", infos[1])
        self.add_extra_attr("max_weights", infos[2])

    def build_forward(self, **kwargs):
        raw_inputs, self.inputs, self.labels = self.create_inputs()
        logits, group_max_weights_idx, group_max_weights, self.outputs = self.call(self.inputs, **kwargs)

        # flatten group info
        max_weight_idxs = []
        max_weights = []
        for group in self.group_output_max_weight_info:
            max_weight_idxs.append(group_max_weights_idx[group])
            max_weights.append(group_max_weights[group])

        self.loss = self.compute_loss(logits, self.labels)
        self.metrics = self.compute_metrics(self.outputs, self.labels)
        self.add_extra_attrs([logits, max_weight_idxs, max_weights])

        training_utils.create_task_in_graph(
            raw_inputs, [self.outputs] + max_weight_idxs + max_weights, self.labels, self.loss,
            self.metrics, name=self.name)

    def comput_loss(self, logits, label):
        loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
            labels=label, logits=logits)
        loss = tf.reduce_mean(loss)
        return loss

    def compute_metrics(self, outputs, labels):
        accuracy = tf.cast(tf.nn.in_top_k(outputs, labels, k=1), dtype=tf.float32)
        return accuracy


class AutoMultiModal(object):
    """
    run both block model and mfp model, compare them on test data and choose a better one
    if two models' difference is very small, we choose mfp model for the better inference speed
    """

    def __init__(self, config, model=EmbeddingFusion, **kwargs):
        self.config = config
        self.precision = self.config.get('precision', 0.9)  # the expected precision which we want to compare recall at
        # if a model's recall is lower than recall_th, we assume it is meaningless to compare
        self.recall_th = self.config.get('recall_th', 0.05)
        # only the two models' recall difference is bigger than recall_gap we assume the difference is remarkable
        self.recall_gap = self.config.get('recall_gap', 0.005)
        # only the two models' accuracy difference is bigger than acc_gap we assume the difference is remarkable
        self.acc_gap = self.config.get('acc_gap', 0.005)
        self.export_frozen = self.config.get('export_frozen', True)
        self.clear_old_models = self.config.get('clear_old_models', True)

        self.block_model = model(self.config, use_new_config=True, model_name=BLOCK_MODEL, name=BLOCK_MODEL)
        self.block_model.build_model()
        # if embedding_cnt <= 2, we just train block model
        if self.config['embedding_cnt'] > 2:
            self.mfp_model = model(self.config, use_new_config=True, model_name=MFP_MODEL, name=MFP_MODEL)
            self.mfp_model.build_model()
        else:
            self.mfp_model = None

    def select_model(self, model_name):
        """
        select model by model name
        Args:
            model_name: a string of "block_model" or "mfp_model"

        Returns: the corresponding model

        """

        if model_name == BLOCK_MODEL:
            return self.block_model
        elif model_name == MFP_MODEL:
            return self.mfp_model
        else:
            raise ValueError(f"Model name {model_name} is illegal! Please use block_model or mfp_model.")

    def restore_from_checkpoint_and_export_frozen(self, model_name, checkpoint_dir):
        """
        restore model variables from checkpoint and export frozen.pb
        Args:
            model_name: a string of "block_model" or "mfp_model"
            checkpoint_dir: checkpoint directory

        Returns: None. will export frozen.pb in {checkpoint_dir}/frozen/multimodal_v1

        """
        model_name = self.select_model(model_name)
        best_model = glob.glob(os.path.join(checkpoint_dir, 'best_model', '*meta'))[0][:-5]
        model_name.restore_checkpoint(path=best_model)
        model_name.export_freeze_graph(graph_dir=os.path.join(checkpoint_dir, 'frozen'), model_version='multimodal_v1')

    def predict(self, model_name, checkpoint_path, data):
        """
        predict model result by the given data
        TODO: it seems it will run several times when using horovod, now we just write a new function: predict_labels
        Args:
            model_name:      a string of "block_model" or "mfp_model"
            checkpoint_path: checkpoint path, for example: /rc_algo/model/multi_modal_demo-epoch0.ckpt
            data:            data to inference: tf.data.Dataset (usually TFRecord), python list or numpy array

        Returns: predict_result

        """

        predict_model = self.select_model(model_name)
        checkpoint_path = glob.glob(os.path.join(checkpoint_path, '*meta'))[0][:-5]
        predict_model.restore_checkpoint(path=checkpoint_path)
        # data = data.split(1,0)
        outputs = predict_model.predict(data)
        return outputs[0]

    def predict_labels(self, model_name, checkpoint_path, data, batch_size=256):
        """
        predict model result by the given data
        Args:
            model_name:      a string of "block_model" or "mfp_model"
            checkpoint_path: checkpoint path, for example: /rc_algo/model/multi_modal_demo-epoch0.ckpt
            data:            data to inference: tf.data.Dataset (usually TFRecord), python list or numpy array
            batch_size:      batch_size

        Returns: predicted classify results

        """
        predict_model = self.select_model(model_name)
        checkpoint_path = glob.glob(os.path.join(checkpoint_path, '*meta'))[0][:-5]
        predict_model.restore_checkpoint(path=checkpoint_path)
        data = convert_to_tfdataset(data)
        # data = data.split(1, 0)
        test_data = data.batch(batch_size, drop_remainder=False)
        test_iterator = test_data.make_iterator()
        test_iterator.reinitialize()
        next_element = test_iterator.next_element()
        tqdm_iter = tqdm(range(test_data.get_num_steps(ceil=True)), position=0, leave=True)
        outputs = []
        sess = context.get_session()
        for item in tqdm_iter:
            batch_outputs = predict_model.predict_on_batch(next_element)
            outputs.append(batch_outputs[0])
        return np.concatenate(outputs, axis=0)

    def get_best_model(self, labels, block_preds, mfp_preds):
        """
        compare block model and mfp model and choose a better one
        Args:
            labels:       true labels
            block_preds:  block model predict results
            mfp_preds:    mfp model predict results

        Returns: best model name, block_model or mfp_model

        """
        # binary classification：compare recall at the same precision, multi classification：compare top1 accuracy
        if self.config.get("num_classes", 2) == 2:
            block_pred_probs = block_preds[:, 1]
            mfp_pred_probs = mfp_preds[:, 1]

            block_recall = get_recall(0.0, 1.0, labels, block_pred_probs, self.precision)
            mfp_recall = get_recall(0.0, 1.0, labels, mfp_pred_probs, self.precision)

            # 如果在设定 precision 下两种结构模型的召回都太低，可能不具备实际比较意义，直接选择 acc 较高的模型
            if mfp_recall < self.recall_th and block_recall < self.recall_th:
                mfp_acc = get_top1_acc(labels, mfp_preds)
                block_acc = get_top1_acc(labels, block_preds)
                return BLOCK_MODEL if block_acc - mfp_acc > self.acc_gap else MFP_MODEL

            return BLOCK_MODEL if block_recall - mfp_recall > self.recall_gap else MFP_MODEL

        else:
            block_acc = get_top1_acc(labels, block_preds)
            mfp_acc = get_top1_acc(labels, mfp_preds)
            return BLOCK_MODEL if block_acc - mfp_acc > self.acc_gap else MFP_MODEL

    def save_best_model(self, best_model_checkpoint_dir, worse_model_checkpoint_dir,
                        dest_checkpoint_dir, clear_old_models=True):
        """
        copy the best model's checkpoint from best_model_checkpoint_path to dest_checkpoint_dir and delete
        useless model files if clear_old_models is True

        before saving, the directory is like
        |── root
            |── mfp
            |   |── best_model
            |   |   |── mfp-epochx.ckpt.index
            |   |   |── mfp-epochx.ckpt.meta
            |   |   └── ...
            |   |── mfp-epochy.ckpt.meta
            |   |── mfp-epochy.ckpt.index
            |   └── ...
            └── block
                |── best_model
                |   |── block-epochx.ckpt.index
                |── block-epochx.ckpt.meta
                |   └── ...
                |── block-epochy.ckpt.meta
                |── block-epochy.ckpt.index
                └── ...

        if `clear_old_models` is True, after saving, the directory is like
        |── root
            |── best_model
            |   |── mfp/block-epochx.ckpt.index
            |   |── mfp/block-epochx.ckpt.meta
            |   └── ...
            |── mfp/block-epochy.ckpt.meta
            |── mfp/block-epochy.ckpt.index
            └── ...

        Args:
            best_model_checkpoint_dir:  the path of the best model checkpoint
            dest_checkpoint_dir:         dest checkpoint dir to copy to
            worse_model_checkpoint_dir: we only keep the best model's checkpoint if `clear_old_models` is set `True`
                                         so the other model's checkpoint can be deleted
            clear_old_models:            if True, we would delete the original mfp and block directory

        Returns: None

        """
        best_dir = os.path.join(dest_checkpoint_dir, 'best_model')
        for f in glob.glob(os.path.join(best_dir, '*')):
            os.remove(f)
        if not os.path.exists(best_dir):
            os.makedirs(best_dir)
        for root, dirs, files in os.walk(best_model_checkpoint_dir, True):
            for file in files:
                if 'best_model' in root:
                    shutil.copy(os.path.join(root, file), best_dir)
                else:
                    shutil.copy(os.path.join(root, file), dest_checkpoint_dir)
        if clear_old_models:
            shutil.rmtree(path=best_model_checkpoint_dir)
            shutil.rmtree(path=worse_model_checkpoint_dir)

    def train_and_eval(self,
                       train_data,
                       valid_data,
                       batch_size,
                       epochs,
                       checkpoint_dir,
                       checkpoint_name,
                       max_to_keep=5,
                       test_data=None):
        """
        train and evaluate
        Args:
            train_data:      tf.data.Dataset (usually TFRecord), python list or numpy array
            valid_data:      tf.data.Dataset (usually TFRecord), python list or numpy array
            batch_size:
            epochs:
            checkpoint_dir:  checkpoint directory
            checkpoint_name: checkpoint name
            max_to_keep:     max number of checkpoint to keep
            test_data:       tf.data.Dataset (usually TFRecord), python list or numpy array

        Returns: None, save model in the checkpoint dir

        """
        best_model = BLOCK_MODEL
        # embedding_cnt <= 2: we just train block_model
        if self.config['embedding_cnt'] <= 2:
            checkpoint_dir_block = checkpoint_dir
            checkpoint_name_block = checkpoint_name
            self.block_model.train_and_evaluate(train_data,
                                                valid_data,
                                                batch_size,
                                                epochs,
                                                max_to_keep,
                                                checkpoint_dir_block,
                                                checkpoint_name_block
                                                )
        # embedding_cnt > 2: we train both block_model and mfp_model and then choose the better one
        else:
            checkpoint_dir_block = os.path.join(checkpoint_dir, 'block')
            checkpoint_name_block = checkpoint_name + '_' + 'block'
            self.block_model.train_and_evaluate(train_data,
                                                valid_data,
                                                batch_size,
                                                epochs,
                                                max_to_keep,
                                                checkpoint_dir_block,
                                                checkpoint_name_block
                                                )

            checkpoint_dir_mfp = os.path.join(checkpoint_dir, 'mfp')
            checkpoint_name_mfp = checkpoint_name + '_' + 'mfp'
            self.mfp_model.train_and_evaluate(train_data,
                                              valid_data,
                                              batch_size,
                                              epochs,
                                              max_to_keep,
                                              checkpoint_dir_mfp,
                                              checkpoint_name_mfp
                                              )
            # we do inference and compare only on the first GPU
            if hvd.rank() == 0:
                # load best mfp and block model to predict
                test_data = valid_data if test_data is None else test_data
                block_model_path = os.path.join(checkpoint_dir_block, 'best_model')
                # block_outputs = self.predict("block_model", block_model_path, test_data)
                block_outputs = self.predict_labels(BLOCK_MODEL, block_model_path, test_data)

                mfp_model_path = os.path.join(checkpoint_dir_mfp, 'best_model')
                # mfp_outputs = self.predict("mfp_model", mfp_model_path, test_data)
                mfp_outputs = self.predict_labels(MFP_MODEL, mfp_model_path, test_data)

                labels = get_labels(test_data, batch_size)

                best_model = self.get_best_model(labels, block_outputs, mfp_outputs)

                if best_model == BLOCK_MODEL:
                    self.save_best_model(checkpoint_dir_block, checkpoint_dir_mfp, checkpoint_dir,
                                         clear_old_models=self.clear_old_models)
                else:
                    self.save_best_model(checkpoint_dir_mfp, checkpoint_dir_block, checkpoint_dir,
                                         clear_old_models=self.clear_old_models)

        if hvd.rank() == 0 and self.export_frozen:
            self.restore_from_checkpoint_and_export_frozen(best_model, checkpoint_dir)

