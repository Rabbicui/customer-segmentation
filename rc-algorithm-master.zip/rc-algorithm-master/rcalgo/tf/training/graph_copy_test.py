import numpy as np
from rcalgo.tf.utils.tf_collections import *
from tensorflow.python.distribute.cross_device_ops import NcclAllReduce
from rcalgo.tf.training import graph_copy
from tensorflow.python.framework import ops
from collections import OrderedDict
from tensorflow.python.ops.gen_dataset_ops import multi_device_iterator_to_string_handle


class GraphCopyTest(tf.test.TestCase):
    
    def setUp(self):
        super().setUp()
        self.task = "default"
        task = self.task
        self.task_key = tf.compat.v1.GraphKeys.TASKS
        self.inputs_key = f"{task}_{tf.compat.v1.GraphKeys.INPUTS}"
        self.outputs_key = f"{task}_{tf.compat.v1.GraphKeys.OUTPUTS}"
        self.targets_key = f"{task}_{tf.compat.v1.GraphKeys.TARGETS}"
        self.loss_key = f"{task}_{tf.compat.v1.GraphKeys.LOSS}"
        self.metrics_key = f"{task}_{tf.compat.v1.GraphKeys.METRICS}"
        self.lr_key = f"{task}_{tf.compat.v1.GraphKeys.LR_VARIABLES}"
        self.train_ops_key = f"{task}_{tf.compat.v1.GraphKeys.TRAIN_OPS}"
        self.opt_pramas_key = f"{task}_{tf.compat.v1.GraphKeys.OPT_PARAMS}"
        self.input_iter_key = f"{task}_{tf.compat.v1.GraphKeys.INPUT_ITER}"
        self.iter_incar_id_key = f"{task}_{tf.compat.v1.GraphKeys.INPUT_ITER_INCARNATION_ID}"
        # self.test_data = np.reshape(np.arange(4, dtype=np.float32), [2, 2])
        self.test_data = np.ones([2, 2], dtype=np.float32)

    def test_build_train_graph(self):
        """测试graph copy前后，前向计算的结果是否相同（测试环境要求至少双卡）"""
        strategy = tf.distribute.MirroredStrategy(
            cross_device_ops=NcclAllReduce()
        )
        origin_graph = tf.Graph()
        with origin_graph.as_default():
            x = tf.placeholder(dtype=tf.float32, name='x')
            y = tf.placeholder(dtype=tf.float32, name='y')
            w = tf.Variable(2.0, name='w')
            b = tf.Variable(1.0, name='b')
            y_pred = tf.multiply(w, x) + b
            loss = tf.square(y - y_pred, name='loss')
            lr = 0.001
            optimizer = tf.train.AdamOptimizer(lr)
            train_op = optimizer.minimize(loss)

            origin_graph.add_to_collection(self.task_key, self.task)
            origin_graph.add_to_collection(self.inputs_key, x)
            origin_graph.add_to_collection(self.outputs_key, y_pred)
            origin_graph.add_to_collection(self.targets_key, y)
            origin_graph.add_to_collection(self.loss_key, loss)
            origin_graph.add_to_collection(self.metrics_key, loss)
            origin_graph.add_to_collection(self.lr_key, ops.convert_to_tensor(lr))
            origin_graph.add_to_collection(self.train_ops_key, train_op)

            opt_params = OrderedDict([("optimizer", "adam"), 
                          ("loss_scaling", False),
                          ("loss_scale_factor", 1000),
                          ("adam_epsilon", 1e-7),
                          ("adam_beta1", 0.9),
                          ("adam_beta2", 0.99),
                          ("adam_wd", 0.9),
                          ("clip_gradient", 1.0),
                          ("clip_type", 'clip_value')])
                        
            for key in opt_params:
                origin_graph.add_to_collection(self.opt_pramas_key,
                                       ops.convert_to_tensor(opt_params[key], name=key))

        new_graph = graph_copy.build_train_graph(origin_graph, strategy)
        # print(f"Original graph: {origin_graph.as_graph_def()}")
        # print(f"New graph: {new_graph.as_graph_def()}")
        
        # 保存copy前后的图结构
        # train_writer = tf.summary.FileWriter("summary_dir")
        # train_writer.add_graph(origin_graph)
        # train_writer.add_graph(new_graph)
        
        origin_y = self.run_original_graph(origin_graph)
        new_y = self.run_copyed_graph(new_graph)
        print(origin_y, new_y)
        self.assertEqual(origin_y, new_y)

    def run_original_graph(self, graph):
        with tf.Session(graph=graph) as sess:
            with sess.graph.as_default():
                x = graph.get_collection(self.inputs_key)[0]
                y_pred = graph.get_collection(self.outputs_key)[0]
                init_ops = [tf.compat.v1.global_variables_initializer(),
                            tf.compat.v1.local_variables_initializer(),
                            tf.compat.v1.tables_initializer()]
                sess.run(init_ops)
                return np.mean(sess.run(y_pred, feed_dict={x: self.test_data}))


    def run_copyed_graph(self, graph):        
        with tf.Session(graph=graph) as sess:
            with sess.graph.as_default():
                # x = graph.get_collection(self.inputs_key)[1]
                y_pred_1, y_pred_2 = graph.get_collection(self.outputs_key)
                print(y_pred_1, y_pred_2)
                input_iter = graph.get_collection(self.input_iter_key)[0]
                incarnation_id = graph.get_collection(self.iter_incar_id_key)[0]
                x_val = self.test_data
                y_val = self.test_data
                init_ops = [tf.compat.v1.global_variables_initializer(), 
                            tf.compat.v1.local_variables_initializer(),
                            tf.compat.v1.tables_initializer()]
                sess.run(init_ops)
                dataset = tf.data.Dataset.zip((tf.data.Dataset.from_tensor_slices(x_val), 
                                              tf.data.Dataset.from_tensor_slices(y_val))).batch(2)
                distribute_strategy = tf.distribute.MirroredStrategy()
                dist_dataset = distribute_strategy.experimental_distribute_dataset(dataset)
                iterator = dist_dataset.make_initializable_iterator()
                single_worker_iterator = iterator.get_iterator(iterator._input_workers.worker_devices[0])
                str_handle = multi_device_iterator_to_string_handle(single_worker_iterator._iterator._multi_device_iterator_resource)
                str_handle_val, _, incarnation_id_val = sess.run([str_handle, single_worker_iterator.initialize(), 
                                                                  single_worker_iterator._iterator._incarnation_id])
                y_pred_1_val = np.mean(sess.run(y_pred_1, feed_dict={input_iter: str_handle_val, incarnation_id: incarnation_id_val}))
                y_pred_2_val = np.mean(sess.run(y_pred_2, feed_dict={input_iter: str_handle_val, incarnation_id: incarnation_id_val}))
                
                return np.mean([y_pred_1_val, y_pred_2_val])

            

if __name__ == "__main__":
    tf.test.main()
