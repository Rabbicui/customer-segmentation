BLOCK_MODEL = "block_model"
MFP_MODEL = "mfp_model"

# block_model config
BLOCK_MODEL_SUBNET_FUSION_CONFIGS = {
    "block_attention": True,
    "block_attention_fc_layer_dropout": True,
    "block_attention_fc_layer_dropout_ratio": 0.2,
    "block_attention_n_layer": 4,
    "block_attention_n_head": 2,
    "block_attention_size": 32,
    "block_self_attention": False,
    "block_self_attention_size": 64,
    "block_attention_transformer_attention_dropout": 0.3,
    "block_attention_transformer_fc_dropout": 0.5,
    "lmf_fusion": False,
    "lmf_fusion_rank": 20,
    "self_attention": False,
    "additive_attention": False,
    "concat_fusion": False,
    "mfp": False,
    "mlp_mix": False,
    "mlp_dim": 128,
    "mlp_mix_depth": 3,
    "add_fusion": False,
    "lower_rank_fusion": False
}

BLOCK_MODEL_PREFUSION_CONFIGS = dict()
BLOCK_MODEL_PREFUSION_CONFIGS['multi'] = {
    "unary_attention": True,
    "pairwise_attention": False,
    "pairwise_attention_groups": None,
    "max_pooling": True,
    "avg_pooling": True,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 512,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": True,
    "post_fc_hidden_size": 512,
    "post_fc_dropout_ratio": 0.2
}

BLOCK_MODEL_PREFUSION_CONFIGS['single'] = {
    "unary_attention": False,
    "pairwise_attention": False,
    "pairwise_attention_types": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 512,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": False,
    "post_fc_hidden_size": False,
    "post_fc_dropout_ratio": 0.2
}

# mfp_model config
MFP_MODEL_SUBNET_FUSION_CONFIGS = {
    "block_attention": False,
    "block_attention_fc_layer_dropout": True,
    "block_attention_fc_layer_dropout_ratio": 0.2,
    "block_attention_n_layer": 4,
    "block_attention_n_head": 2,
    "block_attention_size": 32,
    "block_self_attention": False,
    "block_self_attention_size": 64,
    "block_attention_transformer_attention_dropout": 0.3,
    "block_attention_transformer_fc_dropout": 0.5,
    "lmf_fusion": False,
    "lmf_fusion_rank": 20,
    "self_attention": False,
    "additive_attention": False,
    "concat_fusion": False,
    "mfp": True,
    "mlp_mix": False,
    "mlp_dim": 128,
    "mlp_mix_depth": 3,
    "add_fusion": False,
    "lower_rank_fusion": False
}

MFP_MODEL_PREFUSION_CONFIGS = dict()
MFP_MODEL_PREFUSION_CONFIGS['multi'] = {
    "unary_attention": True,
    "pairwise_attention": False,
    "pairwise_attention_groups": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 512,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": True,
    "post_fc_hidden_size": 512,
    "post_fc_dropout_ratio": 0.2
}

MFP_MODEL_PREFUSION_CONFIGS['single'] = {
    "unary_attention": False,
    "pairwise_attention": False,
    "pairwise_attention_types": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 512,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": False,
    "post_fc_hidden_size": False,
    "post_fc_dropout_ratio": 0.2
}

# 小数据集合 < 100w
SMALL_DEFAULT_SUBNET_FUSION_CONFIGS = {
    "block_attention": True,
    "block_attention_fc_layer_dropout": True,
    "block_attention_fc_layer_dropout_ratio": 0.2,
    "block_attention_n_layer": 4,
    "block_attention_n_head": 2,
    "block_attention_size": 32,
    "block_self_attention": True,
    "block_self_attention_size": 64,
    "block_attention_transformer_attention_dropout": 0.3,
    "block_attention_transformer_fc_dropout": 0.3,
    "lmf_fusion": False,
    "lmf_fusion_rank": 20,
    "self_attention": False,
    "additive_attention": False,
    "concat_fusion": False,
    "add_fusion": False,
    "lower_rank_fusion": False
}

SMALL_DEFAULT_PREFUSION_CONFIGS = dict()
SMALL_DEFAULT_PREFUSION_CONFIGS['multi'] = {
    "unary_attention": True,
    "pairwise_attention": False,
    "pairwise_attention_groups": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 512,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": True,
    "post_fc_hidden_size": 512,
    "post_fc_dropout_ratio": 0.2
}

SMALL_DEFAULT_PREFUSION_CONFIGS['single'] = {
    "unary_attention": False,
    "pairwise_attention": False,
    "pairwise_attention_types": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 512,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": False,
    "post_fc_hidden_size": False,
    "post_fc_dropout_ratio": 0.2
}

# 大数据集 > 100w
DEFAULT_SUBNET_FUSION_CONFIGS = {
    "block_attention": True,
    "block_attention_fc_layer_dropout": True,
    "block_attention_fc_layer_dropout_ratio": 0.2,
    "block_attention_n_layer": 6,
    "block_attention_n_head": 2,
    "block_attention_size": 64,
    "block_self_attention": True,
    "block_self_attention_size": 128,
    "block_attention_transformer_attention_dropout": 0.3,
    "block_attention_transformer_fc_dropout": 0.3,
    "lmf_fusion": False,
    "lmf_fusion_rank": 20,
    "self_attention": False,
    "additive_attention": False,
    "concat_fusion": False,
    "add_fusion": False,
    "lower_rank_fusion": False
}

DEFAULT_PREFUSION_CONFIGS = dict()
DEFAULT_PREFUSION_CONFIGS['multi'] = {
    "unary_attention": True,
    "pairwise_attention": False,
    "pairwise_attention_groups": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 1024,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": True,
    "post_fc_hidden_size": 1024,
    "post_fc_dropout_ratio": 0.2
}

DEFAULT_PREFUSION_CONFIGS['single'] = {
    "unary_attention": False,
    "pairwise_attention": False,
    "pairwise_attention_types": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 1024,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": False,
    "post_fc_hidden_size": 1024,
    "post_fc_dropout_ratio": 0.2
}
