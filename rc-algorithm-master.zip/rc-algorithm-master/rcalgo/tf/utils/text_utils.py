import jieba
import re
import numpy as np
from tqdm import tqdm_notebook as tqdm

from collections import *
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
#sns.set_style("darkgrid")
plt.style.use('ggplot')
sns.set_style('whitegrid',{'font.sans-serif':['simhei','Arial']})
#sns.set(font="SimHei")
#%load_ext autoreload
#%autoreload 2
#%matplotlib inline

def get_term_list(sentence, word_seg=False):
    if word_seg:
        seg_list = jieba.cut(sentence.strip().lower())
        return " ".join(seg_list).split()
    else:
        return list(sentence)

def build_word2idx(word_freq, freq_threshold=10, blackset=set(['\t', '\r', '\n'])):
    term_id_map = {'<SOS>': 0}
    for key, value in word_freq.items():
        if value >= freq_threshold and key not in blackset:
            term_id_map[key] = len(term_id_map)
    return term_id_map

def get_truncated_geometric_distribution(p, max_k, length):
    z = np.random.geometric(p, size=length*10)
    return z[z<=max_k][0:length]

def get_mask_length(seq_len, low, high):
    start_position = np.mod(np.random.randint(0, 99999721, len(seq_len)), seq_len)
    sents_length = np.random.randint(low,high,size=len(seq_len))
    ngram_length = np.ceil(seq_len/sents_length)
    end_position = np.minimum(seq_len+1, start_position+ngram_length)
    return end_position-start_position

def regex_remove_duplicates(text, num=1):
    return re.sub(r'(.)\1+', r'\1'*num, text)     

def regex_remove_duplicates_exclude_str(text, exclude_str='6哈', num=1):
    return re.sub(r'([^{}])\1+'.format(exclude_str), r'\1'*num, text)  

def drop_duplicates(text, exclude_str='6哈', num=3):
    return regex_remove_duplicates(regex_remove_duplicates_exclude_str(regex_remove_duplicates_words(text),exclude_str),num) 
    
def contain_chinese(text):
    return re.search('[\u4e00-\u9fa5]+', text) is not None

def regex_remove_duplicates_words(text):
    return re.sub(r'([\u0000-\uffff]{2,5})\1+', r'\1', text)

def word_count(sentences, word_freq=None, word_seg=False):
    if word_freq is None:
        word_freq = defaultdict(int)
    for sentence in tqdm(sentences):
        for s in get_term_list(sentence, word_seg):
            word_freq[s] += 1
    return word_freq

def update_bow(sentence, id_term_map, word_seg=False, terminator=0, unk=-1):
    sen_id = []
    for s in get_term_list(sentence, word_seg):
        if s not in id_term_map:
            id_term_map[s] = len(id_term_map)+1 if unk == -1 else unk
        if id_term_map[s] is not None:
            sen_id.append(id_term_map[s])
    if terminator is not None:
        sen_id.append(terminator)
    return sen_id

def load_stopwords(file = '../MyNLP/data/chinese_words/stopwords.dat'):
    stopwords = set()
    with open(file, 'r') as f:
        for line in f:
            stopwords.add(line.strip())
    return stopwords

def generate_prediction_array(raw_sentence, id_term_map, maxlen=120, unk=None):
    sentence_id = update_bow(weibo_filter(raw_sentence.strip()), id_term_map, unk=unk)
    seq_len = len(sentence_id)
    if seq_len < maxlen:
        document = np.pad(np.array(sentence_id),((0),(maxlen-seq_len)), mode='constant', constant_values=0)
    else:
        document = np.array(sentence_id[0:maxlen])
    return document, seq_len

def generate_prediction_ndarray(raw_sentences, id_term_map, maxlen=120, unk=None):
    documents = np.empty(shape=(len(raw_sentences),maxlen))
    seq_len = np.empty(shape=(len(raw_sentences)))
    for i, raw_sentence in enumerate(raw_sentences):
        document, seqlen = generate_prediction_array(raw_sentence, id_term_map, maxlen, unk)
        documents[i] = document
        seq_len[i] = seqlen
    return documents, seq_len


def weibo_filter(sentence):
    #sentence = sentence.decode('utf8')
    #reply
    sentence = re.sub(u'\u56de\u590d@([\u4e00-\u9fa5a-zA-Z0-9_-]+)(\u0020\u7684\u8d5e)?:',' ',sentence)
    #at
    sentence = re.sub(u'@[\u4e00-\u9fa5a-zA-Z0-9_-]+', ' ', sentence)
    #link
    sentence = re.sub('([hH]ttp[s]{0,1})://[a-zA-Z0-9\.\-]+\.([a-zA-Z]{2,4})(:\d+)?(/[a-zA-Z0-9\-~!@#$%^&*+?:_/=<>.\',;]*)?',' ',sentence)
    #topic
    sentence = re.sub('#[^#]+#', '', sentence)
    return sentence

def softmax(w, t = 1.0):
    e = np.exp(np.array(w) / t)
    dist = e / np.sum(e)
    return dist

def display_text_with_weight(text, values, n_limit=20, fig_width=2, fig_height=0.5):
    num_chars = len(values)
    for i in np.arange(0, len(values), n_limit):
        if i + n_limit > num_chars:
            end_index = num_chars
        else:
            end_index = i+n_limit
        values_limited = values[i:end_index]
        values_reshaped = values_limited.reshape((1, end_index - i))
        chars_to_display = np.array([str(x) for x in list(text)[i:end_index]]).reshape((1,end_index-i))
        data = values_reshaped
        labels = chars_to_display
        fig, ax = plt.subplots(figsize=(fig_width,fig_height))
        ax = sns.heatmap(data, annot = labels, fmt = '', annot_kws={"size":15}, vmin=0, vmax=1, cmap='OrRd')
