import tensorflow as tf

from rcalgo.tf.module import Module
from rcalgo.tf.utils.logging import logger


class TFNgramSpanMaskProcessor(Module):
    """Convert (or maybe span mask) raw sentence sequence to n-gram id
        sequence in some tensorflow graph.

    Note:
        id顺序与旧顺序一致: word_dict < oov < sos < eos < mask
    """

    def __init__(self, config, word_dict, name=None):
        """Initialize vocabulary table. Can do lower, add PAD, SOS, EOS
            or do span-mask to sentences. Its string methods are static.

        Notes:
            word_dict is like {[PAD]:0, word1: 1, word2: 2, ..., wordx: x};
            0 holds a place in lookup table, and is default padding value;
            token order: [PAD], word, oov, [SOS], [EOS], [MASK]
        """
        super().__init__(name)
        self.word_dict = word_dict
        self.oov_buckets = config.get('oov_buckets')
        self.do_regex = config.get('do_regex', True)
        self.filter_pattern = config.get('filter_pattern')
        self.do_single_space = config.get('do_single_space', True)
        self.do_truncate = config.get('do_truncate', True)
        self.do_lower = config.get('do_lower', True)
        self.mark_boundary = config.get('mark_boundary', True)
        self.seq_length = config.get('seq_length', 512)
        self.ngram_width = config.get('ngram_width', 3)
        self.do_span_mask = config.get('do_span_mask', True)
        self.prob1 = config.get('prob1', 0.8)
        self.prob2 = config.get('prob2', 0.9)
        self.low_threshold = config.get('low_threshold', 6)
        self.high_threshold = config.get('high_threshold', 7)
        self.nb_words = len(word_dict.values()) + self.oov_buckets + \
            2 * self.mark_boundary + self.do_span_mask
        self.do_pad = config.get('do_pad', True)
        kv_init = tf.lookup.KeyValueTensorInitializer(
            list(word_dict.keys()), list(word_dict.values()),
            key_dtype=tf.string, value_dtype=tf.int64)
        self.word_table = tf.lookup.StaticVocabularyTable(
            kv_init, num_oov_buckets=self.oov_buckets)

    def call(self, inputs, **args):
        raw_inputs, masked_flag = inputs
        if self.do_regex:
            raw_inputs = tf.strings.regex_replace(
                raw_inputs, self.filter_pattern, '')
        if self.do_single_space:
            raw_inputs = tf.strings.regex_replace(raw_inputs, r'\s+', ' ')
        if self.do_truncate:
            raw_inputs = tf.strings.substr(
                raw_inputs, pos=0, len=self.seq_length)
        if self.do_lower:
            raw_inputs = tf.strings.lower(raw_inputs)
        ngram_ragged = self.tf_ngram_split(raw_inputs, self.ngram_width)
        token_sparse = self.word_table.lookup(ngram_ragged.to_sparse())
        token_inputs = tf.sparse.to_dense(token_sparse)
        if self.do_truncate:
            token_inputs = token_inputs[:, :(
                self.seq_length - 2 * self.mark_boundary)]
        mask_idx, origin_tokens, mask_length = raw_inputs, ngram_ragged, token_inputs
        # used to debug
        if self.mark_boundary:
            token_inputs = self.tf_mark_boundary(
                token_inputs, self.nb_words - 2 - self.do_span_mask)
        if self.do_span_mask:
            info = 'The span-mask needs mark-boundary for [SOS],[EOS].'
            # assert self.mark_boundary is True, assert_into
            if self.mark_boundary is False:
                logger.error(info)
            mask_result = self.tf_span_mask(
                token_inputs,
                masked_flag,
                self.nb_words - 1,
                self.prob1,
                self.prob2,
                self.low_threshold,
                self.high_threshold)
            token_inputs = mask_result[0]
            mask_idx, origin_tokens, mask_length = mask_result[1:]
        if self.do_pad:
            token_inputs = self.tf_pad(token_inputs, self.seq_length)
            token_inputs.set_shape([None, self.seq_length])
        return token_inputs, mask_idx, origin_tokens, mask_length

    @staticmethod
    def tf_pad(inputs, length):
        shape = tf.shape(inputs)
        pad_length = length - shape[1]
        padding = [[0, 0], [0, pad_length]]
        return tf.pad(inputs, padding)

    @staticmethod
    def tf_mark_boundary(inputs, nb_words):
        shape = tf.shape(inputs)
        sos_value = nb_words
        eos_value = nb_words + 1
        sos = tf.fill([shape[0], 1], sos_value)
        sos = tf.cast(sos, tf.int64)
        eos = tf.fill([shape[0], 1], eos_value)
        eos = tf.cast(eos, tf.int64)
        ragged_inputs = tf.RaggedTensor.from_tensor(inputs, padding=0)
        expanded_ragged = tf.concat([sos, ragged_inputs, eos], axis=1)
        return expanded_ragged.to_tensor()

    @staticmethod
    def tf_ngram_split(inputs, ngram_width):
        """将单字的输入拆分为ngram；
            特别地，比ngram长度还要短的句子作为一个ngram块，不补长。

        Args:
            inputs: tf.Tensor(tf.string), 一维数据，句子
            ngram_width: ngram长度

        Returns:
            tf.RaggedTensor(tf.string), 二维数据，包含ngram字符块

        Modified from JiangJiaLiang's code.

        Numerical examples:
        <inputs>
        tf.Tensor([b'' b'a' b'bc' b'def' b'uv w xyz'], shape=(5,), dtype=string)
        <char_inputs>
        <tf.RaggedTensor [[], [b'a'], [b'b', b'c'], [b'd', b'e', b'f'], [b'u', b'v', b' ', b'w', b' ', b'x', b'y', b'z']]>
        <ngram_inputs>
        tf.Tensor(
        [[b'' b'' b'' b'' b'' b'' b'' b'']
         [b'a' b'' b'' b'' b'' b'' b'' b'']
         [b'bc' b'c' b'' b'' b'' b'' b'' b'']
         [b'def' b'ef' b'f' b'' b'' b'' b'' b'']
         [b'uv ' b'v w' b' w ' b'w x' b' xy' b'xyz' b'yz' b'z']], shape=(5, 8), dtype=string)
        <ngram_length>
        tf.Tensor(
        [[0 0 0 0 0 0 0 0]
         [1 0 0 0 0 0 0 0]
         [2 1 0 0 0 0 0 0]
         [3 2 1 0 0 0 0 0]
         [3 3 3 3 3 3 2 1]], shape=(5, 8), dtype=int64)
        <less_idx>
        tf.Tensor(
        [[ True False False False False False False False]
         [ True False False False False False False False]
         [ True False False False False False False False]
         [False False False False False False False False]
         [False False False False False False False False]], shape=(5, 8), dtype=bool)
        <equal_idx>
        tf.Tensor(
        [[False False False False False False False False]
         [False False False False False False False False]
         [False False False False False False False False]
         [ True False False False False False False False]
         [ True  True  True  True  True  True False False]], shape=(5, 8), dtype=bool)
        <positive_idx>
        tf.Tensor(
        [[False False False False False False False False]
         [ True False False False False False False False]
         [ True  True False False False False False False]
         [ True  True  True False False False False False]
         [ True  True  True  True  True  True  True  True]], shape=(5, 8), dtype=bool)
        <ngram_idx>
        tf.Tensor(
        [[False False False False False False False False]
         [ True False False False False False False False]
         [ True False False False False False False False]
         [ True False False False False False False False]
         [ True  True  True  True  True  True False False]], shape=(5, 8), dtype=bool)
        <ngram_values>
        tf.Tensor([b'a' b'bc' b'def' b'uv ' b'v w' b' w ' b'w x' b' xy' b'xyz'], shape=(9,), dtype=string)
        <needed_idx>
        tf.Tensor([1 2 3 4 4 4 4 4 4], shape=(9,), dtype=int64)
        <ngram_ragged.to_tensor()>
        tf.Tensor(
        [[b'' b'' b'' b'' b'' b'']
         [b'a' b'' b'' b'' b'' b'']
         [b'bc' b'' b'' b'' b'' b'']
         [b'def' b'' b'' b'' b'' b'']
         [b'uv ' b'v w' b' w ' b'w x' b' xy' b'xyz']], shape=(5, 6), dtype=string)
        """
        char_inputs = tf.strings.unicode_split(inputs, 'UTF-8')
        ngram_inputs = tf.concat([char_inputs[0:, i:]
                                  for i in range(ngram_width)], axis=0)
        ngram_inputs = tf.split(ngram_inputs.to_tensor(), ngram_width, axis=0)
        ngram_inputs = tf.strings.reduce_join(ngram_inputs, axis=0)
        ngram_length = tf.strings.length(ngram_inputs)
        less_idx = tf.cast(ngram_length < ngram_width, tf.int64)
        less_idx_pad = tf.zeros_like(ngram_length, dtype=tf.int64)[:, 1:]
        less_idx = tf.reduce_min(less_idx, axis=-1)
        less_idx = tf.expand_dims(less_idx, axis=-1)
        less_idx = tf.concat([less_idx, less_idx_pad], axis=-1)
        less_idx = tf.cast(less_idx, dtype=tf.bool)
        # 0 <= len(sentence) < ngram_width
        equal_idx = ngram_length >= ngram_width
        # len(sentence) = ngram_width
        positive_idx = ngram_length > 0
        # 0 < len(sentence)
        ngram_idx = equal_idx | (less_idx & positive_idx)
        ngram_values = ngram_inputs[ngram_idx]
        needed_idx = tf.where(ngram_idx)[:, 0]
        return tf.RaggedTensor.from_value_rowids(ngram_values, needed_idx)

    @staticmethod
    def tf_span_mask(inputs, masked_flag, nb_words, prob1=0.8, prob2=0.9,
                     low_threshold=6, high_threshold=7):
        """对句子tensor进行span mask，得到masked句子、mask位置下标和mask部分的文本

        Args:
            inputs: tf.Tensor(tf.int64)，二维数据，token_id形式，包含eos,sos, 无pad
            masked_flag: tf.Tensor(tf.float32)， 一维数据，全1或全0，为1时进行mask
            nb_words: int, 词表长度，最后一个位置是[MASK]=nb_words-1
            prob1: float, mask位置中确实进行mask的比例
            prob2: float, prob2-prob1=随机比例，1-prob2=维持原状比例
            low_threshold: int, threshold最小值
            high_threshold: int, threshold最大值，区间是[l,h]而非[l,h)

        Return:
            masked_inputs: tf.Tensor(tf.int64), masked之后的输入
            mask_idx: tf.Tensor(tf.int64), mask部分的二维下标
            origin_bow: tf.Tensor(tf.int64), mask部分的原始字符，作为预测目标

        Modified from old func: utils.tf_func.generate_span_masked_bow
        Old description：基于span的连续mask玩法

        Numerical examples:
        <inputs>
        tf.Tensor(
        [[7 8 0 0 0 0 0]
         [7 1 8 0 0 0 0]
         [7 3 4 8 0 0 0]
         [7 6 4 3 2 5 8]], shape=(4, 7), dtype=int64)
        <input_length>
        tf.Tensor([1 1 2 5], shape=(4,), dtype=int64)
        <threshold>
        tf.Tensor([1 1 1 2], shape=(4,), dtype=int64)
        <start_position>
        tf.Tensor([1 1 1 2], shape=(4,), dtype=int64)
        <ngram_length>
        tf.Tensor([1 1 2 3], shape=(4,), dtype=int64)
        <end_position>
        tf.Tensor([2 2 3 5], shape=(4,), dtype=int64)
        <mask_to_start>
        tf.Tensor(
        [[1 0 0 0 0 0 0]
         [1 0 0 0 0 0 0]
         [1 0 0 0 0 0 0]
         [1 1 0 0 0 0 0]], shape=(4, 7), dtype=int64)
        <mask_matrix>
        tf.Tensor(
        [[0 1 0 0 0 0 0]
         [0 1 0 0 0 0 0]
         [0 1 1 0 0 0 0]
         [0 0 1 1 1 0 0]], shape=(4, 7), dtype=int64)
        <replace_tokens>
        tf.Tensor(
        [[0 9 0 0 0 0 0]
         [0 9 0 0 0 0 0]
         [0 9 4 0 0 0 0]
         [0 0 9 3 9 0 0]], shape=(4, 7), dtype=int64)
        <masked_inputs>
        tf.Tensor(
        [[7 9 0 0 0 0 0]
         [7 9 8 0 0 0 0]
         [7 9 4 8 0 0 0]
         [7 6 9 3 9 5 8]], shape=(4, 7), dtype=int64)
        <mask_ids>
        tf.Tensor(
        [[0 1]
         [1 1]
         [2 1]
         [2 2]
         [3 2]
         [3 3]
         [3 4]], shape=(7, 2), dtype=int64)
        <origin_tokens>
        tf.Tensor([8 1 3 4 4 3 2], shape=(7,), dtype=int64)
        <mask_length>
        tf.Tensor([1 1 2 3], shape=(4,), dtype=int64)
        """
        mask_token = nb_words
        raw_input_length = tf.count_nonzero(inputs, 1)
        max_len = tf.reduce_max(raw_input_length)
        input_length = tf.maximum(
            tf.ones_like(raw_input_length),
            raw_input_length - 2)
        # -2, without [SOS][EOS]
        threshold = tf.random.uniform(
            tf.shape(input_length),
            low_threshold,
            high_threshold + 1,
            tf.int64)
        big_int = 99999721
        # to do: 需要解释，但应该只是个大数
        random_big_int = tf.random.uniform(
            tf.shape(input_length), maxval=big_int, dtype=tf.int64)
        start_postion = tf.floormod(random_big_int, input_length) + 1
        # +1, skip [SOS]
        ngram_length = tf.cast(tf.math.ceil(
            input_length / threshold), dtype=tf.int64)
        # todo: 实现该逻辑，需要input_placeholder_with_default，我不确定是否还有此功能
        # if mask_length is None:
        #     ngram_length = tf.cast(tf.math.ceil(
        #         input_length/threshold), dtype=tf.int64)
        # else:
        #     ngram_length = tf.cast(mask_length, dtype=tf.int64)
        end_position = tf.minimum(
            input_length + 2,
            start_postion + ngram_length)
        # +2, skip [SOS], mask [EOS]
        mask_to_end = tf.sequence_mask(
            end_position, maxlen=max_len, dtype=tf.int64)
        mask_to_start = tf.sequence_mask(
            start_postion, maxlen=max_len, dtype=tf.int64)
        mask_matrix = mask_to_end - mask_to_start
        mask_length = tf.reduce_sum(mask_matrix, 1)
        mask_num = tf.reduce_sum(mask_matrix)
        mask_idx = tf.compat.v2.where(
            tf.math.not_equal(mask_matrix, tf.constant(0, dtype=tf.int64)))
        # todo: V2与V1区别具体是什么(我的测试是, v1.where值相同)
        random_tokens = tf.random.uniform(
            [mask_num], minval=1, maxval=nb_words, dtype=tf.int64)
        probs = tf.random.uniform([mask_num], maxval=1.0, dtype=tf.float32)
        origin_tokens = tf.gather_nd(inputs, mask_idx)
        masked_flag = tf.reduce_mean(masked_flag)
        prob1 = prob1 * masked_flag
        prob2 = prob2 * masked_flag
        mask_prob = tf.cast(probs <= prob1, dtype=tf.int64)
        random_prob = tf.cast(
            (probs > prob1) & (
                probs <= prob2),
            dtype=tf.int64)
        origin_prob = tf.cast(probs > prob2, dtype=tf.int64)
        replace_mask = mask_prob * mask_token
        replace_mask += random_prob * random_tokens
        replace_mask += origin_prob * origin_tokens
        # 0.8 mask, 0.1 random, 0.1 origin
        replace_tokens = tf.SparseTensor(
            mask_idx, replace_mask,
            tf.shape(inputs, out_type=tf.int64))
        replace_tokens = tf.sparse.to_dense(replace_tokens)
        masked_inputs = replace_tokens + (1 - mask_matrix) * inputs
        return masked_inputs, mask_idx, origin_tokens, mask_length
