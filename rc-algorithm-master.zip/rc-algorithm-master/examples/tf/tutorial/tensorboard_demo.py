"""
Subclassing API Demo

运行脚本的命令:
单卡:
    PYTHONPATH=../.. python horovod_subclassing_demo.py
单机8卡:
    PYTHONPATH=../.. horovodrun -np 8 python horovod_subclassing_demo.py
多机多卡:
    PYTHONPATH=../.. horovodrun -np 16 -H server1:8,server2:8 python horovod_subclassing_demo.py
"""

import pandas as pd
import tensorflow as tf

from rcalgo.tf.models.classifier.text_classifier import TransformerClassifier
from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.training.hook import TensorBoardHook


config = {
    "learning_rate": 0.0001,

    "num_classes": 2,
    "max_seq_len": 128,
    "embedding_size": 256,
    "num_layers": 2,
    "conv_num_filters": 256,
    "keep_prob": 0.9,
}


def main(_):
    # 1. load data
    data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
    train_data = pd.read_csv(data_dir + 'train.csv')
    # count word dict
    tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=1)
    word_dict = tokenizer.word2idx

    # 2. create model
    model = TransformerClassifier(config, word_dict, name=None)
    model.build_model()
    print(model.model_summary())

    tf.summary.scalar('summary_loss', model.loss)

    # 3. train
    log_dir = '/home/web_server/antispam/project/public/tensorboard/demo'
    # tensorboard link: https://kml-task-22819-record-395067-prod-tensorboard.cluster-bjlt-production-2.corp.kuaishou.com/
    model.train(
        [train_data['text'], train_data['label']],
        batch_size=128,
        test_size=0.1,
        epochs=5,
        hooks=[TensorBoardHook(log_dir, every_n_step=5)])


if __name__ == '__main__':
    tf.app.run()
