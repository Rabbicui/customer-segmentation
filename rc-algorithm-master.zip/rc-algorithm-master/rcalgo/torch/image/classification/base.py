import os
import sys

import torch
from torch import nn
import time
from rcalgo.torch.image.classification.dataset import mk_dataset
from rcalgo.torch.image.classification import utils
from rcalgo.torch.image.classification import lbtoolbox as lb


def recycle(iterable):
  """Variant of itertools.cycle that does not save iterates."""
  while True:
    for i in iterable:
      yield i



def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


class ModelWrapper(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, x):
        self.model.eval()
        with torch.no_grad():
            logits = self.model(x)
            outputs = nn.functional.softmax(logits, dim=-1)
        self.model.train()
        return outputs


class Finetune(object):
    def __init__(self, config):
        self.config = config
        self.classes = config.get('num_classes', -1)
        if self.classes < 0:
            raise Exception('num_classes not set')
        self.eval_every = config.get('eval_every', 500)
        self.lr = config.get('lr', 0.003)
        self.logdir = config.get('logdir', './')
        self.logname = config.get('logname', 'train')

        self.pretrain_path = None
        self.cri = None
        self.model = None
        self.opt = None
        self.batch_size = None

    def init_model(self):
        raise Exception('unimplemented')

    def new_lr(self, step, train_size):
        return self.lr

    def new_batch(self, x, y, train_size):
        return x, y

    def criterion(self, logits, y):
        return self.cri(logits, y)

    def train(self, train_data, test_data, ckpt_dir, ckpt_name, batch=256, total_epoch=None):
        self.batch_size = batch
        logger = utils.setup_logger(self.logdir, self.logname)
        # build data loader
        train_set, _, train_loader, valid_loader = mk_dataset(train_data, test_data, batch=self.batch_size)
        train_size = len(train_set)
        steps_one_epoch = len(train_loader)

        # model parallel
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        model = self.init_model()
        model = torch.nn.DataParallel(model)
        model = model.to(device)
        model.train()
        self.model = model

        # build opt

        optim = torch.optim.SGD(self.model.parameters(), lr=self.lr, momentum=0.9)
        optim.zero_grad()
        self.opt = optim

        # build cri
        cri = torch.nn.CrossEntropyLoss().to(device)
        self.cri = cri

        savename = ckpt_dir + '/' + ckpt_name
        step = 0
        epoch = 0
        max_steps = 9999999
        if total_epoch is not None:
            max_steps = total_epoch * steps_one_epoch
            logger.info(f"Starting training for epochs {total_epoch}!")
        else:
            # max steps is defined automatically
            logger.info(f"Starting training!")

        best_acc1 = -1
        if self.eval_every > steps_one_epoch:
            self.eval_every = steps_one_epoch

        with lb.Uninterrupt() as u:
            for x, y in recycle(train_loader):
                if u.interrupted:
                    break

                # Schedule sending to GPU(s)
                x = x.to(device, non_blocking=True)
                y = y.to(device, non_blocking=True)

                # Update learning-rate, including stop training if over.
                lr = self.new_lr(step, train_size)
                if lr is None or step > max_steps:
                    break
                for param_group in optim.param_groups:
                    param_group["lr"] = lr

                x, y = self.new_batch(x, y, train_size)

                # compute output
                logits = model(x)
                c = self.criterion(logits, y)
                c_num = float(c.data.cpu().numpy())  # Also ensures a sync point.
                c.backward()

                # print info
                if step % 10 == 0:
                    logger.info(
                        f"epoch: {epoch} step: {step} loss={c_num:.5f}  (lr={lr:.1e}) ")  # pylint: disable=logging-format-interpolation
                    logger.flush()

                # Update params
                optim.step()
                optim.zero_grad()
                step += 1

                # Run evaluation and save the model.
                if self.eval_every and step % self.eval_every == 0:
                    acc1 = self.run_eval(model, valid_loader, device, logger, step)
                    is_best = acc1 > best_acc1
                    best_acc1 = max(acc1, best_acc1)
                    logger.info(f"Step {step}: best acc@1 {best_acc1}")
                    # save best checkpoint
                    if is_best:
                        utils.dump(model, optim, step, savename)
                        # save tracing
                        utils.script_tracing(ModelWrapper(model.module), savename, example=torch.rand([1, 3, 224, 224]))

                if step % steps_one_epoch == 0:
                    epoch += 1

    def run_eval(self, model, data_loader, device, logger, step):
        # switch to evaluate mode
        model.eval()

        logger.info("Running validation...")
        logger.flush()

        # to record
        batch_time = utils.AverageMeter('Time', ':6.3f')
        losses = utils.AverageMeter('Loss', ':.4e')
        top1 = utils.AverageMeter('Acc@1', ':6.2f')
        top5 = utils.AverageMeter('Acc@5', ':6.2f')

        for i, (x, y) in enumerate(data_loader):
            with torch.no_grad():
                end = time.time()
                x = x.to(device, non_blocking=True)
                y = y.to(device, non_blocking=True)

                # compute output, measure accuracy and record loss.
                logits = model(x)
                c = torch.nn.CrossEntropyLoss(reduction='none')(logits, y)
                if self.classes > 2:
                    acc1, acc5 = accuracy(logits, y, topk=(1, 5))
                else:
                    acc1, acc5 = accuracy(logits, y, topk=(1, 2))
                losses.update(c.cpu().data.numpy(), x.size(0))
                top1.update(acc1[0], x.size(0))
                top5.update(acc5[0], x.size(0))

                # measure elapsed time
                batch_time.update(time.time() - end)
                end = time.time()
                logger.info(f"eval batch {i}...")
                logger.flush()


        model.train()
        logger.info(f"***validation step {step} acc@1 {top1.avg} acc@5 {top5.avg}***")
        logger.flush()
        return top1.avg








