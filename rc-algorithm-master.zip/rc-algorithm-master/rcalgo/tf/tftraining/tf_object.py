from rcalgo.tf.tftraining.incremental_training import IncrementalTraining
from rcalgo.tf.tftraining.incremental_training import TrainingData
from rcalgo.tf.tftraining.tf_object_base import *


class TFModel(TFModelBase):
    """
    Bind the IncrementalTraining to this class
    TODO Once we merged the IncrementalTraining and MultiTraining, this class can be removed
    """

    def __init__(self, config, graph):
        super(TFModel, self).__init__(config, graph)

    def _update_optimizer(self, task, old_task=None, learning_rate=0.0):
        super(TFModel, self)._update_optimizer(task, self.lr_params, self.opt_params,
                                               old_task, learning_rate)

    def _init_training_job(self):
        self.job = IncrementalTraining(model_input_dir=self.model_dir,
                                       model_name=self.model_name,
                                       model_output_dir=self.model_dir,
                                       graph=self.graph,
                                       lr_annealing=self.lr_annealing,
                                       lr_annealing_value=self.lr_annealing_value,
                                       lr_annealing_stop_value=self.lr_stop_value,
                                       logs_dir=self.logs_dir,
                                       save_checkpoint=self.epoch_save,
                                       debug_mode=self.debug_mode,
                                       use_tf_dataset=self.use_tf_dataset)

    def run(self, input_list, test_size, run_type=None, default_random_seed=42, input_index=None):
        data = TrainingData(input_list, self.batch_size,
                            test_size, default_random_seed)
        self.job.train(data, n_epochs=self.n_epochs,
                       task_names=run_type, input_index=input_index)

    def model_run(self, input_list, test_size, run_type=None, mode='train', default_random_seed=42):
        data = TrainingData(input_list, self.batch_size,
                            test_size, default_random_seed)
        self.job._run_epoch(data.create_iterator(
            mode), tasks=self.job._get_tasks(run_type), mode=mode)

    def model_run_output(self, input_list, run_type=None):
        # test_size is not userd here
        data = TrainingData(input_list, self.batch_size, test_size=0.1)
        return self.job._run_output(data.create_iterator('all'),
                                    tasks=self.job._get_tasks(run_type))

