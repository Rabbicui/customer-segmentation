import tensorflow as tf

from rcalgo.tf.modules_v2.base_module import Module
from rcalgo.tf.modules_v2.layers.transformer import TransformerEncoderLayer


class TransformerEncoder(Module):
    """Transformer Encoder."""

    def __init__(self,
                 num_layers,
                 num_units=512,
                 num_heads=8,
                 ffn_inner_dim=2048,
                 attention_dropout=0.1,
                 hidden_dropout=0.1,
                 ffn_activation=tf.nn.relu,
                 name=None):
        """Initialize the parameters of the encoder."""
        super(TransformerEncoder, self).__init__(name=name)

        self.num_units = num_units
        # self.dropout = Dropout(hidden_dropout)
        with self.name_scope:
            self.layers = [
                TransformerEncoderLayer(
                    num_units,
                    num_heads,
                    ffn_inner_dim,
                    attention_dropout=attention_dropout,
                    hidden_dropout=hidden_dropout,
                    ffn_activation=ffn_activation,
                    name="layer_%d" % i)
                for i in range(num_layers)]

    def call(self, inputs, sequence_length=None, training=None):
        """Encode inputs."""
        """
        inputs *= self.num_units ** 0.5  # ?
        if self.position_encoder is not None:
            inputs = self.position_encoder(inputs)

        inputs = self.dropout(inputs, training=training)
        """
        mask = None
        if sequence_length is not None:
            mask = tf.sequence_mask(sequence_length,
                                    maxlen=tf.shape(inputs)[1],
                                    dtype=tf.float32)
            mask = tf.expand_dims(mask, 1)
        hiddens = inputs
        for layer in self.layers:
            hiddens = layer(hiddens, mask=mask, training=training)
        return hiddens
