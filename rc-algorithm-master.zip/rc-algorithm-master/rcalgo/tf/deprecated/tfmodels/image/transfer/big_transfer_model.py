# coding: utf-8

import os

import tensorflow as tf
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))

from rcalgo.tf.tfmodels.image.base.base_model import BaseModel
from rcalgo.tf.tfmodels.image.base import base_model, models
from rcalgo.tf.tfmodels.image.transfer import bit_hyperrule
from rcalgo.tf.tfmodels.image.utils import input_pipeline

HOROVOD_SUPPORT = base_model.HOROVOD_SUPPORT

"""
Sample args
eval_every = len(images) // batch_size  same as the steps_per_epoch
parser = bit_common.argparser(None)
args = parser.parse_args(args=[
        '--name', 'cifar10',
        '--model', 'BiT-M-R50x1',     # some options like 50*3 or   101 * 1
        '--bit_pretrained_dir', '/project/zhoukan/transfer/big_transfer/pre_trained_models/', 
        '--batch', '512',
        '--eval_every', str(eval_every),
        '--save_checkpoint', 'True', 
        '--save_path', './ckpt/xxx' ,  # if save weights only (save_checkpoint is False save path 'cifar10_weights.{epoch:02d}-{val_loss:.2f}.hdf5' ,
        '--logdir', './cifar_transfer_log',
        '--base_lr', '0.003',   
        '--gpu_num', '1'   # if gpu_num > 1 run in parallel, horovod use be used if env is allowed otherwise keras multi gpu model is used

        # if the gpu mem is not enough , batch --> 128    base_lr -->0.001
    ]
)
"""

class BiTLRSched(tf.keras.callbacks.Callback):
    def __init__(self, base_lr, num_samples):
        self.step = 0
        self.base_lr = base_lr
        self.num_samples = num_samples

    def on_train_batch_begin(self, batch, logs=None):
        lr = bit_hyperrule.get_lr(self.step, self.num_samples, self.base_lr)
        tf.keras.backend.set_value(self.model.optimizer.lr, lr)
        self.step += 1


class BigTransferModel(BaseModel):

    def _build_data(self, batch, train_data, test_data=None):
        original_resolution = [320, 320]
        if 'resolution' in train_data:
            original_resolution = train_data['resolution']
        resize_size, crop_size = bit_hyperrule.get_resolution(original_resolution)
        data_train = input_pipeline.get_bit_data(
            mode='train',
            batch_size=batch,
            resize_size=resize_size, crop_size=crop_size,
            mixup_alpha=bit_hyperrule.get_mixup(len(train_data['image'])),
            data=train_data)

        data_test = None
        if test_data is not None:
            data_test = input_pipeline.get_bit_data(
                mode='test',
                batch_size=batch,
                resize_size=resize_size, crop_size=crop_size,
                mixup_alpha=bit_hyperrule.get_mixup(len(train_data['image'])),
                data=test_data)

        data_train = data_train.map(lambda x: input_pipeline.reshape_for_keras(
            x, batch_size=batch, crop_size=crop_size))
        if data_test is not None:
            data_test = data_test.map(
                lambda x: input_pipeline.reshape_for_keras(x, batch_size=batch, crop_size=crop_size))
        return data_train, data_test, resize_size, crop_size

    def _build_model(self, num_classes):
        # build the main model here
        args = self.args
        filters_factor = int(args.model[-1]) * 4
        x = tf.keras.Input(shape=(None, None, 3))
        model = models.ResnetV2WithAttention(
            num_units=models.NUM_UNITS[args.model],
            num_outputs=None,
            filters_factor=filters_factor,
            name="resnet",
            trainable=True,
            dtype=tf.float32)
        model._head = tf.keras.layers.Dense(
            units=num_classes,
            use_bias=True,
            kernel_initializer="zeros",
            trainable=True,
            name="new_head/dense")
        y = model(x)
        bit_model_file = os.path.join(args.bit_pretrained_dir, f'{args.model}.h5')
        model.load_weights(bit_model_file, by_name=True)
        model.summary()
        # wrap inputs and outputs
        model = tf.keras.Model(inputs=x, outputs=y)
        return model

    def _get_epochs(self, num_examples):
        lr_supports = bit_hyperrule.get_schedule(num_examples, self.args.batch)
        schedule_length = lr_supports[-1]
        return schedule_length // self.args.eval_every

    def _build_custom_callbacks(self):
        return [BiTLRSched(self.args.base_lr, self.num_samples)]

