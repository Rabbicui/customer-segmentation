import sys
import os
# sys.path.insert(0,'..')
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))

from rcalgo.tf.tftraining.tf_object import *
from rcalgo.tf.tfmodels.rnnlm import *
from tftools.tf_float_type import get_default_float_type


class BiRNNLMModel(RNNLMModel):
    def __init__(self, config, graph, word_dict=None):
        super(BiRNNLMModel, self).__init__(
            config, graph, word_dict)

    def init_rnn_state(self):
        self.init_state_fw, self.split_init_state_fw = self._init_rnn_state(
            'init_state_fw')
        self.input_dict['input_state_fw'] = self.split_init_state_fw[0]
        self.init_state_bw, self.split_init_state_bw = self._init_rnn_state(
            'init_state_bw')
        self.input_dict['input_state_bw'] = self.split_init_state_bw[0]

    def build_input_sequence(self, gpu_id=0):
        # embedding layer
        self._build_embedding_layer(gpu_id)
        with get_new_variable_scope('bi-rnn_lstm') as rnn_scope:
            #fw_cell and bw_cell
            state_fw, rnn_output_fw = self.build_rnn_sequence(self.input_embedding[gpu_id],
                                                              self.split_seqLengths[gpu_id],
                                                              self.split_init_state_fw[gpu_id])
            state_bw, rnn_output_bw = self.build_rnn_sequence(self.input_embedding[gpu_id],
                                                              self.split_seqLengths[gpu_id],
                                                              self.split_init_state_bw[gpu_id],
                                                              go_backwards=True)
            self.state_list[gpu_id] = [state_fw, state_bw]
            self.rnn_output_list[gpu_id] = rnn_output_fw + rnn_output_bw
            # the last state of fw and bw
            self.output_list[gpu_id] = tf.concat(
                [self.rnn_output_list[gpu_id][self.num_layers-1][0], self.rnn_output_list[gpu_id][-1][0]], 1)
        if self.input_params is None:
            # self.input_params = tf.compat.v1.trainable_variables()[1:]
            self.input_params = tf.compat.v1.trainable_variables()

    def build_output(self, task=None):
        with tf.name_scope('output'):
            if task is None or task == self.default_task_name:
                # can use slice + tf.shape(self.inputX)[1]-2
                self.split_fw_targets = [tf.concat([self.split_inputX[i][:, 1:], tf.zeros_like(
                    self.split_inputX[i][:, 0:1])], 1) for i in range(0, self.gpu_num)]
                self.split_bw_targets = [tf.concat([tf.zeros_like(
                    self.split_inputX[i][:, 0:1]), self.split_inputX[i][:, 0:-1]], 1) for i in range(0, self.gpu_num)]
            else:
                self.targets = tf.compat.v1.placeholder(
                    tf.int32, [None, None], name="targets")
                self._add_to_graph_targets([self.targets])
                self.split_targets = tf.split(self.targets, self.gpu_num, 0)

    def build_sequence_prediction(self, task=None, gpu_id=0, nb_class=None, accK=5):
        if nb_class is None:
            nb_class = self.nb_words
        if task is None:
            task = self.default_task_name
        with get_new_variable_scope('prediction') as pred_scope:
            self.compute_metrics([self.state_list[gpu_id][0],self.state_list[gpu_id][1]], [self.split_fw_targets[gpu_id], self.split_bw_targets[gpu_id]], task=task, nb_class=nb_class, accK=accK)
            self.state_list[gpu_id] = tf.concat(self.state_list[gpu_id], -1)
