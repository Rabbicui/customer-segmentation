from rcalgo.torch.image.classification.img_classification import KwaiImageClassificationModel

config = {
    # 必要参数:
    "model_name": 'bit',  # 模型名: bit , moco,  vit,
    # 第一个是在公开数据集预训练的，第二个是在我们自己大数据级self train的
    # 时间足够可以前两个都尝试下
    "num_classes": 2,  # 分类个数

    # 可选参数:
    "lr": 0.003,  # 初始化 learning rate
    "eval_every": 500,  # 每100个 step 跑一次validation，同时会保存最优的 checkpoint
    "logdir": './',  # 日志目录默认当前目录
    "logname": 'train',  # 日志名
}

model = KwaiImageClassificationModel(config)

images = ['xx1.png', 'xx2.png']
labels = [1, 0]
val_images = ['xx1.png', 'xx2.png']
val_labels = [1, 0]
train_data = {
    "image": images,
    'label': labels
}
val_data = {
    "image": val_images,
    'label': val_labels
}

# case1: 少量标注数据集
# train 的 可选参数epoch 如果不指定，会根据训练数据集自动设置
if __name__ == '__main__':
    model.train(train_data, val_data, checkpoint_dir='./', checkpoint_name='demo', batch_size=128)

# done

# 最后会在 checkpoint_dir 下保存 两个文件  以 checkpoint_name命名
# 其中带tracing的可用于线上直接上线

# case 2: 如果有大量的未标准的数据 + 小量标注数据
unlabel_images = []
unlabel_data = {
    "image": unlabel_images
}

# 这里避免 unlabel train 耗时过久 可以加入对 非标注数据的 epoch限定, 默认20个epoch
# 这里非标注数据训练比较慢 100w的数据 一个epoch时间会比较长 需要1个小时

# 另外除了 分类模型的ckpt 我们还会额外保存  已 ckpt_name + '_embedding' 的 pretrain模型
if __name__ == '__main__':
    model.train(train_data, val_data, checkpoint_dir='./', checkpoint_name='demo', batch_size=128,
                unlabel_data=unlabel_data, unlabel_epochs=20)
