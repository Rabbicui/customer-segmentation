import tensorflow as tf
from tensorflow.python.framework import ops
from tensorflow.python.ops import math_ops

def inverse_sigmoid_sample_proba(decay_factor, global_step, dtype=tf.float32, name=None):
    with ops.name_scope(name, "inverse_sigmoid") as name:
        tmp_global_step = math_ops.cast(global_step, dtype)
        sample_prob = decay_factor /(decay_factor + tf.exp(tmp_global_step/decay_factor))
        return sample_prob

def linear_sample_proba(decay_factor, global_step, dtype=tf.float32, name=None):
    raise NotImplementedError

    
def exponential_sample_proba(decay_factor, global_step, dtype=tf.float32, name=None):
    raise NotImplementedError
