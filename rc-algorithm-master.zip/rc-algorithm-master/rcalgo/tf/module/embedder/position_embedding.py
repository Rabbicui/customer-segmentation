import math
import tensorflow as tf

from rcalgo.tf.utils.tf_func import get_new_variable_scope, add_weight_to_collection


def google_position_embedding(length, embedding_size,
                              min_timescale=1.0, max_timescale=1.0e4):
    """
    Return positional encoding.
    code: https://github.com/tensorflow/models/blob/master/official/transformer/model/model_utils.py#L29:26

    Args:
        length: Sequence length.
        embedding_size: Size of the embedding
        min_timescale: Minimum scale that will be applied at each position
        max_timescale: Maximum scale that will be applied at each position
    """
    position = tf.to_float(tf.range(length))
    num_timescales = embedding_size // 2
    log_timescale_increment = (
        math.log(float(max_timescale) / float(min_timescale)) /
        (tf.to_float(num_timescales) - 1))
    inv_timescales = min_timescale * tf.exp(
        tf.to_float(tf.range(num_timescales)) * -log_timescale_increment)
    scaled_time = tf.expand_dims(position, 1) * \
        tf.expand_dims(inv_timescales, 0)
    signal = tf.concat([tf.sin(scaled_time), tf.cos(scaled_time)], axis=1)
    return signal


def position_embedding(length, embedding_size, seqlen, dtype=None,
                       trainiable=False, layer_name='pos_embedding',
                       init_scale=0.01, initializer=None, scale=False,
                       scope=None, variables_collections=None):
    """
        Return positional encoding.
        Paper:  https://arxiv.org/pdf/1706.03762.pdf Section3.5

        Args:
        length: Sequence length.
        embedding_size: Size of the embedding
        trainiable: when false, using static embedding according to the paper,
                    else init an embeeding table variable
    """
    vscope = get_new_variable_scope(layer_name, scope)
    with vscope as scope:
        if initializer is None:
            initializer = tf.random_uniform_initializer(
                -init_scale, init_scale)
        embedding_table = tf.compat.v1.get_variable('embedding_table',
                                                    [length, embedding_size], dtype=dtype,
                                                    initializer=initializer)
        add_weight_to_collection(embedding_table, variables_collections)
        mask = tf.sequence_mask(seqlen, maxlen=length,
                                dtype=embedding_table.dtype)
        output = tf.reshape(tf.tile(embedding_table, [tf.shape(
            seqlen)[0], 1]), [-1, length, embedding_size]) * tf.expand_dims(mask, [-1])
        if scale:
            output = output * (embedding_size ** 0.5)
        return output

