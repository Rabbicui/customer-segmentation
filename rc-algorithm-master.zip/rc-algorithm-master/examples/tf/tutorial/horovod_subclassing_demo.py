"""
Subclassing API Demo

运行脚本的命令:
单卡:
    PYTHONPATH=../.. python horovod_subclassing_demo.py
单机8卡:
    PYTHONPATH=../.. horovodrun -np 8 python horovod_subclassing_demo.py
多机多卡:
    PYTHONPATH=../.. horovodrun -np 16 -H server1:8,server2:8 python horovod_subclassing_demo.py
"""

import pandas as pd
import tensorflow as tf

from rcalgo.tf.models.classifier.text_classifier import TransformerClassifier
from rcalgo.tf.utils.tokenizers import CharTokenizer


config = {
    "learning_rate": 0.0001,

    "num_classes": 2,
    "max_seq_len": 128,
    "embedding_size": 256,
    "num_layers": 2,
    "conv_num_filters": 256,
    "keep_prob": 0.9,
}


def main(_):
    # 1. load data
    data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
    train_data = pd.read_csv(data_dir + 'train.csv')
    test_data = pd.read_csv(data_dir + 'test.csv')
    # count word dict
    tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=1)
    word_dict = tokenizer.word2idx

    # 2. create model
    model = TransformerClassifier(config, word_dict, name=None)
    model.build_model()
    print(model.model_summary())

    # 3. train
    model.train(
        [train_data['text'], train_data['label']],
        batch_size=128,
        test_size=0.1,
        epochs=5,
        hooks=[])

    model.evaluate([test_data['text'], test_data['label']], batch_size=512)
    results = model.predict([test_data['text']], batch_size=512)
    print(results[0].shape)

    train_sample = train_data.sample(128)
    print(model.train_on_batch([train_sample['text'], train_sample['label']]))
    print(model.train_on_batch([train_sample['text'], train_sample['label']]))
    print(model.train_on_batch([train_sample['text'], train_sample['label']]))

    # 这里sample的话需要同步，不然不同卡数据不一样,结果肯定不一样
    test_sample = test_data.head(10)
    print(model.test_on_batch([test_sample['text'], test_sample['label']]))
    print(model.predict_on_batch([test_sample['text'], test_sample['label']]))


if __name__ == '__main__':
    tf.app.run()
