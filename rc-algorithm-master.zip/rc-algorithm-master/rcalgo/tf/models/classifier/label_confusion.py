"""
Label Confusion Learning to Enhance Text Classification Models
https://arxiv.org/pdf/2012.04987.pdf
"""

import tensorflow as tf

from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.training.training_utils import get_or_create_is_training, create_task_in_graph
from rcalgo.tf.module.layer.basic import my_full_connected
from rcalgo.tf.models.classifier.text_classifier import TextCNN, TextClassifierBase
from rcalgo.tf.module.encoder.cnn import text_cnn_encoder
from rcalgo.tf.training.model import Model
from rcalgo.tf.training.data.data import Data
from rcalgo.tf.metric.loss import my_sparse_cross_entropy_loss
from rcalgo.tf.utils.tf_func import get_new_variable_scope, add_weight_to_collection, fp32_storage_getter
from rcalgo.tf.module.layer.basic import my_dropout


class KwaiLabelConfusionWrapper(Model):
    def __init__(self, execute_model, config, **kwargs):
        self.execute_model = execute_model
        self.num_classes = config.get("num_classes", 2)
        self.label_embed_size = config.get("label_embed_size", 256)
        self.alpha = config.get("alpha")
        self.hidden_size = config.get("hidden_size")
        self.final_keep_prob = config.get("final_keep_prob", 0.5)
        init_scale = config.get("init_scale", 1.0)
        # self.initializer = tf.contrib.layers.xavier_initializer()
        self.initializer = tf.random_uniform_initializer(
             -init_scale, init_scale)
        super().__init__(config, **kwargs)

    def compute_loss(self, logits, labels):
        print(f"logits: {logits}")
        cls_logits, text_reps_norm, label_reps_norm = logits
        # [batch_size, class_num]
        self.cos_sim_matrix = tf.matmul(text_reps_norm, tf.transpose(label_reps_norm, [1, 0]), name='cos_sim_matrix')
        print(f"cos_sim_matrix: {self.cos_sim_matrix}")
        cos_sim_matrix_nog = tf.stop_gradient(self.cos_sim_matrix)
        one_hot_labels = tf.one_hot(labels, depth=self.num_classes, dtype=tf.float32)
        self.simulated_labels = tf.nn.softmax(cos_sim_matrix_nog + self.alpha * one_hot_labels, axis=1)
#         self.original_loss = self.execute_model.compute_loss(cls_logits, self.simulated_labels)
        self.original_loss = tf.reduce_mean(my_sparse_cross_entropy_loss(self.simulated_labels, cls_logits, 2))
        print(f"original_loss: {self.original_loss}")

        y_true_embed = tf.nn.embedding_lookup(label_reps_norm, labels)
        text_reps_no_grad = tf.stop_gradient(text_reps_norm)
        self.dist_loss = tf.keras.losses.CosineSimilarity(axis=1)(text_reps_no_grad, y_true_embed) + 1
        
        final_loss = self.execute_model._penalty() + self.original_loss + self.dist_loss
        return final_loss

    def compute_metrics(self, outputs, labels):
        accuracy = tf.cast(tf.nn.in_top_k(outputs, labels, k=1),  # TODO: fix magic number
                           dtype=tf.float32)
        return accuracy

    def create_inputs(self):
        text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
        label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return text, label

    def call(self, inputs, **kwargs):
        is_training = get_or_create_is_training()
        embedding, seq_lengths = self.execute_model.build_embedding(inputs)
        text_reps = self.execute_model.build_representation(embedding, seq_lengths, **kwargs)
        self.label_embedding = tf.compat.v1.get_variable('label_embedding',
                                                         [self.num_classes, self.label_embed_size],
                                                         dtype=tf.float32,
                                                         initializer=self.initializer)
        label_reps = my_full_connected(self.label_embedding, self.hidden_size,
                                       act=tf.nn.tanh, layer_name='label_emb_dense')
        # [class_num, hidden_size]
        label_reps_norm = tf.math.l2_normalize(label_reps, axis=1, name="label_reps_norm")
        self.label_reps_norm = label_reps_norm
        # [batch_size, hidden_size]
        text_reps_norm = tf.math.l2_normalize(text_reps, axis=1, name="text_reps_norm")
        output_tensor = my_dropout(text_reps, rate=(1 - self.final_keep_prob), training=is_training)
        cls_logits = my_full_connected(output_tensor, self.num_classes, layer_name="final_dense")
        prediction = tf.nn.softmax(cls_logits)
        return [cls_logits, text_reps_norm, label_reps_norm], prediction
    
    
class LabelConfusionWrapper(Model):
    def __init__(self, execute_model, config, **kwargs):
        self.execute_model = execute_model
        self.num_classes = config.get("num_classes", 2)
        self.label_embed_size = config.get("label_embed_size", 256)
        self.alpha = config.get("alpha")
        self.hidden_size = config.get("hidden_size")
        self.final_keep_prob = config.get("final_keep_prob", 0.5)
        init_scale = config.get("init_scale", 1.0)
        # self.initializer = tf.contrib.layers.xavier_initializer()
        self.initializer = tf.random_uniform_initializer(
             -init_scale, init_scale)
        super().__init__(config, **kwargs)

    def compute_loss(self, logits, labels):
        print(f"logits: {logits}")
        cls_logits, text_reps, label_reps = logits
        # [batch_size, class_num]
        self.cos_sim_matrix = tf.matmul(text_reps, tf.transpose(label_reps, [1, 0]), name='cos_sim_matrix')
        print(f"cos_sim_matrix: {self.cos_sim_matrix}")
        self.label_sims = my_full_connected(self.cos_sim_matrix, self.num_classes,
                                            act=tf.nn.softmax, layer_name='label_sims_dense')
        print(f"label_sims: {self.label_sims}")
        one_hot_labels = tf.one_hot(labels, depth=self.num_classes, dtype=tf.float32)
        self.simulated_labels = tf.nn.softmax(self.label_sims + self.alpha * one_hot_labels, axis=1)
        self.original_loss = tf.reduce_mean(my_sparse_cross_entropy_loss(self.simulated_labels, cls_logits, 2))
        
        final_loss = self.execute_model._penalty() + self.original_loss
        return final_loss

    def compute_metrics(self, outputs, labels):
        accuracy = tf.cast(tf.nn.in_top_k(outputs, labels, k=1),  # TODO: fix magic number
                           dtype=tf.float32)
        return accuracy

    def create_inputs(self):
        text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
        label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return text, label

    def call(self, inputs, **kwargs):
        is_training = get_or_create_is_training()
        embedding, seq_lengths = self.execute_model.build_embedding(inputs)
        text_reps = self.execute_model.build_representation(embedding, seq_lengths, **kwargs)
        self.label_embedding = tf.compat.v1.get_variable('label_embedding',
                                                         [self.num_classes, self.label_embed_size],
                                                         dtype=tf.float32,
                                                         initializer=self.initializer)
        label_reps = my_full_connected(self.label_embedding, self.hidden_size,
                                       act=tf.nn.tanh, layer_name='label_emb_dense')

        output_tensor = my_dropout(text_reps, rate=(1 - self.final_keep_prob), training=is_training)
        cls_logits = my_full_connected(output_tensor, self.num_classes, layer_name="final_dense")
        prediction = tf.nn.softmax(cls_logits)
        return [cls_logits, text_reps, label_reps], prediction

