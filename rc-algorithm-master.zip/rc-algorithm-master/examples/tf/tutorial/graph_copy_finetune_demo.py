# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.6.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %%
import pandas as pd
import tensorflow as tf
import sys,os

sys.path.insert(0, '../../')

from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.module.layer.basic import my_full_connected, my_conv_1d, my_dropout
from rcalgo.tf.models.finetune.kwai_bert import KwaiBertClassificationModel, SpanBertClassificationModel

# %%
config = {
    "original_ckpt_path": "/home/web_server/antispam/project/zhouyalin/data/women_scene/"
                          "pretrained_model/bi_transformer_2l_photo_comment_1.ckpt",
    "input_index": 0,
    "output_index": 0,
    "clear_devices": True,
    "gpu_id": 0,
    "gpu_num": 2
    # "fix_lm_layer": True
}

# %%
# 1. load data
data_dir = "/home/web_server/antispam/project/zhouyalin/data/antispam_datasets/female_vulgar/"
train_data = pd.read_csv(data_dir + 'train.csv')
# test_data = pd.read_csv(data_dir + 'test.csv')


# %%
# 2. create model
model = KwaiBertClassificationModel(config, name="finetune", distribute='tf_distribute')
model.build_model()
print(model.model_summary())

# %%
model.train([train_data['text'], train_data['label']],
            batch_size=128,
            epochs=3,
            test_size=0.1)
