import tensorflow as tf
from tensorflow.python.util import nest


class Module(tf.Module):
    """Base class inherited by modules."""
    def __init__(self, name=None):
        super(Module, self).__init__(name=name)
        self.built = False

    def build(self, input_shape):
        self.built = True

    @tf.Module.with_name_scope
    def __call__(self, inputs, *args, **kwargs):
        if not self.built:
            input_list = nest.flatten(inputs)
            input_shapes = None
            if all(hasattr(x, "shape") for x in input_list):
                input_shapes = nest.map_structure(
                    lambda x: x.shape.as_list(), inputs)
                self.build(input_shapes)
        return self.call(inputs, *args, **kwargs)

    def call(self, inputs, *args, **kwargs):
        return inputs
