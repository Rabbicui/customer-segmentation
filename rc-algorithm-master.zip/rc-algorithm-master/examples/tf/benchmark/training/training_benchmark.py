import sys

from rcalgo.tf.utils.logging import logger

sys.path.insert(0, "../../")

import argparse
import json

import pandas as pd
import tensorflow as tf

from rcalgo.tf.models.finetune.kwai_bert import KwaiBertClassificationModel
from rcalgo.tf.models.classifier.text_classifier import TransformerClassifier
from rcalgo.tf.utils.tokenizers import CharTokenizer

FLAGS = None

TRAIN_DATA_PATH = "/home/web_server/antispam/project/datasets/female_vulgar/train.csv"
BI_TRANSFORMER_LM_PATH = "/home/web_server/antispam/project/pretrained_models/bi_transformer_2l_photo_comment_1.ckpt"
SPAN_BERT_LM_PATH = "/home/web_server/antispam/project/pretrained_models/span_bert_5_v100-epoch3.ckpt"


def _get_replica_count():
    if FLAGS.distribute == "horovod":
        raise NotImplementedError
    elif FLAGS.distribute == "tf_distribute":
        return FLAGS.gpu_num
    else:
        with open(FLAGS.cluster_spec_path) as json_file:
            cluster_spec_json = json.load(json_file)
            num_gpu_per_worker = cluster_spec_json.get('num_gpu_per_worker')
            worker_count = len(cluster_spec_json['chief']) + len(cluster_spec_json['worker'])
            return num_gpu_per_worker * worker_count


def run_transformer_benchmark():
    config = {
        "learning_rate": 0.0001,

        "num_classes": 2,
        "max_seq_len": 100,
        "embedding_size": 256,
        "num_layers": 2,
        "conv_num_filters": 256,
        "keep_prob": 0.5,

        "gpu_id": FLAGS.gpu_id,  # used in Single Worker Graph Copy Training
        "gpu_num": FLAGS.gpu_num,  # used in Single Worker Graph Copy Training
        "cluster_spec_json": FLAGS.cluster_spec_path,  # used in Multi Worker Graph Copy Training

        "model_output_dir": "./saved_models",
        "model_name": "transformer",

        "clip_type": "clip_value",
        "clip_gradient": 1.0
    }

    # 1. load data
    train_data = pd.read_csv(TRAIN_DATA_PATH)
    logger.info(f"train_data size: {train_data.size}")

    # count word dict
    tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=1)
    word_dict = tokenizer.word2idx

    # 2. create model
    model = TransformerClassifier(config, word_dict, name="transformer", distribute=FLAGS.distribute)
    model.build_model()
    print(model.model_summary())

    # 3. train
    model.train(
        [train_data['text'], train_data['label']],
        batch_size=FLAGS.per_gpu_batch_size if FLAGS.distribute == "horovod"
        else FLAGS.per_gpu_batch_size * _get_replica_count(),
        test_size=0.1,
        epochs=2,
        hooks=[])


def run_finetune_benchmark():
    config = {
        "clear_devices": True,
        "fix_lm_layer": FLAGS.model_type.endswith("fixed_lm"),
        "original_ckpt_path": BI_TRANSFORMER_LM_PATH if FLAGS.model_type.startswith("bi_transformer")
        else SPAN_BERT_LM_PATH,
        "gpu_id": FLAGS.gpu_id,  # used in Single Worker Graph Copy Training
        "gpu_num": FLAGS.gpu_num,  # used in Single Worker Graph Copy Training
        "cluster_spec_json": FLAGS.cluster_spec_path,  # used in Multi Worker Graph Copy Training

    }
    train_data = pd.read_csv(TRAIN_DATA_PATH)
    logger.info(f"train_data size: {train_data.size}")

    # 2. create model
    model = KwaiBertClassificationModel(config, name="finetune", distribute=FLAGS.distribute)
    model.build_model()
    print(model.model_summary())

    # 3. train
    model.train([train_data['text'], train_data['label']],
                batch_size=FLAGS.per_gpu_batch_size if FLAGS.distribute == "horovod"
                else FLAGS.per_gpu_batch_size * _get_replica_count(),
                epochs=2,
                test_size=0.1)


def main(_):
    if FLAGS.model_type == "transformer":
        run_transformer_benchmark()
    else:
        run_finetune_benchmark()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model-type",
        type=str,
        default="transformer",
        help="benchmark test type, One of 'transformer', 'bi_transformer_finetune', 'bi_transformer_finetune_fixed_lm', 'spanbert_finetune', 'spanbert_finetune_fixed_lm'"
    )
    parser.add_argument(
        "--distribute",
        type=str,
        default="horovod",
        help="One of 'horovod', 'tf_distribute' and 'multiworker_tf_distribute'"
    )
    parser.add_argument(
        "--per-gpu-batch-size",
        type=int,
        default=128,
        help="default per replica batch_size"
    )
    parser.add_argument(
        "--gpu-id",
        type=int,
        default=0,
        help="default start gpu id (only for single worker GraphCopy)"
    )
    parser.add_argument(
        "--gpu-num",
        type=int,
        default=2,
        help="default gpu num (only for single worker GraphCopy)"
    )
    parser.add_argument(
        "--cluster-spec-path",
        type=str,
        default="./training_server/cluster_config.json",
        help="cluster spec path (only for multi worker GraphCopy)"
    )
    FLAGS, unparsed = parser.parse_known_args()
    print(f"Parsed args:{FLAGS}, \n Unparsed args: {unparsed}")
    tf.app.run(main=main)
