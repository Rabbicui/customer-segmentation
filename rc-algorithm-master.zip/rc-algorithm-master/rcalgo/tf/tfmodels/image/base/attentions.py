import tensorflow as tf
from rcalgo.tf.tfmodels.image.base import layers
from rcalgo.tf.tfmodels.image.base.keras_model_wrapper import InfoCollectLayerWrapper
from rcalgo.tf.utils.tf_func import shape_list
from tensorflow.keras.layers import GlobalAveragePooling2D, GlobalMaxPooling2D, Reshape, Dense, \
    Conv2D, Lambda
from tensorflow.keras import backend as K



class LearnToAttentionLayer(InfoCollectLayerWrapper):
    _ATTENTION_TYPE_ = 'out_block'

    def __init__(self, num_filter, scale=False, dropout=0, **kwargs):
        super(LearnToAttentionLayer, self).__init__(**kwargs)
        # create global transition
        g_trans = [
            tf.keras.layers.Dense(
                units=num_filter * 4,
                use_bias=True,
                kernel_initializer="zeros",
                trainable=self.trainable,
                name="attention_global_trans_dense%02d" % num_filter),
            # ReLU()
        ]
        self._global_trans = tf.keras.Sequential(g_trans,
                                                 name='global_trans_layer%02d' % num_filter)

        # create local unit transition
        # TODO 对于最后一个unit 经过 groupnorm + relu后实际上和 pre-logit的区别就是 avg pooling了
        # TODO 另外这里对于前面的unit 直接这么判断需要加上全局信息么？ 这种attention方式只是通过全局来判断pixel attention 但是并没有融合近全局信息
        l_trans = [
            layers.GroupNormalization(name="local_group_norm"),
            layers.ReLU(),
            tf.keras.layers.Conv1D(
                num_filter * 4,
                1,
                kernel_initializer="zeros",
                trainable=self.trainable,
                name="attention_local_trans_dense%02d" % num_filter),
            # ReLU()
        ]
        self._local_trans = tf.keras.Sequential(l_trans, name='local_trans_layer%02d' % num_filter)

        self.num_fiter = num_filter
        self.scale = scale
        self.dropout_layer = None
        if dropout > 0:
            self.dropout_layer = tf.keras.layers.Dropout(dropout)

    def call(self, inputs):
        l, g = inputs[0], inputs[1]
        # attention score between feature map and global layer before final head
        # l should be of shape (batch, h, w, channel)
        # g (batch, channel)
        # 本质就是根据所有channel 信息算出每个位置的权重
        batch, _, _, c = shape_list(l)
        l = tf.reshape(l, [batch, -1, c])
        assert c == self.num_fiter * 4
        l_bak = l
        l = self._local_trans(l)
        g = self._global_trans(g)
        g = tf.expand_dims(g, axis=2)
        # l: (batch, h*w, channel)
        # g: (batch, channel, 1)
        # score (batch, h*w, 1)
        score = tf.matmul(l, g)
        # score (batch, h*w)
        score = tf.reduce_sum(score, 2)
        if self.scale:
            score = score / tf.sqrt(tf.cast(c, tf.float32))
        score = tf.nn.softmax(score, axis=-1)
        if self.dropout_layer is not None:
            score = self.dropout_layer(score)
        # attention map
        attention = tf.expand_dims(score, axis=2)
        # l_bak (batch, h*w, c)
        # attention (batch, h*w, 1)
        # attention will broadcast automatically along the channel dim
        new_g = tf.multiply(l_bak, attention)
        # sum by channel or max pooling or avg?
        new_g = tf.reduce_sum(new_g, [1])
        # collect extra infos
        self.collect((attention, g, l))
        return new_g

    def learn_to_pay_attention(self, l, g):
        # Paper: LearnToPayAttention
        batch, _, _, c = shape_list(l)
        l = tf.reshape(l, [batch, -1, c])
        # shape (batch, channel, h*w)
        l_t = tf.transpose(l, (0, 2, 1))
        # g (batch, channel, 1)
        g = self._global_trans(g)
        g = tf.expand_dims(g, axis=2)
        # score (batch, channel, h * w)
        score = tf.multiply(l_t, g)
        # score (batch, h * w)
        score = tf.reduce_sum(score, 1)
        if self.scale:
            score = score / tf.sqrt(tf.cast(c, tf.float32))
        score = tf.nn.softmax((score + 1e-10), axis=-1)
        if self.dropout_layer is not None:
            score = self.dropout_layer(score)
        # attention map
        imgs = tf.expand_dims(score, axis=1)
        attention = tf.expand_dims(score, axis=1)
        new_g = tf.multiply(l_t, attention)
        # sum by channel or max pooling or avg?
        new_g = tf.reduce_sum(new_g, [2])
        self.collect((imgs, g, l))
        return new_g


class CBAMAttention(tf.keras.layers.Layer):
    _ATTENTION_TYPE = 'in_block'

    def __init__(self, channel, ratio=8, kernel_size=7, name='cbam', collector=None):
        super(CBAMAttention, self).__init__(name=name)
        channel = ChannelAttention(channel, ratio)
        spatial = SpatialAttention(kernel_size, collector=collector)
        self.net = tf.keras.Sequential([channel, spatial])

    def call(self, x):
        return self.net(x)


class ChannelAttention(tf.keras.layers.Layer):
    def __init__(self, channel, ratio=8, **kwargs):
        super(ChannelAttention, self).__init__(**kwargs)
        self.channel = channel
        shared_layer_one = Dense(channel // ratio,
                                 activation='relu',
                                 kernel_initializer='he_normal',
                                 use_bias=True,
                                 bias_initializer='zeros',
                                 name='channel_attention_dense_1_channel%2d' % channel)
        shared_layer_two = Dense(channel,
                                 kernel_initializer='he_normal',
                                 use_bias=True,
                                 bias_initializer='zeros',
                                 name='channel_attention_dense_2%2d' % channel)

        self.avg = tf.keras.Sequential([
            GlobalAveragePooling2D(),
            Reshape((1, 1, channel)),
            shared_layer_one,
            shared_layer_two
        ])

        self.max = tf.keras.Sequential([
            GlobalMaxPooling2D(),
            Reshape((1, 1, channel)),
            shared_layer_one,
            shared_layer_two
        ])

    def call(self, x):
        avg_x = self.avg(x)
        max_x = self.max(x)
        attention = avg_x + max_x
        attention = tf.math.sigmoid(attention)
        return tf.multiply(x, attention)


class SpatialAttention(InfoCollectLayerWrapper):

    def __init__(self, kernel_size=7, **kwargs):
        super(SpatialAttention, self).__init__(**kwargs)
        self.avg_pool = Lambda(lambda x: K.mean(x, axis=3, keepdims=True))
        self.max_pool = Lambda(lambda x: K.max(x, axis=3, keepdims=True))
        self.conv = Conv2D(filters=1,
                           kernel_size=kernel_size,
                           strides=1,
                           padding='same',
                           activation='sigmoid',
                           kernel_initializer='he_normal',
                           use_bias=False, name='spatial_attention_conv')

    def call(self, x):
        avg_x = self.avg_pool(x)
        max_x = self.max_pool(x)
        concat_x = tf.concat([avg_x, max_x], axis=-1)
        attention = self.conv(concat_x)
        self.collect(attention)
        return tf.multiply(x, attention)



#
#
# def se_block(input_feature, ratio=8):
#     """Contains the implementation of Squeeze-and-Excitation(SE) block.
#     As described in https://arxiv.org/abs/1709.01507.
#     """
#
#     channel_axis = 1 if K.image_data_format() == "channels_first" else -1
#     channel = input_feature._keras_shape[channel_axis]
#
#     se_feature = GlobalAveragePooling2D()(input_feature)
#     se_feature = Reshape((1, 1, channel))(se_feature)
#     assert se_feature._keras_shape[1:] == (1, 1, channel)
#     se_feature = Dense(channel // ratio,
#                        activation='relu',
#                        kernel_initializer='he_normal',
#                        use_bias=True,
#                        bias_initializer='zeros')(se_feature)
#     assert se_feature._keras_shape[1:] == (1, 1, channel // ratio)
#     se_feature = Dense(channel,
#                        activation='sigmoid',
#                        kernel_initializer='he_normal',
#                        use_bias=True,
#                        bias_initializer='zeros')(se_feature)
#     assert se_feature._keras_shape[1:] == (1, 1, channel)
#     if K.image_data_format() == 'channels_first':
#         se_feature = Permute((3, 1, 2))(se_feature)
#
#     se_feature = multiply([input_feature, se_feature])
#     return se_feature
