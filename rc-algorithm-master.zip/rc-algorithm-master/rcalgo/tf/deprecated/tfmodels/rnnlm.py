import os
import sys
# sys.path.insert(0,'..')
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))

from rcalgo.tf.tftraining.tf_object import *
from rcalgo.tf.tfmodels.text_basic_model import *
from tftools.tf_float_type import get_default_float_type
from tensorflow.python.util import nest


class RNNLMModel(TextModel):
    """
    tf 2.0开始，原先的RNN模块废弃，替换成keras中的RNN，会有一些不一样的地方
    对于RNN，关注几点：
    1. init_state
    2. cell这块的residual connection支持
    3. 调用，返回
    """
    def __init__(self, config, gragh, word_dict=None):
        super(RNNLMModel, self).__init__(
            config, gragh, word_dict)
        self.num_layers = config.num_layers  # the number of rnn layers
        self.hidden_size = config.hidden_size  # rnn hidden size
        self.keep_prob = config.keep_prob  # keep probability of drop out
        self.state_fc_convert = config.state_fc_convert
        self.state_init_size = config.state_init_size
        self.sampled_softmax = config.sampled_softmax
        self.num_sampled = config.num_sampled
        # for self prediction
        self.input_params = None

    def _init_rnn_state(self, size, state_name='init_state'):
        with tf.name_scope('input_state'):
            if self.state_fc_convert:
                init_state = tf.compat.v1.placeholder(
                    get_default_float_type(), [None, self.state_init_size], name=state_name)
            else:
                #还有一种情况，不走fc，这里copy，但是意义不大，因为预测的时候，还是得三维
                state_fill = tf.fill(
                    [self.dynamic_batch_size*self.gpu_num, size, self.hidden_size], 0.0)
                init_state = tf.compat.v1.placeholder_with_default(
                    state_fill, [None, size, self.hidden_size], name=state_name)
            split_init_state = tf.split(init_state, self.gpu_num, 0)
            self._add_to_graph_inputs([init_state])
            return init_state, split_init_state

    def _add_init_state(self, split_init_state, use_old_version=False):
        init_state = []
        if self.state_fc_convert:
            split_init_state = tf.stack([my_full_connected(split_init_state, self.hidden_size, act=tf.nn.tanh) for i in range(self.num_layers*2)], axis=1)
        for i in range(0, self.num_layers):
            # keras rnn的init state直接按list输入
            if use_old_version:
                temp = rnn_cell.LSTMStateTuple(c=split_init_state[:, i*2, :],
                                               h=split_init_state[:, (i*2+1), :])
            else:
                temp = [split_init_state[:, i*2, :], split_init_state[:, (i*2+1), :]]           
            init_state.append(temp)
        if use_old_version:
            init_state = tuple(init_state)
        return init_state, split_init_state

    def init_rnn_state(self):
        self.init_state, self.split_init_state = self._init_rnn_state(self.num_layers*2)
        self.input_dict['input_state'] = self.split_init_state[0]

    def build_input(self, expand_input=False):
        super(RNNLMModel, self).build_input(expand_input)
        self.init_rnn_state()
        # state list for each gpu
        with tf.name_scope('states_array'):
            self.state_list = [[] for i in range(0, self.gpu_num)]
            self.rnn_output_list = [[] for i in range(0, self.gpu_num)]
            self.output_list = [[] for i in range(0, self.gpu_num)]
            self.total_output_list = [[] for i in range(0, self.gpu_num)]
            self.logits = [[] for i in range(0, self.gpu_num)]

    def build_output(self, task=None):
        with tf.name_scope('output'):
            if task is None or task == self.default_task_name:
                self.split_targets = [tf.concat(
                    [self.split_inputX[i][:, 1:], tf.zeros_like(self.split_inputX[i][:, 0:1])], 1) for i in range(0, self.gpu_num)]
            else:
                self.targets = tf.compat.v1.placeholder(
                    tf.int32, [None, None], name="targets")
                self._update_optimizer(task, self.default_task_name)
                self._add_to_graph_targets(self.targets)
                self.split_targets = tf.split(self.targets, self.gpu_num, 0)

    def _build_rnn_encoder(self):
        cell = self.build_cell(self.hidden_size, self.keep_prob, self.num_layers)
        return tf.keras.layers.RNN(cell, return_state=True, return_sequences=True,
                                         stateful=False, dynamic=False)

    def build_input_sequence(self, gpu_id=0):
        """
        keras的RNN是传cell，对cell可以自定义；LSTM不行
        同时，RNN是一个类，不是函数，需要call，传入的时候不是sequence length，而是基于seq_len的mask
        返回的结果比较乱，需要自己适当解析，且返回的c,h的顺序不一样
        """
        # embedding layer
        self._build_embedding_layer(gpu_id)
        if gpu_id == 0:
            self.encoder = self._build_rnn_encoder()
        self.state_list[gpu_id], self.rnn_output_list[gpu_id] = self.build_rnn_sequence(self.encoder,
                                                                                        self.input_embedding[gpu_id],
                                                                                        self.split_seqLengths[gpu_id],
                                                                                        self.split_init_state[gpu_id],
                                                                                        self.maxlen)
        #V1版本的LSTMCell返回的是[c,h], keras的版本返回的是[h,c]
        #https://github.com/tensorflow/tensorflow/blob/r1.14/tensorflow/python/keras/layers/recurrent.py#L2255
        #https://github.com/tensorflow/tensorflow/blob/r1.14/tensorflow/python/ops/rnn_cell_impl.py#L1059
        self.output_list[gpu_id] = self.rnn_output_list[gpu_id][-1][0]
        self.total_output_list[gpu_id] = tf.concat(
                [tf.stack(state, axis=1) for state in self.rnn_output_list[gpu_id]], axis=1)
        if self.input_params is None:
            self.input_params = tf.compat.v1.trainable_variables()


    def build_rnn_sequence(self, encoder, input_seq, seq_len, input_init_state, maxlen, go_backwards=False):
        """
        RNN自带的go_backwards参数似乎有坑，reverse的时候存在各种问题
        """
        with get_new_variable_scope('rnn_lstm') as rnn_scope:
            init_state, tmp_state  = self._add_init_state(input_init_state)
            # we can add an 1*1 conv1d here to match the hidden_size where user_residual is true.
            # from tensorflow.python.layers.core import Dense  (Dense is ok)

            #lstm = tf.keras.layers.LSTM(self.hidden_size, return_state=True, return_sequences=True,
            #                                 stateful=False, dynamic=False)
            mask = tf.sequence_mask(seq_len, maxlen=maxlen, dtype=tf.int32)
            #tmp_init_state = lstm.get_initial_state(self.input_embedding[gpu_id])
            if go_backwards:
                input_seq = array_ops.reverse_sequence(input_seq,seq_lengths=seq_len, seq_axis=1, batch_axis=0)
            encoder_results = encoder(input_seq, mask=mask, initial_state=init_state)
            if go_backwards:
                encoder_results[0] = array_ops.reverse_sequence(encoder_results[0], seq_lengths=seq_len, seq_axis=1, batch_axis=0)
            #state_list, rnn_output_list
            return encoder_results[0], tuple(encoder_results[1:])


    def build_sequence_prediction(self, task=None, gpu_id=0, nb_class=None, accK=5):
        nb_class = self.nb_words if nb_class is None else nb_class
        task = self.default_task_name if task is None else task
        with get_new_variable_scope('prediction') as pred_scope:
            self.compute_metrics(self.state_list[gpu_id], self.split_targets[gpu_id],
                                 task=task, nb_class=nb_class, accK=accK)

    def convert_list(self, predictions, targets):
        if not isinstance(predictions, list):
            predictions = [predictions]
        if not isinstance(targets, list):
            targets = [targets]
        return predictions, targets

    def loss_function(self, predictions, targets, nb_class):
        #predictions, targets = self.convert_list(predictions, targets)
        loss_list = [variable_seq_loss(prediction, target, self.label_smooth, nb_class) for prediction, target in zip(predictions, targets)]
        loss = tf.reduce_mean(loss_list)
        return reset_nan(loss)
    
    def metrics_function(self, predictions, targets, accK):
        #predictions, targets = self.convert_list(predictions, targets)
        metrics_list = [varibale_topk_accuracy(prediction, target, k=accK) for prediction, target in zip(predictions, targets)]
        metrics = tf.reduce_mean(metrics_list)
        return metrics

    def compute_metrics(self, logits, targets, metrics_name='accuracy', task=None, nb_class=None, accK=5):
        logits, targets = self.convert_list(logits, targets)
        new_logits = []
        loss_list = []
        with tf.name_scope('loss'):
            for idx, (logit, target) in enumerate(zip(logits, targets)):
                with get_new_variable_scope('loss_{}'.format(idx)) as pred_scope:
                    [sampled_softmax_loss, full_softmax_loss], new_logit = my_seq_sampled_softmax_loss(logit, target, nb_class, self.num_sampled, init_std=self.init_std)
                new_logits.append(new_logit)
                if self.sampled_softmax:
                    loss_list.append(sampled_softmax_loss)
                else:
                    loss_list.append(full_softmax_loss)
            loss = tf.reduce_mean(loss_list)
            #loss = tf.where(self.training, sampled_softmax_loss, full_softmax_loss)
            grads, capped_gvs = my_compute_grad(self.opt, loss, self.params,
                                                clip_type='clip_value', task=task,
                                                max_clip_grad=self.clip_gradients)
            self.tower_prediction_results.append(tf.concat(new_logits, 1))
        with tf.name_scope(metrics_name):
            accuracy = self.metrics_function(new_logits, targets, accK)
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task)
        
    def _dump_rnn_output(self):
        self.output_dict['state'] = self.state_list[0]
        self.output_dict['output'] = self.output_list[0]
        #self.output_dict['rnn_output'] = self.rnn_output_list[0]
        if not isinstance(self.total_output_list[0], list):
            self.output_dict['total_output'] = self.total_output_list[0]
        self.build_model_aggregation()
        if not isinstance(self.prediction_results, list):
            self.prediction_results = [self.prediction_results]
        self.prediction_results = self.prediction_results + [tf.concat(
            self.state_list, 0), tf.concat(self.output_list, 0)]
        if not isinstance(self.total_output_list[0], list):
            self.prediction_results + [tf.concat(self.total_output_list, 0)]

    @replace_default_graph
    def build_model(self, task=None, accK=5, nb_class=None):
        self.build_input(expand_input=((
            task is None or task == self.default_task_name) and self.expand_input))
        self.build_output(task)
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    reuse = tf.compat.v1.AUTO_REUSE#(idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_input_sequence(gpu_id=idx)
                        self.build_sequence_prediction(
                            task=task, gpu_id=idx, accK=accK, nb_class=nb_class)
        self._dump_rnn_output()
        self._add_to_graph_outputs(self.prediction_results)
