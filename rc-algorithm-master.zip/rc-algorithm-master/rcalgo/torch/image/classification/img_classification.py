import os

import torch

from rcalgo.torch.image.classification.model import BIT
from rcalgo.torch.image.classification.model import KwaiMoco
from rcalgo.torch.image.classification.semi_classifier.export_pseudo_labels import PseudoLabelsExporter
from rcalgo.torch.image.classification.semi_classifier.few_shot_finetune import KwaiMocoFinetuneModel
from rcalgo.torch.image.classification.semi_classifier.semi_utils import DataKeyRegistry as DK
from rcalgo.torch.image.classification.utils import setup_logger


class KwaiImageClassificationModel(object):

    def __init__(self, config):
        # 1.模型选择
        self.config = config

    def train(self, train_data, test_data, checkpoint_dir, checkpoint_name, batch_size=128, epochs=None,
              unlabel_data=None, unlabel_epochs=20, sup_mode='self'):
        torch.backends.cudnn.benchmark = True

        # 2.train
        config = self.config
        model_name = self.config.get('model_name', 'bit')
        if unlabel_data is not None:
            if sup_mode == 'semi':
                return self.__semi_train(train_data,
                                         test_data,
                                         unlabeled_data=unlabel_data,
                                         checkpoint_dir=checkpoint_dir,
                                         checkpoint_name=checkpoint_name,
                                         batch_size=batch_size,
                                         epochs=epochs,
                                         checkpoint_dir4few='./few', )
            elif sup_mode == 'self':
                print('use unlabel data, model is set to [moco]')
                model_name = 'moco'
            else:
                raise ValueError("Wrong supervised mode, valid supervised mode ['self', 'semi']")

        if model_name == 'bit':
            model = BIT(config)
        elif model_name == 'moco':
            model = KwaiMoco(config, unlabel_data, unlabel_epochs)
        elif model_name == 'vit':
            pass
        else:
            raise Exception('unrecognized model name')
        model.train(train_data, test_data, checkpoint_dir, checkpoint_name, batch_size, epochs)
        # done

    def __semi_train(self,
                     train_data: dict,
                     val_data: dict,
                     unlabeled_data: dict,
                     checkpoint_dir='./semi',
                     checkpoint_name='run_instance_demo',
                     batch_size=128,
                     epochs=300,
                     checkpoint_dir4few='./few',
                     ):

        def modify_params(params: dict, p_type='few_shot'):
            if p_type == 'few_shot':
                params.__setitem__('arch', params.get('teacher_arch', params.get('arch')))
                params.__setitem__('checkpoint_dir', params.get('checkpoint_dir4few', params.get('checkpoint_dir')))
            elif p_type == 'pseudo':
                params.__setitem__('label_teacher', params.get('label_teacher', params.get('label_teacher')))
            elif p_type == 'semi':
                params.__setitem__('arch', params.get('target_arch', params.get('arch')))
                params.__setitem__('pretrained', None)
                params.__setitem__('resume', None)
                params.__setitem__('use_torchvision', True)
                params.__setitem__('checkpoint_dir', params.get('checkpoint_dir4semi', params.get('checkpoint_dir')))
            return params

        full_params = {
            'arch': 'resnet50',  # net architecture
            'teacher_arch': 'resnet50',
            'target_arch': 'resnet50',

            'checkpoint_dir': checkpoint_dir,
            'checkpoint_dir4few': checkpoint_dir4few,
            'checkpoint_dir4semi': checkpoint_dir,

            'label_teacher': 'MoCo',  # choices=['MoCo', 'BiTm', 'torchvision'],

            'workers': 32,
            'epochs': epochs,
            'start_epoch': 0,
            'batch_size': batch_size,
            'lr': 0.01,
            'schedule': [60, 80],
            'momentum': 0.9,
            'weight_decay': 0.,
            'print_freq': 10,
            'evaluate': True,
            'seed': 25,
            'pretrained': '',
            # /home/wudi/antispam/project/yujie/image_unsupervised/moco-master/ckpt/imagenet_resnet50_480_0219_full/checkpoint_0003_mid_0008.pth.tar
            'use_torchvision': True,
            'resume': '',
            'num_classes': 1000,
            'model_name': checkpoint_name,
            'eval_every': -1,
            'aug_mode': 1,
            'freeze': False,
        }

        full_params.update(self.config)
        logger = setup_logger(full_params.get('checkpoint_dir4semi'), full_params.get('model_name'))
        logger.info(f"log file is stored at dir: "
                    f"'{os.path.join(full_params.get('checkpoint_dir4semi'), full_params.get('model_name'))}'")

        logger.info('[Running] Step 1: few shot finetune on downstream task with small data ... ')
        few_shot_finetune_model = KwaiMocoFinetuneModel(config=modify_params(params=full_params, p_type='few_shot'),
                                                        runner_name='FewShotFinetune')
        best_checkpoint_path = few_shot_finetune_model.run(train_data, val_data,
                                                           ckpt_dir=checkpoint_dir4few,
                                                           ckpt_name=checkpoint_name,
                                                           batch_size=batch_size,
                                                           total_epoch=epochs)
        logger.info('[Finished] Step 1.')

        logger.info('[Running] Step 2: use finetuned model to export pseudo-labels for unlabeled data ...')
        pseudo_config = modify_params(params=full_params, p_type='pseudo')
        pseudo_config['resume'] = best_checkpoint_path
        pseudo_label_exporter = PseudoLabelsExporter(params=pseudo_config,
                                                     unlabeled_data=unlabeled_data,
                                                     logger=logger)
        img_names, pred_labels = pseudo_label_exporter.run()
        noisy_data = {
            DK.image: train_data[DK.image] + img_names,
            DK.label: train_data[DK.label] + pred_labels
        }
        logger.info('[Finished] Step 2.')

        logger.info('[Running] Step 3: retrain targeted model on noisy-data')
        enhanced_finetune_model = KwaiMocoFinetuneModel(config=modify_params(params=full_params, p_type='semi'),
                                                        runner_name='NoisyEnhanceTrain')
        enhanced_best_checkpoint_path = enhanced_finetune_model.run(noisy_data, val_data,
                                                                    ckpt_dir=checkpoint_dir,
                                                                    ckpt_name=checkpoint_name,
                                                                    batch_size=batch_size,
                                                                    total_epoch=epochs)
        logger.info('[Finished] Step 3.')
        logger.info(f"The best model checkpoint to use is stored at: '{enhanced_best_checkpoint_path}'")
        return enhanced_best_checkpoint_path
