python training/train_server.py --cluster_spec_path=benchmark/training/training_server/cluster_config.json --task_type=chief --task_index=0 --gpu_id=4
