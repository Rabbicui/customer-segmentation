# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.6.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %%
import os
import pandas as pd
import tensorflow as tf
import numpy as np
import sys
import time
from sklearn.metrics import accuracy_score
from tqdm import tqdm_notebook as tqdm

sys.path.insert(0, "../../")

from rcalgo.tf.models.semi_supervised.mix_text import MixText, MixTextData
from rcalgo.tf.models.semi_supervised.mix_bert import MixBertModel
from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.training.hook import TensorInfoPrintHook
from rcalgo.tf.training.data.data_iterator import DataIterator
from rcalgo.tf.models.finetune.google_bert import BertClassificationModel
from rcalgo.tf.models.finetune.google_bert import BertIdSequenceClassificationModel
from rcalgo.tf.utils.preprocessors import BertSentencePreprocessor

# %%
# load data
data_dir = "/home/web_server/antispam/project/datasets/female_vulgar/"
train_data = pd.read_csv(data_dir + 'train_400.csv')
test_data = pd.read_csv(data_dir + 'test.csv')
# count word dict
tokenizer = CharTokenizer.build_from_corpus(test_data['text'], freq_threshold=2)
word_dict = tokenizer.word2idx

# %%
# augment unsupvised data with EDA
# warning: this step may be time-costing

org_unsup_file = data_dir + "unsup0.txt"
aug_unsup_file = data_dir + "unsup1.txt"

if not os.path.exists(aug_unsup_file):
    from rcalgo.tf.models.augmentation.token_level.eda import EDA
    eda = EDA(stopwords=[], need_cut=True, rand_seed=0)
    start_t = time.time()
    with open(org_unsup_file) as in_f, open(aug_unsup_file, "w") as out_f:
        sentences = [line.strip() for line in in_f]
        aug_sentences = eda.run(sentences, alpha_sr=0.1, alpha_ri=0.1, alpha_rs=0.1, p_rd=0.1, times=1)
        for line in aug_sentences:
            out_f.write(f"{line}\n")

    print(f"Unsup data augment time cost: {time.time() - start_t} s")

# %%
sup_texts = train_data['text']
labels = train_data['label']
batch_size = 32
unsup_ratio = 1
gpu_num = 2
num_epochs = 220
num_train_steps = num_epochs * (int(len(sup_texts)) // (batch_size * gpu_num))
print(f"num_train_steps: {num_train_steps}")

# %%
# create execute model
config = {
    # mix text config
    "mix_type": "mix_sentence_hidden", 
    "lambda_u": 1,
    "lambda_u_hinge" : 1,
    "batch_size": batch_size,
    "epoch_num": num_epochs,
    "num_train_steps": num_train_steps,
    "T": 0.5,
    "unsup_ratio": unsup_ratio,
    "aug_num": 1,
    "gpu_id": 0,
    "gpu_num": gpu_num,
    
    # model config
    "max_seq_length": 128,
    "epochs": 4,
    "test_size": 0.1,
    "batch_size": 32,
    "warmup_proportion": 0.1,

    "learning_rate": 0.0001,

    "vocab_file": "/home/web_server/antispam/project/pretrained_models/"
                  "chinese_L-12_H-768_A-12/vocab.txt",
    "checkpoint_file": "/home/web_server/antispam/project/pretrained_models/"
                       "chinese_L-12_H-768_A-12/bert_model.ckpt"
}

# %%
test_sup_texts = test_data['text']
test_labels = test_data['label']

# %%
org_unsup_texts = []
aug_unsup_texts = []
with open(org_unsup_file) as org_f:
    all_org_unsup_texts = [line.strip() for line in org_f.readlines()]
with open(aug_unsup_file) as aug_f:
    all_aug_unsup_texts = [line.strip() for line in aug_f.readlines()]

unsup_size = len(all_org_unsup_texts) // unsup_ratio
for i in range(unsup_size):
    org_unsup_texts.append([all_org_unsup_texts[i + j] for j in range(unsup_ratio)])
    aug_unsup_texts.append([all_aug_unsup_texts[i + j] for j in range(unsup_ratio)])
    
test_size = len(test_labels)
test_org_unsup_texts = org_unsup_texts[:test_size]
test_aug_unsup_texts = aug_unsup_texts[:test_size]

# %%
print(f"sup_texts: ")
print(sup_texts[:5])
print(f"org_unsup_texts: ")
print(org_unsup_texts[:5])
print(len(org_unsup_texts))
print(f"aug_unsup_texts: ")
print(aug_unsup_texts[:5])
print(len(test_aug_unsup_texts))

# %%
# compute num_train_steps and num_warmup_steps
n_examples = len(sup_texts)
config["num_train_steps"] = int(n_examples * config["epochs"] / config["batch_size"] / gpu_num)
config["num_warmup_steps"] = int(config["num_train_steps"] * config["warmup_proportion"])
print(config)

# %% [markdown]
# ## training with original model

# %%
preprocessor = BertSentencePreprocessor(config["vocab_file"])
sup_texts_ids= [preprocessor.convert_text_to_ids_string(text) for text in sup_texts]
test_sup_texts_ids= [preprocessor.convert_text_to_ids_string(text) for text in test_sup_texts]

# %%
tf.compat.v1.reset_default_graph()
model = BertIdSequenceClassificationModel(config, distribute="tf_distribute")
model.build_model()
model.trainer.initialize()
model.trainer.load_single_graph_checkpoint(config["checkpoint_file"])
print(model.model_summary())

# %%
model.train_and_evaluate(
    [sup_texts_ids, labels],
    [test_sup_texts_ids, test_labels],
    batch_size=config["batch_size"],
    epochs=config["epochs"],
    hooks=[])

# %% [markdown]
# ## training with MixText wrapper

# %%
preprocessor = BertSentencePreprocessor(config["vocab_file"])
sup_texts_ids= [preprocessor.convert_text_to_ids_string(text) for text in sup_texts]
test_sup_texts_ids= [preprocessor.convert_text_to_ids_string(text) for text in test_sup_texts]
org_unsup_texts_ids= [[preprocessor.convert_text_to_ids_string(text) for text in texts] 
                      for texts in org_unsup_texts]
test_org_unsup_texts_ids= [[preprocessor.convert_text_to_ids_string(text) for text in texts] 
                           for texts in test_org_unsup_texts]
aug_unsup_texts_ids= [[preprocessor.convert_text_to_ids_string(text) for text in texts] 
                      for texts in aug_unsup_texts]
test_aug_unsup_texts_ids= [[preprocessor.convert_text_to_ids_string(text) for text in texts] 
                           for texts in test_aug_unsup_texts]

# %%
tf.compat.v1.reset_default_graph()
model = MixBertModel(config=config, name="default", distribute="tf_distribute")
mix_text_model = MixText(config=config, execute_model=model, name="default", distribute="tf_distribute")

# %%
mix_text_model.build_model()

print(mix_text_model.model_summary())
print(mix_text_model.loss)

# %%
logging_hook = TensorInfoPrintHook({"unsup_loss": mix_text_model.unsup_loss,
                                    "sup_loss": mix_text_model.sup_loss, 
                                    "sup_ce_loss": mix_text_model.sup_ce_loss,
                                    "sup_kl_loss": mix_text_model.sup_kl_loss,
                                    "consistency_loss": mix_text_model.consistency_loss,
                                    "self_training_loss": mix_text_model.self_training_loss})

# %%
train_data = MixTextData([sup_texts, org_unsup_texts, aug_unsup_texts, labels],
                     mode="train", batch_size=batch_size * config['gpu_num'], 
                     drop_remainder=True, name="train_data")

test_data = MixTextData([test_sup_texts, test_org_unsup_texts, test_aug_unsup_texts, test_labels],
                     mode="test", batch_size=batch_size * config['gpu_num'], 
                    drop_remainder=True, name="test_data")

# %%
mix_text_model.train_and_evaluate(train_data, test_data,
                batch_size=batch_size * config['gpu_num'],
                epochs=num_epochs,
                hooks=[logging_hook])

# %% [markdown]
# ## Export and infer

# %%
mix_text_model.export_freeze_graph("freeze", 1, multi_replica_ckpt_path="saved_models/best_model/default-epoch204.ckpt")


# %%
def load_feeze_graph(model_fn):
    gpu_options = tf.compat.v1.GPUOptions(allow_growth=True)
    config = tf.compat.v1.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True)
    session = tf.compat.v1.Session(config=config, graph=tf.Graph())
    with session.graph.as_default():
        tf.compat.v1.train.import_meta_graph(model_fn)
        session.run(tf.compat.v1.tables_initializer())
    return session

sess = load_feeze_graph('freeze/1/frozen.pb')

# %%
with sess.graph.as_default():
    inputs = tf.get_collection('input_dict')
    outputs = tf.get_collection('output_dict')[0]

    data_iter = DataIterator([test_sup_texts], 
                             np.array(range(len(test_sup_texts))), batch_size=batch_size)
    data_iter_tqdm = tqdm(data_iter, leave=False)
    res = []
    for idx, batch in data_iter_tqdm:
        feed_data = dict(zip(inputs, batch))
        batch_res = sess.run(outputs, feed_dict=feed_data)
        res.append(batch_res)
       
    np_res = np.concatenate(res, axis=0)
    
print(np_res)

# %%
pos_predicts = np.argmax(np_res, axis=1)
pos_acc = accuracy_score(test_labels, pos_predicts)
print(f"acc on test: {pos_acc}")
