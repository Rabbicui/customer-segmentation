class HParams(object):
    def __init__(self, params):
        if isinstance(params, dict):
            self.__dict__ = params
        else:
            raise ValueError("input type error!")