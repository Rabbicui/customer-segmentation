import numpy as np
import pprint


class FormatPrinter(pprint.PrettyPrinter):
    def __init__(self, formats, simplify_dict=False):
        super(FormatPrinter, self).__init__()
        self.formats = formats
        self.simplify_dict = simplify_dict
    def format(self, obj, ctx, max_level, level):
        if type(obj) in self.formats:
            return self.formats[type(obj)].format(obj), 1, 0
        elif isinstance(obj, list):
            return "[{}]".format(", ".join(
                self.format(element, ctx, max_level, level + 1)[0] for element in obj
            )), 1, 0
        elif isinstance(obj, dict) and self.simplify_dict and len(obj) == 1:
            return self.format(list(obj.values())[0], ctx, max_level, level)
        elif isinstance(obj, dict):
            return pprint.PrettyPrinter.format(
                self,
                dict((k, self.format(v, ctx, max_level, level + 1)[0]) for k,v in obj.items()),
                ctx, max_level, level
            )
        else:
            return pprint.PrettyPrinter.format(self, obj, ctx, max_level, level)

float_format = "{:0.4f}"
formats = {float : float_format, np.float16 : float_format, np.float32 : float_format, np.float64 : float_format}
general_printer = FormatPrinter(formats)
pretty_print = general_printer.pprint

simplify_printer = FormatPrinter(formats, simplify_dict=True)
simplify_print = simplify_printer.pprint
