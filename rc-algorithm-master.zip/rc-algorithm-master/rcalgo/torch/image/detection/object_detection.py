import os
import sys
import torch

from rcalgo.torch.image.detection.model import YOLOV5


class KwaiImageObjectDetectionModel(object):

    def __init__(self, config):
        # 1.模型选择
        self.config = config

    def train(
            self,
            train_data,
            val_data,
            checkpoint_dir,
            checkpoint_name,
            batch_size=64,
            epochs=None):

        config = self.config
        model_name = self.config.get('model_name', 'yolov5')
        if model_name == 'yolov5':
            model = YOLOV5(config)
        elif model_name == 'efficientdet':
            pass
        else:
            raise Exception('unrecognized model name')

        torch.backends.cudnn.benchmark = True
        model.train(
            train_data,
            val_data,
            checkpoint_dir,
            checkpoint_name,
            batch_size=batch_size,
            total_epoch=epochs)
        # done
