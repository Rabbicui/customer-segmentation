import synonyms
import random
import jieba

class EDA(object):
    def __init__(self, stopwords, need_cut=True, rand_seed=0):
        """
        Easy Data Augmentation
        :param need_cut: default True
        :param stopwords:
        :param rand_seed:
        """
        self.need_cut = need_cut
        self.stopwords = stopwords
        random.seed(rand_seed)

    def get_synonyms(self, token):
        """
        get synonyms of token
        """
        return synonyms.nearby(token)[0]

    def synonym_replacement(self, tokens, n):
        """
        replace n tokens to synonyms
        """
        new_tokens = tokens.copy()
        random_token_list = list(set([token for token in tokens if token not in self.stopwords]))
        random.shuffle(random_token_list)
        num_replaced = 0
        for random_token in random_token_list:
            synonyms = self.get_synonyms(random_token)
            if len(synonyms) > 0:
                synonym_token = random.choice(synonyms)
                new_tokens = [synonym_token if token == random_token else token for token in new_tokens]
                num_replaced += 1
            if num_replaced >= n:
                break
        return new_tokens

    def random_insert(self, tokens, n):
        """
        randomly insert n tokens
        """

        def _add_token(new_tokens):
            synonyms = []
            count = 0
            while len(synonyms) < 1:
                random_token = new_tokens[random.randint(0, len(new_tokens) - 1)]
                synonyms = self.get_synonyms(random_token)
                count += 1
                if count >= 10:
                    return

            random_synonym = random.choice(synonyms)
            random_idx = random.randint(0, len(new_tokens) - 1)
            new_tokens.insert(random_idx, random_synonym)

        new_tokens = tokens.copy()
        for _ in range(n):
            _add_token(new_tokens)
        return new_tokens

    def random_swap(self, tokens, n):
        """
        randomly swap two tokens n times
        """
        def _swap_tokens(new_tokens):
            random_idx_1 = random.randint(0, len(new_tokens) - 1)
            random_idx_2 = random_idx_1
            count = 0
            while random_idx_2 == random_idx_1:
                random_idx_2 = random.randint(0, len(new_tokens) - 1)
                count += 1
                if count > 5:
                    return new_tokens
            new_tokens[random_idx_1], new_tokens[random_idx_2] = new_tokens[random_idx_2], new_tokens[random_idx_1]
            return new_tokens

        new_tokens = tokens.copy()
        for _ in range(n):
            new_tokens = _swap_tokens(new_tokens)
        return new_tokens

    def random_delete(self, tokens, p):
        """
        randomly delete token by p probability
        """
        if len(tokens) == 1:
            return tokens
        new_tokens = []
        for token in tokens:
            r = random.uniform(0, 1)
            if r > p:
                new_tokens.append(token)

        if len(new_tokens) == 0:
            random_idx = random.randint(0, len(tokens) - 1)
            return [tokens[random_idx]]
        return new_tokens

    def run(self, sentences, alpha_sr=0.1, alpha_ri=0.1, alpha_rs=0.1, p_rd=0.1, times=4):
        """
        :param sentences: total texts need to augment
        :param alpha_sr: ratio of synonyms replacement
        :param alpha_ri: ratio of random insertion
        :param alpha_rs: ratio of random swap
        :param p_rd: probability of random deletion
        :param times: how many times do you want to augment
        :return:
        """
        ret_text = []
        for text in sentences:
            if self.need_cut:
                tokens = list(jieba.cut(text))
            else:
                tokens = list(text)

            num_tokens = len(tokens)
            num_augments_per_method = int(times/4) + 1
            n_sr = max(1, int(alpha_sr * num_tokens))
            n_ri = max(1, int(alpha_ri * num_tokens))
            n_rs = max(1, int(alpha_rs * num_tokens))

            cur_aug_texts = []
            for _ in range(num_augments_per_method):
                # method1: synonyms replacement
                a_tokens = self.synonym_replacement(tokens, n_sr)
                cur_aug_texts.append(''.join(a_tokens))

                # method2: random insertion
                a_tokens = self.random_insert(tokens, n_ri)
                cur_aug_texts.append(''.join(a_tokens))

                # method3: random swap
                a_tokens = self.random_swap(tokens, n_rs)
                cur_aug_texts.append(''.join(a_tokens))

                # method4: random deletion
                a_tokens = self.random_delete(tokens, p_rd)
                cur_aug_texts.append(''.join(a_tokens))

            random.Random(0).shuffle(cur_aug_texts)
            cur_aug_texts = cur_aug_texts[:times]
            ret_text.append(cur_aug_texts)

        return ret_text


def test():
    sentences = ['为什么屏蔽我', '怎样才能上热门', '我买的东西卖家不给退货怎么办', '不要屏蔽我好不好', '感谢官方']

    eda = EDA(stopwords=[], need_cut=True, rand_seed=0)
    texts = eda.run(sentences, alpha_sr=0.1, alpha_ri=0.1, alpha_rs=0.1, p_rd=0.1, times=4)
    print(texts)


if __name__ == '__main__':
    test()