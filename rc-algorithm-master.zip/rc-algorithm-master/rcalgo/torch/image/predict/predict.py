import torch
import torchvision as tv
import numpy as np
from rcalgo.torch.image.classification.dataset import CustomImageFolder


val_tx = tv.transforms.Compose([
    tv.transforms.Resize((480, 480)),
    tv.transforms.ToTensor(),
    tv.transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])


class PredictModel(object):

    def __init__(self, tracing_path=None):
        if tracing_path is None:
            raise Exception("tracing path must be provided")

        self.model = torch.jit.load('./demo_classification_with_ssl_embedding_tracing')
        self.model.cuda()


    def predict(self, valid_data):
        valid_set = CustomImageFolder(data=valid_data, transform=val_tx)
        valid_loader = torch.utils.data.DataLoader(
            valid_set, batch_size=16, shuffle=False,
            num_workers=8, pin_memory=True, drop_last=False)

        res = []
        for x, y in valid_loader:
            # Schedule sending to GPU(s)
            x = x.cuda()
            scores = self.model(x)
            scores = scores.data.cpu().numpy()  # Also ensures a sync point.
            res.append(scores)

        return np.concatenate(res, axis=0)







