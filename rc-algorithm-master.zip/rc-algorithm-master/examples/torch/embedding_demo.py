import sys
import os

# 目前通用快手视频截图embedding模型已经上线

# 如果有一批自己的无标注数据，可以考虑在这批数据上调整下，这里给出具体调整方式

from rcalgo.torch.image.embedding.kwai_moco import KwaiMocoSSL

config = {
    # 必要参数:无
    #可选参数:
    "lr": 0.03,             # 初始化 learning rate
    "weight_decay": 1e-4,
    "dist_url": 'tcp://localhost:10002',
    "logdir": './',         # 日志目录默认当前目录
    "logname": 'train',       # 日志名
}

model = KwaiMocoSSL(config)

images = ['xx1.png', 'xx2.png']
# train 的 可选参数epoch 如果不指定，会根据训练数据集自动设置
train_data = {
    'image': images
}
if __name__ == '__main__':
    model.train(images, batch_size=128, checkpoint_dir='./', checkpoint_name='demo')

# done

# 最后会在 checkpoint_dir 下保存 两个文件  以 checkpoint_name命名
# 其中带tracing的可用于线上直接上线
