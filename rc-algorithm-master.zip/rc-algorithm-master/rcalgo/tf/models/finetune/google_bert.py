import tensorflow as tf

from rcalgo.tf.training.model import Model
from rcalgo.tf.optimizer import bert_adamw
from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.module.layer.basic import my_dropout
from rcalgo.tf.module.encoder.bert_encoder import BertConfig, BertModel, \
    get_masked_lm_output, get_next_sentence_output
from rcalgo.tf.training import training_utils
from rcalgo.tf.utils.logging import logger
from rcalgo.tf.utils.tf_func import label_smoothing


class BertClassificationModel(Model):
    """Implementation of Official BERT.

    https://github.com/google-research/bert
    """

    def __init__(self, config={}, **kwargs):
        super(BertClassificationModel, self).__init__(config=config,  **kwargs)

        self.max_seq_length = config.get("max_seq_length", 128)
        self.use_one_hot_embeddings = config.get("use_one_hot_embeddings", False)
        self.num_classes = config.get("num_classes", 2)
        self.learning_rate = config.get("learning_rate", 0.00003)

        self.num_train_steps = config.get("num_train_steps", 10000)
        self.num_warmup_steps = config.get("num_warmup_steps", 100)

        self.freeze_layer_num = config.get("freeze_layer_num", 0)
        self.label_smooth = config.get("label_smooth", 0.0)

        self.scope = config.get("scope")

        self.bert_config = BertConfig(
            attention_probs_dropout_prob=config.get("attention_probs_dropout_prob", 0.1),
            hidden_act=config.get("hidden_act", "gelu"),
            hidden_dropout_prob=config.get("hidden_dropout_prob", 0.1),
            hidden_size=config.get("hidden_size", 768),
            initializer_range=config.get("initializer_range", 0.02),
            intermediate_size=config.get("intermediate_size", 3072),
            max_position_embeddings=config.get("max_position_embeddings", 512),
            num_attention_heads=config.get("num_attention_heads", 12),
            num_hidden_layers=config.get("num_hidden_layers", 12),
            type_vocab_size=config.get("type_vocab_size", 2),
            vocab_size=config.get("vocab_size", 21128)
        )

    def create_inputs(self):
        input_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="input_ids")
        input_mask = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="input_mask")
        token_type_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="token_type_ids")
        labels = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None], name="label")
        return [input_ids, input_mask, token_type_ids], labels

    def call(self, inputs, **kwargs):
        input_ids, input_mask, token_type_ids = inputs[0], inputs[1], inputs[2]

        bert_model = BertModel(
            config=self.bert_config,
            input_ids=input_ids,
            input_mask=input_mask,
            token_type_ids=token_type_ids,
            use_one_hot_embeddings=self.use_one_hot_embeddings,
            scope=self.scope)
        output_layer = bert_model.get_pooled_output()

        is_training = get_or_create_is_training()
        output_layer = my_dropout(output_layer, rate=self.bert_config.hidden_dropout_prob,
                                  training=is_training)
        hidden_size = output_layer.shape[-1].value
        output_weights = tf.get_variable(
            "output_weights", [self.num_classes, hidden_size],
            initializer=tf.truncated_normal_initializer(stddev=0.02))
        output_bias = tf.get_variable(
            "output_bias", [self.num_classes],
            initializer=tf.zeros_initializer())

        logits = tf.matmul(output_layer, output_weights, transpose_b=True)
        logits = tf.nn.bias_add(logits, output_bias)
        probabilities = tf.nn.softmax(logits, axis=-1)
        log_probs = tf.nn.log_softmax(logits, axis=-1)

        embedding = bert_model.get_embedding_table()
        hidden_layers = bert_model.get_all_encoder_layers()
        attentions = bert_model.get_all_encoder_attentions()
        return [log_probs, logits, embedding, hidden_layers, attentions], probabilities

    def compute_loss(self, states, labels):
        log_probs = states[0]
        one_hot_labels = tf.one_hot(labels, depth=self.num_classes, dtype=tf.float32)
        if self.label_smooth > 0.0:
            one_hot_labels = label_smoothing(one_hot_labels, self.label_smooth)
        per_example_loss = -tf.reduce_sum(one_hot_labels * log_probs, axis=-1)
        loss = tf.reduce_mean(per_example_loss)
        return loss

    def compute_metrics(self, predictions, labels):
        accuracy = tf.cast(tf.nn.in_top_k(predictions, labels, k=1),
                           dtype=tf.float32)
        return accuracy

    def filter_trainable_variables(self, tvars):
        if self.freeze_layer_num == 0:
            return tvars
        else:
            filter_keywords = [f"layer_{i}/" for i in range(self.freeze_layer_num)] + ["embeddings/"]
            filtered_tvars = []
            left_tvars = []
            for v in tvars:
                if all(keyword not in v.name for keyword in filter_keywords):
                    left_tvars.append(v)
                else:
                    filtered_tvars.append(v)
            logger.info(f"filtered vars: {filtered_tvars}, total: {len(filtered_tvars)}.")
            return left_tvars

    def add_extra_attrs(self, hiddens):
        self.add_extra_attr("logits", hiddens[1])
        self.add_extra_attr("embeddings", hiddens[2])
        self.add_extra_attr("hidden_layers", hiddens[3])
        self.add_extra_attr("attentions", hiddens[4])

    def _build_optimization(self):
        """跟bert原来的逻辑保持一致

        Graph copy目前不支持在这里set_train_op，所以目前只在horovod下使用BERT自带的
        optimization, graph copy情况下使用adam
        """
        if self._distribute == "horovod":
            self.train_op, self.lr_variable = bert_adamw.create_optimizer(
                self.loss, self.learning_rate,
                self.num_train_steps, self.num_warmup_steps,
                use_horovod=True)
            training_utils.set_task_train_op_and_lr(
                self.name, self.train_op, self.lr_variable)
        else:
            super(BertClassificationModel, self)._build_optimization()


class BertIdSequenceClassificationModel(BertClassificationModel):
    def create_inputs(self):
        input_ids_str = tf.compat.v1.placeholder(
            dtype=tf.string, shape=[None], name="input_ids_str")
        labels = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None], name="label")
        return input_ids_str, labels

    def call(self, inputs):
        # split and cast to int
        input_ids = tf.compat.v1.strings.split(inputs, sep=" ")
        input_ids = tf.sparse.to_dense(input_ids, default_value="0")
        input_ids = tf.compat.v1.string_to_number(input_ids, tf.int32)

        # padding sequence
        paddings = tf.constant([[0, 0], [0, self.max_seq_length]])
        input_ids = tf.pad(input_ids, paddings, "CONSTANT")[:, 0:self.max_seq_length]
        sequence_lengths = tf.count_nonzero(input_ids, 1)

        # create input_mask and token_type_ids
        input_mask = tf.sequence_mask(sequence_lengths, maxlen=self.max_seq_length)
        token_type_ids = tf.zeros_like(input_ids)
        return super().call([input_ids, input_mask, token_type_ids])


class BertPreTrainModel(Model):
    def __init__(self, config, **kwargs):
        super().__init__(config=config, **kwargs)

        self.max_seq_length = config.get("max_seq_length", 128)
        self.use_one_hot_embeddings = config.get("use_one_hot_embeddings", False)
        self.learning_rate = config.get("learning_rate", 0.00003)
        self.max_predictions_per_seq = config.get("max_predictions_per_seq", 10)
        self.acc_k = config.get("acc_k", 1)
        self.pred_top_k = config.get("pred_top_k", 100)
        self.enable_nsp = config.get("enable_nsp", True)  # enable next sentence prediction
        self.freeze_layer_num = config.get("freeze_layer_num", 0)

        self.num_train_steps = config.get("num_train_steps", 10000)
        self.num_warmup_steps = config.get("num_warmup_steps", 100)

        self.bert_config = BertConfig(
            attention_probs_dropout_prob=config.get("attention_probs_dropout_prob", 0.1),
            hidden_act=config.get("hidden_act", "gelu"),
            hidden_dropout_prob=config.get("hidden_dropout_prob", 0.1),
            hidden_size=config.get("hidden_size", 768),
            initializer_range=config.get("initializer_range", 0.02),
            intermediate_size=config.get("intermediate_size", 3072),
            max_position_embeddings=config.get("max_position_embeddings", 512),
            num_attention_heads=config.get("num_attention_heads", 12),
            num_hidden_layers=config.get("num_hidden_layers", 12),
            type_vocab_size=config.get("type_vocab_size", 2),
            vocab_size=config.get("vocab_size", 21128)
        )

    def create_inputs(self):
        input_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="input_ids")
        input_mask = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="input_mask")
        token_type_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="token_type_ids")

        masked_lm_positions = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None, self.max_predictions_per_seq],
                                                       name="masked_lm_positions")
        masked_lm_ids = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None, self.max_predictions_per_seq],
                                                 name="masked_lm_ids")
        masked_lm_weights = tf.compat.v1.placeholder(dtype=tf.float32, shape=[None, self.max_predictions_per_seq],
                                                     name="masked_lm_weights")
        if self.enable_nsp:
            next_sentence_labels = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name="next_sentence_labels")
            return [input_ids, input_mask, token_type_ids, masked_lm_positions], \
                   [masked_lm_ids, masked_lm_weights, next_sentence_labels]
        else:
            return [input_ids, input_mask, token_type_ids, masked_lm_positions], \
                          [masked_lm_ids, masked_lm_weights]

    def filter_trainable_variables(self, tvars):
        if self.freeze_layer_num == 0:
            return tvars
        else:
            filter_keywords = [f"layer_{i}/" for i in range(self.freeze_layer_num)] + ["embeddings/"]
            filtered_tvars = []
            left_tvars = []
            for v in tvars:
                if all(keyword not in v.name for keyword in filter_keywords): 
                    left_tvars.append(v)
                else:
                    filtered_tvars.append(v)
            logger.info(f"filtered vars: {filtered_tvars}, total: {len(filtered_tvars)}.")
            return left_tvars

    def call(self, inputs):
        input_ids, input_mask, token_type_ids, masked_lm_positions = inputs
        bert_model = BertModel(config=self.bert_config,
                               input_ids=input_ids,
                               input_mask=input_mask,
                               token_type_ids=token_type_ids,
                               use_one_hot_embeddings=self.use_one_hot_embeddings)

        mlm_logits = get_masked_lm_output(bert_config=self.bert_config,
                                          input_tensor=bert_model.get_sequence_output(),
                                          output_weights=bert_model.get_embedding_table(),
                                          positions=masked_lm_positions)
        mlm_outputs = tf.argmax(tf.nn.log_softmax(mlm_logits), axis=-1, output_type=tf.int32)
        mlm_predictions = tf.argsort(-tf.nn.softmax(mlm_logits))[:, :self.pred_top_k]

        if self.enable_nsp:
            nsp_logits = get_next_sentence_output(bert_config=self.bert_config,
                                                  input_tensor=bert_model.get_pooled_output())
            nsp_predictions = tf.nn.softmax(nsp_logits)
            return [mlm_logits, nsp_logits], [mlm_outputs, mlm_predictions, nsp_predictions]
        else:
            return mlm_logits, [mlm_outputs, mlm_predictions]

    def compute_loss(self, logits, labels):
        if self.enable_nsp:
            mlm_label_ids, mlm_label_weights, next_sentence_labels = labels
            mlm_logits, nsp_logits = logits
        else:
            mlm_label_ids, mlm_label_weights = labels
            mlm_logits = logits

        mlm_log_probs = tf.nn.log_softmax(mlm_logits, axis=-1)
        mlm_label_ids = tf.reshape(mlm_label_ids, [-1])
        mlm_label_weights = tf.reshape(mlm_label_weights, [-1])

        mlm_one_hot_labels = tf.one_hot(
            mlm_label_ids, depth=self.bert_config.vocab_size, dtype=tf.float32)
        # The `positions` tensor might be zero-padded (if the sequence is too
        # short to have the maximum number of predictions). The `label_weights`
        # tensor has a value of 1.0 for every real prediction and 0.0 for the
        # padding predictions.
        mlm_per_example_loss = -tf.reduce_sum(mlm_log_probs * mlm_one_hot_labels, axis=[-1])
        mlm_numerator = tf.reduce_sum(mlm_label_weights * mlm_per_example_loss)
        mlm_denominator = tf.reduce_sum(mlm_label_weights) + 1e-5
        mlm_loss = mlm_numerator / mlm_denominator

        if self.enable_nsp:
            nsp_log_probs = tf.nn.log_softmax(nsp_logits, axis=-1)
            next_sentence_labels = tf.reshape(next_sentence_labels, [-1])
            one_hot_labels = tf.one_hot(next_sentence_labels, depth=2, dtype=tf.float32)
            per_example_loss = -tf.reduce_sum(one_hot_labels * nsp_log_probs, axis=-1)
            nsp_loss = tf.reduce_mean(per_example_loss)
            return mlm_loss + nsp_loss
        else:
            return mlm_loss

    def compute_metrics(self, outputs, labels):
        if self.enable_nsp:
            mlm_label_ids, mlm_label_weights, nsp_labels = labels
            mlm_outputs, mlm_predictions, nsp_predictions = outputs
        else:
            mlm_label_ids, mlm_label_weights = labels
            mlm_outputs, mlm_predictions = outputs
        mlm_label_ids = tf.reshape(mlm_label_ids, [-1])
        mlm_label_weights = tf.reshape(mlm_label_weights, [-1])
        mlm_label_ids = tf.reshape(mlm_label_ids, [-1])
        mlm_label_weights = tf.reshape(mlm_label_weights, [-1])
        mlm_accuracy = tf.cast(tf.math.equal(mlm_outputs, mlm_label_ids), dtype=tf.float32)
        mlm_numerator = tf.reduce_sum(mlm_label_weights * mlm_accuracy)
        mlm_denominator = tf.reduce_sum(mlm_label_weights) + 1e-5
        mlm_accuracy = mlm_numerator / mlm_denominator

        if self.enable_nsp:
            nsp_predictions = tf.argmax(nsp_predictions, axis=-1, output_type=tf.int32)
            nsp_labels = tf.reshape(nsp_labels, [-1]) 
            nsp_accuracy = tf.cast(tf.math.equal(nsp_predictions, nsp_labels), dtype=tf.float32)

            return [mlm_accuracy, nsp_accuracy]
        else:
            return mlm_accuracy
