import numpy as np
import tensorflow as tf

from rcalgo.tf.training import context
from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.modules_v2.layers.preprocessing import TFCharSequencePreprocessor
from rcalgo.tf.modules_v2.layers.common import LayerNormalization, BatchNormalization
from rcalgo.tf.modules_v2.layers.common import Highway, Flatten, flatten, Dropout
from rcalgo.tf.modules_v2.layers.convolutional import Conv1d, Conv2d, Conv2dTranspose
from rcalgo.tf.modules_v2.layers.embeddings import (
    WordEmbedding, PositionEmbedding, SinusoidalPositionEmbedding)
from rcalgo.tf.modules_v2.layers.attentions import (
    SelfPositionAttention, DotProductionAttention, MultiplicativeAttention,
    AdditiveAttention, PairwiseAttention)
from rcalgo.tf.modules_v2.layers.transformer import (FeedForward, MultiHeadAttention,
                                           TransformerEncoderLayer)


class BatchNormalizationTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_batch_norm(self):
        inputs = tf.random.uniform([8, 16, 128], dtype=tf.float32)
        layer = BatchNormalization()
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 16, 128])
        self.assertAllEqual(layer.beta.shape, [128])
        self.assertAllEqual(layer.gamma.shape, [128])
        self.assertAllEqual(layer.moving_mean.shape, [128])
        self.assertAllEqual(layer.moving_variance.shape, [128])

    def test_batch_norm_train_with_keras(self):
        inputs = tf.random.uniform([8, 16, 128], dtype=tf.float32)
        layer1 = tf.keras.layers.BatchNormalization()
        output1 = layer1(inputs, training=tf.constant(True))

        layer2 = BatchNormalization(decay=0.99)
        output2 = layer2(inputs, training=tf.constant(True))

        sess = context.get_session()
        res1, res2 = sess.run([output1, output2])
        self.assertAllEqual(res1, res2)

    def test_batch_norm_inference_with_keras(self):
        inputs = tf.random.uniform([8, 16, 128], dtype=tf.float32)
        layer1 = tf.keras.layers.BatchNormalization()
        output1 = layer1(inputs, training=tf.constant(False))

        layer2 = BatchNormalization(decay=0.99)
        output2 = layer2(inputs, training=tf.constant(False))

        sess = context.get_session()
        res1, res2 = sess.run([output1, output2])
        self.assertAllEqual(res1, res2)


class LayerNormalizationTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_layer_norm_with_keras(self):
        inputs = tf.random.uniform([8, 16, 128], dtype=tf.float32)
        layer1 = tf.keras.layers.LayerNormalization(epsilon=1e-12)
        output1 = layer1(inputs)

        output2 = tf.contrib.layers.layer_norm(
            inputs=inputs, begin_norm_axis=-1, begin_params_axis=-1)

        layer3 = LayerNormalization(epsilon=1e-12)
        output3 = layer3(inputs)

        sess = context.get_session()
        res1, res2, res3 = sess.run([output1, output2, output3])

        self.assertAllEqual(res1, res2)
        self.assertAllEqual(res1, res3)

    def test_layer_norm_multi_axis_with_keras(self):
        inputs = tf.random.uniform([8, 16, 128], dtype=tf.float32)
        layer1 = tf.keras.layers.LayerNormalization(axis=[1, 2], epsilon=1e-12)
        output1 = layer1(inputs)

        output2 = tf.contrib.layers.layer_norm(
            inputs=inputs, begin_norm_axis=1, begin_params_axis=1)

        layer3 = LayerNormalization(axis=[1, 2], epsilon=1e-12)
        output3 = layer3(inputs)

        sess = context.get_session()
        res1, res2, res3 = sess.run([output1, output2, output3])
        self.assertAllEqual(res1, res2)
        self.assertAllEqual(res1, res3)


class DropoutTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_dropout(self):
        inputs = tf.random.uniform([8])
        layer = Dropout(0.5)
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8])

        is_training = get_or_create_is_training()
        res = context.get_session().run(outputs, feed_dict={is_training: True})
        self.assertAlmostEqual(0., res.min())

        res1, res2 = context.get_session().run(
            [inputs, outputs], feed_dict={is_training: False})
        self.assertAllEqual(res1, res2)


class Conv1dTest(tf.test.TestCase):
    def test_conv1d(self):
        inputs = tf.random.uniform([2, 8, 256], dtype=tf.float32)
        layer = Conv1d(128, conv_length=1)
        outputs = layer(inputs)
        expected_shape = [2, 8, 128]
        self.assertAllEqual(outputs.shape, expected_shape)

        layer = Conv1d(128, conv_length=2, use_bn=True)
        outputs = layer(inputs)
        expected_shape = [2, 8, 128]
        self.assertAllEqual(outputs.shape, expected_shape)

    def test_conv1d_padding(self):
        inputs = tf.random.uniform([2, 8, 256], dtype=tf.float32)

        layer = Conv1d(128, conv_length=2, padding='VALID')
        outputs = layer(inputs)
        expected_shape = [2, 7, 128]
        self.assertAllEqual(outputs.shape, expected_shape)

        layer = Conv1d(128, conv_length=2, padding='SAME')
        outputs = layer(inputs)
        expected_shape = [2, 8, 128]
        self.assertAllEqual(outputs.shape, expected_shape)

        layer = Conv1d(128, conv_length=3, padding='LEFT_SAME')
        outputs = layer(inputs)
        expected_shape = [2, 8, 128]
        self.assertAllEqual(outputs.shape, expected_shape)

        layer = Conv1d(128, conv_length=3, padding='RIGHT_SAME')
        outputs = layer(inputs)
        expected_shape = [2, 8, 128]
        self.assertAllEqual(outputs.shape, expected_shape)


class Conv2dTest(tf.test.TestCase):
    def test_conv2d(self):
        inputs = tf.random.uniform([8, 128, 128, 256], dtype=tf.float32)

        layer = Conv2d(128, kernel_size=[2, 2], strides=[2, 2], padding='VALID')
        outputs = layer(inputs)
        expected_shape = [8, 64, 64, 128]
        self.assertAllEqual(outputs.shape, expected_shape)

        layer = Conv2d(128, kernel_size=[2, 2], strides=[2, 2], padding='SAME')
        outputs = layer(inputs)
        expected_shape = [8, 64, 64, 128]
        self.assertAllEqual(outputs.shape, expected_shape)


class Conv2dTransposeTest(tf.test.TestCase):
    def test_conv2d_transpose(self):
        inputs = tf.random.uniform([8, 128, 128, 256], dtype=tf.float32)
        layer = Conv2dTranspose(128, kernel_size=[2, 2],
                                strides=[2, 2], padding='SAME')
        outputs = layer(inputs)
        expected_shape = [8, 256, 256, 128]
        self.assertAllEqual(outputs.shape, expected_shape)


class PreprocessingTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_char_sequence(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, False)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs)

        texts = ["测试a", "c测试abc"]
        expected_results = [[1, 2, 3, 0, 0, 0], [5, 1, 2, 3, 4, 5]]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)

    def test_char_sequence_with_padding(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, False)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs, max_length=7)

        texts = ["测试a", "c测试abc"]
        expected_results = [[1, 2, 3, 0, 0, 0, 0], [5, 1, 2, 3, 4, 5, 0]]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)

    def test_char_sequence_with_boundary(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, True)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs, max_length=10)

        texts = ["测试a", "d测试abc"]
        expected_results = [
            [5, 1, 2, 3, 6, 0, 0, 0, 0, 0],
            [5, 7, 1, 2, 3, 4, 7, 6, 0, 0]
        ]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)

    def test_char_sequence_with_boundary_and_cutting(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, True)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs, max_length=4)

        texts = ["测试a", "d测试abc"]
        expected_results = [
            [5, 1, 2, 6],
            [5, 7, 1, 6]
        ]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)


class HighwayTest(tf.test.TestCase):
    def test_highway(self):
        inputs = tf.random.uniform([8, 16, 128])
        layer = Highway()
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 16, 128])


class FlattenTest(tf.test.TestCase):
    def test_flatten(self):
        inputs = tf.random.uniform([8, 16, 128])
        layer = Flatten()
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 16 * 128])

        outputs = flatten(inputs)
        self.assertAllEqual(outputs.shape, [8, 16 * 128])


class WordEmbeddingTest(tf.test.TestCase):
    def test_word_embedding(self):
        inputs = tf.constant(np.arange(8 * 16).reshape([8, 16]),
                             dtype=tf.int32)
        layer = WordEmbedding(vocab_size=500, embedding_size=256)
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 16, 256])


class SelfPositionAttentionTest(tf.test.TestCase):
    def test_self_position_attention(self):
        inputs = tf.random.uniform([8, 16, 128])
        layer = SelfPositionAttention(attn_dim=256)
        outputs, attn = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 128])
        self.assertAllEqual(attn.shape, [8, 16])


class DotProductionAttentionTest(tf.test.TestCase):
    def test_dot_production_attention(self):
        query = tf.random_uniform([8, 128])
        keys = tf.random_uniform([8, 16, 128])
        values = tf.random_uniform([8, 16, 128])
        layer = DotProductionAttention()
        outputs, attn = layer([query, keys, values])
        self.assertAllEqual(outputs.shape, [8, 128])
        self.assertAllEqual(attn.shape, [8, 16])


class MultiplicativeAttentionTest(tf.test.TestCase):
    def test_multiplicative_attention(self):
        query = tf.random_uniform([8, 128])
        keys = tf.random_uniform([8, 16, 128])
        values = tf.random_uniform([8, 16, 128])
        layer = MultiplicativeAttention()
        outputs, attn = layer([query, keys, values])
        self.assertAllEqual(outputs.shape, [8, 128])
        self.assertAllEqual(attn.shape, [8, 16])


class AdditiveAttentionTest(tf.test.TestCase):
    def test_additive_attention(self):
        query = tf.random_uniform([8, 128])
        keys = tf.random_uniform([8, 16, 128])
        values = tf.random_uniform([8, 16, 128])
        layer = AdditiveAttention()
        outputs, attn = layer([query, keys, values])
        self.assertAllEqual(outputs.shape, [8, 128])
        self.assertAllEqual(attn.shape, [8, 16])


class PairwiseAttentionTest(tf.test.TestCase):
    def test_pairwise_attention(self):
        inputs_a = tf.random_uniform([8, 32, 256])
        inputs_b = tf.random_uniform([8, 16, 128])
        layer = PairwiseAttention(attn_dim=1024)
        scores_a, scores_b = layer([inputs_a, inputs_b])
        self.assertAllEqual(scores_a.shape, [8, 32])
        self.assertAllEqual(scores_b.shape, [8, 16])


class PositionEmbeddingTest(tf.test.TestCase):
    def test_position_embedding(self):
        inputs = tf.random_uniform([8, 32, 256])
        layer = PositionEmbedding(max_position=64)
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [1, 32, 256])


class SinusoidalPositionEmbeddingTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_sinusoidal_position_embedding(self):
        inputs = tf.random_uniform([8, 32, 256])
        layer = SinusoidalPositionEmbedding()
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [1, 32, 256])


class FeedForwardTest(tf.test.TestCase):
    def test_feed_forward(self):
        inputs = tf.random_uniform([8, 32, 256])
        layer = FeedForward(1024, 512)
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 32, 512])
        self.assertAllEqual(layer.inner.kernel.shape, [256, 1024])
        self.assertAllEqual(layer.outer.kernel.shape, [1024, 512])


class MultiHeadAttentionTest(tf.test.TestCase):
    def test_multi_head_attention(self):
        inputs = tf.random_uniform([8, 32, 768])
        layer = MultiHeadAttention(12, 768)
        outputs, attns = layer(inputs, return_attention=True)
        self.assertAllEqual(outputs.shape, [8, 32, 768])
        self.assertAllEqual(attns.shape, [8, 12, 32, 32])

    def test_multi_head_attention_with_memory(self):
        inputs = tf.random_uniform([8, 32, 768])
        memory = tf.random_uniform([8, 64, 768])
        layer = MultiHeadAttention(12, 768)
        outputs, attns = layer(inputs, memory, return_attention=True)
        self.assertAllEqual(outputs.shape, [8, 32, 768])
        self.assertAllEqual(attns.shape, [8, 12, 32, 64])


class TransformerEncoderLayerTest(tf.test.TestCase):
    def test_transformer_encoder_layer(self):
        inputs = tf.random_uniform([8, 32, 768])
        layer = TransformerEncoderLayer(768, 12, 1024)
        outputs = layer(inputs)
        self.assertAllEqual(outputs.shape, [8, 32, 768])


if __name__ == "__main__":
    tf.test.main()
