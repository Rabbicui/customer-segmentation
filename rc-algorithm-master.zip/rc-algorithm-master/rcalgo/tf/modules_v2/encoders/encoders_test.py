import tensorflow as tf

from rcalgo.tf.modules_v2.encoders.transformer_encoder import TransformerEncoder
from rcalgo.tf.modules_v2.encoders.conv_encoder import (TextCNNEncoder,
                                              TextDeepCNNEncoder)


class TransformerEncoderTest(tf.test.TestCase):
    def test_transformer_encoder(self):
        inputs = tf.random_uniform([8, 32, 768])
        encoder = TransformerEncoder(2, num_units=768)
        outputs = encoder(inputs)
        self.assertAllEqual(outputs.shape, [8, 32, 768])

    def test_transformer_encoder_with_mask(self):
        inputs = tf.random_uniform([8, 32, 768])
        encoder = TransformerEncoder(2, num_units=768)
        outputs = encoder(inputs)
        self.assertAllEqual(outputs.shape, [8, 32, 768])


class TextCNNEncoderTest(tf.test.TestCase):
    def test_text_cnn_encoder(self):
        inputs = tf.random_uniform([8, 32, 768])
        encoder = TextCNNEncoder(128)
        outputs = encoder(inputs)
        self.assertAllEqual(outputs.shape, [8, 384])


class TextDeepCNNEncoderTest(tf.test.TestCase):
    def test_text_deep_cnn_encoder(self):
        inputs = tf.random_uniform([8, 256, 768])
        encoder = TextDeepCNNEncoder(128)
        outputs = encoder(inputs)
        self.assertAllEqual(outputs.shape, [8, 640])

    def test_text_deep_cnn__encoder_mean_pooling(self):
        inputs = tf.random_uniform([8, 256, 768])
        encoder = TextDeepCNNEncoder(128,
                                     conv_lengths=[1],
                                     pool_sizes=[-1])
        outputs = encoder(inputs)
        self.assertAllEqual(outputs.shape, [8, 256])


if __name__ == "__main__":
    tf.test.main()
