from rcalgo.tf.training import context
import tensorflow as tf
import horovod.tensorflow as hvd


hvd.init()


class ContextTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_GraphExecutionFunction(self):
        """GraphExecutionFunction 支持图执行时的多态（可以传入不同的dataset或numpy array），
        是keras中`model.fit()`的底层实现。测试其该函数不同类型输入是否可以支持。"""
        x = tf.placeholder(dtype=tf.float32)
        w = tf.Variable(2.0)
        y = tf.multiply(w, tf.square(x)) + x
        optimizer = tf.train.AdamOptimizer()
        train_op = optimizer.minimize(y)

        fn = context.GraphExecutionFunction(inputs=[x],
                                            outputs=[y],
                                            updates=[train_op],
                                            name="train_function")
        # test list data
        res = fn([10.0])
        print(f"fn result with array input: {res}")
        self.assertAllEqual(res, [210])
        session = context.get_session()
        print(f"w: {session.run(w)}")

        # test dataset data
        dataset = tf.data.Dataset.from_tensor_slices([10.0])
        iterator = dataset.make_one_shot_iterator()
        res = fn(iterator.get_next())
        print(f"fn result with dataset input: {res}")

    def test_fetches(self):
        """fetches功能测试."""
        x = tf.placeholder(dtype=tf.float32)
        w = tf.Variable(2.0)
        y = tf.multiply(w, tf.square(x)) + x
        optimizer = tf.train.AdamOptimizer()
        train_op = optimizer.minimize(y)

        context.get_session()
        fn = context.GraphExecutionFunction(inputs=[x],
                                            outputs=[y],
                                            updates=[train_op],
                                            name="train_function")
        tensors = {'w': w, 'y': y}
        fn.set_fetches(tensors)

        fn([10.0])
        self.assertAllEqual(fn.fetches_results, {'w': 2.0, 'y': 210.0})


if __name__ == "__main__":
    tf.test.main()
