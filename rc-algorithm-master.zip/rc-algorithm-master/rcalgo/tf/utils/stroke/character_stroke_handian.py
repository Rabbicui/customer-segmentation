from .handian import Handian
import urllib.request as urllib2
import urllib
from bs4 import BeautifulSoup
# solve encoding
from imp import reload



class Stroke(object):
    handian_url = None

    def __init__(self):
        self.dictionary = {}
        #self.read_dictionary()
        self.handian = Handian()

    def read_dictionary(self):
        self.dictionary = {}
        with open(self.dictionary_filepath, encoding="UTF-8") as f:
            for line in f:
                line = line.strip("\n")
                line = line.split(" ")
                self.dictionary[line[0]] = line[1:]
        f.close()
        # print(self.dictionary)

    def get_stroke(self, word):
        if word in self.dictionary:
            return self.dictionary[word]
        else:
            print("From handian:    word {}".format(word), end=" ")
            self.handian_url = self.handian.get_url(word=word)
            word_utf = word
            word = hex((ord(word)))[2:]
            word = urllib.parse.quote(word)
            return self.get_stroke_from_handian(word_utf)

    def get_stroke_from_handian(self, word):
        url = self.handian_url
        print("url", url)
        if url == "http://www.zdic.net/sousuo/":
            return None

        html = self.post_baidu(url)
        # print(html)
        if html is None:
            return None
        char_stroke = self.anlysis_stroke_from_html(html)
        if char_stroke is not None:
            self.dictionary[word] = char_stroke
        # print("char_stroke {}".format(char_stroke))
        return char_stroke

    def anlysis_stroke_from_html(self, html_doc):
        soup = BeautifulSoup(html_doc, 'html.parser')
        zh_stroke = soup.find(id="z_i_t2_bis")
        zh_stroke = zh_stroke.contents
        zh_stroke_list = []
        for st in zh_stroke[0]:
            zh_stroke_list.append(st)
        return zh_stroke_list

    def post_baidu(self, url):
        try:
            timeout = 10
            # request = urllib2.Request(url)
            request = urllib2.Request(url)
            request.add_header('User-agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
            request.add_header('connection','keep-alive')
            request.add_header('referer', url)
            response = urllib2.urlopen(request, timeout=timeout)
            html = response.read()
            response.close()
            return html
        except Exception as e:
            print('HANDIAN URL Request Error:', e)
            return None
