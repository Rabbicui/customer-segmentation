import os
import horovod.tensorflow as hvd
import tensorflow as tf
import time
import glob
import shutil

from rcalgo.tf.utils.logging import logger
from rcalgo.tf.utils.pretty_print import simplify_print


class Hook(object):
    chief_only = False  # if you only want to run this hook in horovod chief process, please set chief_only = True

    def begin(self, session):
        """Called when train, evaluate, or predict begin
        """
        pass

    def before_epoch(self, session, dataset, epoch):
        """Called before each epoch

        Args:
            session: Session used by the trainer
            dataset: An `TrainingData` object. The dataset user provided
            epoch: Epoch num, an `int` value

        Returns:
          tensor, dict or list: extra tensors need to be fetched
        """
        return None

    def before_run(self, session, batch):
        """Called before each step.
        """
        pass

    def after_run(self, session, batch, extras={}):
        """Called after each step.
        """
        pass

    def after_epoch(self, session, epoch, extras={}):
        """Called after each epoch

        Args:
            session: Session used by the trainer.
            epoch: Epoch num, an int value.
            extras: A dict, which contains extra infos like
                train_loss, train_metrics, valid_loss, valid_metrics.
        """
        pass

    def end(self, session):
        """Called when train, evaluate, or predict is finished
        """
        pass


class BroadcastGlobalVariablesHook(Hook):
    def __init__(self, root_rank=0):
        self.root_rank = root_rank
        self.broadcast_done = False

    def after_run(self, session, batch, extras=None):
        if self.broadcast_done:
            return
        bcast_op = hvd.broadcast_global_variables(self.root_rank)
        session.run(bcast_op)
        self.broadcast_done = True


class CheckpointHook(Hook):
    """Hook for saving checkpoints
    """
    def __init__(self, checkpoint_dir, checkpoint_name, max_to_keep=5, defer_build=False):
        self.defer_build = defer_build
        self.checkpoint_name = checkpoint_name if checkpoint_name else "default_model"
        self.checkpoint_dir = checkpoint_dir if checkpoint_dir else "./saved_models"
        self.saver = tf.compat.v1.train.Saver(max_to_keep=max_to_keep, defer_build=defer_build)
        self.chief_only = True
        self.best_validate_metric = None

    def after_epoch(self, session, epoch, extras):  # pylint: disable=unused-argument
        model_path = "{}/{}-epoch{}.ckpt".format(self.checkpoint_dir, self.checkpoint_name, epoch)
        self.save_checkpoint(session, model_path)

        if self.best_validate_metric is None or extras['validate_metric'] > self.best_validate_metric:
            self.best_validate_metric = extras['validate_metric']
            best_dir = "{}/{}".format(self.checkpoint_dir, 'best_model')
            self.update_best_model(best_dir)

    def save_checkpoint(self, session, model_path, write_meta_graph=True):
        directory = os.path.dirname(model_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        with session.graph.as_default():
            if self.defer_build:
                self.saver.build()
            self.saver.save(session, model_path, write_meta_graph=write_meta_graph)
        logger.info(f"checkpoint saved to : {model_path}")

    def update_best_model(self, best_dir):
        if not os.path.exists(best_dir):
            os.makedirs(best_dir)
        # remove previous best ckpt
        for f in glob.glob(os.path.join(best_dir, '*')):
            os.remove(f)
        last_checkpoints = self.saver.last_checkpoints
        if len(last_checkpoints) > 0:
            latest_checkpoint = self.saver.last_checkpoints[-1]
            for name in glob.glob(latest_checkpoint + '.*'):
                shutil.copy(name, os.path.join(best_dir, os.path.basename(name)))


class TrainInfoPrintHook(Hook):
    """Hook to print train info
    """
    def __init__(self):
        self.chief_only = True
        self.best_train_metric = None
        self.best_test_metric = None

    def before_epoch(self, session, dataset, epoch):
        self.epoch_begin_time = time.time()

    def after_run(self, session, batch, extras=None):
        """Record end time

        Note that hook.after_epoch() is called after the whole epoch,
        including evaluation stage, but here we only want to know the time
        cost of training stage, so epoch_end_time is recorded here.
        """
        self.epoch_end_time = time.time()

    def after_epoch(self, session, epoch, extras):
        if self._is_larger(extras['train_metric'], self.best_train_metric):
            self.best_train_metric = extras['train_metric']
        if self._is_larger(extras['validate_metric'], self.best_test_metric):
            self.best_test_metric = extras['validate_metric']

        simplify_print("epoch {} train time(sec): {}".format(epoch, self.epoch_end_time - self.epoch_begin_time))
        simplify_print({
            "epoch_index": epoch,
            "train_loss": extras['train_loss'],
            "train_metrics": extras['train_metric'],
            "validate_loss": extras['validate_loss'],
            "validate_metrics": extras['validate_metric'],
            "best_train_metrics": self.best_train_metric,
            "best_validate_metrics": self.best_test_metric
        })

    def _is_larger(self, current_metric, best_metric):
        if best_metric is None or not current_metric:
            return True
        if isinstance(current_metric, (list, tuple)):
            return current_metric[0] > best_metric[0]
        else:
            return current_metric > best_metric


class RestoreHook(Hook):
    def __init__(self, saver, original_ckpt_path):
        self.saver = saver
        self.original_ckpt_path = original_ckpt_path

    def begin(self, session):
        self.saver.restore(session, self.original_ckpt_path)


class TensorBoardHook(Hook):
    def __init__(self, log_dir, every_n_step=1):
        self.chief_only = True
        self.writer = tf.summary.FileWriter(log_dir)
        self.step_num = 0
        self.every_n_step = every_n_step

    def begin(self, session):
        self.summary_op = tf.summary.merge_all()

    def before_epoch(self, session, dataset, epoch):
        return self.summary_op

    def after_run(self, session, batch, extras={}):
        if self.step_num % self.every_n_step == 0:
            summary = extras['fetch_results']
            self.writer.add_summary(summary, self.step_num)
        self.step_num += 1


class TensorInfoHook(Hook):
    """Hook to print extra tensors during training. """
    def __init__(self, tensors):
        self.chief_only = True
        self._tensors = tensors

    def before_epoch(self, session, dataset, epoch):
        return self._tensors

    def after_run(self, session, batch, extras={}):
        print(extras)
