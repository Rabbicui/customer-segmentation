import tensorflow as tf

from rcalgo.tf.modules_v2.base_module import Module
from rcalgo.tf.modules_v2.layers.common import flatten
from rcalgo.tf.modules_v2.layers.convolutional import Conv1d


class TextCNNEncoder(Module):
    """TextCNN Encoder."""
    def __init__(self,
                 num_units,
                 conv_lengths=(1, 2, 3),
                 activation='relu',
                 name=None):
        super(TextCNNEncoder, self).__init__(name=name)

        self.num_units = num_units
        self.conv_layers = [
            Conv1d(num_units,
                   conv_length=length,
                   activation=activation,
                   padding="VALID",
                   name="conv_length_{}".format(length))
            for length in conv_lengths]

    def call(self, inputs, training=None):
        pooled_outputs = [
            tf.reduce_max(conv(inputs), axis=1)
            for conv in self.conv_layers]

        outputs = tf.concat(pooled_outputs, 1)
        return outputs


class TextDeepCNNEncoder(Module):
    """Multi-Layer CNN Encoder."""
    def __init__(self,
                 num_units,
                 conv_lengths=[7, 7, 3, 3, 3, 3],
                 pool_sizes=[3, 3, None, None, None, 3],
                 activation='relu',
                 add_mean_pooling=True,
                 name=None):
        super(TextDeepCNNEncoder, self).__init__(name=name)
        self.num_units = num_units
        self.add_mean_pooling = add_mean_pooling

        if len(conv_lengths) != len(pool_sizes):
            raise ValueError("conv_lengths and pool_sizes should have same length!")
        self.pool_sizes = pool_sizes
        with self.name_scope:
            self.conv_layers = [
                Conv1d(num_units,
                       conv_length=length,
                       activation=activation,
                       padding="VALID",
                       name="conv_length_{}".format(length))
                for length in conv_lengths]

    def _pooling(self, conv_x, pool_size, add_mean_pooling=True):
        if pool_size == -1:
            max_pooled = tf.reduce_max(conv_x, axis=1)
            if add_mean_pooling:
                summed = tf.reduce_sum(conv_x, axis=1)
                num_values = tf.count_nonzero(
                    tf.reduce_sum(conv_x, axis=-1),
                    axis=1,
                    keepdims=True,
                    dtype=self.dtype)
                mean_pooled = summed / (num_values + 1e-8)
                conv_x = tf.concat([max_pooled, mean_pooled], axis=1)
        elif pool_size > 0:
            conv_x = tf.nn.max_pool(
                tf.expand_dims(conv_x, -1),
                ksize=[1, pool_size, 1, 1],
                strides=[1, pool_size, 1, 1],
                padding='VALID')
            conv_x = tf.squeeze(conv_x, [3])
        else:
            raise ValueError("invalid pool_size: %d" % pool_size)
        return conv_x

    def call(self, inputs, training=None):
        conv_x = inputs
        for conv_layer, pool_size in zip(self.conv_layers, self.pool_sizes):
            conv_x = conv_layer(conv_x)
            if pool_size is None:
                conv_x = conv_x
            else:
                conv_x = self._pooling(conv_x, pool_size, self.add_mean_pooling)

        outputs = flatten(conv_x)
        # 这里直接把flatten的结果作为输出，原来的全连接层在外面做
        return outputs
