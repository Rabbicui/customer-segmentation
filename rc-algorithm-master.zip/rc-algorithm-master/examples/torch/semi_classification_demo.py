# from rcalgo.torch.image.semi_classifier.classifier import KwaiSemiSupEnhancedClassifier
from rcalgo.torch.image.classification.img_classification import KwaiImageClassificationModel

"""
场景描述：
    有预训练的（任务无关或任务相关）大模型（或自身）、无标注数据、少量标注数据
    使用预训练好的模型在少量标注数据上 finetune，得到"领域内"模型
    使用"领域内"模型输出无标注数据的 pseudo-label，与少量标注数据融合，得到 噪声数据
    使用噪声数据训练目标模型，预期比直接在少量标注数据上训练目标模型能取得较大的提升

使用方法：
    使用者只需要准备以下几类数据
        标注数据-训练集：train_data
        标注数据-测试集: test_data
        无标注数据: unlabeled_data

注意事项：
    程序执行时间可能较长

目标模型表现最优的 checkpoint 存储在 
    f"config['checkpoint_dir4semi']/config['model_name']/model_best.pth.tar"
"""

config = {
    # 必须参数
    'num_classes': 1000,  # 分类个数

    # 默认参数
    'teacher_arch': 'resnet50',  # （任务无关或任务相关的）大模型（或自身）, 比如：resnet152，resnet101，resnet50
    'target_arch': 'resnet50',  # 目标模型，比如：resnet50，resnet18
    'lr': 0.01,  # 初始化 learning rate
}


# images = ['xx1.png', 'xx2.png']
# labels = [1, 0]
# val_images = ['xx1.png', 'xx2.png']
# val_labels = [1, 0]
# unlabeled_images = ['xxx1.png', 'xxx2.png']


def load_image_names_with_labels(path):
    _images, _labels = [], []
    with open(path, 'r', encoding='utf-8') as rf:
        for li in rf.readlines():
            sps = li.strip().split(',')
            assert len(sps) == 2
            _images.append(sps[0])
            _labels.append(int(sps[1]))
    return _images, _labels


demo = True

images, labels = load_image_names_with_labels(
    '/home/web_server/antispam/project/xuemiao/datasets/semi-sl/imagenet1k/ratio0.01/labeled_data.csv')
if demo: images, labels = images[:1000], labels[:1000]

unlabeled_images, _ = load_image_names_with_labels(
    '/home/web_server/antispam/project/xuemiao/datasets/semi-sl/imagenet1k/ratio0.01/unlabeled_data.csv')
if demo: unlabeled_images = unlabeled_images[:1000]

val_images, val_labels = load_image_names_with_labels(
    '/home/web_server/antispam/project/xuemiao/datasets/semi-sl/imagenet1k/val.csv')
if demo: val_images, val_labels = val_images[:1000], val_labels[:1000]

train_data = {
    "image": images,
    'label': labels
}
val_data = {
    "image": val_images,
    'label': val_labels
}

unlabeled_data = {
    "image": unlabeled_images
}

model = KwaiImageClassificationModel(config=config)
if __name__ == '__main__':
    # model.train(train_data, val_data, unlabeled_data)
    # model.semi_train(train_data,
    #                  val_data,
    #                  unlabeled_data,
    #                  checkpoint_dir='./semi',
    #                  checkpoint_name='run_instance_demo',
    #                  batch_size=128,
    #                  epochs=50,
    #                  checkpoint_dir4few='./few', )
    model.train(train_data,
                val_data,
                checkpoint_dir='./semi',
                checkpoint_name='run_instance_demo',
                batch_size=128,
                epochs=100,
                unlabel_data=unlabeled_data,
                unlabel_epochs=20,
                sup_mode='semi')
