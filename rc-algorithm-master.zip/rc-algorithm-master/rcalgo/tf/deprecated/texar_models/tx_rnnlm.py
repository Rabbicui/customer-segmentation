import os
import sys
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))

from rcalgo.tf.tfmodels.rnnlm import *
from tftools.tf_func import inverse_sigmoid_sample_proba
import texar.tf as tx

class TxRNNLMModel(RNNLMModel):
    def __init__(self, config, graph, word_dict=None):
        super(TxRNNLMModel, self).__init__(
            config, graph, word_dict)
        self.inference_decoder_output = [[] for i in range(0, self.gpu_num)]
        self.beam_width = config.beam_width
        self.sampling_probability = 1.0 - inverse_sigmoid_sample_proba(config.sample_decay_factor, self.global_step)
        #self.sampling_probability = config.sampling_probability

    def build_input(self, expand_input=False):
        super(TxRNNLMModel, self).build_input(expand_input)
        self.build_sentence_flag(self.nb_words)

    def build_sentence_flag(self, nb_words):
        self.go_value = tf.compat.v1.placeholder_with_default(tf.constant([self._sos_token_id(nb_words)],dtype=tf.int32),
                                                    tf.TensorShape([1]), name='go_value')
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.GO_VALUE, self.go_value)
        self.eos_value = self._eos_token_id(nb_words)
        self.top_k = tf.compat.v1.placeholder_with_default(tf.constant(10,dtype=tf.int32),
                                                 tf.TensorShape(None), name='top_k_sample')
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.TOP_K_SAMPLE, self.top_k)
        self.softmax_temperature = tf.compat.v1.placeholder_with_default(tf.constant([1.0],dtype=tf.float32),
                                                    tf.TensorShape([1]), name='softmax_temperature')
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.SOFTMAX_TEMPERATURE, self.softmax_temperature)


    def build_input_sequence(self, gpu_id=0):
        self._build_embedding_layer(gpu_id, 'encoder_embedding')
        if gpu_id == 0:
            cell = self.build_cell(self.hidden_size, self.keep_prob, self.num_layers, True)
            self.decoder = tx.modules.BasicRNNDecoder(cell=cell, vocab_size=self.nb_words)
            """
            cell = {
                "type": "LSTMBlockCell",
                "kwargs": {
                    "num_units": self.hidden_size,
                },
                "dropout": {"output_keep_prob": self.keep_prob},
                "num_layers": self.num_layers,
            }
            self.decoder = tx.modules.BasicRNNDecoder(
                vocab_size=self.nb_words, hparams={"rnn_cell": cell})
            """
            
        enc_embeddings = tf.compat.v1.get_collection('encoder_embedding')[0]
        training_helper = tf.contrib.seq2seq.ScheduledEmbeddingTrainingHelper(
            inputs=self.input_embedding[gpu_id],
            sequence_length=tf.to_int32(self.split_seqLengths[gpu_id]),
            embedding=enc_embeddings,
            sampling_probability=self.sampling_probability)

        init_state, tmp_state  = self._add_init_state(self.split_init_state[gpu_id], True)
        if gpu_id == 0:
            self.input_dict['input_tmp_state'] = tmp_state  
        outputs, final_state, _ = self.decoder(
            decoding_strategy="train_greedy",
            impute_finished=False,
            #inputs=self.input_embedding[gpu_id],
            #sequence_length=tf.to_int32(self.split_seqLengths[gpu_id]),
            helper=training_helper,
            initial_state=init_state
        )
        self.state_list[gpu_id] = outputs.cell_output
        self.logits[gpu_id] = outputs  # .logits
        self.output_list[gpu_id] = tf.concat([tf.stack(state, axis=1) for state in final_state],axis=1)#final_state[-1].h
        # print(outputs)
        self.build_inference(init_state, gpu_id)

    def _build_inference(self, gpu_id, decoder, init_state, go_value, eos_value, maxlen, embedding):
        decoder_start_token = tf.ones_like(
            self.split_inputX[gpu_id][:, 0], dtype=tf.int32) * go_value
        topk_helper = tx.modules.TopKSampleEmbeddingHelper(embedding,
                                                           start_tokens=decoder_start_token,
                                                           end_token=eos_value,
                                                           top_k=self.top_k,
                                                           softmax_temperature=self.softmax_temperature
                                                          )
        infer_greedy_outputs, _, _ = decoder(
            decoding_strategy='infer_greedy',
            initial_state=init_state,
            start_tokens=decoder_start_token,
            end_token=eos_value,
            embedding=embedding,
            mode='infer',
            max_decoding_length=maxlen)

        infer_sample_outputs, _, _ = decoder(
            decoding_strategy='infer_sample',
            initial_state=init_state,
            start_tokens=decoder_start_token,
            end_token=eos_value,
            embedding=embedding,
            mode='infer',
            helper=topk_helper,
            max_decoding_length=maxlen)

        beam_outputs, _, _ = tx.modules.beam_search_decode(
            decoder_or_cell=decoder,
            initial_state=init_state,
            embedding=embedding,
            start_tokens=decoder_start_token,
            end_token=eos_value,
            beam_width=self.beam_width,
            max_decoding_length=maxlen)

        self.inference_decoder_output[gpu_id] = [
            infer_greedy_outputs, infer_sample_outputs, beam_outputs]

    def build_inference(self, init_state, gpu_id=0):
        enc_embeddings = tf.compat.v1.get_collection('encoder_embedding')[0]
        self._build_inference(gpu_id, decoder=self.decoder, init_state=init_state, go_value=self.go_value,
                              eos_value=self.eos_value, maxlen=self.maxlen, embedding=enc_embeddings)

    def _dump_rnn_output(self):
        """
        add decoder results
        """
        
        self.output_dict['greedy_logits'] = tf.identity(
            self.inference_decoder_output[0][0].logits, name='greedy_logits')
        self.output_dict['greedy_sample_id'] = tf.identity(
            self.inference_decoder_output[0][0].sample_id, name='greedy_sample_id')
        self.output_dict['sample_logits'] = tf.identity(
            self.inference_decoder_output[0][1].logits, name='sample_logits')
        self.output_dict['sample_sample_id'] = tf.identity(
            self.inference_decoder_output[0][1].sample_id, name='sample_sample_id')
        self.output_dict['beam_search_results'] = tf.identity(
            self.inference_decoder_output[0][2].predicted_ids, name='beam_search_results')
        super(TxRNNLMModel, self)._dump_rnn_output()

        
    def build_sequence_prediction(self, task=None, gpu_id=0, nb_class=None, accK=1):
        with get_new_variable_scope('prediction') as pred_scope:
            current_max_length = tf.reduce_max(self.split_seqLengths[gpu_id])
            paddings = tf.constant([[0, 0], [0, self.maxlen]])
            predictions = self.logits[gpu_id].logits
            self.tower_prediction_results.append(predictions)
        super(RNNLMModel, self).compute_metrics(predictions, self.split_targets[gpu_id][:, 0:current_max_length],
                            task=task, nb_class=nb_class, accK=accK)    
      
    def loss_function(self, preditions, targets, nb_class):
        preditions, targets = self.convert_list(preditions, targets)
        loss_list = [variable_seq_loss(predition, target, self.label_smooth, nb_class) for predition, target in zip(preditions, targets)]
        loss = tf.reduce_mean(loss_list)
        return reset_nan(loss)
    
    def metrics_function(self, preditions, targets, accK):
        preditions, targets = self.convert_list(preditions, targets)
        metrics_list = [varibale_topk_accuracy(predition, target, k=accK) for predition, target in zip(preditions, targets)]
        metrics = tf.reduce_mean(metrics_list)
        return metrics

