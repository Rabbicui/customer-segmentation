import tensorflow as tf
import os

class Trainer(object):
    def __init__(self, model_input_dir, model_name):
        self.gpu_config = tf.compat.v1.ConfigProto(allow_soft_placement=True)
        self.gpu_config.gpu_options.allow_growth = True

        self.model_input_dir = model_input_dir
        self.model_name = model_name
        self.session = self._init_from_checkpoint(
            ckpt_path=os.path.join(self.model_input_dir, "{}.ckpt".format(self.model_name)),
            config=self.gpu_config, clear_devices=False)
        self.graph = self.session.graph

    def run(self, data):
        with self.graph.as_default():
            task = [name.decode() if isinstance(name, bytes) else name for name in
                               tf.compat.v1.get_collection('tasks')][0]
            outputs = tf.compat.v1.get_collection("{}_{}".format(task, 'outputs'))[0]
            inputs = tf.compat.v1.get_collection("{}_{}".format(task, 'inputs'))[0]
            feed_dict = {inputs: data}
            return self.session.run(outputs, feed_dict=feed_dict)

        
    def _init_from_checkpoint(self, ckpt_path, config, clear_devices):
        session = tf.compat.v1.Session(config=config, graph=tf.Graph())
        with session.graph.as_default():
            saver = tf.compat.v1.train.import_meta_graph("{}.meta".format(ckpt_path), clear_devices=clear_devices)
            saver.restore(session, ckpt_path)
            op_name = "init_all_tables"
            if self._exists_op_name(graph=session.graph, op_name=op_name):
                session.run(session.graph.get_operation_by_name(op_name))
        return session

    def _exists_op_name(self, graph, op_name):
        return any(op.name == op_name for op in graph.get_operations())