import tensorflow as tf
from rcalgo.tf.module.layer.basic import *
from rcalgo.tf.module.layer.activations import leaky_relu

def vanilla_discriminator(gan, input_x, reuse=None):
    """
    The discriminator task the `real data`/`generated data`. Outputs a tensor in the range
    [-inf, inf]

    Args:
        gan:       The gan model object
        input_x:   The real or generated data.
        reuse:     Whether reuse the variable scope

    Returns:
        Logits for the probability that the data is real.
    """
    d_h1 = my_full_connected(input_x, gan.hidden_dim, act=tf.nn.relu, reuse=reuse,
                             layer_name='discriminator_fc_1',
                             add_bias=True, variables_collections=gan.D_TASK)
    d_logit = my_full_connected(d_h1, 1, add_bias=True, reuse=reuse,
                                layer_name='discriminator_fc_2',
                                variables_collections=gan.D_TASK)
    return d_logit

def conv2d_discriminator(gan, input_x, reuse=None):
    """
    Discriminator works on Mnist images
    """
    input_x = tf.reshape(input_x, [-1, 28, 28, 1])
    net = my_conv_2d(input_x, 64, [4, 4], strides=2, reuse=reuse, act=leaky_relu,
                     layer_name='discriminator_conv2d_1', variables_collections=gan.D_TASK)

    net = my_conv_2d(net, 128, [4, 4], strides=2, reuse=reuse, act=leaky_relu,
                     layer_name='discriminator_conv2d_2', variables_collections=gan.D_TASK)

    net = my_flatten(net)
    net = my_full_connected(net, 1024, act=leaky_relu, reuse=reuse, layer_name='discriminator_fc_1',
                            add_bias=True, variables_collections=gan.D_TASK)

    net = tf.contrib.layers.layer_norm(net)

    net = my_full_connected(net, 1, act=leaky_relu, reuse=reuse, layer_name='discriminator_fc_2',
                            add_bias=True, variables_collections=gan.D_TASK)
    return net


