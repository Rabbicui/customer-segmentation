import os
import sys

import numpy as np
import torch
from torch import nn
from torchvision import models
from rcalgo.torch.image.classification.base import Finetune
from rcalgo.torch.image.classification import utils
from rcalgo.torch.image.classification import backbone
from rcalgo.torch.image.embedding.kwai_moco import KwaiMocoSSL


class BIT(Finetune):

    def __init__(self, config, *args, **kwargs):
        super().__init__(config)
        self.mixup = 0
        self.mixup_l = 0
        default_ckpt_path = '/home/web_server/antispam/project/multimodal/image/BiT-M-R50x1.npz'
        self.pretrain_path = config.get('pretrain_path', default_ckpt_path)

    def init_model(self):
        model = backbone.KNOWN_MODELS['BiT-M-R50x1'](head_size=self.classes, zero_head=True)
        model.load_from(np.load(self.pretrain_path))
        print("=> loaded pre-trained model '{}'".format(self.pretrain_path))
        return model

    def new_lr(self, step, train_size):
        lr = utils.get_lr(step, train_size, self.lr, self.batch_size)
        return lr

    def new_batch(self, x, y, train_size):
        mixup = utils.get_mixup(train_size)
        mixup_l = np.random.beta(mixup, mixup) if mixup > 0 else 1
        # do some modification on batch
        if mixup > 0.0:
            x, y_a, y_b = utils.mixup_data(x, y, mixup_l)
            self.mixup = mixup
            self.mixup_l = mixup_l
            return x, (y_a, y_b)
        return x, y

    def criterion(self, logits, y):
        if self.mixup > 0.0:
            y_a, y_b = y
            c = utils.mixup_criterion(self.cri, logits, y_a, y_b, self.mixup_l)
        else:
            c = self.cri(logits, y)
        return c



class KwaiMoco(BIT):
    def __init__(self, config, unlabel_data=None, unlabel_epochs=20):
        super().__init__(config)
        default_ckpt_path = '/home/web_server/antispam/project/multimodal/image/moco.pth.tar'
        self.pretrain_path = config.get('pretrain_path', default_ckpt_path)
        self.unlabel_data = unlabel_data
        self.unlabel_epochs = unlabel_epochs
        if self.lr == 0.003:
            # moco 需要大一点lr
            self.lr = 0.01

    def init_model(self):
        model = models.__dict__['resnet50']()
        dim_mlp = model.fc.weight.shape[1]
        model.fc = nn.Linear(dim_mlp, self.classes)
        model.fc.weight.data.normal_(mean=0.0, std=0.01)
        model.fc.bias.data.zero_()

        checkpoint = torch.load(self.pretrain_path, map_location="cpu")

        # rename moco pre-trained keys
        state_dict = checkpoint['state_dict']
        for k in list(state_dict.keys()):
            # retain only encoder_q up to before the embedding layer
            if k.startswith('module.encoder_q') and not k.startswith('module.encoder_q.fc'):
                # remove prefix
                state_dict[k[len("module.encoder_q."):]] = state_dict[k]
            # delete renamed or unused k
            del state_dict[k]

        msg = model.load_state_dict(state_dict, strict=False)
        assert set(msg.missing_keys) == {"fc.weight", "fc.bias"}
        print("=> loaded pre-trained model '{}'".format(self.pretrain_path))
        return model

    def train(self, train_data, test_data, ckpt_dir, ckpt_name, batch=256, epochs=None):
        if self.unlabel_data is not None:
            # 复用 kwai moco 训练逻辑
            # 这里简化版本直接隐藏 moco ssl训练的所有参数
            model = KwaiMocoSSL({})
            print("=> start training unlabeled data {} images for {} epochs".format(len(self.unlabel_data['image']), self.unlabel_epochs))
            ssl_name = ckpt_name + '_embedding'
            model.train(self.unlabel_data, batch_size=batch, checkpoint_dir=ckpt_dir,
                        checkpoint_name=ssl_name, epochs=self.unlabel_epochs)
            print("=> finish training unlabeled data.")
            # 让模型load 新的预训练地址ckpt
            # 释放gpu
            del model
            self.pretrain_path = ckpt_dir + '/' + ssl_name

        # do normal classification part
        super().train(train_data, test_data, ckpt_dir, ckpt_name, batch=batch, total_epoch=epochs)


