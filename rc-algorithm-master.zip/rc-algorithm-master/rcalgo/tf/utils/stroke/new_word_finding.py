from rcalgo.tf.utils.text_utils import *
import hashlib
from tqdm import *
import jieba
from collections import defaultdict

class NewWordFinding(object):
    def __init__(self, texts, stopwords, ngram=5, min_count=5, min_proba={2:5, 3:25, 4:125}):
        self.stopwords = stopwords
        self.min_count = min_count
        self.ngram = ngram
        self.md5 = lambda s: hashlib.md5(s).hexdigest()
        self.texts = texts
        self.parse_word()  #use jieba to parse word
        self.parse_ngram()
        self.coag_filter(min_proba=min_proba)
        self.ngram_cut()
        self.ngram_filter()

    def read_comments(self, sentences, split_sentence=False):
        texts_set = set()
        for line in sentences:
            text = weibo_filter(line.strip())
            if self.md5(text.encode('utf-8','ignore')) in texts_set:
                continue
            else:
                texts_set.add(self.md5(text.encode('utf-8','ignore')))
                if split_sentence:
                    for t in re.split(u'[^\u4e00-\u9fa50-9a-zA-Z]+', text):
                        if t:
                            yield t.lower()
                else:
                    yield text.lower()

    def parse_word(self):
        self.word_set = set()
        self.word_map = defaultdict(int)
        for text in tqdm(self.read_comments(self.texts)):
            seg_list = jieba.cut(text.lower())
            sent = " ".join(seg_list).split()
            self.word_set.update(sent)
            for s in sent:
                self.word_map[s] += 1

    def parse_ngram(self):
        self.ngrams_map = defaultdict(int)
        for t in tqdm(self.read_comments(self.texts, split_sentence=True)):
            for i in range(len(t)):
                for j in range(1, self.ngram+1):
                    if i+j <= len(t):
                        self.ngrams_map[t[i:i+j]] += 1
        #filter the ngrams with low frequency
        self.ngrams_map = {i:j for i,j in self.ngrams_map.items() if j >= self.min_count}


    def coag_filter(self, min_proba={2:5, 3:25, 4:125}):
        total = 1.*sum([j for i,j in self.ngrams_map.items() if len(i) == 1]) #single word count
        def coag_score(s, ngrams):
            if len(s) >= 2 and s in self.ngrams_map:
                score = min([total*self.ngrams_map[s]/(self.ngrams_map[s[:i+1]]*self.ngrams_map[s[i+1:]]) for i in range(len(s)-1)])
                return score
            else:
                return 0
        self.ngrams_coag_list = []
        self.ngrams = set()
        for i in range(2,5):
            self.score_dict = dict((s, coag_score(s,self.ngrams_map)) for s,j in self.ngrams_map.items() if len(s) == i)
            self.ngrams_coag_list.append(dict((s, j) for s,j in self.score_dict.items() if j > min_proba[i]))
            self.ngrams.update(self.ngrams_coag_list[-1].keys())

    def ngram_cut(self):
        def cut(s):
            r = np.array([0]*(len(s)-1))
            for i in range(len(s)-1):
                for j in range(2, self.ngram+1):
                    if i+j <= len(t):
                        if s[i:i+j] in self.ngrams:
                            r[i:i+j-1] += 1
            w = [s[0]]
            for i in range(1, len(s)):
                if r[i-1] > 0:
                    w[-1] += s[i]
                else:
                    w.append(s[i])
            return w
        self.words = defaultdict(int)
        for t in tqdm(self.read_comments(self.texts, split_sentence=True)):
            for i in cut(t):
                self.words[i] += 1
        self.words = {i:j for i,j in self.words.items() if j >= self.min_count}

    def ngram_filter(self, cut=False, maxlen=5):
        def is_real(s):
            if len(s) >= 2:
                for i in range(1, self.ngram+1):
                    for j in range(len(s)-i+1):
                        if cut and s[j:j+i] not in self.ngrams:
                        #    print(s[j:j+i], s)
                            return False
                        if s[j:j+i] in self.stopwords:
                            #print(s[j:j+i], s)
                            return False
                return True
            else:
                return True
        self.new_words = {i:j for i,j in self.words.items() if len(i) > 1 and len(i) <= maxlen and is_real(i)}# and self.word_map[i] < 5}
