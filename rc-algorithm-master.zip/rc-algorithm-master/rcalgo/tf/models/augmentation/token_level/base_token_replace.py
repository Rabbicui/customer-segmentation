import collections
import copy
import math
import numpy as np
import jieba
np.seterr(divide='ignore', invalid='ignore')


class TokenReplace(object):
    def __init__(self, sentences, need_cut=False):
        """
        :param sentences: list of text
        :param need_cut: cut text by jieba if true or text will be represent by single word if false
        """
        self.need_cut = need_cut
        self.vocab = self._build_vocab(sentences)
        self.data_stats = self._get_data_stats(sentences)

    def _build_vocab(self, sentences):
        vocab = {}
        for text in sentences:
            if self.need_cut:
                tokens = jieba.cut(text)
            else:
                tokens = list(text)
            for word in tokens:
                if word not in vocab:
                    vocab[word] = len(vocab)
        return vocab

    def _get_data_stats(self, sentences):
        """Compute the IDF score for each word. Then compute the TF-IDF score."""
        word_doc_freq = collections.defaultdict(int)
        # Compute IDF
        for text in sentences:
            cur_word_dict = {}
            if self.need_cut:
                tokens = list(jieba.cut(text))
            else:
                tokens = list(text)

            cur_sent = copy.deepcopy(tokens)
            for word in cur_sent:
                cur_word_dict[word] = 1
            for word in cur_word_dict:
                word_doc_freq[word] += 1
        idf = {}
        for word in word_doc_freq:
            idf[word] = math.log(len(sentences) * 1. / word_doc_freq[word])

        # Compute TF-IDF
        tf_idf = {}
        for text in sentences:
            if self.need_cut:
                tokens = list(jieba.cut(text))
            else:
                tokens = list(text)
            cur_sent = copy.deepcopy(tokens)

            for word in cur_sent:
                if word not in tf_idf:
                    tf_idf[word] = 0
                tf_idf[word] += 1. / len(cur_sent) * idf[word]
        return {
            "idf": idf,
            "tf_idf": tf_idf,
        }

    def reset_random_prob(self):
        """Generate many random numbers at the same time and cache them."""
        cache_len = 100000
        self.random_prob_cache = np.random.random(size=(cache_len,))
        self.random_prob_ptr = cache_len - 1

    def get_random_prob(self):
        """Get a random number."""
        value = self.random_prob_cache[self.random_prob_ptr]
        self.random_prob_ptr -= 1
        if self.random_prob_ptr == -1:
            self.reset_random_prob()
        return value

    def get_random_token(self):
        """Get a random token."""
        token = self.token_list[self.token_ptr]
        self.token_ptr -= 1
        if self.token_ptr == -1:
            self.reset_token_list()
        return token