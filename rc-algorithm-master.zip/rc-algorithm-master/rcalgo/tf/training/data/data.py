# coding: utf-8
import tensorflow as tf

from rcalgo.tf.utils.logging import logger
from rcalgo.tf.utils.text_utils import *
from rcalgo.tf.training.data.data_iterator import DataIterator


class Data(object):
    def __init__(self, datasets, batch_size, mode="train", default_random_seed=None,
                 drop_remainder=False, name="Data"):
        self.ignored_input_index = [idx for idx, col in enumerate(datasets) if col is None]
        raw_dataset_size = min([len(col) for col in datasets if col is not None])
        if not drop_remainder:
            datasets = [col for col in datasets if col is not None]
        else:
            remainder_size = raw_dataset_size % int(batch_size)

            logger.info(f"{name}: will drop {remainder_size} remainder_size data items.")

            datasets = [col[:-remainder_size] if remainder_size != 0 else col
                        for col in datasets if col is not None]
        self.datasets = [np.array(dataset) if not isinstance(dataset, np.ndarray)
                         else dataset for dataset in datasets]
        self.batch_size = batch_size
        self.default_random_seed = default_random_seed
        self.mode = mode
        self.data_schema = None

    def build_schema(self):
        self.data_schema = tuple(tf.compat.v1.placeholder(
            dataset.dtype if dataset.dtype is not np.dtype(np.int64) else np.dtype(np.int32),
            tuple(d if idx2 == 0 else d for idx2, d in enumerate(dataset.shape)),
            name=f'{self.mode}_col_{idx}') for idx, dataset in enumerate(self.datasets))

    def to_tf_dataset(self):
        self.build_schema()
        if self.mode == "train":
            return tf.data.Dataset.from_tensor_slices(self.data_schema).shuffle(
                self.get_dataset_size()).batch(self.batch_size).repeat().prefetch(tf.data.experimental.AUTOTUNE)
        else:
            return tf.data.Dataset.from_tensor_slices(self.data_schema).batch(self.batch_size)

    def get_dataset_size(self):
        return int(len(self.datasets[0]))

    def get_batch_size(self):
        return self.batch_size

    def get_tf_dataset_feed_dict(self):
        feed_dict = self.get_feed_dict()
        return feed_dict

    def get_feed_dict(self):
        return dict(zip([col.name for col in self.data_schema],
                        [dataset for dataset in self.datasets]))

    def create_iterator(self, batch_size=None):
        if batch_size is None:
            batch_size = self.batch_size
        return DataIterator(datasets=self.datasets, index_list=np.arange(0, len(self.datasets[0])),
                            batch_size=batch_size)
