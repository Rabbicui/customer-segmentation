## Subclassing API示例

本文介绍如何使用subclassing api在低俗数据集上训练一个transformer分类模型。

主要步骤：

1. 通过subclassing实现一个TransformerModel
2. 读取数据
3. 训练模型
4. 测试模型效果
5. 导出pb文件



### 1. 通过subclassing实现一个TransformerModel

实现subclassing模型需要继承Model作为基类。Model类主要提供如下几个接口：

* `__init__`: 初始化函数，在这里获取config里的参数 
* `create_inputs`: 定义模型的inputs和labels
* `call`: 在这里实现模型的网络结构，输出logits和predictions
* `compute_loss`: 计算模型的loss
* `compute_metrics`: 计算模型的metrics
* `create_optimizer`(optional): 定义模型的optimizer，默认使用`tf.train.AdamOptimizer`

TransformerModel的具体实现：

```python
import tensorflow as tf
from rcalgo.tf.training import Model

class TransformerModel(Model):
	def __init__(self, config, word_dict, **kwargs):
    """初始化config，初始化layer."""
    super().__init__(config=config, **kwargs)
    self.max_seq_len = hparams.get("max_seq_len", 128)
    self.embedding_size = hparams.get("embedding_size", 256)
    self.num_classes = hparams.get("num_classes", 2)
    self.num_layers = hparams.get("num_layers", 2)
    
    self.preprocessor = TFCharSequencePreprocessor(word_dict)
  
  def create_inputs(self):
    """定义模型的input和label."""
    text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
    label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_label')
    return text, label
  
  def call(self, text, **kwargs):
    sequence, seq_lengths = self.preprocessor(text, max_length=self.max_seq_len)
    embedding = my_embedding_layer(sequence, self.nb_words, self.embedding_size,
                                   variables_collections="encoder_embedding",
                                   layer_name="embedding_layer",
                                   init_scale=self.init_scale,
                                   dtype=tf.float32)
    state_list, rnn_output_list = conv_transformer_layer(
    	embedding, self.num_layers,
      seq_lengths, self.conv_num_filters,
      self.position_type, n_head=self.n_head,
      combine_mode=self.combine_mode,
      attn_drop=self.attn_drop, mask=self.mask,
      ffn_act=self.ffn_act, ffn_drop=self.ffn_drop
    )
    hidden, alphas = self_position_attention(state_list, self.attention_size)
    logits = my_full_connected(hidden, self.num_classes)
    prediction = tf.nn.softmax(logits)
    return logits, predictions
    
  def compute_loss(self, logits, label)
  	"""使用cross entropy loss."""
  	loss = tf.reduce_mean(my_sparse_cross_entropy_loss(label, logits, 2))
    return loss
    
  def compute_metrics(self, output, label)
  	"""使用top1 accuracy作为metric"""
  	accuracy = tf.cast(tf.nn.in_top_k(outputs, labels, k=1), dtype=tf.float32)
    return accuracy
  
```

### 2. 读取数据

使用female_vulgar数据集作为训练数据，数据格式可以用numpy，也可以用`tf.data.Dataset`。

这里我们直接用pandas读取训练数据：

```python
data_dir = "/home/web_server/antispam/project/datasets/female_vulgar/"
train_data = pd.read_csv(data_dir + 'train.csv')
test_data = pd.read_csv(data_dir + 'test.csv')
```

### 3. 训练模型

因为我们的模型是文本模型，所以需要首先构建词表，然后再初始化一个`TransformerModel`进行训练。

具体步骤包括：

1. 从训练数据中构建word_dict
2. 初始化`TransformerModel`的实例
3. 调用`build_model`构建模型
4. 使用`train`接口训练模型

```python
# 1. build word dict
tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=1)
word_dict = tokenizer.word2idx

# 2. create model
config = {
  "learning_rate": 0.0001,
  "num_classes": 2,
  "num_layers": 2,
  "embedding_size": 256,
  "conv_num_filters": 256
}
model = TransformerModel(config=config, word_dict=word_dict, name="your_model_name", distribute="horovod")

# 3. build model
model.build_model()

# 4. train
model.train([train_data['text'], train_data['label']],
            batch_size=128,
            test_size=0.1,
            epochs=5,
            checkpoint_dir="./saved_models",
            checkpoint_name="your_checkpoint_name")
```

目前分布式训练支持horovod和graph copy两种方式，在初始化模型时通过distribute参数指定。另外启动方式略有差别：

**Horovod:** 

参数：model = TransformerModel(..., distribute="horovod")

启动命令：

* 单卡：python your_script.py 
* 多卡: mpirun -np 8 --allow-run-as-root python your_script.py (8指的是8卡训练)

**Graph copy:** 

参数：

config = {"gpu_id": 0, "gpu_num": 8}

model = TransformerModel(config=config, ..., distribute="tf_distribute")

启动命令：python your_script.py



### 4. 测试模型效果

模型训练好以后，可以选择效果最好的checkpoint，在测试数据集上看一下效果。主要包括两步：

1. 从checkpoint恢复模型
2. 在测试数据集上`evaluate`

```python
# 1. restore checkpoint
model.restore_checkpoint("./saved_models/your_best_checkpoint_name")

# 2. evaluate
model.evaluate([test_data['text'], test_data['label']],
               batch_size=512)
```

如果是在一个单独的脚本里，可以先新建一个model的实例，再调用`restore_checkpoint`，或者直接使用`Model.from_checkpoint`得到一个model实例:

```python
# 在一个单独的脚本里，没有model实例的情况
# method 1:
model = TransformerModel(config=config, word_dict=word_dict, name="your_model_name")
model.build_model()
model.restore_checkpoint("./saved_models/your_best_checkpoint_name")
model.evaluate(...)

# method 2:
model = Model.from_checkpoint("./saved_models/your_best_checkpoint_name")
model.evaluate(...)
```



### 5. 导出pb文件

使用model.export_freeze_graph来导出pb文件，下面这行代码会将模型存储到your_directory/1/frozen.pb文件里.

```python
model.export_freeze_graph("your_directory", "1")
```

