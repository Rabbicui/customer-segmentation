import sys
import os
import time
import torch
import torchvision
import torch.nn as nn

from rcalgo.torch.image.detection.models import common
from rcalgo.torch.image.detection.utils.activations import Hardswish, SiLU
from rcalgo.torch.image.detection.utils.general import check_img_size
from rcalgo.torch.image.detection.utils.torch_utils import attempt_load

use_cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if use_cuda else "cpu")


def export_first_stage_trace_model(
    model_path, save_path, img_size=[
        640, 640], batch_size=1):
    # Load PyTorch model
    model = attempt_load(
        model_path,
        map_location=torch.device('cpu'))  # load FP32 model
    model = model.to(device)

    # Checks
    gs = int(max(model.stride))  # grid size (max stride)
    # verify img_size are gs-multiples
    img_size = [check_img_size(x, gs) for x in img_size]

    # Input
    # image size(1,3,320,192) iDetection
    img = torch.zeros(batch_size, 3, *img_size).to(device)

    # Update model
    for k, m in model.named_modules():
        m._non_persistent_buffers_set = set()  # pytorch 1.6.0 compatibility
        if isinstance(
                m, common.Conv):  # assign export-friendly activations
            if isinstance(m.act, nn.Hardswish):
                m.act = Hardswish()
            elif isinstance(m.act, nn.SiLU):
                m.act = SiLU()

    model.model[-1].export = True  # set Detect() layer export=True
    y = model(img)  # dry run

    # TorchScript export
    try:
        print(
            '\nStarting TorchScript export with torch %s...' %
            torch.__version__)
        # f = model_path.replace('.pt', '.torchscript.pt')  # filename
        ts = torch.jit.trace(model, img)
        ts.save(save_path)
        print('TorchScript first stage export success')
    except Exception as e:
        print('TorchScript first stage export failure: %s' % e)

    return


class Yolov5Model(torch.jit.ScriptModule):
    def __init__(self, model, stride, anchor_grid, grid, no):
        super(Yolov5Model, self).__init__()
        self.model = model
        self.stride, self.anchor_grid, self.grid, self.no = stride, anchor_grid, grid, no

    @torch.jit.script_method
    def forward(self, img):
        pre_result = self.model.forward(img)
        boxs = self.results_processing(
            pre_result[0], pre_result[1], pre_result[2])
        filter_result = self.non_max_suppression_by_torch(boxs)
        return filter_result

    @torch.jit.script_method
    def _make_grid(self, nx: int = 20, ny: int = 20):
        yv, xv = torch.meshgrid([torch.arange(ny), torch.arange(nx)])
        return torch.stack((xv, yv), 2).view((1, 1, ny, nx, 2)).float()

    @torch.jit.script_method
    def _processing(self, x, stride, anchor_grid, grid):

        stride, anchor_grid = stride.to(
            torch.device("cuda:0")), anchor_grid.to(
            torch.device("cuda:0"))

        bs, na, ny, nx, _ = x.shape
        if grid.shape[2:4] != x.shape[2:4]:
            grid = self._make_grid(nx, ny)

        grid = grid.to(torch.device("cuda:0"))
        y = x.sigmoid()
        y[..., 0:2].mul_(2.).sub_(0.5).add_(grid).mul_(stride)
        # y[..., 0:2] = (y[..., 0:2] * 2. - 0.5 + grid) * stride

        y[..., 2:4].mul_(2.).pow_(2).mul_(anchor_grid)
        # y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * anchor_grid
        return y.view(bs, -1, self.no)

    @torch.jit.script_method
    def results_processing(self, x, y, z):
        result = []
        result.append(
            self._processing(
                x,
                self.stride[0],
                self.anchor_grid[0],
                self.grid[0]))
        result.append(
            self._processing(
                y,
                self.stride[1],
                self.anchor_grid[1],
                self.grid[1]))
        result.append(
            self._processing(
                z,
                self.stride[2],
                self.anchor_grid[2],
                self.grid[2]))
        return torch.cat(result, 1)

    @torch.jit.script_method
    def xywh2xyxy(self, x):
        y = torch.zeros_like(x)
        y[:, 0].copy_(x[:, 0] - x[:, 2] / 2)  # top left x
        y[:, 1].copy_(x[:, 1] - x[:, 3] / 2)  # top left y
        y[:, 2].copy_(x[:, 0] + x[:, 2] / 2)  # bottom right x
        y[:, 3].copy_(x[:, 1] + x[:, 3] / 2)  # bottom right y
        return y

    @torch.jit.script_method
    def non_max_suppression_by_torch(self, prediction):
        # conf_thres = 0.3
        conf_thres = float('-inf')
        iou_thres = 0.5
        max_det = 100

        if prediction.dtype is torch.float16:
            prediction = prediction.float()  # to FP32

        nc = prediction[0].shape[1] - 5  # number of classes
        xc = prediction[..., 4] > conf_thres  # candidates

        output = [
            torch.zeros(
                (0, 6), device=prediction.device)] * prediction.shape[0]
        for xi, x in enumerate(prediction):  # image index, image inference

            x = x[xc[xi]]  # confidence

            # If none remain process next image
            if not x.shape[0]:
                continue

            # Compute conf
            x[:, 5:].mul_(x[:, 4:5])  # conf = obj_conf * cls_conf

            # Box (center x, center y, width, height) to (x1, y1, x2, y2)
            box = self.xywh2xyxy(x[:, :4])

            conf, j = x[:, 5:].max(1, keepdim=True)
            x = torch.cat((box, conf, j.float()), 1)[
                conf.view(-1) > conf_thres]

            # If none remain process next image
            if not x.shape[0]:  # number of boxes
                continue

            # Picked bounding boxes
            indexs = torch.zeros(x.shape[0])

            # boxes (offset by class), scores
            boxes, scores = x[:, :4], x[:, 4]
            i = torchvision.ops.boxes.nms(boxes, scores, iou_thres)
            if len(i) > max_det:  # limit detections
                i = i[:max_det]

            # output[xi] = x[i]
            output[xi] = torch.flatten(x[i])  # torch.cat(x[i], 1)

        output_tensor = torch.stack(output, 0)

        return output_tensor


def script_tracing(savename):
    savename = str(savename)
    first_stage_ts_path = savename.replace('.pt', '.firstStage.pt')
    save_path = savename.replace('.pt', '.tracing.pt')
    export_first_stage_trace_model(savename, first_stage_ts_path)
    jit_model = torch.jit.load(first_stage_ts_path)

    modeldata = torch.load(savename, map_location=torch.device('cpu'))
    model = modeldata['model'].float().eval()
    model = model.float()
    model = model.to(device)

    # 载入相关参数
    stride, anchor_grid, grid, no = model.model[-1].stride, model.model[-1].anchor_grid, \
        model.model[-1].grid, model.model[-1].no

    # 初始化模型并编译
    complete_model = Yolov5Model(jit_model, stride, anchor_grid, grid, no)

    # 保存模型
    complete_model.save(save_path)
    os.remove(first_stage_ts_path)

    return
