## Horovod Trainer

Horovod trainer是基于horovod和mpi4py实现的一套多卡训练工具。

### 1. Horovod简介

horovod是基于mpi实现的一套分布式训练框架，支持单机多卡和多机多卡，底层使用openmpi, nccl等进程间通信库。它主要的优点在于易用性和性能，只要对单卡代码做简单的修改，就可以实现分布式训练。

#### Horovod的原理

horovod的分布式训练采用的是数据并行，每张卡上都有一个完整的模型，卡之间通过allreduce算法来同步梯度信息。

<img src="./.images/image-20201116185830436.png" alt="image-20201116185830436"  width="50%" height="50%" /> 

#### horovod的使用

horovod的使用比较简单，主要是将普通的optimizer用hvd.DistributedOptimizer包装一下，这样就会在计算梯度时就会自动将不同卡上的梯度进行平均。

```python
import tensorflow as tf
import horovod.tensorflow as hvd


# Initialize Horovod
hvd.init()

# Pin GPU to be used to process local rank (one GPU per process)
config = tf.ConfigProto()
config.gpu_options.visible_device_list = str(hvd.local_rank())

# Build model...
loss = ...
opt = tf.train.AdagradOptimizer(0.01 * hvd.size())

# Add Horovod Distributed Optimizer
opt = hvd.DistributedOptimizer(opt)

# Add hook to broadcast variables from rank 0 to all other processes during
# initialization.
hooks = [hvd.BroadcastGlobalVariablesHook(0)]

# Make training operation
train_op = opt.minimize(loss)

# Save checkpoints only on worker 0 to prevent other workers from corrupting them.
checkpoint_dir = '/tmp/train_logs' if hvd.rank() == 0 else None

# The MonitoredTrainingSession takes care of session initialization,
# restoring from a checkpoint, saving to a checkpoint, and closing when done
# or an error occurs.
with tf.train.MonitoredTrainingSession(checkpoint_dir=checkpoint_dir,
                                       config=config,
                                       hooks=hooks) as mon_sess:
  while not mon_sess.should_stop():
    # Perform synchronous training.
    mon_sess.run(train_op)
```



### 2. Horovod Trainer

Horovod trainer就是借助horovod实现的trainer，支持以下功能：

* 支持list、numpy、tf.dataset格式的输入
* 支持分布式训练
* 支持分布式predict、evaluate



具体的执行逻辑如图：

#### Train

<img src="./.images/image-20201116204151923.png" alt="image-20201116204151923"  width="50%" height="50%"/>

#### Predict

<img src="./.images/image-20201116204305641.png" alt="image-20201116204305641"  width="50%" height="50%" />



**Evaluate**

<img src="./.images/image-20201116204651311.png" alt="image-20201116204651311"  width="50%" height="50%" />

参考资料：

* [horovod官方github](https://github.com/horovod/horovod)
* [组内分享-Horovod分布式训练介绍](https://wiki.corp.kuaishou.com/pages/viewpage.action?pageId=380881819&preview=/380881819/440839278/Horovod%E5%88%86%E5%B8%83%E5%BC%8F%E8%AE%AD%E7%BB%83.pdf)

