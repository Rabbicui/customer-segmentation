import numpy as np
from sklearn import metrics


def threshold_by_precision(y_label, y_score, target, start=0.0, end=1.0, step=0.01):
    return __threshold_by_metrics(y_label, y_score, target, metrics.precision_score, start, end, step)


def threshold_by_recall(y_label, y_score, target, start=0.0, end=1.0, step=0.01):
    return __threshold_by_metrics(y_label, y_score, target, metrics.recall_score, start, end, step)


def __threshold_by_metrics(y_label, y_score, target, metrics_func, start, end, step):
    cur_diff = None
    cur_score = None
    cur_threshold = None
    for threshold in np.arange(start, end, step):
        score = metrics_func(y_label, y_score > threshold)
        diff = abs(score - target)
        if cur_diff is None or diff < cur_diff:
            cur_diff = diff
            cur_score = score
            cur_threshold = threshold
    return cur_threshold, cur_score
