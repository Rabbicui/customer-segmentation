import os
import math
import time
from collections import defaultdict

import numpy as np
from tensorflow.python.client import timeline
from tensorflow.python.distribute.cross_device_ops import NcclAllReduce
from tensorflow.python.distribute.device_util import local_devices_from_num_gpus
from tensorflow.python.ops.gen_dataset_ops import multi_device_iterator_to_string_handle
from tqdm import tqdm

from rcalgo.tf.utils.logging import logger
from rcalgo.tf.training import graph_copy
from rcalgo.tf.training.hook import CheckpointHook, TrainInfoPrintHook
from rcalgo.tf.training.trainer import Trainer
from rcalgo.tf.training.data.data import Data
from rcalgo.tf.training.data.data_utils import split_data
import tensorflow as tf

from rcalgo.tf.training.training_utils import get_from_task_collection
from rcalgo.tf.utils.tf_func import replace_default_graph
from rcalgo.tf.training.training_utils import get_or_create_is_training


class SingleWorkerGraphCopyTrainer(Trainer):
    """ graph copy based trainer.


    TODO: build_model_summary迁移。
    TODO: update learning rate迁移。
    """

    def __init__(self,
                 graph=None,
                 session_config=None,
                 gpu_id=None,
                 gpu_num=None,
                 multi_worker_training=False,
                 distribute_strategy=None,
                 session_target=None,
                 lr_annealing=False,
                 lr_annealing_stop_value=None,
                 default_task_name="default",
                 save_trace=False,
                 trace_json_path="./timeline.json",
                 log_train_graph=False,
                 train_graph_log_path="./train_log",
                 *args, **kwargs):
        super(SingleWorkerGraphCopyTrainer, self).__init__(default_task_name=default_task_name, *args, **kwargs)
        if session_config is None:
            self.session_config = tf.compat.v1.ConfigProto(allow_soft_placement=True)
            self.session_config.gpu_options.allow_growth = True
        else:
            self.session_config = session_config

        if graph is None:
            self.org_graph = tf.compat.v1.get_default_graph()
        else:
            self.org_graph = graph

        self.graph = None
        self.session = None
        self.single_graph_sess = None

        self.multi_worker_training = multi_worker_training
        self.distribute_strategy = distribute_strategy
        self.session_target = None
        if self.multi_worker_training is True:
            self.session_target = session_target
        self._gpu_id = gpu_id
        self._gpu_num = gpu_num

        self.lr_annealing = lr_annealing
        self.lr_annealing_stop_value = lr_annealing_stop_value
        self.config = kwargs

        self._initialized = False

        self.save_trace = save_trace
        self.trace_json_path = trace_json_path
        self.run_options = None
        self.run_metadata = None
        if self.save_trace:
            self.run_options = tf.compat.v1.RunOptions(trace_level=tf.compat.v1.RunOptions.FULL_TRACE)
            self.run_metadata = tf.compat.v1.RunMetadata()

        self.log_train_graph=log_train_graph
        self.train_graph_log_path=train_graph_log_path

    def initialize(self, hooks=[]):
        logger.info("Initializing trainer ...")
        init_start_time = time.time()
        if self.multi_worker_training is True:
            tf.Session.reset(self.session_target)
            self.graph = graph_copy.build_train_graph(self.org_graph, self.distribute_strategy, **self.config)
            self.session = tf.compat.v1.Session(config=self.session_config, target=self.session_target,
                                                graph=self.graph)
            self.is_chief_worker = self.distribute_strategy.extended._is_chief
        else:
            self.cross_device_ops = NcclAllReduce()
            if self._gpu_id is not None and self._gpu_num is not None:
                os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(
                    [str(i) for i in range(self._gpu_id, self._gpu_id + self._gpu_num)])
            logger.info(f"gpu_num: {self._gpu_num}")
            self.distribute_strategy = tf.distribute.MirroredStrategy(
                cross_device_ops=self.cross_device_ops,
                devices=local_devices_from_num_gpus(self._gpu_num)
            )
            self.graph = graph_copy.build_train_graph(self.org_graph, self.distribute_strategy, **self.config)
            self.session = tf.compat.v1.Session(config=self.session_config, graph=self.graph)

        self.single_graph_sess = tf.compat.v1.Session(config=self.session_config, target=self.session_target,
                                                      graph=self.org_graph)

        with self.session.graph.as_default():
            self.is_training_placeholder = get_or_create_is_training()
            self.all_tasks = self._get_all_tasks()  # get all tasks
            logger.info("all_tasks: {}".format([task.task_name for task in self.all_tasks]))
            init_ops = [tf.compat.v1.global_variables_initializer(), tf.compat.v1.local_variables_initializer(),
                        tf.compat.v1.tables_initializer()]
            logger.info(f"init variables with sess target: {self.session_target}")
            self.session.run(init_ops)
            logger.info("single_worker: initialized")
        logger.info(f"Init time cost (secs): {time.time() - init_start_time: .3f}")
        self._initialized = True

    def train(self, data, task_names=None, epochs=10, hooks=[], test_size=0.1, batch_size=256, reinitialize=False):
        if isinstance(data, tf.data.Dataset):
            if test_size > 0:
                raise ValueError("`test_size is not supported when input_list"
                                 "is a tf.data.Dataset")
            self.train_and_evaluate(data, None, task_names, epochs, hooks, batch_size, reinitialize)
        elif test_size == 0:
            self.train_and_evaluate(data, None, task_names, epochs, hooks, batch_size, reinitialize)
        else:
            train_data, test_data = split_data(data, test_size=test_size, sync=False)
            self.train_and_evaluate(train_data, test_data, task_names, epochs, hooks, batch_size, reinitialize)

    def train_and_evaluate(self, train_data, evaluate_data, task_names=None, epochs=10, hooks=[],
                           batch_size=256, reinitialize=False):
        if not self._initialized or reinitialize:
            self.initialize()
        self._train_and_evaluate(train_data, evaluate_data, task_names, epochs, hooks, batch_size)

    @replace_default_graph
    def _train_and_evaluate(self, train_data, test_data, task_names=None, epochs=10, hooks=[], batch_size=256):
        # if task_names is not specified, will use self.default_task_name as default
        tasks = self._filter_task(task_names)
        logger.info(f"tasks: {[task.task_name for task in tasks]}")
        logger.info(f"loss: {tasks[0].loss}, loss_list: {tasks[0].loss_list}, task name: {tasks[0].task_name}")
        hooks = self._setup_train_hooks(hooks)
        lr_variables = [t.lr_variable for t in tasks]
        do_test = test_data is not None

        logger.info(f"do_test: {do_test}")
        logger.info("building dataset ...")
        if not isinstance(train_data, Data):
            train_data = Data(train_data, mode="train", batch_size=batch_size, drop_remainder=True)

        train_iterator, train_iterator_handle = self._init_dataset_iterator(train_data)
        if do_test:
            if not isinstance(test_data, Data):
                test_data = Data(test_data, mode="test", batch_size=batch_size, drop_remainder=True)
            test_iterator, test_iterator_handle = self._init_dataset_iterator(test_data)
            train_iterator_handle, test_iterator_handle = self.session.run(
                [train_iterator_handle, test_iterator_handle])
        else:
            train_iterator_handle = self.session.run(train_iterator_handle)
        for hook in hooks:
            hook.begin(self.session)
        sess = self.session

        logger.info("start training sess run ...")
        feed_dict = train_data.get_tf_dataset_feed_dict()
        train_incarnation_id, _ = self.session.run([train_iterator._incarnation_id,
                                                        train_iterator.initializer],
                                                       feed_dict=feed_dict)
        for epoch in range(epochs):

            for hook in hooks:
                hook.before_epoch(self.session, train_data, epoch)
            epoch_train_loss, epoch_train_metric = self._run_epoch(train_iterator_handle,
                                                                   train_incarnation_id,
                                                                   train_data.get_batch_size(),
                                                                   train_data.get_dataset_size(),
                                                                   tasks,
                                                                   mode="train",
                                                                   hooks=hooks,
                                                                   session=sess)
            if do_test:
                test_feed_dict = test_data.get_tf_dataset_feed_dict()
                test_incarnation_id, _ = self.session.run([
                                                           test_iterator._incarnation_id,
                                                           test_iterator.initializer
                                                          ],
                                                          feed_dict=test_feed_dict)
                epoch_test_loss, epoch_test_metric = self._run_epoch(test_iterator_handle,
                                                                     test_incarnation_id,
                                                                     test_data.get_batch_size(),
                                                                     test_data.get_dataset_size(),
                                                                     tasks,
                                                                     mode="test",
                                                                     session=sess)

            # FIXME： hack一下，暂时不理会多任务
            extras = {
                "train_loss": {k.task_name: v for (k, v) in epoch_train_loss.items()}
                if len(tasks) > 1 else [epoch_train_loss[tasks[0]]],
                "train_metric": {k.task_name: v for (k, v) in epoch_train_metric.items()}
                if len(tasks) > 1 else [epoch_train_metric[tasks[0]]]
            }
            if do_test:
                test_extras = {
                    "validate_loss": {k.task_name: v for (k, v) in epoch_test_loss.items()}
                    if len(tasks) > 1 else [epoch_test_loss[tasks[0]]],
                    "validate_metric": {k.task_name: v for (k, v) in epoch_test_metric.items()}
                    if len(tasks) > 1 else [epoch_test_metric[tasks[0]]]
                }
                extras.update(test_extras)
            for hook in hooks:
                hook.after_epoch(self.session, epoch, extras)

            if self.save_trace:
                tl = timeline.Timeline(self.run_metadata.step_stats)
                ctf = tl.generate_chrome_trace_format()
                with open(self.trace_json_path, 'w') as f:
                    f.write(ctf)

            learning_rates = self.session.run(lr_variables)
            if self.lr_annealing and any(lr_value < self.lr_annealing_stop_value for lr_value in learning_rates):
                break

        # training end
        for hook in hooks:
            hook.end(self.session)

    def _run_epoch(self, dataset_iter_handle, incarnation_id, batch_size, data_size,
                   tasks, mode="train", hooks=[], session=None):
        batch_loss = defaultdict(list)
        batch_metric = defaultdict(list)
        data_iter_tqdm = tqdm(range(math.ceil(data_size / batch_size)), leave=False) \
            if self._is_chief() else range(math.ceil(data_size / batch_size))
        for batch_index in data_iter_tqdm:
            fetch_dict = {}
            for hook in hooks:
                request = hook.before_run(session, batch_index)
                if request is not None:
                    if request.fetches is not None:
                        fetch_dict[hook] = request.fetches

            for task in tasks:
                feed_dict = dict(zip([task.input_iter, task.input_iter_incarnation_id],
                                     [dataset_iter_handle, incarnation_id]))
                if self.is_training_placeholder is not None:
                    feed_dict[self.is_training_placeholder] = mode == "train"
                if mode == "train":
                    fetches = [task.train_op, task.lr_variable, task.loss, task.metric]
                    fetch_dict.update({"caller": fetches})
                    fetch_res_dict = session.run(fetch_dict,
                                                 feed_dict=feed_dict,
                                                 options=self.run_options,
                                                 run_metadata=self.run_metadata)
                    _, lr_value, loss, metric = fetch_res_dict["caller"]
                else:  # mode == "test"
                    fetches = [task.lr_variable, task.loss, task.metric]
                    fetch_dict.update({"caller": fetches})
                    fetch_res_dict = session.run(fetch_dict,
                                                 feed_dict=feed_dict,
                                                 options=self.run_options,
                                                 run_metadata=self.run_metadata)
                    lr_value, loss, metric = fetch_res_dict["caller"]
                avg_loss = np.mean(loss)
                batch_loss[task].append(avg_loss * batch_size)
                avg_metric = np.mean(metric)
                batch_metric[task].append(avg_metric * batch_size)
                if self._is_chief():
                    data_iter_tqdm.set_description_str("task:{}, lr:{:.4e}, loss:{:.4f}, metric:{:.4f}".format(
                        task.task_name, lr_value, avg_loss, avg_metric))
            for hook in hooks:
                if hook in fetch_res_dict:
                    if hasattr(hook, "fetch_res"):
                        hook.fetch_res.append(fetch_res_dict[hook])
                    else:
                        hook.fetch_res = [fetch_res_dict[hook]]
                hook.after_run(session, batch_index)

            if batch_index == 10:
                if self.save_trace:
                    tl = timeline.Timeline(self.run_metadata.step_stats)
                    ctf = tl.generate_chrome_trace_format()
                    with open(self.trace_json_path, 'w') as f:
                        f.write(ctf)

        epoch_loss = dict((k, np.array(v).sum() / data_size) for (k, v) in batch_loss.items())
        epoch_metric = dict((k, np.array(v).sum() / data_size) for (k, v) in batch_metric.items())
        return epoch_loss, epoch_metric

    def predict(self, data, task_names=None, output_indexes=None, hooks=[], batch_size=256):
        test_data = Data(data, mode="test", batch_size=batch_size, drop_remainder=False)
        tasks = self._filter_task(task_names)
        test_iterator = test_data.create_iterator(batch_size=batch_size)
        batch_output = defaultdict(list)
        data_size = test_data.get_dataset_size()
        data_iter_tqdm = tqdm(range(math.ceil(data_size / batch_size)), leave=False) \
            if self._is_chief() else range(math.ceil(data_size / batch_size))
        replica_num = self.distribute_strategy.extended._device_map.num_replicas_in_graph
        # only use first replica for inference
        task_input_num = {task: len(task.inputs) // replica_num for task in tasks}
        task_output_num = {task: len(task.outputs) // replica_num for task in tasks}
        task_input_tensors = {task: [task.inputs[i * replica_num] for i in range(task_input_num[task])] for task in
                              tasks}
        task_output_tensors = {task: [task.outputs[i * replica_num] for i in range(task_output_num[task])] for task in
                               tasks}
        logger.info(f"task_input_tensors: {task_input_tensors}")
        logger.info(f"task_output_tensors: {task_output_tensors}")
        for batch_index in data_iter_tqdm:
            for task in tasks:
                input_tensors = task_input_tensors[task]
                output_tensors = task_output_tensors[task]
                _, batch_inputs = next(test_iterator)
                feed_dict = dict(zip(input_tensors, batch_inputs))
                if self.is_training_placeholder is not None:
                    feed_dict[self.is_training_placeholder] = False
                outputs = self.session.run(output_tensors, feed_dict=feed_dict)
                for i in range(task_output_num[task]):
                    if len(batch_output[task]) < i + 1:
                        batch_output[task].append([])
                    batch_output[task][i].append(outputs[i])
        for task in tasks:
            for i in range(task_output_num[task]):
                batch_output[task][i] = np.vstack(batch_output[task][i])

        return batch_output

    def evaluate(self, test_data, task_names=None, hooks=[], batch_size=256):
        if not isinstance(test_data, Data):
            test_data = Data(test_data, mode="test", batch_size=batch_size, drop_remainder=True)
        tasks = self._filter_task(task_names)
        test_iterator, test_iterator_handle = self._init_dataset_iterator(test_data)
        test_iterator_handle = self.session.run(test_iterator_handle)
        test_incarnation_id, _ = self.session.run([test_iterator._incarnation_id,
                                                   test_iterator.initializer],
                                                  feed_dict=test_data.get_feed_dict())
        test_loss, test_metric = self._run_epoch(test_iterator_handle,
                                                 test_incarnation_id,
                                                 test_data.get_batch_size(),
                                                 test_data.get_dataset_size(),
                                                 tasks,
                                                 mode="test",
                                                 session=self.session)
        return test_loss, test_metric

    def _setup_train_hooks(self, org_hooks=[]):
        # setup train hook
        hooks = [hook for hook in org_hooks]
        if self._is_chief():
            hooks += [CheckpointHook(self.model_output_dir, self.model_name, defer_build=True)]
            hooks += [TrainInfoPrintHook()]
        return hooks

    def _is_chief(self):
        return not self.multi_worker_training or self.is_chief_worker

    @replace_default_graph
    def _init_dataset_iterator(self, data):
        with self.distribute_strategy.scope():
            dataset = data.to_tf_dataset()
            dist_dataset = self.distribute_strategy.experimental_distribute_dataset(dataset)
            iterator = dist_dataset.make_initializable_iterator()
            single_worker_iterator = iterator.get_iterator(iterator._input_workers.worker_devices[0])
            return single_worker_iterator._iterator, multi_device_iterator_to_string_handle(
                single_worker_iterator._iterator._multi_device_iterator_resource)

    def _get_single_graph_dump_path(self, epoch=None):
        if epoch is None:
            return os.path.join(self.model_output_dir, "single_graph", "{}.ckpt".format(self.model_name))
        else:
            return os.path.join(self.model_output_dir, "single_graph", "{}-epoch{}.ckpt".format(self.model_name, epoch))

    def dump_multi_replica_checkpoint(self, model_path, saver=None):
        """导出多replica对应的checkpoint"""
        # TODO: fix the hacky code
        if saver is None:
            saver = tf.compat.v1.train.Saver()
        saver._max_to_keep = 0
        saver.saver_def.max_to_keep = 0
        directory = os.path.dirname(model_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        save_path = saver.save(self.session, model_path)
        logger.info("Multi-replica model checkpoint saved in file: {}".format(save_path))

    def dump_checkpoint(self, model_path=None):
        """导出多repilca对应的checkpoint和原始单图对应的checkpoint"""
        # 完整的graph的checkpoint保存在原来的model_path指定的路径
        saver = tf.compat.v1.train.Saver()
        if model_path is None:
            model_path = self._get_dump_path()
            single_model_path = self._get_single_graph_dump_path()
        else:
            single_model_path = os.path.join(os.path.dirname(model_path), "single_graph", os.path.basename(model_path))
        # 保存多副本的图
        self.dump_multi_replica_checkpoint(model_path, saver)
        # 保存单图
        self.load_full_ckpt_to_single_graph(model_path)
        with self.org_graph.as_default():
            saver.save(self.single_graph_sess, single_model_path)

    def export_single_graph_def(self, path):
        """导出copy前单图的graph def"""
        graphdef_inf = tf.graph_util.remove_training_nodes(self.org_graph.as_graph_def())
        with open(path, 'w') as f:
            f.write(str(graphdef_inf))

    def _filter_nodes(self, nodes, index=None):
        if index is None:
            return nodes
        if not isinstance(index, list):
            index = [index]
        nodes = [nodes[idx] for idx in index]
        return nodes

    def load_full_ckpt_to_single_graph(self, model_path=None):
        """加载多replica的checkpoint的参数到单图"""
        if model_path is None:
            model_path = self._get_dump_path()
        with self.org_graph.as_default():
            tvars = tf.trainable_variables()
            (assignment_map, _) = self.get_assignment_map_from_checkpoint(tvars, model_path)
            logger.info(f"Restore {len(assignment_map)} vars from checkpoint.")
            tf.train.init_from_checkpoint(model_path, assignment_map)
            self.single_graph_sess.run(tf.compat.v1.global_variables_initializer())

    def dump_model(self, serving_dir, model_version, task_name="default",
                   input_index=None, output_index=None, clear_devices=True,
                   multi_replica_ckpt_path="", input_nodes=None, output_nodes=None):
        """导出单图模型为SavedModel"""
        if multi_replica_ckpt_path != "":
            model_path = multi_replica_ckpt_path
        else:
            model_path = os.path.join(serving_dir, "tmp_multi_replica.ckpt")
            self.dump_multi_replica_checkpoint(model_path)
        self.load_full_ckpt_to_single_graph(model_path)

        if not input_nodes:
            org_inputs = get_from_task_collection(task_name, tf.compat.v1.GraphKeys.INPUTS, self.org_graph)
            input_nodes = self._filter_nodes(org_inputs, input_index)
        if not output_nodes:
            org_outputs = get_from_task_collection(task_name, tf.compat.v1.GraphKeys.OUTPUTS, self.org_graph)
            output_nodes = self._filter_nodes(org_outputs, output_index)

        export_path = os.path.join(serving_dir, str(model_version))
        legacy_init_op = tf.group(
            tf.compat.v1.tables_initializer(), name="legacy_init_op")
        prediction_signature = (
            tf.compat.v1.saved_model.signature_def_utils.build_signature_def(
                inputs=self._build_dict("input", input_nodes),
                outputs=self._build_dict("output", output_nodes),
                method_name=tf.saved_model.PREDICT_METHOD_NAME))
        builder = tf.compat.v1.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            sess=self.single_graph_sess,
            tags=[tf.saved_model.tag_constants.SERVING],
            clear_devices=clear_devices,
            signature_def_map={
                tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:
                    prediction_signature
            },
            main_op=legacy_init_op
            # legacy_init_op=legacy_init_op
        )
        builder.save()

    def export_freeze_graph(self, graph_dir, model_version, task_name="default",
                            input_index=None, output_index=0, clear_devices=True,
                            as_text=False, export_mata_graph=True, multi_replica_ckpt_path="",
                            input_nodes=None, output_nodes=None):
        """导出单图模型为pb"""

        if multi_replica_ckpt_path != "":
            model_path = multi_replica_ckpt_path
        else:
            model_path = os.path.join(graph_dir, "tmp_multi_replica.ckpt")
            self.dump_multi_replica_checkpoint(model_path)
        self.load_full_ckpt_to_single_graph(model_path)

        with self.org_graph.as_default():
            export_path = os.path.join(graph_dir, str(model_version), "frozen.pb")
            if not input_nodes:
                org_inputs = get_from_task_collection(task_name, tf.compat.v1.GraphKeys.INPUTS, self.org_graph)
                input_nodes = self._filter_nodes(org_inputs, input_index)
            if not output_nodes:
                org_outputs = get_from_task_collection(task_name, tf.compat.v1.GraphKeys.OUTPUTS, self.org_graph)
                output_nodes = self._filter_nodes(org_outputs, output_index)
            self.org_graph.clear_collection(tf.compat.v1.GraphKeys.INPUT_DICT)
            for node in input_nodes:
                self.org_graph.add_to_collection(tf.compat.v1.GraphKeys.INPUT_DICT, node)
            self.org_graph.clear_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)
            for node in output_nodes:
                self.org_graph.add_to_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT, node)

            OUTPUT_NODE = [node.op.name for node in output_nodes]
            table_init_op = self.org_graph.get_collection(tf.compat.v1.GraphKeys.TABLE_INITIALIZERS)
            for op in table_init_op:
                OUTPUT_NODE.append(op.name)
            graph_def = self.org_graph.as_graph_def()
            # tf.graph_util.remove_training_nodes(graphdef_def.as_graph_def())
            graphdef_frozen = tf.compat.v1.graph_util.convert_variables_to_constants(
                self.single_graph_sess, graph_def, OUTPUT_NODE)
            if export_mata_graph:
                tf.compat.v1.train.export_meta_graph(
                    filename=export_path, graph_def=graphdef_frozen,
                    collection_list=[
                        tf.compat.v1.GraphKeys.TABLE_INITIALIZERS,
                        tf.compat.v1.GraphKeys.INPUT_DICT,
                        tf.compat.v1.GraphKeys.OUTPUT_DICT],
                    as_text=as_text,
                    clear_devices=clear_devices)
            else:
                if not os.path.isdir(os.path.join(graph_dir, str(model_version))):
                    os.makedirs(os.path.join(graph_dir, str(model_version)))
                tf.train.write_graph(graphdef_frozen, './',
                                     export_path, as_text=as_text)

    def load_multi_replica_checkpoint(self, model_path):
        with self.graph.as_default():
            saver = tf.compat.v1.train.Saver()
            saver.restore(self.session, model_path)

    def load_single_graph_checkpoint(self, model_path):
        logger.info(f"Reload single graph from {model_path}")
        #with self.org_graph.as_default():
        #    saver = tf.compat.v1.train.Saver()
        #    saver.restore(self.single_graph_sess, model_path)
        with self.graph.as_default():
            tvars = tf.trainable_variables()
            # print(f"tvars: {tvars}")
            (assignment_map, _) = self.get_assignment_map_from_checkpoint(tvars, model_path)
            logger.info(f"Restore {len(assignment_map)} vars from checkpoint.")
            tf.train.init_from_checkpoint(model_path, assignment_map)
            self.session.run(tf.compat.v1.global_variables_initializer())

    def restore_meta_graph(self, path, import_scope=None):
        with self.org_graph.as_default():
            tf.train.import_meta_graph(path, clear_devices=True, import_scope=import_scope)

    def restore_checkpoint_from_output(self, model_path=None):
        raise AttributeError(f"restore_checkpoint_from_output is not available in {self.__class__.__name__},"
                             f" please use load_multi_replica_checkpoint or load_single_graph_checkpoint instead!")
