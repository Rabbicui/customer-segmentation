import sys

#sys.path.insert(0,'..')
import os
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))
from rcalgo.tf.tfmodels.rnnlm import *
from tftools.tf_float_type import get_default_float_type
from tensorflow.contrib.legacy_seq2seq.python.ops import *
from tensorflow.contrib.rnn.python.ops.core_rnn_cell import *
from tensorflow.contrib.legacy_seq2seq.python.ops.seq2seq import *


class BasicSeq2SeqModel(RNNLMModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(BasicSeq2SeqModel, self).__init__(config, graph, word_dict)
        self.output_maxlen = config.output_maxlen
        self.output_hidden_size = config.output_hidden_size if hasattr(config,'output_hidden_size') else self.hidden_size
        self.output_keep_prob = config.output_keep_prob if hasattr(config,'output_keep_prob') else self.keep_prob
        self.output_num_layers = config.output_num_layers if hasattr(config,'output_num_layers') else self.num_layers
        self.num_decoder_symbols = config.num_decoder_symbols if hasattr(config,'num_decoder_symbols') else self.nb_words
        self.target_word_dict = target_word_dict if word_dict is None else word_dict
        if self.raw_text and self.target_word_dict is not None:
            self.target_word_table, self.num_decoder_symbols = self._init_word_table(self.target_word_dict)
        else:
            self.target_word_table = None

    def _get_target_text_parameters(self, expand_input=False):
        return self.target_word_table, self.output_maxlen, self.num_decoder_symbols

    def build_input(self, expand_input=False):
        super(BasicSeq2SeqModel,self).build_input(expand_input)

    def build_input_sequence(self, gpu_id=0):
        super(BasicSeq2SeqModel,self).build_input_sequence(gpu_id)

    def build_output(self, expand_input=False, key='target'):
        self.split_targets, self.split_targets_seqLengths = self.build_text_input(expand_input=expand_input,key=key)

    def _build_rnn_decoder(self):
        cell = self.build_cell(self.hidden_size, self.keep_prob, self.num_layers)
        return tf.keras.layers.RNN(cell, return_state=True, return_sequences=True,
                                         stateful=False, dynamic=False)

    def build_output_sequence(self, gpu_id=0):
        target_input = tf.reshape(tf.tile(self.output_list[gpu_id],[1,self.output_maxlen]),
                                  [-1,self.output_maxlen,self.hidden_size])
        if gpu_id == 0:
            self.decoder = self._build_rnn_decoder()
        with get_new_variable_scope('rnn_lstm_decoder') as rnn_scope:
            self.state_list[gpu_id], _ = self.build_rnn_sequence(self.decoder,
                                                                 target_input,
                                                                 self.split_targets_seqLengths[gpu_id],
                                                                 self.split_init_state[gpu_id],
                                                                 self.output_maxlen)

    @replace_default_graph
    def build_model(self, task=None, accK=1, nb_class=None):
        self.build_input()
        self.build_output()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    reuse = (idx!=0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_input_sequence(gpu_id=idx)
                        self.build_output_sequence(gpu_id=idx)
                        self.build_sequence_prediction(gpu_id=idx, accK=accK, nb_class=self.num_decoder_symbols)
        self._dump_rnn_output()
        self._add_to_graph_outputs(self.prediction_results)


class Seq2SeqModel(BasicSeq2SeqModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(Seq2SeqModel, self).__init__(config, graph, word_dict, target_word_dict)
        self.go_value = self.nb_words + 1

    def build_output(self, expand_input=False, key='target'):
        super(Seq2SeqModel, self).build_output(expand_input=expand_input,key=key)
        with tf.name_scope('decode_input'):
            decoder_start_token = tf.ones_like(self.split_targets[0][:,0:1], dtype=tf.int64) * self.go_value
            self.split_decoder_inputs_train = [tf.concat([decoder_start_token, targets[:,0:-1]], axis=1) for targets in self.split_targets]

    def rnn_decoder(self, gpu_id, feed_previous=True):
        with tf.compat.v1.variable_scope('decoder', reuse=tf.compat.v1.AUTO_REUSE) as scope:
            return embedding_rnn_decoder(decoder_inputs=tf.unstack(self.split_decoder_inputs_train[gpu_id],axis=1),
                                     initial_state=self.rnn_output_list[gpu_id],
                                     cell=self.dec_cell,
                                     num_symbols=self.go_value,
                                     embedding_size=self.embedding_size,
                                     feed_previous=feed_previous,
                                     update_embedding_for_previous=False)

    def build_output_sequence(self, gpu_id=0, reuse=None):
        with get_new_variable_scope('rnn_lstm_decoder') as rnn_scope:
            self.dec_cell = self.build_cell(self.output_hidden_size, self.output_keep_prob,
                                            self.num_layers, use_old_version=True)
            #正常情况下应该根据training设置feed_previous，然后用tf.cond；目测有bug；
            #考虑tf.contrib未来基本不维护，仅仅fix问题
            self.dec_states, _ = self.rnn_decoder(gpu_id)
            self.state_list[gpu_id] = tf.transpose(tf.stack(self.dec_states), [1,0,2])


class AttentionSeq2SeqModel(Seq2SeqModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(AttentionSeq2SeqModel, self).__init__(config, graph, word_dict, target_word_dict)

    def rnn_decoder(self, gpu_id, feed_previous=True):
        with tf.compat.v1.variable_scope('decoder', reuse=tf.compat.v1.AUTO_REUSE) as scope:
            return embedding_attention_decoder(decoder_inputs=tf.unstack(self.split_decoder_inputs_train[gpu_id],axis=1),
                                               initial_state=self.rnn_output_list[gpu_id],
                                               attention_states=self.state_list[gpu_id],
                                               cell=self.dec_cell,
                                               num_symbols=self.go_value,
                                               embedding_size=self.embedding_size,
                                               feed_previous=feed_previous,
                                               update_embedding_for_previous=False)

