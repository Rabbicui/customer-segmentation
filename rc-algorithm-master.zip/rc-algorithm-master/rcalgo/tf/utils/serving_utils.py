import tensorflow as tf
import collections
import re
from rcalgo.tf.utils.logging import logger


def load_freeze_graph(pb_path):
    gpu_options = tf.compat.v1.GPUOptions(allow_growth=True)
    config = tf.compat.v1.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True)
    session = tf.compat.v1.Session(config=config, graph=tf.Graph())
    with session.graph.as_default():
        tf.compat.v1.train.import_meta_graph(pb_path)
        session.run(tf.compat.v1.tables_initializer())
    return session


def load_from_ckpt(ckpt_path):
    gpu_options = tf.compat.v1.GPUOptions(allow_growth=True)
    config = tf.compat.v1.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True)
    session = tf.compat.v1.Session(config=config, graph=tf.Graph())
    with session.graph.as_default():
        saver = tf.compat.v1.train.import_meta_graph("{}.ckpt.meta".format(ckpt_path), clear_devices=True)
        saver.restore(session, "{}.ckpt".format(ckpt_path))
        session.run(tf.compat.v1.tables_initializer())
    return session


def infer_once(sess, input_vals):
    graph = sess.graph
    inputs = graph.get_collection(tf.compat.v1.GraphKeys.INPUT_DICT)
    outputs = graph.get_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)
    feed_dict = dict(zip(inputs, input_vals))
    return sess.run(outputs, feed_dict=feed_dict)


def predict_by_ckpt(sess, input_vals):
    graph = sess.graph
    inputs = graph.get_collection('default_inputs')
    outputs = graph.get_collection('default_outputs')
    feed_dict = dict(zip(inputs, input_vals))
    return sess.run(outputs, feed_dict=feed_dict)


def add_prefix_to_ckpt(add_prefix, org_ckpt, new_ckpt):
    with tf.Graph().as_default():
        for var_name, _ in tf.contrib.framework.list_variables(org_ckpt):
            # Load the variable
            var = tf.contrib.framework.load_variable(org_ckpt, var_name)
            new_name = add_prefix + var_name
            new_var = tf.Variable(var, name=new_name)
        saver = tf.train.Saver()
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            saver.save(sess, new_ckpt)


def get_assignment_map_from_checkpoint(to_all_vars, init_checkpoint, name_map_func=None, verbose=0):
        """Compute the union of the current variables and checkpoint variables."""
        initialized_variable_names = {}
        graph_name_to_variable = collections.OrderedDict()
        for var in to_all_vars:
            graph_var_name = var.name
            m = re.match("^(.*):\\d+$", graph_var_name)
            if m is not None:
                name = m.group(1)
            graph_name_to_variable[name] = var
        if verbose:
            logger.info(f"graph_name_to_variable: {graph_name_to_variable}")

        init_vars = tf.train.list_variables(init_checkpoint)
        if verbose:
            logger.info(f"init_vars : {init_vars} from ckpt: {init_checkpoint}")

        assignment_map = collections.OrderedDict()
        for x in init_vars:
            (ckpt_var_name, ckpt_var) = (x[0], x[1])
            if name_map_func is None:
                graph_var_name = ckpt_var_name
            else:
                graph_var_name = name_map_func(ckpt_var_name)
            if graph_var_name not in graph_name_to_variable:
                if verbose:
                    logger.info(f'name not used: {ckpt_var_name}')
                continue
            assignment_map[ckpt_var_name] = graph_name_to_variable[graph_var_name]
            initialized_variable_names[graph_var_name] = 1
            initialized_variable_names[graph_var_name + ":0"] = 1

        return assignment_map, initialized_variable_names


def load_checkpoint_with_name_map(graph, session, model_path, name_map_func=None, verbose=0):
    """
    name_map_func: from ckpt_name (from) to graph_name (to) func
    """
    print(f"Reload graph from {model_path}")
    with graph.as_default():
        to_all_vars = tf.trainable_variables()
        if verbose:
            logger.info(f"to_all_vars: {to_all_vars}")
        (assignment_map, _) = get_assignment_map_from_checkpoint(to_all_vars, model_path,
                                                                 name_map_func, verbose)
        if verbose:
            logger.info(f"assignment_map: {assignment_map} from_var_name -> to_var")
        logger.info(f"Restore {len(assignment_map)} vars from checkpoint.")
        tf.train.init_from_checkpoint(model_path, assignment_map)
        session.run(tf.compat.v1.global_variables_initializer())

