import os
import sys
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../"))

from rcalgo.tf.tfmodels.image.deprecated.image_model import ImageModel
from rcalgo.tf.tfmodels.image.self_supervised import resnet_model
from rcalgo.tf.tfmodels.image.utils.aug_util import *
from rcalgo.tf.tfmodels.image.self_supervised.lamb_bak import LAMBOptimizer
from tftools.tf_layer import my_full_connected
from tftools.tf_func import shape_list
from tftools.tf_func import my_compute_grad
from tftools.tf_func import replace_default_graph
from rcalgo.tf.tftraining.train_data import *

DEFAULT_SIM_CONFIG = dict()
DEFAULT_SIM_CONFIG['resnet_size'] = 50
DEFAULT_SIM_CONFIG['projection_size'] = 128


def _parse(x):
    raw_bytes = tf.io.read_file(x)
    image = tf.io.decode_image(raw_bytes, channels=3)
    image.set_shape([None, None, 3])
    image = tf.image.resize(image, [224, 224])
    xs = []
    for _ in range(2):
        xs.append(preprocess_image(image, 224, 224, True, True, True))
    # create two aug and concat by last dim
    return tf.concat(xs, -1)


class ImageTrainingData(TrainingData):
    def __init__(self, datasets, batch_size, test_size, default_random_seed=None):
        super(ImageTrainingData, self).__init__(datasets, batch_size, test_size, default_random_seed)

    def to_tf_dataset(self, mode="train"):
        if mode == "train":
            train_data = tuple(tf.compat.v1.placeholder(tf.string,
                                                        tuple(d * (1 - self.test_size)
                                                              if idx2 == 0 else d
                                                              for idx2, d in
                                                              enumerate(dataset.shape)),
                                                        name='train_col_{}'.format(idx))
                               for idx, dataset in enumerate(self.datasets))
            ds = tf.data.Dataset.from_tensor_slices(train_data)
            # the shuffle must come before the map func
            ds = ds.shuffle(self.get_dataset_size(mode="train"))
            # data data aug
            ds = ds.map(_parse, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            ds = ds.batch(self.batch_size)
            ds = ds.prefetch(buffer_size=10)
            return ds
        else:
            test_data = tuple(tf.compat.v1.placeholder(tf.string,
                                                       tuple(d * self.test_size
                                                             if idx2 == 0 else d
                                                             for idx2, d in
                                                             enumerate(dataset.shape)),
                                                       name='test_col_{}'.format(idx))
                              for idx, dataset in enumerate(self.datasets))
            ds = tf.data.Dataset.from_tensor_slices(test_data)
            # the shuffle must come before the map func
            ds = ds.shuffle(self.get_dataset_size(mode="test"))
            ds = ds.map(_parse)
            ds = ds.batch(self.batch_size)
            ds = ds.prefetch(buffer_size=10)
            return ds


class Sim2Clr(ImageModel):

    def __init__(self, config, graph, sim_config=None):
        super(Sim2Clr, self).__init__(config, graph)
        self.image_model = None
        self.init_std = config.init_std
        self.sim_config = sim_config
        self.p_coef = config.p_coef
        self.num_train_steps = config.total_update
        self.num_warmup_steps = int(config.learning_rate_warmup * self.num_train_steps)
        self.weight_decay = config.p_coef
        self.learning_rate = config.learning_rate
        self.build_opt()
        self.label = self.build_label(sim_config.get('split_loss', True))

    @replace_default_graph
    def build_label(self, split_loss):
        batch = int(self.batch_size / self.gpu_num)
        # each split batch will create 4 units (2 label and 2 zero)
        # if use the merge loss there will be gpu_num*gpu_num*batch
        def zero_unit(batch):
            return tf.zeros([batch, batch])
        def label_unit(batch):
            return tf.matrix_set_diag(tf.zeros([batch, batch]), tf.ones(batch))
        def label_block(batch):
            label1 = zero_unit(batch)
            label2 = label_unit(batch)
            label3 = label_unit(batch)
            label4 = zero_unit(batch)
            # here we assume that the label of same embedding (the diag of similarity matrix) are 0
            # which can eliminate the affect
            label_top = tf.concat([label1, label2], axis=1)
            label_buttom = tf.concat([label3, label4], axis=1)
            return tf.concat([label_top, label_buttom], axis=0)

        if split_loss:
            # labels 2N * 2N  is hard to build directly split into four parts
            return label_block(batch)
        else:
            # build the merge loss labels
            # the whole label matrix is built from gpu_num * gpu_num block
            rows = []
            for i in range(self.gpu_num):
                row = []
                for j in range(self.gpu_num):
                    if i == j:
                        # build row
                        row.append(label_block(batch))
                    else:
                        row.append(tf.zeros(2 * batch, 2 * batch))
                row.append(tf.concat(row, axis=1))
            return tf.concat(rows, axis=0)

    @replace_default_graph
    def _build_global_setting(self, task=None):
        with tf.name_scope('global'):
            # the keras optimizer use the default global step
            self.global_step = tf.compat.v1.train.get_or_create_global_step()

    @replace_default_graph
    def build_opt(self):
        # use LARS optimizer
        # the learning rate is 0.3 × BatchSize / 256
        # and linear warmup for first 10 epochs and decay with cosine decay
        learning_rate = self.lr[self.default_task_name]

        # Implements linear decay of the learning rate.
        learning_rate = tf.train.polynomial_decay(
            learning_rate,
            self.global_step,
            self.num_train_steps,
            end_learning_rate=0.0,
            power=1.0,
            cycle=False)

        # Implements linear warmup. I.e., if global_step < num_warmup_steps, the
        # learning rate will be `global_step/num_warmup_steps * init_lr`.
        if self.num_warmup_steps:
            global_steps_int = tf.cast(self.global_step, tf.int32)
            warmup_steps_int = tf.constant(self.num_warmup_steps, dtype=tf.int32)

            global_steps_float = tf.cast(global_steps_int, tf.float32)
            warmup_steps_float = tf.cast(warmup_steps_int, tf.float32)

            warmup_percent_done = global_steps_float / warmup_steps_float
            warmup_learning_rate = self.learning_rate * warmup_percent_done

            is_warmup = tf.cast(global_steps_int < warmup_steps_int, tf.float32)
            learning_rate = (
                    (1.0 - is_warmup) * learning_rate + is_warmup * warmup_learning_rate)

        # It is recommended that you use this optimizer for fine tuning, since this
        # is how the model was trained (note that the Adam m/v variables are NOT
        # loaded from init_checkpoint.)
        optimizer = LAMBOptimizer(
            learning_rate=learning_rate,
            weight_decay_rate=self.weight_decay,
            beta_1=0.9,
            beta_2=0.999,
            epsilon=1e-6,
            exclude_from_weight_decay=["LayerNorm", "layer_norm", "bias", "batch_norm"])
        self.opt[self.default_task_name] = optimizer

    def _build_image_input2(self):
        # the train and inference is not compatible
        input_iter_handle = tf.compat.v1.placeholder_with_default('', shape=None,
                                                                  name='{}_input_iter'.format(
                                                                      'input'))
        self._add_to_graph_input_iter(input_iter_handle)
        self.batch_input = tf.cond(tf.equal(input_iter_handle, ''),
                                   true_fn=lambda: tf.zeros([1, 1, 1, 6]),
                                   false_fn=lambda: tf.compat.v1.data.Iterator.from_string_handle(
                                       input_iter_handle,
                                       tf.float32)
                                   .get_next())

        np_inputs = tf.compat.v1.placeholder_with_default(self.batch_input, shape=[None, None, None,
                                                                                   self._channel_num * 2],
                                                          name='images')

        self.train_inputs = tf.split(np_inputs, self.gpu_num)
        # we build the input seperately for inference !
        self.infer_inputs = tf.compat.v1.placeholder_with_default([ss], [None],
                                                                  name='image_byte_placeholder')
        self._add_to_graph_input_dict(self.infer_inputs)

    def build_input(self):
        ## SimClr is self-supervised learning model, no label used
        self._build_image_input2()
        with tf.name_scope('nets'):
            self.l2_embs = [None for _ in range(self.gpu_num)]

    def _get_block_sizes(self, resnet_size):
        choices = {
            18: [2, 2, 2, 2],
            34: [3, 4, 6, 3],
            50: [3, 4, 6, 3],
            101: [3, 4, 23, 3],
            152: [3, 8, 36, 3],
            200: [3, 24, 36, 3]
        }

        try:
            return choices[resnet_size]
        except KeyError:
            err = ('Could not find layers for selected Resnet size.\n'
                   'Size received: {}; sizes allowed: {}.'.format(
                resnet_size, choices.keys()))
            raise ValueError(err)

    def build_basic_image_model(self):
        resnet_size = self.sim_config.get('resnet_size', 50)
        # use the default ImageNet config here
        self.image_model = resnet_model.Model(resnet_size=resnet_size,
                                              bottleneck=True,
                                              num_classes=2,
                                              num_filters=64,
                                              kernel_size=7,
                                              conv_stride=2,
                                              first_pool_size=3,
                                              first_pool_stride=2,
                                              block_sizes=self._get_block_sizes(resnet_size),
                                              block_strides=[1, 2, 2, 2],
                                              resnet_version=resnet_model.DEFAULT_VERSION,
                                              data_format='channels_first',
                                              dtype=resnet_model.DEFAULT_DTYPE)

    def _nt_xent_loss(self, l2_embeddings, temp=0.1, reg_lambda=0.002):
        label_without_diag = self.label
        batch = tf.cast(shape_list(l2_embeddings)[0], tf.int32)
        def version1(l2_embeddings, label):
            # normalize the embeddings and ignore the diag (the same embeddings)
            # this should be same as the paper
            similarity_matrix = tf.matmul(l2_embeddings, l2_embeddings, transpose_a=False, transpose_b=True)
            similarity_matrix = similarity_matrix / temp
            similarity_matrix = tf.matrix_set_diag(similarity_matrix, tf.zeros(batch) - 100000)
            # build labels
            # Add the softmax loss.
            xent_loss = tf.nn.softmax_cross_entropy_with_logits(
                logits=similarity_matrix, labels=label)
            xent_loss = tf.reduce_mean(xent_loss, name='xentropy-v1')
            return xent_loss, similarity_matrix

        return version1(l2_embeddings, label_without_diag)

    def build_classification_model(self, gpu_id=0):
        if gpu_id == 0:
            self.build_basic_image_model()

            def decode(raw_bytes):
                image = tf.io.decode_image(raw_bytes, channels=self._channel_num)
                image.set_shape([None, None, self._channel_num])
                image = tf.image.resize(image, [self._resize_to, self._resize_to])
                image = preprocess_image(image, 224, 224, False, False, True)
                return image

            infer_images = tf.map_fn(decode, self.infer_inputs, dtype=tf.float32)

            with tf.variable_scope('resnet_model', reuse=False) as scope:
                tmp = self.image_model(infer_images, self.training, classify=False)
                tmp = tf.stop_gradient(tmp)
                self.output_dict['image_embedding'] = tmp

        # split the aug1 and aug2
        def split_and_blur(features):
            # do batch blur
            features_list = tf.split(features, 2, -1)
            features_list = batch_random_blur(features_list, 224, 224)
            return tf.concat(features_list, 0)  # (2 * bsz, h, w, c)

        features = split_and_blur(self.train_inputs[gpu_id])
        features.set_shape([None, None, None, 3])
        # inputs = tf.cond(self.training, lambda: self.data_augmentation(inputs), lambda : inputs)
        # aug1, aug2 of shape (batch, h, w, c)
        # each element of aug1 and aug2 with same index are positive samples
        # resnet 50
        # apply image model
        with tf.variable_scope('resnet_model', reuse=True) as scope:
            embeddings = self.image_model(features, self.training, classify=False)

            # apply non linear projection head
        projection_size = self.sim_config.get('projection_size', 128)
        embeddings = my_full_connected(embeddings, shape_list(embeddings)[-1], act=tf.nn.relu,
                                       init_std=.01, layer_name='non_linear_projection',
                                       weights_initializer=tf.variance_scaling_initializer(
                                           scale=2.0, mode='fan_in', distribution='normal'))
        embeddings = my_full_connected(embeddings, projection_size, act=tf.identity, init_std=.01,
                                       layer_name='linear_projection', add_bias=False)
        self.l2_embs[gpu_id] = tf.math.l2_normalize(embeddings, -1)

    def add_contrastive_loss(self, hidden1, hidden2,
                             temperature=1.0,
                             weights=1.0):
        """Compute loss for model.

        Args:
          hidden: hidden vector (`Tensor`) of shape (bsz, dim).
          hidden_norm: whether or not to use normalization on the hidden vector.
          temperature: a `floating` number for temperature scaling.
          tpu_context: context information for tpu.
          weights: a weighting number or vector.

        Returns:
          A loss scalar.
          The logits for contrastive prediction task.
          The labels for contrastive prediction task.
        """
        batch_size = tf.shape(hidden1)[0]
        hidden1_large = hidden1
        hidden2_large = hidden2
        labels = tf.one_hot(tf.range(batch_size), batch_size * 2)
        masks = tf.one_hot(tf.range(batch_size), batch_size)

        logits_aa = tf.matmul(hidden1, hidden1_large, transpose_b=True) / temperature
        logits_aa = logits_aa - masks * 1e9
        logits_bb = tf.matmul(hidden2, hidden2_large, transpose_b=True) / temperature
        logits_bb = logits_bb - masks * 1e9
        logits_ab = tf.matmul(hidden1, hidden2_large, transpose_b=True) / temperature
        logits_ba = tf.matmul(hidden2, hidden1_large, transpose_b=True) / temperature

        loss_a = tf.losses.softmax_cross_entropy(
            labels, tf.concat([logits_ab, logits_aa], 1), weights=weights)
        loss_b = tf.losses.softmax_cross_entropy(
            labels, tf.concat([logits_ba, logits_bb], 1), weights=weights)
        loss = loss_a + loss_b

        return loss, logits_ab, labels

    def build_prediction(self, gpu_id=0, num_classes=10, accK=1):
        with tf.name_scope('loss'):
            # normalized temperature-scaled cross entropy
            temp = self.sim_config.get('temperature', 0.1)
            loss, prediction = self._nt_xent_loss(l2_embeddings=self.l2_embs[gpu_id], temp=temp)
            self.output_dict['loss'] = loss
            # loss = loss + self.l2_penalty()
            grads, capped_gvs = my_compute_grad(self.opt, loss, tf.trainable_variables(),
                                                clip_type='clip_value',
                                                task=self.default_task_name,
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            label = tf.math.argmax(self.label, axis=1)
            accuracy = tf.to_float(tf.nn.in_top_k(prediction, label, k=accK))
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task=self.default_task_name)






