from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
import os


# the basic config for word embedding based model
def build_input_parse_args(parser):
    parser.add_argument('--raw-text', default=True,
                        action='store_true', help='input raw text')
    parser.add_argument('--oov-buckets', default=100, type=int,
                        help='term number in input sequence(zero mask)')
    parser.add_argument('--maxlen', default=50, type=int,
                        help='the max length of input sequence')
    parser.add_argument('--word-freq', default=2, type=int,
                        help='the minimal frequency of word dict')
    # where nb_words is zero, using len(word_dict) + oov_buckets
    parser.add_argument('--nb-words', default=0, type=int,
                        help='term number in input sequence(zero mask)')
    parser.add_argument('--embedding-size', default=200,
                        type=int, help='the dim of word embedding')
    parser.add_argument('--labels', default=1,
                        type=int, help='the second dim for input labels')
    parser.add_argument('--expand-input', default=False,
                        action='store_true', help='add sos and eos to the sentences')
    parser.add_argument('--word-level-seg', default=False,
                        action='store_true', help='word segmation, not char')


def build_rnn_parse_args(parser):
    # rnn parameters
    parser.add_argument('--num-layers', default=1, type=int,
                        help='the number of rnn layers')
    parser.add_argument('--use-cudnn-rnn', default=False,
                        action='store_true', help='using cudnn lstm accelerate')

    # rnn state init parameters
    # parser.add_argument('--state-init', default=False,
    #                    action='store_true', help='support state init of placeholder')
    parser.add_argument('--state-fc-convert', default=False,
                        action='store_true', help='using fc to convert the input state')
    parser.add_argument('--state-init-size', default=None,
                        type=int, help='the input state size')

    parser.add_argument('--fc_dropout', default=1.0,
                        type=float, help='dropout of last full connected')
    parser.add_argument('--hidden-size', default=512,
                        type=int, help='rnn hidden size')
    parser.add_argument('--keep-prob', default=1.0, type=float,
                        help='keep probability of drop out')
    parser.add_argument('--use-residual', default=False, action='store_true',
                        help='residual connection between rnn input and output')
    parser.add_argument('--sampled-softmax', default=True, action='store_true',
                        help='using sampled softmax instead of full softmax')
    parser.add_argument('--num-sampled', default=500, type=int, help='the number of sampled')

    # quasi-rnn parameters
    parser.add_argument('--conv-legnth', default=2,
                        type=int, help='the conv length of quasi rnn')
    parser.add_argument('--use-qrnn', default=False, action='store_true',
                        help='ussing quasi rnn instead of rnn')

    # for self attentive rnn
    parser.add_argument('--output-matrix-dim', default=16, type=int,
                        help='the dimension of self attentive matrix')
    parser.add_argument('--last-fc-dim', default=128, type=int,
                        help='the dimension of last full connect layer')

    # for transformer
    parser.add_argument('--n-head', default=8, type=int,
                        help='the number of heads')
    parser.add_argument('--position-type', default='pos', type=str,
                        help='position type')
    parser.add_argument('--transformer-func', default='relu', type=str,
                        help='the function string of transfomer block')
    parser.add_argument('--combine-mode', default='ADD', type=str,
                        help='the combine mode for the first multiple width conv block')
    parser.add_argument('--conv-num-filters', default=512, type=int,
                        help='the num of filters of first conv ')
    parser.add_argument('--bi-direction', default=False,
                        action='store_true', help='bi direction transformer')
    parser.add_argument('--position-info', default=False,
                        action='store_true', help='add position embedding')
    parser.add_argument('--output-reduce-size', default=0, type=int,
                        help='the reduce dimension of the seq state')
    parser.add_argument('--low-sent-scale-length', default=2, type=int,
                        help='the scale length of low boundary')
    parser.add_argument('--high-sent-scale-length', default=5, type=int,
                        help='the scale length of high boundary')

    # for decoder
    parser.add_argument('--beam-width', default=50, type=int,
                        help='the width for beam search decoder')
    parser.add_argument('--sample-decay-factor', default=5000, type=int,
                        help='the decay factor for scheduled sampling')
    # parser.add_argument('--sampling-probability', default=0.4, type=float,
    #                    help='the sample prob for helper')


def build_gan_parse_args(parser):
    # for Vanilla gan
    parser.add_argument('--input-dim', default=64,
                        type=int, help='input dim')
    parser.add_argument('--hidden-dim', default=64,
                        type=int, help='the dim for hidden layer ')
    parser.add_argument('--generator-noise-dim', default=64,
                        type=int, help='input dimension for noise vector')
    parser.add_argument('--generate-sample-size', default=10,
                        type=int, help='the sample generated')
    parser.add_argument('--generator-learning-rate', default=0.001,
                        type=float, help='the learning rate for generator')
    parser.add_argument('--discriminator-learning-rate', default=0.0001,
                        type=float, help='the learning rate for discriminator')
    parser.add_argument('--generator-train-steps', default=1,
                        type=int, help='the training steps for generator')
    parser.add_argument('--discriminator-train-steps', default=1,
                        type=int, help='the training steps for discriminator')
    parser.add_argument('--discriminator-label-smooth', default=0.25,
                        type=float, help='one-sided label smoothing for discriminator')

    # for seqgan
    parser.add_argument('--rnn-hidden-size', default=64,
                        type=int, help='the hidden state output size for decoder rnn')
    parser.add_argument('--encoder-keep-prob', default=1.0,
                        type=float, help='the keep prob for encoder output')
    parser.add_argument('--decoder-keep-prob', default=1.0,
                        type=float, help='the keep prob for decoder output')
    parser.add_argument('--g-pre-train-learning-rate', default=0.001,
                        type=float, help='the learning rate for generator used in pre train stage')
    parser.add_argument('--d-pre-train-learning-rate', default=0.0001,
                        type=float, help='the learning rate for discriminator used in pre train stage')
    parser.add_argument('--english-style', default=False, action='store_true',
                        help='whether the input sentences are english style')
    parser.add_argument('--adversarial-train-infer-strategy', default='infer_sample',
                        type=str, help='strategy used to create the infer samples for discriminator'
                                       'training, possible choice: infer_greedy, infer_sample')
    parser.add_argument('--pretrain-strategy', default='greedy',
                        type=str, help='strategy used to for MLE training, possible choice:greedy,'
                                       'schedule_sampling')
    parser.add_argument('--schedule-decay-factor', default=0.0,
                        type=float,
                        help='the sampling probability for scheduling_sampling')
    parser.add_argument('--beam-search-width', default=2,
                        type=int,
                        help='beam search width for infer')
    parser.add_argument('--layer-norm', default=False,
                        action='store_true',
                        help='whether apply layer norm to encoder and decoder')
    parser.add_argument('--input-maxlen', default=-1,
                        type=int,
                        help='the default maxlen for input')
    parser.add_argument('--target-maxlen', default=-1,
                        type=int,
                        help='the default maxlen for target')
    parser.add_argument('--input-english-style', default=False,
                        action='store_true',
                        help='whether need to add space to input')
    parser.add_argument('--encoder-embedding-size', default=32,
                        type=int,
                        help='the size of embedding for encoder')
    parser.add_argument('--decoder-embedding-size', default=32,
                        type=int,
                        help='the size of embedding for decoder')


def build_cnn_parse_args(parser):
    parser.add_argument('--mean-pooling', default=1, type=int,
                        help='using mean pooling')


def build_memory_qa_parse_args(parser):
    parser.add_argument('--linear-ratio', default=0.5,
                        type=float, help='ratio of linear nodes')
    parser.add_argument('--nhop', default=6,
                        type=int, help='the number of hop layers')
    parser.add_argument('--question-slots', default=100,
                        type=int, help='number of question slots')


def build_transformer_lm_qa_parse_args(parser):
    parser.add_argument('--fix-lm-layer', default=False,
                        action='store_true', help='whether to fix the trainable variables when to train the QA task')


#     parser.add_argument('--question-slots', default=100,
#                         type=int, help='number of question slots')

def build_test_args(parser):
    parser.add_argument('--conv-window-size', nargs="+", type=int, help='length of conv')
    parser.add_argument('--conv-number', nargs="+", type=int, help='n_filter_out. # of conv')
    parser.add_argument('--conv-pool-size', nargs="+", type=int,
                        help='pool_size. -1 means pooling over time. 0 means None')
    parser.add_argument('--fully-layer', nargs="+", type=int, help='fully connected layer, node numbers')


def build_image_parser(parser):
    parser.add_argument('--image-byte-input', default=False, action='store_true', help='whether use byte input')
    parser.add_argument('--image-channel-num', default=3,
                        type=int, help='channel num for pic')
    parser.add_argument('--image-resize-to', default=128,
                        type=int, help='resize to size')


def build_multi_modal_parser(parser):
    parser.add_argument('--prefusion-config-file', default=None,
                        type=str, help='config json file for prefusion')
    parser.add_argument('--subnet-fusion-config-file', default=None,
                        type=str, help='config json file for subnet fusion')
    parser.add_argument('--embedding-cnt', default=None,
                        type=int, help='count of embeddings')
    parser.add_argument('--embedding-sizes', default=None,
                        type=str, help='size of each embedding')
    parser.add_argument('--embedding-groups', default=None,
                        type=str, help='group of each embedding')
