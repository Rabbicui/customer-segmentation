# coding: utf-8

import os

import tensorflow as tf
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))


class KeraModelWrapper(object):
    """
    The keras (tf v1 version) need to explicitly define the inputs and outputs.
    To work around this, a new model wrapper is usually used e.g.
        model = xxx
        y, xxx = model(x)
        model = tf.keras.Model(inputs=x, outputs=y)
    The drawback of this method: the final 'model' blocks other output info like attention map or
    debug outputs
    Thus a new custom wrapper with all same usages as the original keras model is created.
    """

    def __init__(self, raw_model, inputs, outputs):
        self.raw_model = raw_model
        self.delegate = tf.keras.Model(inputs=inputs, outputs=outputs)
        self.update_ops = []

    def __call__(self, inputs, *args, **kwargs):
        return self.delegate(inputs, *args, **kwargs)

    def call_raw(self, inputs):
        """
            call this func instead of __call__  when you want to obtain all outputs
        """
        return self.raw_model(inputs)

    def compile(self, *args, **kwargs):
        self.delegate.compile(*args, **kwargs)

    def fit(self, *args, **kwargs):
        self.delegate.fit(*args, **kwargs)

    def save_weights(self, *args, **kwargs):
        self.delegate.save_weights(*args, **kwargs)

    def load_weights(self, *args, **kwargs):
        self.delegate.load_weights(*args, **kwargs)

    def get_raw_model(self):
        return self.raw_model

    def get_info_collector(self):
        # 获取模型保存的中间结果， 如attention值，或者其他一些可以用于debug的信息
        return self.raw_model._info_collector

    def add_update_ops(self, ops):
        self.update_ops += ops

    def get_update_ops(self):
        return self.update_ops


class InfoCollectLayerWrapper(tf.keras.layers.Layer):

    # To collect extra info in middle layer
    def __init__(self, collector=None, **kwargs):
        super(InfoCollectLayerWrapper, self).__init__(**kwargs)
        self.collector = collector

    def collect(self, x):
        if isinstance(x, list) or isinstance(x, tuple):
            for y in x:
                self.collector.append(y)
        else:
            self.collector.append(x)

