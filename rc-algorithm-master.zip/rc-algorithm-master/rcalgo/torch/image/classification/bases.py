import os
import time

import numpy as np
import torch

from rcalgo.torch.image.classification import lbtoolbox as lb
from rcalgo.torch.image.classification import utils
from rcalgo.torch.image.classification.dataset import mk_dataset
from rcalgo.torch.image.classification.utils import ModelWrapper


class Finetune(object):
    def __init__(self, config):
        self.config = config
        self.classes = config.get('num_classes', -1)
        if self.classes < 0:
            raise Exception('num_classes not set')
        self.eval_every = config.get('eval_every', 500)
        self.lr = config.get('lr', 0.003)
        self.logdir = config.get('logdir', './')
        self.logname = config.get('logname', 'train')

        self.logger = utils.setup_logger(self.logdir, self.logname)
        self.runner_name = 'Finetune'

        self.parallel = 'DataParallel'

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.pretrain_path = None

        self.steps_per_display = 10

    def init_model(self, *args, **kwargs):
        raise NotImplementedError()

    def create_optimizer(self, model, lr, momentum, *args, weight_decay=0, **kwargs):
        assert model, 'Must create model before create optimizer'
        optimizer = torch.optim.SGD(model.parameters(),
                                    lr=lr,
                                    momentum=momentum,
                                    weight_decay=weight_decay)
        return optimizer

    def model_parallel_wrapper(self, model, *args, dist_type=None, **kwargs):
        assert dist_type is None or dist_type in ['DataParallel', 'DistributedDataParallel'], \
            "valid dist_type values: [None, 'DataParallel', 'DistributedDataParallel']"
        if dist_type is None:
            model = model
        elif dist_type == 'DataParallel':
            model = torch.nn.DataParallel(model)
        elif dist_type == 'DistributedDataParallel':
            # model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu])
            raise NotImplementedError()
        else:
            raise ValueError()
        return model

    def build_model(self, *args, **kwargs):
        self.cri = torch.nn.CrossEntropyLoss().to(self.device)
        self.eval_cri = torch.nn.CrossEntropyLoss().to(self.device)

        self.init_model()
        self.model = self.model_parallel_wrapper(self.model, dist_type=self.parallel)
        self.model.to(self.device)

    def save_model(self, model, optimizer, step, filename, epoch, best_acc1, *args, **kwargs):
        utils.dump(model, optimizer, step, filename)
        # save tracing
        utils.script_tracing(ModelWrapper(model.module), filename, example=torch.rand([1, 3, 224, 224]))

    def new_lr(self, step, train_size, *args, **kwargs):
        return self.lr

    def new_batch(self, x, y, train_size):
        mixup = utils.get_mixup(train_size)
        mixup_l = np.random.beta(mixup, mixup) if mixup > 0 else 1

        self.mixup = mixup
        self.mixup_l = mixup_l

        # do some modification on batch
        if mixup > 0.0:
            x, y_a, y_b = utils.mixup_data(x, y, mixup_l)
            return x, (y_a, y_b)
        return x, y

    def criterion(self, logits, y):
        if self.mixup > 0.0:
            y_a, y_b = y
            c = utils.mixup_criterion(self.cri, logits, y_a, y_b, self.mixup_l)
        else:
            c = self.cri(logits, y)
        return c

    def eval_criterion(self, logits, y, *args, **kwargs):
        return self.eval_cri(logits, y)

    def build_data(self, train_data, test_data, batch_size, *args, **kwargs):
        train_set, valid_set, train_loader, valid_loader = mk_dataset(train_data, test_data, batch=batch_size)
        return train_set, valid_set, train_loader, valid_loader

    def train(self, train_data, test_data, ckpt_dir, ckpt_name, batch_size=256, total_epoch=None):
        logger = self.logger

        train_set, _, train_loader, valid_loader = self.build_data(train_data, test_data, batch_size)
        train_size = len(train_set)
        steps_one_epoch = len(train_loader)

        self.build_model()
        model, optimizer, criterion = self.model, self.optimizer, self.criterion
        model = model.to(self.device)
        model.train()
        optimizer.zero_grad()

        os.makedirs(ckpt_dir, exist_ok=True)
        savename = os.path.join(ckpt_dir, ckpt_name)

        step = 0
        epoch = 0
        max_steps = 9999999
        if total_epoch is not None:
            max_steps = total_epoch * steps_one_epoch
            logger.info(f"Starting training for epochs {total_epoch}!")
        else:
            # max steps is defined automatically
            logger.info(f"Starting training!")

        best_acc1 = -1
        if self.eval_every > steps_one_epoch or self.eval_every < 0:
            self.eval_every = steps_one_epoch

        with lb.Uninterrupt() as u:
            for x, y in utils.recycle(train_loader):
                if u.interrupted:
                    break

                # Schedule sending to GPU(s)
                x = x.to(self.device, non_blocking=True)
                y = y.to(self.device, non_blocking=True)

                # Update learning-rate, including stop training if over.
                lr = self.new_lr(step, train_size)

                if lr is None or step > max_steps:
                    break

                for param_group in optimizer.param_groups:
                    param_group["lr"] = lr

                x, y = self.new_batch(x, y, train_size)

                # compute output
                logits = model(x)
                loss = criterion(logits, y)
                # loss.backward()

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                c_num = float(loss.item())  # Also ensures a sync point.

                # print info
                if step % self.steps_per_display == 0:
                    logger.info(f"[{self.runner_name}]: epoch: {epoch} step: {step} loss={c_num:.5f}  (lr={lr:.1e}) ")
                    logger.flush()

                # Run evaluation and save the model.
                if self.eval_every and step % self.eval_every == 0:
                    acc1 = self.run_eval(model, valid_loader, self.device, logger, step)
                    is_best = acc1 > best_acc1
                    best_acc1 = max(acc1, best_acc1)
                    logger.info(f"Step {step}: current acc@1 {acc1}, best acc@1 {best_acc1}")
                    # save best checkpoint
                    if is_best:
                        self.save_model(model, optimizer, step, savename, epoch, best_acc1)

                step += 1

                if step % steps_one_epoch == 0:
                    epoch += 1

    def run_eval(self, model, data_loader, device, logger, step):
        logger.info("Running validation...")

        # to record
        batch_time = utils.AverageMeter('Time', ':6.3f')
        losses = utils.AverageMeter('Loss', ':.4e')
        top1 = utils.AverageMeter('Acc@1', ':6.2f')
        top5 = utils.AverageMeter('Acc@5', ':6.2f')
        progress = utils.ProgressMeter(len(data_loader), [batch_time, losses, top1, top5], prefix='Test: ')

        # switch to evaluate mode
        model.eval()

        with torch.no_grad():
            for i, (x, y) in enumerate(data_loader):
                end = time.time()
                x = x.to(device, non_blocking=True)
                y = y.to(device, non_blocking=True)

                # compute output, measure accuracy and record loss.
                logits = model(x)
                c = self.eval_criterion(logits, y)
                topk = (1, 5) if self.classes > 2 else (1, 2)
                acc1, acc5 = utils.accuracy(logits, y, topk=topk)

                losses.update(c.item(), x.size(0))
                top1.update(acc1[0], x.size(0))
                top5.update(acc5[0], x.size(0))

                # measure elapsed time
                batch_time.update(time.time() - end)

                if i % self.steps_per_display * 2 == 0: progress.display(i, printf=self.logger.info)

        model.train()
        logger.info(f"***validation step {step} acc@1 {top1.avg} acc@5 {top5.avg}***")
        logger.flush()
        return top1.avg
