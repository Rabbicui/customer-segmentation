import os
import sys
import collections

sys.path.append(os.path.join(os.path.abspath(
    os.path.dirname(__file__)), "../"))

from rcalgo.tf.utils.pretty_print import simplify_print
from rcalgo.tf.utils.tf_func import init_from_checkpoint, replace_default_graph
from rcalgo.tf.tftraining.train_data import *

try:
    __IPYTHON__
    from tqdm import tqdm_notebook as tqdm
except NameError:
    from tqdm import tqdm

#dafault setting:  https://github.com/tensorflow/tensorflow/blob/master/tensorflow/python/ops/lookup_ops.py#L343
FROZEN_FILE = 'frozen.pb'

class Task(object):
    def __init__(self, task_name, task_index):
        self.task_name = task_name
        self.task_index = task_index
        self.inputs = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.INPUTS))
        self.targets = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.TARGETS))
        self.outputs = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.OUTPUTS))
        self.input_iter = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.INPUT_ITER))
        self.lr_variables = self._compatible_get_collection(tf.compat.v1.GraphKeys.LR_VARIABLES)
        self.lr_annealing_variables = self._compatible_get_collection(tf.compat.v1.GraphKeys.LR_ANNEALING_VARIABLES)
        self.train_ops = self._compatible_get_collection(tf.compat.v1.GraphKeys.TRAIN_OPS)
        self.loss_list = self._compatible_get_collection(tf.compat.v1.GraphKeys.LOSS)
        self.metric_list = self._compatible_get_collection(tf.compat.v1.GraphKeys.METRICS)
        self.lr_index = 0 # also for train_op_index

    @property
    def lr_variable(self):
        return self.lr_variables[self.lr_index]

    @property
    def lr_annealing_variable(self):
        return self.lr_annealing_variables[self.lr_index]

    @property
    def train_op(self):
        return self.train_ops[self.lr_index]

    @property
    def loss(self):
        return self.loss_list[0]

    @property
    def metric(self):
        return self.metric_list[0]

    def _compatible_get_collection(self, collection_name):
        new_name = "{}_{}".format(self.task_name, collection_name)
        items = tf.compat.v1.get_collection(new_name)
        if not items:
            items = tf.compat.v1.get_collection(collection_name)[self.task_index: self.task_index + 1]
            for item in items:
                tf.compat.v1.add_to_collection(new_name, item)
        return items

    def _get_op_from_collection(self, collection_name, index):
        ops = tf.compat.v1.get_collection(collection_name)
        if index > 0 and len(ops) == 1:
            return ops[0]
        else:
            return ops[index]

    def __hash__(self):
        return hash(self.task_index)

    def __eq__(self, other):
        return other is not None and isinstance(other, Task) and self.task_index == other.task_index

    def __ne__(self, other):
        return not(self == other)

    def __str__(self):
        return self.task_name


class IncrementalTraining(object):
    def __init__(self, model_input_dir, model_name,
            model_output_dir=None, session=None, graph=None, learning_rates=None,
            lr_annealing=True, lr_annealing_value=1.5, lr_annealing_stop_value=1e-6,
            logs_dir="./logs", save_checkpoint=False, clear_devices=False, debug_mode=False, use_tf_dataset=False):
        self.gpu_config = tf.compat.v1.ConfigProto(allow_soft_placement=True)
        self.gpu_config.gpu_options.allow_growth = True

        self.model_input_dir = model_input_dir
        self.model_output_dir = model_output_dir if model_output_dir is not None else model_input_dir
        self.model_name = model_name
        self.lr_annealing = lr_annealing
        self.lr_annealing_value = lr_annealing_value
        self.lr_annealing_stop_value = lr_annealing_stop_value
        self.logs_dir = logs_dir
        self.save_checkpoint = save_checkpoint

        self.train_writer = tf.compat.v1.summary.FileWriter(os.path.join(self.logs_dir, self.model_name, "train"))
        self.test_writer = tf.compat.v1.summary.FileWriter(os.path.join(self.logs_dir, self.model_name, "test"))
        self.train_step = 0
        self.test_step = 0

        self.best_train_metric = None
        self.best_test_metric = None
        self.prev_test_loss = None

        self.debug_mode = debug_mode

        if session is not None:
            self.session = session
            self.graph = session.graph
        elif graph is None:
            self.session = init_from_checkpoint(
                ckpt_path=os.path.join(self.model_input_dir, "{}.ckpt".format(self.model_name)),
                config=self.gpu_config, clear_devices=clear_devices)
        else:
            self.session = tf.compat.v1.Session(config=self.gpu_config, graph=graph)
            with self.session.graph.as_default():
                init_ops = [tf.compat.v1.global_variables_initializer(), tf.compat.v1.local_variables_initializer(),
                    tf.compat.v1.tables_initializer()]
                self.session.run(init_ops)

        self.graph = self.session.graph

        # init all tasks in this graph
        self.all_tasks = self._get_all_tasks()
        self.all_lr_variables = [t.lr_variable for t in self.all_tasks]
        self.task_size = len(self.all_tasks)

        with self.graph.as_default():
            # set new learning rate if specified
            self._set_new_lr(learning_rates)
            is_training_collection = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.IS_TRAINING)
            self.is_training_op = is_training_collection[0] if is_training_collection else None

        self.summary_op = None
        self.summary_step = 0

        self.use_tf_dataset  = use_tf_dataset

    def _set_new_lr(self, learning_rates):
        # set new learning rate if specified
        if learning_rates is not None:
            learning_rates = learning_rates if isinstance(learning_rates, list) else [
                learning_rates]
            if len(learning_rates) == 1:
                learning_rates *= len(self.all_tasks)
            assert len(learning_rates) == len(self.all_tasks)
            original_lr_values = self.session.run([task.lr_variable for task in self.all_tasks])
            original_lr_annealing_values = self.session.run([task.lr_annealing_variable for task in self.all_tasks])
            for index, lr_value in enumerate(learning_rates):
                print('original lr value: {}, new value: {}'.format(original_lr_values[index], learning_rates[index]))
                ratio = learning_rates[index] / original_lr_values[index]
                self.session.run(tf.compat.v1.assign(self.all_tasks[index].lr_annealing_variable,
                                                     original_lr_annealing_values[index] * ratio))

    def _is_all_larger(self, current_metric_dict, best_metric_dict):
        for key, score in best_metric_dict.items():
            if key not in current_metric_dict or current_metric_dict[key] < score:
                return False
        return True


    def _build_feed_dict_from_input(self, feed_keys, inputs, ignored_input_index=[]):
        """从输入数据构建feed_dict。
        举例如下：
        1. 输入为
        feed_keys=[placeholder1, placeholder_with_default2, placeholder3],
        inputs=[co1l, col2],
        ignored_inputs_index=[1]，
        构建出的feed_dict为{placeholder1:col1, placeholder3: col2},ignored_input_index里定义的index对应的feed_key会被忽略。
        2. 在1中，若ignored_inputs_index=[]，将试图采取默认行为进行数据截断，即构建字典{placeholder1:col1, placeholder_with_default2: col2}，
        此时由于扔掉的feed_key(placedholder3)仍然需要输入，会抛出异常。
        :param feed_keys: feed_dict的key list。
        :param inputs: 输入的data batch。
        :param ignored_input_index: 忽略的input data index。当feed key list和input data list长度不一致时使用。
        :return: feed_dict
        """
        if len(feed_keys) == len(inputs):
            return dict(zip(feed_keys, inputs))
        elif len(ignored_input_index) == 0:
            feed_keys_exclude_optional = feed_keys[0:len(inputs)]
            feed_keys_thrown = feed_keys[len(inputs):]
            if any([True for key in feed_keys_thrown if key.op.type != 'PlaceholderWithDefault']):
                raise Exception("{} vs {} not match".format(feed_keys, inputs))
        else:
            feed_keys_exclude_optional = [key for idx, key in enumerate(feed_keys) if idx not in ignored_input_index]
            # feed_keys_exclude_optional = [key for key in feed_keys if key.op.type != 'PlaceholderWithDefault']
        if len(feed_keys_exclude_optional) == len(inputs):
            return dict(zip(feed_keys_exclude_optional, inputs))
        else:
            raise Exception("{} vs {} not match".format(feed_keys, inputs))


    def update_word_table(self, word_dict):
        """
        update the word table
        """
        with self.session.graph.as_default():
            table_init_op = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TABLE_INITIALIZERS)
            k1 = tf.convert_to_tensor(list(word_dict.keys()), dtype=tf.string)
            v1 = tf.convert_to_tensor(list(word_dict.values()), dtype=tf.int64)
            tf.contrib.graph_editor.swap_ts(table_init_op[0].inputs._inputs[1:],[k1,v1])
        self.reset_session()

    def reset_session(self):
        """
        re-open a session
        """
        variables = self.export_trainable_variables()
        self.session = tf.compat.v1.Session(config=self.gpu_config, graph=self.session.graph)
        self.graph = self.session.graph
        with self.session.graph.as_default():
            init_ops = [tf.compat.v1.global_variables_initializer(), tf.compat.v1.local_variables_initializer(),
                        tf.compat.v1.tables_initializer()]
            self.session.run(init_ops)
        self.restore_variables(variables)

    @replace_default_graph
    def restore_variables(self, variables, name_check=False):
        for idx, var in enumerate(tf.compat.v1.trainable_variables()):
            if np.array_equal(var.shape.as_list(), variables[idx][1].shape):
                if (not name_check) or var.name == variables[idx][0]:
                    self.session.run(var.assign(variables[idx][1]))

    @replace_default_graph
    def export_freeze_graph(self, graph_dir, model_version, output_index=0,
                            clear_devices=True, as_text=False, export_mata_graph=True):
        export_path = os.path.join(graph_dir, str(model_version), FROZEN_FILE)
        if not isinstance(output_index, list):
            output_index = [output_index]
        output_dicts = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)
        # re-build the tf.compat.v1.GraphKeys.OUTPUT_DICT for metagraph
        self.graph.clear_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)
        [tf.compat.v1.add_to_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT, output_dicts[idx]) for idx in output_index]
        OUTPUT_NODE = [output_dicts[idx].op.name for idx in output_index]
        table_init_op = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TABLE_INITIALIZERS)
        for op in table_init_op:
            OUTPUT_NODE.append(op.name)
        graphdef_def = self.graph.as_graph_def()
        # tf.graph_util.remove_training_nodes(graphdef_def.as_graph_def())
        graphdef_frozen = tf.compat.v1.graph_util.convert_variables_to_constants(self.session, graphdef_def, OUTPUT_NODE)
        if export_mata_graph:
            tf.compat.v1.train.export_meta_graph(filename=export_path, graph_def=graphdef_frozen,
                                       collection_list=[tf.compat.v1.GraphKeys.TABLE_INITIALIZERS,
                                                        tf.compat.v1.GraphKeys.INPUT_DICT,
                                                        tf.compat.v1.GraphKeys.OUTPUT_DICT],
                                       as_text=as_text,
                                       clear_devices=clear_devices)
        else:
            if not os.path.isdir(os.path.join(graph_dir, str(model_version))):
                os.makedirs(os.path.join(graph_dir, str(model_version)))
            tf.train.write_graph(graphdef_frozen, './',
                                 export_path, as_text=as_text)

    @replace_default_graph
    def _get_tasks(self, task_names):
        task_collection = [name.decode() if isinstance(name, bytes) else name for name in tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TASKS)]
        if not task_names:
            task_names = [task_collection[0]] # None treated as default, the 0th of task_names
        elif not isinstance(task_names, list):
            task_names = [task_names]
        return [Task(task_name=name, task_index=task_collection.index(name)) for name in task_names]

    def _filter_task(self, task_names=None):
        if not task_names:
            # return first task in default
            return [self.all_tasks[0]]
        tasks = []
        for name in task_names:
            # too lazy to create a dict
            for task in self.all_tasks:
                if task.task_name == name:
                    tasks.append(task)
        return tasks

    @replace_default_graph
    def _get_all_tasks(self):
        task_collection = [name.decode() if isinstance(name, bytes) else name for name in tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TASKS)]
        return [Task(task_name=name, task_index=task_collection.index(name)) for name in task_collection]

    def _run_output(self, data, tasks, batch_size=256):
        if isinstance(data, DataIterator):
            data_iter = data
        else: # assert list
            data_iter = DataIterator(data, np.array(range(len(data[0]))), batch_size=batch_size)
        data_iter_tqdm = tqdm(data_iter, leave=False)
        results = defaultdict(list)
        for batch_index, batch in data_iter_tqdm:
            for task in tasks:
                feed_dict = self._build_feed_dict_from_input(task.inputs, batch)
                outputs = self.session.run(task.outputs, feed_dict=feed_dict)
                results[task].append(outputs)

        return dict(
            (
                task,
                [
                    np.concatenate([
                        output[index] for output in result
                    ])
                    for index in range(len(task.outputs))
                ]
            ) for (task, result) in results.items()
        )

    def _run_epoch_with_tf_dataset(self, dataset_iter_handle, batch_size, data_size, tasks, summary_step, mode="train"):
        batch_loss = defaultdict(list)
        batch_metric = defaultdict(list)
        data_iter_tqdm = tqdm(range(math.ceil(data_size/batch_size)), leave=False)
        summary_flag = True if self.summary_op is not None and summary_step > 0 else False
        for batch_index in data_iter_tqdm:
            for task in tasks:
                feed_dict = dict(zip(task.input_iter, [dataset_iter_handle]))
                if self.is_training_op is not None:
                    feed_dict[self.is_training_op] = mode == "train"
                add_summary = False
                if summary_flag and batch_index > 0 and batch_index % summary_step == 0:
                    add_summary = True
                if mode == "train":
                    if add_summary:
                        _, lr_value, loss, metric, summary = self.session.run([task.train_op, task.lr_variable, task.loss,
                                                                            task.metric, self.summary_op],
                                                                    feed_dict=feed_dict)
                    else:
                        _, lr_value, loss, metric = self.session.run([task.train_op, task.lr_variable, task.loss,
                                                                task.metric], feed_dict=feed_dict)
                else: # mode == "test"
                    if add_summary:
                        lr_value, loss, metric, summary = self.session.run([task.lr_variable, task.loss, task.metric,
                                                                  self.summary_op],
                                                                 feed_dict=feed_dict)
                    else:
                        lr_value, loss, metric = self.session.run([task.lr_variable, task.loss, task.metric], feed_dict=feed_dict)
                avg_loss = np.mean(loss)
                batch_loss[task].append(avg_loss * batch_size)
                avg_metric = np.mean(metric)
                batch_metric[task].append(avg_metric * batch_size)
                data_iter_tqdm.set_description_str("task:{}, lr:{:.4e}, loss:{:.4f}, metric:{:.4f}"
                                                   .format(task.task_name, lr_value, avg_loss, avg_metric))

                if add_summary:
                    if mode == "train":
                        self.train_writer.add_summary(summary, self.train_step)
                        self.train_step += 1
                    else:
                        self.test_writer.add_summary(summary, self.test_step)
                        self.test_step += 1

        epoch_loss = dict((k, np.array(v).sum() / data_size) for (k, v) in batch_loss.items())
        epoch_metric = dict((k, np.array(v).sum() / data_size) for (k, v) in batch_metric.items())
        return epoch_loss, epoch_metric

    def _run_epoch(self, data_iter, ignored_input_index, tasks, summary_step, mode="train"):
        batch_loss = defaultdict(list)
        batch_metric = defaultdict(list)
        data_iter_tqdm = tqdm(data_iter, leave=False)
        summary_flag = True if self.summary_op is not None and summary_step > 0 else False
        for batch_index, batch in data_iter_tqdm:
            batch_size = len(batch[0])
            for task in tasks:
                feed_key = task.inputs + task.targets # merge two list
                feed_dict = self._build_feed_dict_from_input(feed_key, batch, ignored_input_index)
                if self.is_training_op is not None:
                    feed_dict[self.is_training_op] = mode == "train"
                add_summary = False
                if summary_flag and batch_index > 0 and batch_index % summary_step == 0:
                    add_summary = True
                if mode == "train":
                    if add_summary:
                        _, lr_value, loss, metric, summary = self.session.run([task.train_op, task.lr_variable, task.loss,
                                                                     task.metric, self.summary_op],
                                                                    feed_dict=feed_dict)
                    else:
                        _, lr_value, loss, metric = self.session.run([task.train_op, task.lr_variable, task.loss,
                                                            task.metric], feed_dict=feed_dict)
                else: # mode == "test"
                    if add_summary:
                        lr_value, loss, metric, summary = self.session.run([task.lr_variable, task.loss, task.metric,
                                                                  self.summary_op],
                                                                 feed_dict=feed_dict)
                    else:
                        lr_value, loss, metric = self.session.run([task.lr_variable, task.loss, task.metric], feed_dict=feed_dict)
                avg_loss = np.mean(loss)
                batch_loss[task].append(avg_loss * batch_size)
                avg_metric = np.mean(metric)
                batch_metric[task].append(avg_metric * batch_size)
                data_iter_tqdm.set_description_str("task:{}, lr:{:.4e}, loss:{:.4f}, metric:{:.4f}".format(task.task_name, lr_value, avg_loss, avg_metric))

                if add_summary:
                    if mode == "train":
                        self.train_writer.add_summary(summary, self.train_step)
                        self.train_step += 1
                    else:
                        self.test_writer.add_summary(summary, self.test_step)
                        self.test_step += 1

        epoch_loss = dict((k, np.array(v).sum() / data_iter.processed_rows()) for (k,v) in batch_loss.items())
        epoch_metric = dict((k, np.array(v).sum() / data_iter.processed_rows()) for (k,v) in batch_metric.items())
        return epoch_loss, epoch_metric


    @replace_default_graph
    def _try_adjust_lr(self, current_loss, prev_loss):
        ops = []
        if len(self.all_tasks) == 1 and sum(current_loss.values()) > sum(prev_loss.values()) * 0.9999:
            target_value = self.session.run(self.all_tasks[0].lr_annealing_variable) / self.lr_annealing_value
            ops.append(tf.compat.v1.assign(self.all_tasks[0].lr_annealing_variable, target_value))
        elif len(self.all_tasks) > 1:
            for task, new_loss in current_loss.items():
                if new_loss > prev_loss[task] * 0.9999:
                    target_value = self.session.run(task.lr_annealing_variable) / self.lr_annealing_value
                    ops.append(tf.compat.v1.assign(task.lr_annealing_variable, target_value))
        if ops:
            self.session.run(ops)


    def _build_dict(self, key_prefix, values):
        keys = ["{}_{}".format(key_prefix, index) for index in range(len(values))]
        values = [value if isinstance(value, tf.compat.v1.TensorInfo) else tf.saved_model.utils.build_tensor_info(value) for value in values]
        return dict(zip(keys, values))


    @replace_default_graph
    def dump_model(self, serving_dir, model_version, clear_devices=True):
        export_path = os.path.join(serving_dir, str(model_version))
        legacy_init_op = tf.group(
            tf.compat.v1.tables_initializer(), name="legacy_init_op")
        prediction_signature = (
            tf.compat.v1.saved_model.signature_def_utils.build_signature_def(
                inputs=self._build_dict("input", tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.INPUT_DICT)),
                outputs=self._build_dict("output", tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)),
                method_name=tf.saved_model.PREDICT_METHOD_NAME))
        builder = tf.compat.v1.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            sess=self.session,
            tags=[tf.saved_model.tag_constants.SERVING],
            clear_devices = clear_devices,
            signature_def_map={
                tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:
                prediction_signature
            },
            main_op=legacy_init_op
            #legacy_init_op=legacy_init_op
        )
        builder.save()


    @replace_default_graph
    def restore_checkpoint_from_output(self, model_path=None):
        saver = tf.compat.v1.train.Saver()
        if model_path == None:
            saver.restore(self.session, os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name)))
        else:
            saver.restore(self.session, model_path)
        print("Reload Model ...")

    @replace_default_graph
    def restore_variables_from_output(self, model_path=None):
        if not model_path:
            model_path = os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name))
        tvars = tf.trainable_variables()
        (assignment_map, _) = IncrementalTraining.get_assignment_map_from_checkpoint(tvars, model_path)
        tf.train.init_from_checkpoint(model_path, assignment_map)
        self.session.run(tf.compat.v1.global_variables_initializer())

    @staticmethod
    def get_assignment_map_from_checkpoint(tvars, init_checkpoint):
        """Compute the union of the current variables and checkpoint variables."""
        initialized_variable_names = {}

        name_to_variable = collections.OrderedDict()
        for var in tvars:
            name = var.name
            m = re.match("^(.*):\\d+$", name)
            if m is not None:
                name = m.group(1)
            name_to_variable[name] = var

        init_vars = tf.train.list_variables(init_checkpoint)

        assignment_map = collections.OrderedDict()
        for x in init_vars:
            (name, var) = (x[0], x[1])
            if name not in name_to_variable:
                continue
            assignment_map[name] = name_to_variable[name]
            initialized_variable_names[name] = 1
            initialized_variable_names[name + ":0"] = 1

        return assignment_map, initialized_variable_names

    def _get_dump_path(self, epoch=None):
        if epoch is None:
            return os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name))
        else:
            return os.path.join(self.model_output_dir, "{}-epoch{}.ckpt".format(self.model_name, epoch))

    @replace_default_graph
    def dump_checkpoint(self, model_path=None):
        saver = tf.compat.v1.train.Saver()
        # TODO: fix the hacky code
        saver._max_to_keep = 0
        saver.saver_def.max_to_keep = 0
        if model_path is None:
            model_path = self._get_dump_path()
        directory = os.path.dirname(model_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        save_path = saver.save(self.session, model_path)
        print("Model checkpoint saved in file: {}".format(save_path))

    @replace_default_graph
    def model_summary(self):
        columns = ['variable_name', 'variable_shape', 'parameters']
        df_summary = pd.DataFrame(columns=columns)
        parameter_count = 0
        for i, var in enumerate(tf.compat.v1.trainable_variables()):
            if var.get_shape().dims is None:
                sl = 'unknown'
                para_num = 0
            else:
                sl = var.get_shape().as_list()
                para_num = np.prod(sl)
            df_summary.loc[i] = [var.name, sl, para_num]
            parameter_count += para_num
        print("total parameter number:", parameter_count)
        return df_summary

    @replace_default_graph
    def build_model_summary(self, loss_list, metrics_list, grad_list, capped_grad_list, summary_step=0):
        # usually this should be called by the model after the construction of graph
        for var in tf.compat.v1.trainable_variables():
            tf.compat.v1.summary.histogram(var.name.replace(':', '_'), var)
        for loss in loss_list:
            tf.compat.v1.summary.scalar(loss.name.replace(':', '_'), loss)
        for metric in metrics_list:
            tf.compat.v1.summary.scalar(metric.name.replace(':', '_'), metric)
        for grads in grad_list:
            for grad, var in grads:
                tf.compat.v1.summary.histogram(var.name.replace(
                    ':', '_') + '/gradient', grad)
        for capped_gvs in capped_grad_list:
            for grad, var in capped_gvs:
                tf.compat.v1.summary.histogram(var.name.replace(
                    ':', '_') + '/clip_gradient', grad)
        self.summary_op = tf.compat.v1.summary.merge_all()
        self.summary_step = summary_step


    @replace_default_graph
    def export_dict(self):
        table_init_op = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TABLE_INITIALIZERS)
        # FIXME
        if len(table_init_op) >= 1:
            #two methods to extract the key and value tensors
            key_op, value_op = table_init_op[0].inputs._inputs[1:]
            #key_op, value_op = self.graph.get_tensor_by_name('{}/keys:0'.format(table_init_op[0].name)), self.graph.get_tensor_by_name('{}/values:0'.format(table_init_op[0].name))
            keys, values = self.session.run([key_op, value_op])
            return dict([(k.decode('utf-8'), values[idx]) for idx, k in enumerate(keys)])
        else:
            return None

    @replace_default_graph
    def export_trainable_variables(self):
        variable_values = []
        for var in tf.compat.v1.trainable_variables():
            variable_values.append((var.name, self.session.run(var)))
        return variable_values

    def export_graph_def(self, path):
        graphdef_inf = tf.graph_util.remove_training_nodes(self.graph.as_graph_def())
        with open(path, 'w') as f:
            f.write(str(graphdef_inf))


    @replace_default_graph
    def train(self, data, n_epochs=1, task_names=None, on_epoch_finished_callbacks=None, input_index=None):
        """
        若data和model的feed key lis长度不一致，可在data中对应位置填充None，
        标识该index对应的feed key输入为optional(例如PlaceholderWithDefault)，否则会按默认行为构建feed_dict。
        :param data:
        :param n_epochs:
        :param task_names:
        :param on_epoch_finished_callbacks:
        :return:
        """
        # there should be only one task
        # filter task on task_names
        self._last_data = data
        tasks = self._filter_task(task_names)
        if input_index:
            for task in tasks:
                task.inputs = [task.inputs[i] for i in input_index]
        print('total number of epochs: {}'.format(n_epochs))
        print('tasks: {}'.format(tasks))
        self.lr_variables = [t.lr_variable for t in tasks]
        if on_epoch_finished_callbacks is None:
            on_epoch_finished_callbacks = []
        elif not isinstance(on_epoch_finished_callbacks, list):
            on_epoch_finished_callbacks = [on_epoch_finished_callbacks]
        if self.use_tf_dataset:
            train_dataset = data.to_tf_dataset(mode="train")
            test_dataset = data.to_tf_dataset(mode="test")
            train_iterator = train_dataset.make_initializable_iterator()
            test_iterator = test_dataset.make_initializable_iterator()
            # self.session.run([train_iterator.initializer, test_iterator.initializer],
            #                  feed_dict=data.get_tf_dataset_feed_dict())
            train_iterator_handle, test_iterator_handle = self.session.run([train_iterator.string_handle(),
                                                                            test_iterator.string_handle()], )
        for epoch in range(n_epochs):
            print("lr values: {}".format(self.session.run(self.lr_variables)))
            start_time = time.time()
            if self.use_tf_dataset:
                self.session.run(train_iterator.initializer, feed_dict=data.get_tf_dataset_feed_dict())
                epoch_train_loss, epoch_train_metric = self._run_epoch_with_tf_dataset(train_iterator_handle,
                                                                                       data.get_batch_size(),
                                                                                       data.get_dataset_size(mode="train"),
                                                                                       tasks,
                                                                                       self.summary_step,
                                                                                       mode="train")
            else:
                epoch_train_loss, epoch_train_metric = self._run_epoch(data.create_iterator(mode="train"),
                                                                       data.ignored_input_index,
                                                                       tasks, self.summary_step, mode="train")
            end_time = time.time()
            print("epoch {} train time(sec): {}".format(epoch, end_time - start_time))
            if self.best_train_metric is None or self._is_all_larger(epoch_train_metric, self.best_train_metric):
                self.best_train_metric = epoch_train_metric

            start_time = time.time()
            if self.use_tf_dataset:
                self.session.run(test_iterator.initializer, feed_dict=data.get_tf_dataset_feed_dict())
                epoch_test_loss, epoch_test_metric = self._run_epoch_with_tf_dataset(test_iterator_handle,
                                                                                       data.get_batch_size(),
                                                                                       data.get_dataset_size(mode="test"),
                                                                                       tasks,
                                                                                       self.summary_step,
                                                                                       mode="test")
            else:
                epoch_test_loss, epoch_test_metric = self._run_epoch(data.create_iterator(mode="test"),
                                                                     data.ignored_input_index,
                                                                 tasks, self.summary_step, mode="test")
            end_time = time.time()
            print("epoch {} test time(sec): {}".format(epoch, end_time - start_time))
            if self.save_checkpoint:
                self.dump_checkpoint(self._get_dump_path(epoch=epoch))
            if self.best_test_metric is None or self._is_all_larger(epoch_test_metric, self.best_test_metric):
                self.best_test_metric = epoch_test_metric
                if self.save_checkpoint:
                    self.dump_checkpoint()

            simplify_print({
                "epoch_index": epoch,
                "train_loss": dict((k.task_name, v) for (k,v) in epoch_train_loss.items()),
                "train_metric": dict((k.task_name, v) for (k,v) in epoch_train_metric.items()),
                "validate_loss": dict((k.task_name, v) for (k,v) in epoch_test_loss.items()),
                "validate_metric": dict((k.task_name, v) for (k,v) in epoch_test_metric.items()),
                "best_train_metric": dict((k.task_name, v) for (k,v) in self.best_train_metric.items()),
                "best_validate_metric": dict((k.task_name, v) for (k,v) in self.best_test_metric.items())
            })

            for callback in on_epoch_finished_callbacks:
                callback(self, epoch)

            if self.lr_annealing and self.prev_test_loss is not None:
                self._try_adjust_lr(epoch_test_loss, self.prev_test_loss)
            self.prev_test_loss = epoch_test_loss
            learning_rates = self.session.run(self.lr_variables)
            if self.lr_annealing and any(lr_value < self.lr_annealing_stop_value for lr_value in learning_rates):
                break

