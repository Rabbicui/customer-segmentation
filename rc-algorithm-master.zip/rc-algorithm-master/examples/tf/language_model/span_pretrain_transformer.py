import sys
from rcalgo.tf.models.language_model.span_transformer import NgramSpanMaskTransformersLM
from tqdm import tqdm
import re
from collections import defaultdict
import numpy as np
import pandas as pd
pd.options.display.max_rows = 100

text_list = [
    'Sounds like a cool summer ahead for you...that\'s great!  And if you detect and film in those places, '
    'then it\'s great for us too!',
    'Wow great offer for all 👧😀😃👨‍👩‍👧‍👦',
    'This video deserve Million views😍First is thanks bro for this important video upload.Bhai aapke alava kisi bhi '
    'YouTuber neisk baare m nhi btaya love u bro apne subscriber ki baat samjhne k liye❤️ THANKS BRO SOON YOUR '
    'MILLION SUBSCRIBER ❣️',
    'Hello, my friend. Very nice music and images! Thank you for sharing! Good luck to you.',
    'youre welcome ...me know the feeling ..music saves me everytime !!!!!',
    'Hi Zeamwiss!',
    '@beyourslefstudieos y r u so mean to notacat she shouldn\'t give u credit if u r like that!',
    'Cara is so stinkin CUTE!  I love when she is the star.  Love you Markus and Cara!',
    'Please stand clear of the doors.',
    'Good Video, very helpful, thx :D',
    'Over here it is 4:25am in the morning',
    'DAWWE kitty Blake',
    'I feel this vid landed in some sort of weird uncanny-valley of memes',
    '@kkongnamulgook Thank you so much! :DD',
    'Mix is always on point, I always have trouble mixing multiple guitars ha',
    'what a great idea, thanks Angelo'
]


def get_ngram_list_v2(sentence, ngram_width=3):
    if not isinstance(sentence, str):
        print(sentence)
    words = re.sub(r'\s+', ' ', sentence)
    if len(words) <= ngram_width:
        return [words]
    return [words[i:i + ngram_width]
            for i in range(len(words) - ngram_width + 1)]


def ngram_count_v2(sentences, word_freq=None, ngram_width=3):
    if word_freq is None:
        word_freq = defaultdict(int)
    for sentence in tqdm(sentences):
        for s in get_ngram_list_v2(sentence, ngram_width):
            word_freq[s] += 1
    return word_freq


def build_word2idx(word_freq, freq_num=2**17,
                   black_set=None):
    if black_set is None:
        black_set = {'\t', '\r', '\n'}
    term_id_map = {'[PAD]': 0}
#     default of tf.sparse.to_dense
    n = 0
    for key, value in word_freq.items():
        if key not in black_set:
            term_id_map[key] = len(term_id_map)
            n += 1
        if n == freq_num:
            break
    return term_id_map


word_freq = ngram_count_v2(text_list, ngram_width=3)
word_list = sorted(word_freq.items(), key=lambda item: item[1], reverse=True)
freq = {}
for kv in word_list:
    freq[kv[0]] = kv[1]
term_id_map = build_word2idx(freq, 200)
print(len(term_id_map), list(term_id_map.items())[:3])

config = {
    'num_layers': 4,
    'embedding_size': 32,
    'conv_num_filters': 64,
    'output_reduce_size': 32,
    'seq_length': 64,
    'acc_k': 1,
    'oov_buckets': 10,
    'filter_pattern': r'[^\x{20}-\x{7f}\x{1f300}-\x{1f6ff}\x{1f900}-\x{1f9ff}]',
    'low_threshold': 6,
    'high_threshold': 7,
}

model = NgramSpanMaskTransformersLM(config, term_id_map)
model.build_model()
print(model.model_summary())
print('Init Done')

masked_flag_list = [1.0] * len(text_list)
text_array = np.array(text_list, dtype=object)
# 规避numpy string
print('size(unit: B) from list to ndarray:',
      sys.getsizeof(text_list),
      sys.getsizeof(text_array))
del text_list
# model.train([text_list],
model.train([text_array, masked_flag_list],
            batch_size=2,
            test_size=0.25,
            epochs=2)
