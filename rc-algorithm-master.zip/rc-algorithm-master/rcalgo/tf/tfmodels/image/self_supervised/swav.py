import os

import tensorflow as tf
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))

from rcalgo.tf.tfmodels.image.base.base_model import BaseModel
from rcalgo.tf.tfmodels.image.base.keras_model_wrapper import KeraModelWrapper
from rcalgo.tf.tfmodels.image.base import base_model, models
from rcalgo.tf.tfmodels.image.utils import input_pipeline
from rcalgo.tf.tfmodels.image.base.layers import ReLU
from rcalgo.tf.tfmodels.image.utils.common import load_ckpt_weights

import math
import numpy as np

class SWAV(BaseModel):
    """
    SWAV 模型有个比较大的问题，就是 只有 样本A的 view A ---》 cluster x，  view B ----> 去预测 也属于cluster x

    这边有个大的bug是: 模型会cheat 尝试把所有图片都输出成非常相近的
    """

    def _build_data(self, batch, train_data, test_data=None):
        args = self.args
        data_train = input_pipeline.get_multi_crop_data(
            mode='train',
            batch_size=batch,
            size_crops=args.size_crops,
            nmb_crops=args.nmb_crops,
            min_scale_crops=args.min_scale_crops,
            max_scale_crops=args.max_scale_crops,
            data=train_data)
        iterator = data_train.make_one_shot_iterator()
        batches = iterator.get_next()
        return batches, None, None, None

    def _build_model(self, num_classes):
        args = self.args
        filters_factor = int(args.model[-1]) * 4
        nmb_inputs = np.sum(np.array(args.nmb_crops))
        units = models.NUM_UNITS[args.model]
        model = SWAVResnet(
            hidden_mlp=args.hidden_mlp,
            output_mlp=args.output_mlp,
            prototypes=args.nmb_prototypes,
            num_units=units,
            num_outputs=None,
            filters_factor=filters_factor,
            name="resnet",
            trainable=True,
            dtype=tf.float32,
            attention_params=None)
        y = []
        inputs = []
        for _ in range(nmb_inputs):
            # each crop runs the whole model once
            x = tf.keras.Input(shape=(None, None, 3))
            inputs.append(x)
            y.append(model(x))
        # concat all outputs along first (batch) dim
        y = tf.keras.layers.concatenate(y, axis=0)

        # build the queue
        # TODO 这个地方queue 不好写。而且需要在指定epoch之后启用queue
        queue = tf.zeros((len(args.crops_for_assign), args.queue_length // args.gpu_num, args.output_mlp))

        # TODO 这个方法还得再考虑下
        # tf.(queue[i, -1, :] == 0):
        # def
        # if not tf.(queue[i, -1, :] == 0):
        #     use_the_queue = True
        #     out = torch.cat((torch.mm(
        #         queue[i],
        #         model.module.prototypes.weight.t()
        #     ), out))
        # # fill the queue
        # queue[i, bs:] = queue[i, :-bs].clone()
        # queue[i, :bs] = embedding[crop_id * bs: (crop_id + 1) * bs]



        if args.ckpt_path is not None:
            load_ckpt_weights(args.ckpt_path)
        elif args.bit_pretrained_dir is not None:
            bit_model_file = os.path.join(args.bit_pretrained_dir, f'{args.model}.h5')
            model.load_weights(bit_model_file, by_name=True)
        # wrap inputs and outputs
        keras_model = KeraModelWrapper(model, inputs=inputs, outputs=y)
        keras_model.delegate.summary()
        # hack here
        return keras_model

    def _get_epochs(self, num_samples):
        return self.args.epochs

    def _build_custom_callbacks(self):
        total_steps = (self.num_samples // self.batch_size) * self.args.epochs
        warmup_steps = (self.num_samples // self.batch_size) * self.args.warmup_epochs
        return [WarmupAndCosineSched(self.args.base_lr, self.args.final_lr,
                                     self.args.start_warmup, warmup_steps, total_steps),
                NormPrototype(self.model.get_raw_model().get_prototypes())]

    def _build_loss(self):
        def swav_loss(y_true, y_predict):
            loss = 0
            bs = self.batch_size
            for crop_id in self.args.crops_for_assign:
                # crop id 指向的crop
                out = y_predict[bs * crop_id: bs * (crop_id+1)]
                # get assignments
                # TODO do exp here ?
                q = tf.math.exp(out / self.args.epsilon)
                # q = distributed_sinkhorn(q, args.sinkhorn_iterations)[-bs:]
                subloss = 0
                # 这个crop 和其他所有其他的crops算
                for v in np.delete(np.arange(np.sum(np.array(self.args.nmb_crops))), crop_id):
                    p = tf.nn.softmax(y_predict[bs * v: bs * (v + 1)] / self.args.temperature)
                    subloss -= tf.reduce_mean(tf.reduce_sum(q * tf.math.log(p), axis=1))
                loss += subloss / (np.sum(self.args.nmb_crops) - 1)
            loss /= len(self.args.crops_for_assign)
            return loss
        return swav_loss

    def _build_metric(self):
        return []


class WarmupAndCosineSched(tf.keras.callbacks.Callback):
    def __init__(self, base_lr, final_lr, start_warmup, warmup_steps, total_steps):
        self.step = 0
        self.base_lr = base_lr
        warmup_lr_schedule = np.linspace(start_warmup, base_lr, warmup_steps)
        iters = np.arange(total_steps - warmup_steps)
        cosine_lr_schedule = np.array([final_lr + 0.5 * (base_lr - final_lr) * (1 + math.cos(math.pi * t / (total_steps - warmup_steps)))
                                       for t in iters])
        self.lr_schedule = np.concatenate([warmup_lr_schedule, cosine_lr_schedule])

    def on_train_batch_begin(self, batch, logs=None):
        # 这边 继承 callback的子类 可以拿到  callback   和 model fit 绑定的模型 也就是 继承 Keras.Model 的子类
        lr = self.lr_schedule[self.step]
        tf.keras.backend.set_value(self.model.optimizer.lr, lr)
        self.step += 1


class NormPrototype(tf.keras.callbacks.Callback):
    def __init__(self, proto):
        self.proto = proto

    def on_train_batch_begin(self, batch, logs=None):
        w = self.proto.get_weights()
        # norm
        # TODO axis =1 or 0 ???? 这里比较奇怪，应该是norm axis =0 ?
        w = w / np.linalg.norm(w, axis=1)
        self.proto.set_weights(w)


class SWAVResnet(models.ResnetV2WithAttention):
    def __init__(self, hidden_mlp, output_mlp, prototypes, **kwargs):
        super(SWAVResnet, self).__init__(**kwargs)
        l1 = tf.keras.layers.Dense(hidden_mlp,
                                 kernel_initializer='he_normal',
                                 use_bias=True,
                                 bias_initializer='zeros',
                                 name='swav_pre_linear_%2d' % hidden_mlp)
        l2 = tf.keras.layers.Dense(output_mlp,
                                 use_bias=True,
                                 bias_initializer='zeros',
                                 name='swav_linear_%2d' % output_mlp)
        self._head = tf.keras.Sequential([l1, ReLU(), l2])
        self._prototypes = tf.keras.layers.Dense(prototypes,
                                 use_bias=False,
                                 name='prototypes_linear_%2d' % prototypes)

    def get_prototypes(self):
        return self._prototypes

    def call(self, x):
        # HACK blur and norm 放在这里做
        self._info_collector.clear()
        x = self._root(x)
        for block in self._blocks:
            x = block(x)
        for layer in self._pre_head:
            x = layer(x)
        self._info_collector.append(x)
        if self._head is not None:
            x = self._head(x)
        x = tf.math.l2_normalize(x, axis=1)
        self._info_collector.append(x)
        # collect the raw embedding
        x = self._prototypes(x)
        return x


