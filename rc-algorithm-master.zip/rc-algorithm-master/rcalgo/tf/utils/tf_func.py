import numpy as np
import tensorflow as tf
import shutil
import os
from functools import wraps
from tensorflow.python.framework import function
from tensorflow.python.framework import ops
from tensorflow.python.ops import math_ops
from tensorflow.python.framework.sparse_tensor import SparseTensor
from tensorflow.python.ops.ragged.ragged_tensor import RaggedTensor


def run_from_ipython():
    try:
        __IPYTHON__
        return True
    except NameError:
        return False


def label_smoothing(tensor, epsilon=0.1):
    """
    Applies label smoothing.
    See https://arxiv.org/abs/1512.00567.
    """
    K = tensor.get_shape().as_list()[-1]
    return ((1-epsilon) * tensor) + (epsilon / K)


def exists_op_name(graph, op_name):
    return any(op.name == op_name for op in graph.get_operations())


def replace_default_graph(func):
    @wraps(func)
    def wrapper(self, *args, **kw):
        if tf.compat.v1.get_default_graph() != self.graph:
            with self.graph.as_default():
                return func(self, *args, **kw)
        else:
            return func(self, *args, **kw)
    return wrapper


def get_from_collection_or_create(collection_name, init_func, index=0):
    prev = tf.compat.v1.get_collection(collection_name)
    if len(prev) > index:
        return prev[index]
    else:
        obj = init_func()
        tf.compat.v1.add_to_collection(collection_name, obj)
        return obj


def convert_to_dense(tensor, default_value=0):
    """
    ragged tensor 转 sparse tensor 转 dense
    比ragged tensor 转 dense 要快
    """
    if isinstance(tensor, SparseTensor):
        return sparse_to_dense(tensor, default_value)
    elif isinstance(tensor, RaggedTensor):
        return sparse_to_dense(tensor.to_sparse(), default_value)
        # return tensor.to_tensor()
    else:
        return tensor


def sparse_to_dense(tensor, default_value=0):
    return tf.sparse.to_dense(tensor, default_value=default_value)
    # return tf.sparse_to_dense(out.indices, out.dense_shape, out.values, default_value=default_value)


def shape_list(input_tensor):
    """
    deal with dynamic shape in tensorflow cleanly
    """
    ps = input_tensor.get_shape().as_list()
    ts = tf.shape(input_tensor)
    return [ts[i] if ps[i] is None else ps[i] for i in range(len(ps))]


@function.Defun(
    python_grad_func=lambda x, dy: tf.convert_to_tensor(dy),
    shape_func=lambda op: [op.inputs[0].get_shape()])
def convert_gradient_to_dense_tensor(x):
    """
    force gradient to be a dense tensor
    it's often faster to do dense embedding gradient on GPU than sparse on CPU
    """
    return x


def generate_span_masked_bow(input_bow, input_length, maxlen, nb_words, 
                             expand_input=True, prob1=0.8, prob2=0.9, threshold=6, mask_length=None):
    """
    基于span的连续mask玩法
    Main Args:
        input_bow: 输入的序列
        input_length: 输入序列的长度
        maxlen: 最大长度
        nb_words: 字符数量
        maxk_label: [masked]字符的编码
        expand_input: 是否首尾进行了扩充， expand_input为True的时候，首尾分别多了<SOS>和<EOS>
        prob1: [masked]占比
        prob2: 随机的占比（prob2-prob1）
        threshold: 长度归一化的系数
        mask_length: 指定Masked_length
        
    Return:
        masked_input_bow: masked之后的输入 
        indices: masked的部分
        origin_bow: 原始的字符，即预测的部分
    """
    # 每个组采样一个起始位置
    mask_label = nb_words-1
    #真实的评论文本长度
    true_input_length = tf.maximum(tf.ones_like(input_length), input_length-2*int(expand_input))
    #开始的index的位置
    start_postion = tf.math.mod(tf.random.uniform(tf.shape(true_input_length), minval=0, 
                                             maxval=99999721, dtype=tf.int64), true_input_length) + int(expand_input)
    #start_postion = tf.transpose(tf.map_fn(lambda x: tf.random.uniform(
     #   [1], minval=0, maxval=x, dtype=tf.int64), input_length))[0]
    # ngram的长度
    if mask_length is None:
        ngram_length = tf.cast(tf.math.ceil(true_input_length/threshold), dtype=tf.int64)
    else:
        ngram_length =  tf.cast(mask_length, dtype=tf.int64)
    #因为是右开，所以需要向后延伸一位
    end_position = tf.minimum(true_input_length+int(expand_input)+1, start_postion+ngram_length)
    # 每个span的mask标志位, 左闭右开
    predict_mask = tf.sequence_mask(end_position, maxlen=maxlen, dtype=tf.int64) - \
        tf.sequence_mask(start_postion, maxlen=maxlen, dtype=tf.int64)
    mask_length = tf.reduce_sum(predict_mask, 1)
    # masked的索引位置
    indices = tf.compat.v2.where(tf.not_equal(
        predict_mask, tf.constant(0, predict_mask.dtype)))
    # 预测的sample
    random_smaple = tf.random.uniform(
        [tf.reduce_sum(predict_mask)], minval=1, maxval=nb_words, dtype=tf.int64)
    probs = tf.random.uniform(
        [tf.reduce_sum(predict_mask)], minval=0, maxval=1.0, dtype=tf.float32)
    origin_bow = tf.gather_nd(input_bow, indices)
    mask_prob = tf.cast(probs <= prob1, dtype=tf.int64)
    random_prob = tf.cast((probs > prob1) & (probs <= prob2), dtype=tf.int64)
    origin_prob = tf.cast(probs > prob2, dtype=tf.int64)
    repalce_mask = mask_prob * mask_label + random_prob * \
        random_smaple + origin_prob * origin_bow
    repalce_bow = tf.sparse.to_dense(tf.SparseTensor(
        indices, repalce_mask, tf.shape(input_bow, out_type=tf.int64)))
    masked_input_bow = repalce_bow + (1-predict_mask)*input_bow
    return masked_input_bow, indices, origin_bow, mask_length


###########################################################################
def get_new_variable_scope(name, scope=None, reuse=False, initializer=None, custom_getter=None):
    if (reuse is True or reuse == tf.AUTO_REUSE) and scope is None:
        scope = name
    vscope = tf.compat.v1.variable_scope(
        scope, default_name=name, reuse=reuse, initializer=initializer, custom_getter=custom_getter)
    return vscope

def fp32_storage_getter(getter, name, shape=None, dtype=None,
                        initializer=None, regularizer=None,
                        trainable=True,
                        *args, **kwargs):
    """Custom variable getter that forces trainable variables to be stored in
    float32 precision and then casts them to the training precision.
    """
    storage_dtype = tf.float32 if trainable and dtype is not None else dtype
    variable = getter(name, shape, dtype=storage_dtype,
            initializer=initializer, regularizer=regularizer,
            trainable=trainable,
            *args, **kwargs)
    if trainable and type is not None and dtype != tf.float32:
        variable = tf.cast(variable, dtype)
    return variable



#summary for scalar
def variable_summaries(var, name):
    with tf.name_scope('summaries'):
        mean = tf.reduce_mean(var)
        tf.compat.v1.summary.scalar('mean/' + name.replace(':', '_'), mean)
        with tf.name_scope('stddev'):
            stddev = tf.sqrt(tf.reduce_mean(tf.square(var - mean)))
        tf.compat.v1.summary.scalar('stddev/' + name.replace(':', '_'), stddev)
        tf.compat.v1.summary.scalar(
            'max/' + name.replace(':', '_'), tf.reduce_max(var))
        tf.compat.v1.summary.scalar(
            'min/' + name.replace(':', '_'), tf.reduce_min(var))
        tf.compat.v1.summary.histogram(name.replace(':', '_'), var)


##################################   initializer utils #####################################################################


def _get_fans(shape):
    """Returns values of input dimension and output dimension, given `shape`.

    Args:
      shape: A list of integers.

    Returns:
      fan_in: An int. The value of input dimension.
      fan_out: An int. The value of output dimension.
    """
    if len(shape) == 2:
        fan_in = shape[0]
        fan_out = shape[1]
    elif len(shape) == 4 or len(shape) == 5:
        # assuming convolution kernels (2D or 3D).
        kernel_size = np.prod(shape[:2])
        fan_in = shape[-2] * kernel_size
        fan_out = shape[-1] * kernel_size
    else:
        # no specific assumptions
        fan_in = np.sqrt(np.prod(shape))
        fan_out = np.sqrt(np.prod(shape))
    return fan_in, fan_out


def he_uniform(name, shape, scale=1, dtype=None):
    """
    See He et al. 2015 `http://arxiv.org/pdf/1502.01852v1.pdf`
    """
    fin, _ = _get_fans(shape)
    s = np.sqrt(1. * scale / fin)
    shape = shape if isinstance(shape, (tuple, list)) else [shape]
    vscope = get_new_variable_scope('he_uniform', custom_getter=fp32_storage_getter)
    with vscope as scope:
        # print scope.name
        W = tf.compat.v1.get_variable(
            name, shape, dtype=dtype, initializer=tf.random_uniform_initializer(minval=-s, maxval=s))
        return W

#############################   optimize utils ####################################################################


def _my_compute_grad(opt, loss, params, clip_type=None, max_clip_grad=1.0):
    """
    compute the gradiant, clip the gradiants
    """
    compute_op = getattr(opt, "compute_gradients", None)
    if compute_op is not None:
        grads = opt.compute_gradients(loss, params)
    else:
        grads = opt.get_gradients(loss, params)
    # Processing gradients before applying them
    if clip_type == 'clip_value':
        capped_gvs = [(None if grad is None else tf.clip_by_value(
            grad, -max_clip_grad, max_clip_grad), var) for grad, var in grads]
    elif clip_type == 'clip_norm':
        capped_gvs = [(None if grad is None else tf.clip_by_norm(
            grad, max_clip_grad), var) for grad, var in grads]
    #这段有bug，params有可能为None
    elif clip_type == 'clip_global_norm':
        capped_gvs, grads_norm = tf.clip_by_global_norm(
            [grad for grad, var in grads], max_clip_grad)
        capped_gvs = list(zip(capped_gvs, params))
    else:
        capped_gvs = grads
    return grads, capped_gvs


def my_compute_grad(opt, loss, params, clip_type=None, max_clip_grad=1.0, task=None):
    """
    compute the gradiant, clip the gradiants
    """
    if isinstance(opt, dict):
        if task is None:
            task = list(opt.keys())[0]
        new_opt = opt[task]
    elif isinstance(opt, tf.train.Optimizer):
        new_opt = opt
    else:
        raise ValueError(
            'opt must be tf.train.Optimizer or dict which contains tf.train.Optimizer')
    return _my_compute_grad(new_opt, loss, params, clip_type, max_clip_grad)


def average_gradients(tower_grads):
    """
    Calculate the average gradient for each shared variable across all towers.
    Note that this function provides a synchronization point across all towers.

    Args:
    tower_grads: List of lists of (gradient, variable) tuples. The outer list
      is over individual gradients. The inner list is over the gradient
      calculation for each tower.
    Returns:
     List of pairs of (gradient, variable) where the gradient has been averaged
     across all towers.
    """
    average_grads = []
    for grad_and_vars in zip(*tower_grads):
        # Note that each grad_and_vars looks like the following:
        #   ((grad0_gpu0, var0_gpu0), ... , (grad0_gpuN, var0_gpuN))
        grads = []
        for g, _ in grad_and_vars:
            # Add 0 dimension to the gradients to represent the tower.
            if g is not None:
                expanded_g = tf.expand_dims(g, 0)

                # Append on a 'tower' dimension which we will average over below.
                grads.append(expanded_g)

        # Average over the 'tower' dimension.
        #grad = tf.concat(0, grads)
        if len(grads) > 0:
            grad = tf.concat(grads, 0)
            grad = tf.reduce_mean(grad, 0)
        else:
            grad = None

        # Keep in mind that the Variables are redundant because they are shared
        # across towers. So .. we will just return the first tower's pointer to
        # the Variable.
        v = grad_and_vars[0][1]
        grad_and_var = (grad, v)
        average_grads.append(grad_and_var)
        #average_grads = [(None if grad is None else tf.clip_by_norm(grad, max_grad_norm), var) for grad, var in average_grads]
    return average_grads

#############################   sparse tensor utils ####################################################################


def target_list_to_sparse_tensor(targetList):
    """
       make tensorflow SparseTensor from list of targets, with each element
       in the list being a list or array with the values of the target sequence
       (e.g., the integer values of a character map for an ASR target string)
       See https://github.com/tensorflow/tensorflow/blob/master/tensorflow/contrib/ctc/ctc_loss_op_test.py
       for example of SparseTensor format
    """
    indices = []
    vals = []
    for tI, target in enumerate(targetList):
        for seqI, val in enumerate(target):
            indices.append([tI, seqI])
            vals.append(val)
    shape = [len(targetList), np.asarray(indices).max(0)[1]+1]
    return (np.array(indices), np.array(vals), np.array(shape))


def get_concat_sparse_tensor(tensor, constant, right_join=False):
    """
    concat tensor with constant
    Main Args:
    tensor: sparse tensor, [batch_size, maxlen]
    """    
    seq = tf.sparse_reduce_sum(tf.sign(tensor), 1, True)
    ext = tf.zeros_like(seq) + constant
    if right_join:
        position = seq - tf.math.maximum(tf.reduce_max(seq), tf.cast(tensor.dense_shape[-1], dtype=tf.int64))
    else:
        position = tf.zeros_like(seq)
    idx = tf.cast(tf.range(tf.shape(position)[0]), tensor.dtype)
    new_idx = tf.concat([tf.expand_dims(idx, 1), position], axis=1)
    return tf.SparseTensor(new_idx, ext[:, 0], tf.shape(ext, out_type=tensor.dtype))
    #idx = tf.where(tf.not_equal(tensor, tf.constant(0, dtype=tensor.dtype)))
    # return tf.SparseTensor(idx, tf.gather_nd(tensor, idx), tf.shape(tensor, out_type=tf.int64))


def model_logger_dir_prepare(logs_dir, model_dir, current_name):
    if os.path.exists(logs_dir + current_name):
        shutil.rmtree(logs_dir + current_name)
    os.makedirs(logs_dir + current_name)
    if os.path.exists(model_dir + current_name):
        shutil.rmtree(model_dir + current_name)
    os.makedirs(model_dir + current_name)


class prettyfloat(float):
    def __repr__(self):
        return "%0.5f" % self


def sequence_reverse(seq, pivot, seq_dim=0):
    rev_seq = np.concatenate([np.flip(seq[:pivot], axis=seq_dim), seq[pivot:]])
    return rev_seq


def my_format(my_item):
    if isinstance(my_item, float) and isinstance(my_item, np.float64):
        return prettyfloat(float(my_item))
    elif isinstance(my_item, dict):
        return dict({k: prettyfloat(v) if isinstance(v, float) else v for k, v in my_item.items()})
    else:
        # print(type(my_item).__name__)
        return my_item


def init_from_checkpoint(ckpt_path, config, clear_devices):
    session = tf.compat.v1.Session(config=config, graph=tf.Graph())
    with session.graph.as_default():
        saver = tf.compat.v1.train.import_meta_graph(
            "{}.meta".format(ckpt_path), clear_devices=clear_devices)
        saver.restore(session, ckpt_path)
        op_name = "init_all_tables"
        if exists_op_name(graph=session.graph, op_name=op_name):
            session.run(session.graph.get_operation_by_name(op_name))
    return session


def check_not_nan(vars, descriptions):
    if not isinstance(vars, list):
        vars = [vars]
    if not isinstance(descriptions, list):
        descriptions = [descriptions]
    for var, des in zip(vars, descriptions):
        if var is None:
            raise ValueError('{} is none'.format(des))


def flat_tf_tensor_2_list(tensor):
    res = []
    tf.map_fn(lambda x: res.append(x), tensor)
    return res


def deconv_output_length(input_length, filter_size, padding, stride):
    """Determines output length of a transposed convolution given input length.

    Arguments:
      input_length: integer.
      filter_size: integer.
      padding: one of "same", "valid", "full".
      stride: integer.

    Returns:
      The output length (integer).
    """
    if input_length is None:
        return None
    input_length *= stride
    if padding == 'VALID':
        input_length += max(filter_size - stride, 0)
    elif padding == 'FULL':
        input_length -= (stride + filter_size - 2)
    return input_length


def inverse_sigmoid_sample_proba(decay_factor, global_step, dtype=tf.float32, name=None):
    with ops.name_scope(name, "inverse_sigmoid") as name:
        tmp_global_step = math_ops.cast(global_step, dtype)
        sample_prob = decay_factor / \
            (decay_factor + tf.exp(tmp_global_step/decay_factor))
        return sample_prob


def add_weight_to_collection(weight, variables_collections):
    if variables_collections is not None and isinstance(variables_collections, str):
        if weight not in tf.compat.v1.get_collection(variables_collections):
            tf.compat.v1.add_to_collection(variables_collections, weight)


def gather_indexes(sequence_tensor, positions):
    """Gathers the vectors at the specific positions over a minibatch."""
    sequence_shape = shape_list(sequence_tensor)
    batch_size = sequence_shape[0]
    seq_length = sequence_shape[1]
    width = sequence_shape[2]

    flat_offsets = tf.reshape(
        tf.range(0, batch_size, dtype=tf.int32) * seq_length, [-1, 1])
    flat_positions = tf.reshape(positions + flat_offsets, [-1])
    flat_sequence_tensor = tf.reshape(sequence_tensor,
                                      [batch_size * seq_length, width])
    output_tensor = tf.gather(flat_sequence_tensor, flat_positions)
    return output_tensor
