import sys
import os
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))

from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.module.layer.attention import self_position_attention, self_position_attentive
from rcalgo.tf.metric.loss import l2_loss, my_sparse_cross_entropy_loss
from rcalgo.tf.module.layer.activations import act_fns
from rcalgo.tf.module.layer.basic import *
from rcalgo.tf.module.encoder.transformer import bi_conv_transformer_layer, conv_transformer_layer
from .text_basic_model import *
from .extend_model.quasi_rnn import *


# FastText for Sentence Classification
class FastText(TextModel):
    def __init__(self, config, graph, word_dict=None):
        super(FastText, self).__init__(
            config, graph, word_dict)
        self.labels = config.labels if hasattr(config, 'labels') else 1
        self.p_coef = config.p_coef if hasattr(config, 'p_coef') else 0

    def _get_dataset_output_types(self):
        if self.raw_text:
            if self.labels == 1:
                return tf.string, tf.int32
            else:
                return tf.string, get_default_float_type()
        else:
            if self.labels == 1:
                return [tf.int32], tf.int32
            else:
                return [tf.int32], get_default_float_type()

    def _get_placeholder_default_value(self):
        if self.raw_text:
            if self.labels == 1:
                return tf.constant(''), tf.constant(0)
            else:
                return tf.constant(''), tf.constant(0.1)
        else:
            if self.labels == 1:
                return tf.constant([0]), tf.constant(0)
            else:
                return tf.constant([0]), tf.constant(0.1)

    def build_input(self):
        super(FastText, self).build_input()
        #self.build_text_input()
        with tf.name_scope('input'):
            if self.labels == 1:
                inputLabel = tf.compat.v1.placeholder_with_default(self.batch_input[1], [None], name='label')
            else:
                inputLabel = tf.compat.v1.placeholder_with_default(
                    self.batch_input[1], [None, self.labels], name='label')
            self._add_to_graph_targets(inputLabel)
            self.split_inputLabel = tf.split(inputLabel, self.gpu_num, 0)
        with tf.name_scope('states_array'):
            self.pool_flat_drop_list = [[] for i in range(0, self.gpu_num)]
            #self.input_embedding = [[] for i in range(0, self.gpu_num)]

    def _penalty(self):
        p_loss = self.p_coef * l2_loss()
        return p_loss

    def build_classification_model(self, gpu_id=0, dropout_keep_prob=0.5):
        self._build_embedding_layer(gpu_id)
        concat_pool_flat = tf.reduce_mean(self.input_embedding[gpu_id], axis=1)
        with tf.name_scope("dropout"):
            self.pool_flat_drop_list[gpu_id] = my_dropout(
                concat_pool_flat, rate=(1-dropout_keep_prob), training=self.training)
        #print(self.pool_flat_drop_list[gpu_id])

    def loss_function(self, prediction, targets, nb_class):
        loss = my_sparse_cross_entropy_loss(targets, prediction,
                                            nb_class, self.label_smooth)
        loss = tf.cast(tf.reduce_mean(loss), tf.float32) + self._penalty()
        return loss
    
    def metrics_function(self, prediction, targets, accK):
        labels = targets if self.labels == 1 else tf.argmax(targets, axis=1)
        if prediction.dtype != tf.float32:
            prediction = tf.cast(prediction, tf.float32)
        accuracy = tf.cast(tf.nn.in_top_k(prediction, labels, k=accK), dtype=tf.float32)
        return accuracy
        
    
    def build_prediction(self, gpu_id=0, num_classes=2, accK=1, task=None):
        task = self.default_task_name if task is None else task
        prediction = tf.cast(my_full_connected(
            self.pool_flat_drop_list[gpu_id], num_classes), tf.float32)
        #print(prediction)
        self.tower_prediction_results.append(tf.nn.softmax(prediction))
        self.compute_metrics(prediction, self.split_inputLabel[gpu_id],
                             task=task, nb_class=num_classes, accK=accK)

    @replace_default_graph
    def build_model(self, num_classes=2, accK=1, *args, **kwargs):
        self.build_input()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('{}{}'.format(self.device_str, gpu_id)):
                with tf.name_scope('Tower_{}'.format(idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse, custom_getter=fp32_storage_getter)
                    with gpu_scope as gpu_scope:
                        self.build_classification_model(
                            gpu_id=idx, *args, **kwargs)
                        self.build_prediction(
                            gpu_id=idx, num_classes=num_classes, accK=accK)
        self.build_model_aggregation()
        self._add_to_graph_outputs(self.prediction_results)

# Convolutional Neural Networks for Sentence Classification
class TextCNN(FastText):
    def __init__(self, config, graph, word_dict=None):
        super(TextCNN, self).__init__(config, graph, word_dict=word_dict)

    def build_classification_model(self, gpu_id=0, max_conv_len=3, num_filters=128, dropout_keep_prob=0.5):
        self._build_embedding_layer(gpu_id)
        pooled_outputs = []
        for conv_length in range(1, max_conv_len+1):
            with get_new_variable_scope('conv') as conv_scope:
                conv = my_conv_1d(self.input_embedding[gpu_id], conv_length, num_filters, add_bias=True, bn=False,
                                  padding='VALID', act=tf.nn.relu)
                # pool = tf.nn.max_pool2d(tf.expand_dims(conv, -1),
                #                      ksize=[1, self.maxlen - conv_length + 1, 1, 1],
                #                      strides=[1, 1, 1, 1], padding='VALID', name="pool")
                # using reduce_max repalce max_pool(max_pool over time)
                pool = tf.reduce_max(conv, axis=1)
                pooled_outputs.append(pool)

        num_filters_total = num_filters * len(pooled_outputs)
        # axis = 3 if using max_pool
        concat_pool_flat = tf.concat(pooled_outputs, 1)
        #concat_pool_flat = tf.reshape(concat_pool, [-1, num_filters_total])
        # Add dropout
        with tf.name_scope("dropout"):
            self.pool_flat_drop_list[gpu_id] = my_dropout(
                concat_pool_flat, rate=(1-dropout_keep_prob), training=self.training)


# Character-level Convolutional Networks for Text Classification
class TextDeepCNN(TextCNN):
    def __init__(self, config, graph, word_dict=None):
        super(TextDeepCNN, self).__init__(config, graph, word_dict=word_dict)

    def build_classification_model(self, gpu_id=0, num_filters_per_size=64, filter_sizes=[7, 7, 3, 3, 3, 3],
                                   pool_sizes=[3, 3, None, None, None, 3], fully_layers=[128, 128], dropout_keep_prob=0.5,
                                   add_mean_pooling=True):
        self._build_embedding_layer(gpu_id)
        last_conv = self.input_embedding[gpu_id]
        for idx, conv_length in enumerate(filter_sizes):
            # using same for short text
            with get_new_variable_scope('conv') as conv_scope:
                conv = my_conv_1d(last_conv, conv_length, num_filters_per_size, add_bias=True, bn=False,
                                  padding='VALID', act=tf.nn.relu)
            if pool_sizes[idx] is not None and pool_sizes[idx] > 0:
                with tf.name_scope("MaxPoolingLayer"):
                    pool = tf.nn.max_pool2d(tf.expand_dims(conv, -1),
                                          ksize=[1, pool_sizes[idx], 1, 1], strides=[1, pool_sizes[idx], 1, 1],
                                          padding='VALID', name="pool")
                    last_conv = tf.squeeze(pool, [3])

            elif pool_sizes[idx] == -1:
                with tf.name_scope("MaxPoolingOverTimeLayer"):
                    last_conv = tf.reduce_max(conv, axis=1)
                    if add_mean_pooling:
                        mean_conv = tf.reduce_sum(conv, axis=1)/(tf.count_nonzero(
                            tf.reduce_sum(conv, axis=-1), axis=1, keepdims=True, dtype=get_default_float_type()) + 1e-8)
                        last_conv = tf.concat([last_conv, mean_conv], axis=1)
            else:
                last_conv = conv
        last_flatten = my_flatten(last_conv)
        for idx, fc in enumerate(fully_layers):
            flatten = my_full_connected(last_flatten, fc, act=tf.nn.relu)
            #last_flatten = flatten
            last_flatten = my_dropout(flatten, rate=(
                1-dropout_keep_prob), training=self.training)
        self.pool_flat_drop_list[gpu_id] = last_flatten


# Attention-based RNN classification Model
class AttentionRNNModel(TextCNN):
    def __init__(self, config, graph, word_dict=None):
        super(AttentionRNNModel, self).__init__(
            config, graph, word_dict=word_dict)
        self.attention_size = config.attention_size
        self.num_layers = config.num_layers  # the number of rnn layers
        self.hidden_size = config.hidden_size  # rnn hidden size
        self.keep_prob = config.keep_prob  # keep probability of drop out
        self.use_residual = config.use_residual if hasattr(
            config, 'use_residual') else False
        self.use_qrnn = config.use_qrnn if hasattr(
            config, 'use_qrnn') else True
        # for self prediction
        self.input_params = None
        # for quasi rnn
        self.zoneout = config.zoneout if hasattr(config, 'zoneout') else 0.0
        self.conv_legnth = config.conv_legnth if hasattr(
            config, 'conv_legnth') else 2
        self.pool_type = config.pool_type if hasattr(
            config, 'pool_type') else 'ifo'
        self.activation = tf.nn.tanh
        self.tower_attentions = [[] for i in range(0, self.gpu_num)]

    def build_input(self):
        super(AttentionRNNModel, self).build_input()
        with tf.name_scope('states_array'):
            self.state_list = [[] for i in range(0, self.gpu_num)]
            self.rnn_output_list = [[] for i in range(0, self.gpu_num)]
        self.dynamic_batch_size = tf.shape(self.split_inputX[0])[0]

    def _build_rnn_input_sequence(self, gpu_id=0):
        # embedding layer
        self._build_embedding_layer(gpu_id)
        with get_new_variable_scope('rnn_lstm') as rnn_scope:
            #fw_cell and bw_cell
            cell_fw = self.build_cell(
                self.hidden_size, self.keep_prob, self.num_layers)
            cell_bw = self.build_cell(
                self.hidden_size, self.keep_prob, self.num_layers)
            self.state_list[gpu_id], self.rnn_output_list[gpu_id] = bidirectional_dynamic_rnn(
                cell_fw, cell_bw, self.input_embedding[gpu_id], self.split_seqLengths[gpu_id],
                dtype=get_default_float_type())
            self.state_list[gpu_id] = tf.concat(
                self.state_list[gpu_id], axis=2)
            

    def _build_qrnn_input_sequence(self, gpu_id=0):
        self._build_embedding_layer(gpu_id)
        with get_new_variable_scope('qrnn') as rnn_scope:
            bi_m_qrnn = MultiBiQRNNLayer(self.num_layers, self.hidden_size, self.conv_legnth, pool_type=self.pool_type,
                                         zoneout=self.zoneout, training=self.training, use_residual=self.use_residual)
            self.state_list[gpu_id], self.rnn_output_list[gpu_id] = bi_m_qrnn(self.input_embedding[gpu_id],
                                                                              self.split_seqLengths[gpu_id])
            self.state_list[gpu_id] = tf.concat(
                self.state_list[gpu_id], axis=-1)

    def build_input_sequence(self, gpu_id=0):
        if self.use_qrnn:
            self._build_qrnn_input_sequence(gpu_id)
        else:
            self._build_rnn_input_sequence(gpu_id)

    def build_classification_model(self, gpu_id=0, dropout_keep_prob=1.0):
        self.build_input_sequence(gpu_id=gpu_id)
        if self.attention_size > 0:
            with tf.name_scope('attention') as scope:
                last_flat, alphas = self_position_attention(
                    self.state_list[gpu_id], self.attention_size)
                self.tower_attentions[gpu_id] = alphas
        else:
            with tf.name_scope('pooling_over_time') as scope:
                # pool = tf.nn.max_pool2d(tf.expand_dims(self.state_list[gpu_id], -1),
                #                      ksize=[1, self.maxlen, 1, 1],
                #                      strides=[1, 1, 1, 1], padding='VALID', name="pool")
                pool = tf.reduce_max(self.state_list[gpu_id], axis=1)
                last_flat = tf.reshape(pool, [-1, self.hidden_size*2])
        last_flatten = my_dropout(last_flat, rate=(
            1-dropout_keep_prob), training=self.training)
        self.pool_flat_drop_list[gpu_id] = last_flatten

    @replace_default_graph
    def build_model(self, export_attention=True, num_classes=2, accK=1, *args, **kwargs):
        super(AttentionRNNModel, self).build_model(
            num_classes=num_classes, accK=accK, *args, **kwargs)
        if export_attention:
            self.prediction_results = [
                self.prediction_results, tf.concat(self.tower_attentions, 0)]
            self._add_to_graph_outputs(self.prediction_results[-1])
            self.output_dict['attention'] = self.tower_attentions[0]
            self._add_to_graph_collection(
                tf.compat.v1.GraphKeys.OUTPUT_DICT, self.output_dict['attention'])

# structed self attentive model
class SelfAttentiveRNNModel(AttentionRNNModel):
    def __init__(self, config, graph, word_dict=None):
        super(SelfAttentiveRNNModel, self).__init__(
            config, graph, word_dict=word_dict)
        self.output_matrix_dim = config.output_matrix_dim
        self.last_fc_dim = config.last_fc_dim

    def _penalty(self):
        p_loss = self.p_coef * self.P
        return p_loss

    def build_classification_model(self, gpu_id=0, dropout_keep_prob=1.0):
        self.build_input_sequence(gpu_id=gpu_id)
        with tf.name_scope('attention') as scope:
            last_flat, alphas, self.P = self_position_attentive(
                self.state_list[gpu_id], self.attention_size, self.output_matrix_dim)
            self.tower_attentions[gpu_id] = alphas
        last_flatten = my_full_connected(my_dropout(last_flat, rate=(
            1-dropout_keep_prob), training=self.training), self.last_fc_dim, act=tf.nn.relu)
        self.pool_flat_drop_list[gpu_id] = last_flatten


class TransformerModel(AttentionRNNModel):
    def __init__(self, config, gragh, word_dict=None):
        super(TransformerModel, self).__init__(
            config, gragh, word_dict)
        self.n_head = config.n_head
        self.position_type = config.position_type
        self.attn_drop = 1-config.keep_prob
        self.mask = False
        self.ffn_act = act_fns[config.transformer_func]
        self.ffn_drop = 1-config.keep_prob
        self.combine_mode = config.combine_mode
        self.conv_num_filters = config.conv_num_filters
        self.bi_direction = config.bi_direction

    """
    现阶段默认使用conv+transformer的形式
    def build_classification_model(self, gpu_id=0, reuse=None):
        state = self._build_position_layer(gpu_id, self.position_type, self.conv_num_filters,
                                           self.combine_mode, padding='LEFT_SAME', act=tf.nn.relu)
        for layer in range(self.num_layers):
            state = transformer2_block(state, self.n_head, attn_drop=self.attn_drop,
                                       mask=self.mask, ffn_act=self.ffn_act,
                                       ffn_drop=self.ffn_drop, training=self.training)
        self.pool_flat_drop_list[gpu_id], alpha = self_position_attention(
            state, self.attention_size)
        self.tower_attentions[gpu_id] = alphas
    """

    def build_classification_model(self, gpu_id=0):
        self._build_embedding_layer(gpu_id)
        if self.bi_direction:
            layer_func = bi_conv_transformer_layer
            self.mask = True
        else:
            layer_func = conv_transformer_layer
        self.state_list[gpu_id], self.rnn_output_list[gpu_id] = layer_func(self.input_embedding[gpu_id], self.num_layers, self.split_seqLengths[gpu_id], self.conv_num_filters, self.position_type, n_head=self.n_head, attn_drop=self.attn_drop, mask=self.mask, ffn_act=self.ffn_act, ffn_drop=self.ffn_drop, training=self.training)
        if self.bi_direction:
            self.state_list[gpu_id] = tf.concat(
                self.state_list[gpu_id], axis=-1)
        self.pool_flat_drop_list[gpu_id], alphas = self_position_attention(
            self.state_list[gpu_id], self.attention_size)
        self.tower_attentions[gpu_id] = alphas
