import numpy as np

class CharacterTable(object):
    """Given a set of characters:
    + Encode them to a one hot integer representation
    + Decode the one hot integer representation to their character output
    + Decode a vector of probabilities to their character output
    """
    def __init__(self, chars):
        """Initialize character table.
        # Arguments
            chars: Characters that can appear in the input.
        """
        self.chars = sorted(set(chars))
        self.char_indices = dict((c, i) for i, c in enumerate(self.chars))
        self.indices_char = dict((i, c) for i, c in enumerate(self.chars))

    def encode(self, C, num_rows):
        """One hot encode given string C.
        # Arguments
            num_rows: Number of rows in the returned one hot encoding. This is
                used to keep the # of rows for each data the same.
        """
        x = np.zeros(num_rows, dtype=np.int32)
        for i, c in enumerate(C):
            x[i] = self.char_indices[c]
        return x

    def decode(self, x):
        x = list(x)
        return ''.join(self.indices_char[x] for x in x)

# All the numbers, plus sign and space for padding.
chars = '0123456789+ '
ctable = CharacterTable(chars)

def generate_addtion_pairs(sample_size=50000, digits=3, invert=False, raw_text=False):
    maxlen = digits + 1 + digits
    questions = []
    expected = []
    seen = set()
    print('Generating data...')
    while len(questions) < sample_size:
        f = lambda: int(''.join(np.random.choice(list('0123456789'))
                        for i in range(np.random.randint(1, digits + 1))))
        a, b = f(), f()
        # Skip any addition questions we've already seen
        # Also skip any such that x+Y == Y+x (hence the sorting).
        key = tuple(sorted((a, b)))
        if key in seen:
            continue
        seen.add(key)
        # Pad the data with spaces such that it is always MAXLEN.
        q = '{}+{}'.format(a, b)
        query = q + ' ' * (maxlen - len(q))
        ans = str(a + b)
        # Answers can be of maximum size DIGITS + 1.
        ans += ' ' * (digits + 1 - len(ans))
        if invert:
            # Reverse the query, e.g., '12+345  ' becomes '  543+21'. (Note the
            # space used for padding.)
            query = query[::-1]
        questions.append(query)
        expected.append(ans)
    print('Total addition questions:', len(questions))
    if raw_text:
        return np.array(questions), np.array(expected)
    else:
        print('Vectorization...')
        x = np.zeros((len(questions), maxlen), dtype=np.int32)
        y = np.zeros((len(questions), digits + 1), dtype=np.int32)
        for i, sentence in enumerate(questions):
            x[i] = ctable.encode(sentence, maxlen)
        for i, sentence in enumerate(expected):
            y[i] = ctable.encode(sentence, digits + 1)
        return x, y
