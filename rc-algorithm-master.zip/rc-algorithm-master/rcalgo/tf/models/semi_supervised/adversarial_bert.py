import tensorflow as tf
import copy
from rcalgo.tf.module.layer.basic import my_dropout
from rcalgo.tf.module.encoder.bert_encoder import BertModel as BertEncoder
from rcalgo.tf.module.encoder.bert_encoder import get_shape_list, embedding_lookup, \
    embedding_postprocessor, transformer_model, get_activation, \
    create_attention_mask_from_input_mask, create_initializer
from rcalgo.tf.models.finetune.google_bert import BertClassificationModel, BertIdSequenceClassificationModel
from rcalgo.tf.training.training_utils import get_or_create_is_training, create_task_in_graph
from rcalgo.tf.models.semi_supervised.semi_utils import kl_for_logits, kl_for_log_probs, \
    compute_tsa_threshold, get_normalized_vector, linear_rampup, step_rampup, sigmoid_rampup
from rcalgo.tf.models.semi_supervised.adversarial_training import AdversarialTraining
from rcalgo.tf.utils.logging import logger
from rcalgo.tf.training.data.data import Data


class AdversarialBertEncoder(BertEncoder):
    def __init__(self,
                 config):
        self.config = copy.deepcopy(config)

    def build_embed(self, input_ids, use_one_hot_embeddings):
        with tf.variable_scope("embeddings"):
            # Perform embedding lookup on the word ids.
            embedding_output, embedding_table = embedding_lookup(
                input_ids=input_ids,
                vocab_size=self.config.vocab_size,
                embedding_size=self.config.hidden_size,
                initializer_range=self.config.initializer_range,
                word_embedding_name="word_embeddings",
                use_one_hot_embeddings=use_one_hot_embeddings)
        return embedding_output

    def forward(self, input_ids, token_type_ids, embedding_output, input_mask=None):
        input_shape = get_shape_list(input_ids, expected_rank=2)
        batch_size = input_shape[0]
        seq_length = input_shape[1]

        if token_type_ids is None:
            token_type_ids = tf.zeros(shape=[batch_size, seq_length], dtype=tf.int32)

        if input_mask is None:
            input_mask = tf.ones(shape=[batch_size, seq_length], dtype=tf.int32)

        with tf.variable_scope("embeddings"):
            # Add positional embeddings and token type embeddings, then layer
            # normalize and perform dropout.
            embedding_output = embedding_postprocessor(
                input_tensor=embedding_output,
                use_token_type=True,
                token_type_ids=token_type_ids,
                token_type_vocab_size=self.config.type_vocab_size,
                token_type_embedding_name="token_type_embeddings",
                use_position_embeddings=True,
                position_embedding_name="position_embeddings",
                initializer_range=self.config.initializer_range,
                max_position_embeddings=self.config.max_position_embeddings,
                dropout_prob=self.config.hidden_dropout_prob)

        with tf.variable_scope("encoder"):
            # This converts a 2D mask of shape [batch_size, seq_length] to a 3D
            # mask of shape [batch_size, seq_length, seq_length] which is used
            # for the attention scores.
            attention_mask = create_attention_mask_from_input_mask(
                input_ids, input_mask)

            # Run the stacked transformer.
            # `sequence_output` shape = [batch_size, seq_length, hidden_size].
            all_encoder_layers, all_encoder_attentions = transformer_model(
                input_tensor=embedding_output,
                attention_mask=attention_mask,
                hidden_size=self.config.hidden_size,
                num_hidden_layers=self.config.num_hidden_layers,
                num_attention_heads=self.config.num_attention_heads,
                intermediate_size=self.config.intermediate_size,
                intermediate_act_fn=get_activation(self.config.hidden_act),
                hidden_dropout_prob=self.config.hidden_dropout_prob,
                attention_probs_dropout_prob=self.config.attention_probs_dropout_prob,
                initializer_range=self.config.initializer_range,
                do_return_all_layers=True)

        sequence_output = all_encoder_layers[-1]
        # The "pooler" converts the encoded sequence tensor of shape
        # [batch_size, seq_length, hidden_size] to a tensor of shape
        # [batch_size, hidden_size]. This is necessary for segment-level
        # (or segment-pair-level) classification tasks where we need a fixed
        # dimensional representation of the segment.
        with tf.variable_scope("pooler"):
            # We "pool" the model by simply taking the hidden state corresponding
            # to the first token. We assume that this has been pre-trained
            first_token_tensor = tf.squeeze(sequence_output[:, 0:1, :], axis=1)
            pooled_output = tf.layers.dense(
                first_token_tensor,
                self.config.hidden_size,
                activation=tf.tanh,
                kernel_initializer=create_initializer(self.config.initializer_range))
        return pooled_output


class AdversarialBertClassificationModel(BertClassificationModel):

    def call(self, inputs, **kwargs):
        input_ids, input_mask, token_type_ids = inputs
        is_training = get_or_create_is_training()
        add_adv_pert = kwargs.get("add_adv_pert", False)
        add_vadv_pert = kwargs.get("add_vadv_pert", False)
        epsilon = kwargs.get("epsilon")
        xi = kwargs.get("xi")
        label = kwargs.get("label")

        with tf.variable_scope('bert'):
            bert_encoder = AdversarialBertEncoder(config=self.bert_config)
            embedding = bert_encoder.build_embed(input_ids, self.use_one_hot_embeddings)

            if add_adv_pert:
                one_hot_label = tf.one_hot(label, depth=self.num_classes, dtype=tf.float32)
                logits = self.forward(bert_encoder, input_ids, token_type_ids, input_mask, embedding, is_training)
                loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_label, logits=logits))
                grad = \
                    tf.gradients(loss, [embedding], aggregation_method=tf.AggregationMethod.EXPERIMENTAL_ACCUMULATE_N)[
                        0]
                grad = tf.stop_gradient(grad)
                adv_pert = epsilon * get_normalized_vector(grad)
                embedding += adv_pert

            elif add_vadv_pert:
                d = tf.random_normal(shape=tf.shape(embedding))
                d = xi * get_normalized_vector(d)
                logit_p = self.forward(bert_encoder, input_ids, token_type_ids, input_mask, embedding, is_training)
                logit_q = self.forward(bert_encoder, input_ids, token_type_ids, input_mask, embedding + d, is_training)
                loss = kl_for_logits(logit_p, logit_q)
                grad = tf.gradients(loss, [d], aggregation_method=tf.AggregationMethod.EXPERIMENTAL_ACCUMULATE_N)[0]
                grad = tf.stop_gradient(grad)
                vadv_pert = epsilon * get_normalized_vector(grad)
                embedding += vadv_pert
                logits = logit_p

            else:
                logits = self.forward(bert_encoder, input_ids, token_type_ids, input_mask, embedding, is_training)

        probs = tf.nn.softmax(logits, axis=-1)
        return logits, probs

    def forward(self, bert_encoder, input_ids, token_type_ids, input_mask, embedding_output, is_training):

        output_layer = bert_encoder.forward(input_ids, token_type_ids, embedding_output, input_mask=input_mask)
        output_layer = my_dropout(output_layer,
                                  rate=self.bert_config.hidden_dropout_prob,
                                  training=is_training)
        hidden_size = output_layer.shape[-1].value

        output_weights = tf.get_variable(
            "output_weights", [self.num_classes, hidden_size],
            initializer=tf.truncated_normal_initializer(stddev=0.02))
        output_bias = tf.get_variable(
            "output_bias", [self.num_classes],
            initializer=tf.zeros_initializer())

        logits = tf.matmul(output_layer, output_weights, transpose_b=True)
        logits = tf.nn.bias_add(logits, output_bias)
        return logits


class AdversarialBertClassTraining(AdversarialTraining):
    def __init__(self, execute_model, config, name="adv_bert_train", **kwargs):
        self.max_seq_length = config.get("max_seq_length", 128)
        self.freeze_layer_num = config.get("freeze_layer_num", 0)
        super().__init__(execute_model, config, name=name, **kwargs)

    def create_inputs(self):
        sup_input_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="sup_input_ids")
        sup_input_mask = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="sup_input_mask")
        sup_token_type_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="sup_token_type_ids")
        unsup_input_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="unsup_input_ids")
        unsup_input_mask = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="unsup_input_mask")
        unsup_token_type_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="unsup_token_type_ids")
        labels = tf.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return [sup_input_ids, sup_input_mask, sup_token_type_ids,
                unsup_input_ids, unsup_input_mask, unsup_token_type_ids], labels

    def build_core(self, sup_input_ids, sup_input_mask, sup_token_type_ids,
                   unsup_input_ids, unsup_input_mask, unsup_token_type_ids,
                   labels, **kwargs):
        with tf.variable_scope('AdvTrain', reuse=tf.AUTO_REUSE):
            sup_states, sup_outputs = self.execute_model.call([sup_input_ids, sup_input_mask, sup_token_type_ids],
                                                              add_adv_pert=False, **kwargs)
            unsup_states, unsup_outputs = self.execute_model.call(
                [unsup_input_ids, unsup_input_mask, unsup_token_type_ids],
                add_adv_pert=False, **kwargs)
            sup_pert_states, _ = self.execute_model.call([sup_input_ids, sup_input_mask, sup_token_type_ids],
                                                         add_adv_pert=True, epsilon=self.epsilon, label=labels,
                                                         **kwargs)
            unsup_pert_states, _ = self.execute_model.call([unsup_input_ids, unsup_input_mask, unsup_token_type_ids],
                                                           add_vadv_pert=True, xi=self.xi, epsilon=self.epsilon,
                                                           **kwargs)

        all_states = [sup_states, unsup_states, sup_pert_states, unsup_pert_states]

        loss = self.compute_loss(all_states, labels)
        metrics = self.compute_metrics(sup_outputs, labels)

        self.outputs = [sup_outputs]
        self.labels = [labels]
        self.loss = loss
        self.metrics = metrics

    def build_forward(self, **kwargs):
        inputs, labels = self.create_inputs()
        sup_input_ids, sup_input_mask, sup_token_type_ids, \
        unsup_input_ids, unsup_input_mask, unsup_token_type_ids = inputs
        self.build_core(sup_input_ids, sup_input_mask, sup_token_type_ids,
                        unsup_input_ids, unsup_input_mask, unsup_token_type_ids,
                        labels, **kwargs)

        self.inputs = inputs
        create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)
        return self

    def export_freeze_graph(self, *args, **kwargs):
        return self.trainer.export_freeze_graph(*args, **kwargs)

    def compute_sup_loss(self, states, labels):
        sup_state = states[0]
        sup_pert_state = states[2]
        sup_loss = self.sup_loss_core(sup_state, sup_pert_state, labels)

        return sup_loss

    def compute_unsup_loss(self, states, labels):
        unsup_loss_mask = None
        unsup_state = states[1]
        # unsup_pert_state = states[1][self.sup_batch_size:]
        unsup_pert_state = states[3]

        unsup_loss = self.unsup_loss_core(unsup_state, unsup_pert_state)

        return unsup_loss

    def filter_trainable_variables(self, tvars):
        if self.freeze_layer_num == 0:
            return tvars
        else:
            filter_keywords = [f"layer_{i}/" for i in range(self.freeze_layer_num)] + ["embeddings/"]
            filtered_tvars = []
            left_tvars = []
            for v in tvars:
                if all(keyword not in v.name for keyword in filter_keywords):
                    left_tvars.append(v)
                else:
                    filtered_tvars.append(v)
            logger.info(f"filtered vars: {filtered_tvars}, total: {len(filtered_tvars)}.")
            return left_tvars


class AdversarialBertIdSequenceTraining(AdversarialBertClassTraining):

    def create_inputs(self):
        sup_ids_str = tf.placeholder(dtype=tf.string, shape=[None], name='sup_ids_str')
        unsup_ids_str = tf.placeholder(dtype=tf.string, shape=[None], name='unsup_ids_str')
        labels = tf.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return [sup_ids_str, unsup_ids_str], labels

    def build_forward(self, **kwargs):
        inputs, labels = self.create_inputs()
        sup_ids_str, unsup_ids_str = inputs
        unsup_ids_str = tf.reshape(unsup_ids_str, [self.unsup_batch_size])

        sup_ids = tf.compat.v1.strings.split(sup_ids_str, sep=" ")
        sup_ids = tf.sparse.to_dense(sup_ids, default_value="0")
        sup_ids = tf.compat.v1.string_to_number(sup_ids, tf.int32)

        unsup_ids = tf.compat.v1.strings.split(unsup_ids_str, sep=" ")
        unsup_ids = tf.sparse.to_dense(unsup_ids, default_value="0")
        unsup_ids = tf.compat.v1.string_to_number(unsup_ids, tf.int32)

        # padding sequence
        paddings = tf.constant([[0, 0], [0, self.max_seq_length]])
        sup_ids = tf.pad(sup_ids, paddings, "CONSTANT")[:, 0:self.max_seq_length]
        sup_sequence_lengths = tf.count_nonzero(sup_ids, 1)
        unsup_ids = tf.pad(unsup_ids, paddings, "CONSTANT")[:, 0:self.max_seq_length]
        unsup_sequence_lengths = tf.count_nonzero(unsup_ids, 1)

        # create input_mask and token_type_ids
        sup_input_mask = tf.sequence_mask(sup_sequence_lengths, maxlen=self.max_seq_length)
        sup_token_type_ids = tf.zeros_like(sup_ids)
        unsup_input_mask = tf.sequence_mask(unsup_sequence_lengths, maxlen=self.max_seq_length)
        unsup_token_type_ids = tf.zeros_like(unsup_ids)

        self.build_core(sup_ids, sup_input_mask, sup_token_type_ids,
                        unsup_ids, unsup_input_mask, unsup_token_type_ids,
                        labels, **kwargs)

        self.inputs = inputs
        create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)
        return self


class SemiBertData(Data):
    @property
    def sup_data_size(self):
        return int(len(self.datasets[0]))

    @property
    def unsup_data_size(self):
        return int(len(self.datasets[3]))

    def to_tf_dataset(self):
        self.build_schema()
        sup_text_ids, sup_input_mask, sup_token_type_ids, \
        unsup_text_ids, unsup_input_mask, unsup_token_type_ids, label = self.data_schema
        if self.mode == "train":

            sup_text_ids_ds = tf.data.Dataset.from_tensor_slices(sup_text_ids)
            sup_input_mask_ds = tf.data.Dataset.from_tensor_slices(sup_input_mask)
            sup_token_type_ids_ds = tf.data.Dataset.from_tensor_slices(sup_token_type_ids)
            unsup_text_ids_ds = tf.data.Dataset.from_tensor_slices(unsup_text_ids)
            unsup_input_mask_ds = tf.data.Dataset.from_tensor_slices(unsup_input_mask)
            unsup_token_type_ids_ds = tf.data.Dataset.from_tensor_slices(unsup_token_type_ids)
            label_ds = tf.data.Dataset.from_tensor_slices(label)
            print(f"sup_data_size: {self.sup_data_size}, unsup_data_size: {self.unsup_data_size}")
            # since sup data and unsup data have different size,
            # they need to be repeat and shuffle seperately.
            total_ds = tf.data.Dataset.zip((sup_text_ids_ds.shuffle(self.sup_data_size, seed=0).repeat(),
                                            sup_input_mask_ds.shuffle(self.sup_data_size, seed=0).repeat(),
                                            sup_token_type_ids_ds.shuffle(self.sup_data_size, seed=0).repeat(),
                                            unsup_text_ids_ds.shuffle(self.unsup_data_size, seed=1).repeat(),
                                            unsup_input_mask_ds.shuffle(self.unsup_data_size, seed=1).repeat(),
                                            unsup_token_type_ids_ds.shuffle(self.unsup_data_size, seed=1).repeat(),
                                            label_ds.shuffle(self.sup_data_size, seed=0).repeat()))
            return total_ds.batch(self.batch_size).prefetch(tf.data.experimental.AUTOTUNE)
        else:
            return tf.data.Dataset.from_tensor_slices(self.data_schema).batch(self.batch_size)
