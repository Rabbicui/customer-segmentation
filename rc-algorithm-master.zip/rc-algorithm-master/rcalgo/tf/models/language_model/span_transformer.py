import tensorflow as tf

from rcalgo.tf.module.layer.ngram_process import TFNgramSpanMaskProcessor
from rcalgo.tf.metric.accuracy import varibale_topk_accuracy as variable_topk_accuracy
from rcalgo.tf.metric.loss import my_sparse_cross_entropy_loss
from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.module.encoder.transformer import conv_transformer_layer
from rcalgo.tf.module.layer.activations import act_fns
from rcalgo.tf.training.model import Model
from rcalgo.tf.training.training_utils import create_task_in_graph, get_or_create_is_training
from rcalgo.tf.utils.tf_func import get_new_variable_scope, shape_list


class NgramSpanMaskTransformersLM(Model):
    """Deprecated. 继承Model, 但大量内容从TransformerLM复制过来.
    是tfmodels.transformer_lm.MaskedTransformerLMModel的复现.
    """
    def __init__(self, config, word_dict, distribute='horovod', name='SpanMask'):
        """Will pass config and word_dict to preprocessor.

        Parameters
        ----------
        config: dict
        word_dict: dict, see preprocessor doc for more
        distribute: default 'horovod'
        name: str, name of tqdm bar, must be short
        """
        super().__init__(config, distribute, name)
        # for embedding layer
        self.embedding_size = config.get('embedding_size', 128)
        # for conv-transformers layer
        self.num_layers = config.get('num_layers', 6)
        self.conv_num_filters = config.get('conv_num_filters', 512)
        self.conv_length_list = config.get('conv_length_list', [2, 4, 8, 16])
        self.combine_mode = config.get('combine_mode', 'ADD')
        self.output_reduce_size = config.get('output_reduce_size', 0)
        self.reverse = config.get('reverse', False)
        self.position_info = config.get('position_info', True)
        self.n_head = config.get('n_head', 8)
        self.attn_drop = config.get('attn_drop', 0.5)
        self.scale = config.get('scale', True)
        self.mask = config.get('mask', False)
        self.ffn_act = act_fns[config.get('ffn_act', 'relu')]
        self.ffn_drop = config.get('ffn_drop', 0.5)
        self.is_training = get_or_create_is_training()
        # for loss function
        self.num_sampled = config.get('num_sampled', 1000)
        self.sampled_softmax = config.get('sampled_softmax', False)
        # for metric function
        self.acc_k = config.get('acc_k', 1)
        # for optimizer
        config.setdefault('clip_type', 'clip_value')
        config.setdefault('learning_rate', 0.00002)
        # declare layer, todo: as module
        self.embedding = my_embedding_layer
        self.conv_transformer = conv_transformer_layer
        self._init_preprocessor(config, word_dict, 'TFNgramSpanMaskProcessor')

    def _init_preprocessor(self, config, word_dict, name=None):
        self.preprocessor = TFNgramSpanMaskProcessor(
            config, word_dict, name)
        self.nb_words = self.preprocessor.nb_words
        self.ffn = tf.keras.layers.Dense(self.nb_words)

    def create_inputs(self):
        text = tf.compat.v1.placeholder(
            dtype=tf.string, shape=[None], name='input_text')
        masked_flag = tf.compat.v1.placeholder(
            dtype=tf.float32, shape=[None], name='masked_flag')
        return [text, masked_flag]

    def compute_metrics(self, outputs, labels):
        return variable_topk_accuracy(outputs, labels, k=self.acc_k)

    def compute_logits(self, inputs):
        inputs_shape = shape_list(inputs)
        inputs_flat = tf.reshape(inputs, [-1, inputs_shape[-1]])
        logits = self.ffn(inputs_flat)
        logits = tf.reshape(logits, [-1, inputs_shape[-2], self.nb_words])
        return logits

    @staticmethod
    def _seq_sampled_softmax_loss(inputs, logits, weights, biases, labels, num_classes, num_sampled,
                                  sampler_func=tf.random.learned_unigram_candidate_sampler,
                                  num_true=1, label_smooth=0.0, label_indices=None):
        """compute softmax loss
        Args:
            inputs: [None, hidden_size]
            logits:
            weights:
            biases:
            labels: [None]
            num_classes: vocab size
            num_sampled:
            sampler_func:
            num_true:
            label_smooth:
            label_indices:

        Returns:
            sampled softmax loss and full softmax loss
        """
        # 获取非0的位置，从而减少计算loss的时候的计算量
        if label_indices is None:
            label_mask = tf.cast(tf.sign(tf.abs(labels)), dtype=tf.int32)
            label_indices = tf.reshape(tf.compat.v2.where(tf.not_equal(label_mask, tf.constant(0, label_mask.dtype))),
                                       [-1])
        # 获取真实的需要计算的inputs和labels
        inputs_true = tf.gather(inputs, label_indices)
        labels_reshape = tf.reshape(tf.gather(labels, label_indices), [-1, 1])
        # sampler function
        # more details: https://www.orchome.com/1574
        sampled_values = sampler_func(
            labels_reshape, num_true, num_sampled, True, num_classes)
        sampled_softmax_loss = tf.nn.sampled_softmax_loss(tf.transpose(weights), biases, labels_reshape,
                                                          inputs_true, num_sampled, num_classes,
                                                          num_true, sampled_values)
        full_softmax_loss = my_sparse_cross_entropy_loss(
            labels, logits, num_classes, label_smooth)

        return sampled_softmax_loss, full_softmax_loss

    def compute_loss(self, logits, labels):
        state, logits = logits
        with get_new_variable_scope('loss'):
            weights, bias = self.ffn.weights
            sampled_softmax_loss, full_softmax_loss = self._seq_sampled_softmax_loss(state, logits,
                                                                                     weights, bias, labels,
                                                                                     self.nb_words,
                                                                                     self.num_sampled)
        if self.sampled_softmax:
            loss = sampled_softmax_loss
        else:
            loss = full_softmax_loss

        loss = tf.reduce_mean(loss)
        # todo: import loss from loss.py
        return loss

    def call(self, inputs):
        masked_inputs, mask_idx, origin_tokens, _ = self.preprocessor(
            inputs)
        embedded_state = self.embedding(
            masked_inputs,
            self.nb_words,
            self.embedding_size,
            'embedding')
        masked_length = tf.count_nonzero(masked_inputs, 1)
        # todo: as an output of preprocessor
        hidden_state, outputs = self.conv_transformer(
            embedded_state,
            self.num_layers,
            masked_length,
            self.conv_num_filters,
            self.conv_length_list,
            self.combine_mode,
            self.output_reduce_size,
            self.reverse,
            self.position_info,
            n_head=self.n_head,
            attn_drop=self.attn_drop,
            scale=self.scale,
            mask=self.mask,
            ffn_act=self.ffn_act,
            ffn_drop=self.ffn_drop,
            training=self.is_training)
        logits = self.compute_logits(hidden_state)
        mask_state = tf.gather_nd(hidden_state, mask_idx)
        mask_logits = tf.gather_nd(logits, mask_idx)
        return [mask_state, mask_logits, origin_tokens], [
                hidden_state, mask_logits, outputs]

    def build_forward(self, **kwargs):
        """Build forward propagation.
        """
        self.inputs = self.create_inputs()
        mid_tensors, self.outputs = self(self.inputs)
        states, logits, targets = mid_tensors

        self.loss = self.compute_loss([states, logits], targets)
        self.metrics = self.compute_metrics(self.outputs[1], targets)
        self.add_extra_attrs(logits)

        create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)
