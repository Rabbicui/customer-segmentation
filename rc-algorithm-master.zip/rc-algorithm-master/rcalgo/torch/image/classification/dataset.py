import os
import sys

import torch
import torchvision as tv

from rcalgo.torch.image.classification.utils import get_resolution
import numpy as np
from PIL import Image

from torchvision.datasets import VisionDataset
from torchvision.datasets.folder import default_loader



def mk_dataset(train_data=None, valid_data=None, train_tx=None, val_tx=None, batch=None):
    """
    the train_data parameter (a dict) is kept to be compatiable with the  tf image training format
    usually ,we can specify those in args

    """
    precrop, crop = get_resolution((360, 360))

    """Returns train and validation datasets."""
    if train_tx is None:
        train_tx = tv.transforms.Compose([
        tv.transforms.Resize((precrop, precrop)),
        tv.transforms.RandomCrop((crop, crop)),
        tv.transforms.RandomHorizontalFlip(),
        tv.transforms.ToTensor(),
        tv.transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ])
    if val_tx is None:
        val_tx = tv.transforms.Compose([
        tv.transforms.Resize((crop, crop)),
        tv.transforms.ToTensor(),
        tv.transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ])


    # use custom data
    train_set = CustomImageFolder(data=train_data, transform=train_tx)
    valid_set = CustomImageFolder(data=valid_data, transform=val_tx)

    print(f"Using a training set with {len(train_set)} images.")
    if valid_set is not None:
        print(f"Using a validation set with {len(valid_set)} images.")


    train_loader = torch.utils.data.DataLoader(
        train_set, batch_size=batch, shuffle=True,
        num_workers=8, pin_memory=True, drop_last=True)


    valid_loader = torch.utils.data.DataLoader(
        valid_set, batch_size=batch, shuffle=False,
        num_workers=8, pin_memory=True, drop_last=True)

    return train_set, valid_set, train_loader, valid_loader


"""
    CIFAR100Instance+Sample Dataset
    """
class CIFAR100InstanceSample(tv.datasets.CIFAR100):
    def __init__(self, root, train=True,
                 transform=None, target_transform=None,
                 download=False, k=4096, mode='exact', is_sample=True, percent=1.0):
        super().__init__(root=root, train=train, download=download,
                         transform=transform, target_transform=target_transform)
        self.k = k
        self.mode = mode
        self.is_sample = is_sample

        num_classes = 100
        num_samples = len(self.data)
        label = self.targets


        self.cls_positive = [[] for i in range(num_classes)]
        for i in range(num_samples):
            self.cls_positive[label[i]].append(i)

        self.cls_negative = [[] for i in range(num_classes)]
        for i in range(num_classes):
            for j in range(num_classes):
                if j == i:
                    continue
                self.cls_negative[i].extend(self.cls_positive[j])

        self.cls_positive = [np.asarray(self.cls_positive[i]) for i in range(num_classes)]
        self.cls_negative = [np.asarray(self.cls_negative[i]) for i in range(num_classes)]

        if 0 < percent < 1:
            n = int(len(self.cls_negative[0]) * percent)
            self.cls_negative = [np.random.permutation(self.cls_negative[i])[0:n]
                                 for i in range(num_classes)]

        self.cls_positive = np.asarray(self.cls_positive)
        self.cls_negative = np.asarray(self.cls_negative)

    def __getitem__(self, index):
        img, target = self.data[index], self.targets[index]

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = Image.fromarray(img)

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        if not self.is_sample:
            # directly return
            return img, target, index
        else:
            # sample contrastive examples
            if self.mode == 'exact':
                pos_idx = index
            elif self.mode == 'relax':
                pos_idx = np.random.choice(self.cls_positive[target], 1)
                pos_idx = pos_idx[0]
            else:
                raise NotImplementedError(self.mode)
            replace = True if self.k > len(self.cls_negative[target]) else False
            neg_idx = np.random.choice(self.cls_negative[target], self.k, replace=replace)
            sample_idx = np.hstack((np.asarray([pos_idx]), neg_idx))

            return img, target, index, sample_idx


class CustomImageFolder(VisionDataset):

    def __init__(self, data, loader=default_loader, transform=None, target_transform=None):
        super().__init__(None)
        self.samples = data['image']
        if 'label' in data:
            self.targets = data['label']
        else:
            self.targets = np.ones(len(self.samples))
        self.transform = transform
        self.target_transform = target_transform
        self.loader = loader


    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path = self.samples[index]
        target = self.targets[index]
        sample = self.loader(path)
        if self.transform is not None:
            sample = self.transform(sample)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return sample, target

    def __len__(self):
        return len(self.samples)
