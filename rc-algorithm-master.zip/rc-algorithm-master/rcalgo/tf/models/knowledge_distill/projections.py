import tensorflow as tf


def linear_projection(layer, hidden_size, name=""):
    new_layer = tf.layers.dense(
        layer, hidden_size, name=name,
        kernel_initializer=tf.truncated_normal_initializer(stddev=0.02))
    return new_layer
