# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.6.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %%
import sys, os
current_ipynb_path = os.getcwd()

print(current_ipynb_path)
sys.path.insert(0, "../../")

import pandas as pd
import tensorflow as tf

# %%
from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.models.classifier.text_classifier import TransformerClassifier

# %%
config = {
    "learning_rate": 0.0001,

    "num_classes": 2,
    "max_seq_len": 100,
    "embedding_size": 256,
    "num_layers": 2,
    "conv_num_filters": 256,
    "cluster_spec_json" : "./multiworker_training_demo/cluster_config.json",

    "model_output_dir": "./saved_models",
    "model_name": "transformer"
}

# %%
# 1. load data
data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
train_data = pd.read_csv(data_dir + 'train.csv')
test_data = pd.read_csv(data_dir + 'test.csv')
# count word dict
tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=2)
word_dict = tokenizer.word2idx

# %%
# 2. create model
model = TransformerClassifier(config, word_dict, name="default", distribute="multiworker_tf_distribute")
model.build_model()

# %%
model.train([train_data['text'], train_data['label']],
            batch_size=512,
            test_size=0.1,
            epochs=1,
            hooks=[])

# %%
input_list = [train_data['text'], train_data['label']]

# %%
dataset_size = len(input_list[0])

# %%
dataset_size%256

# %%
model.trainer.graph.get_collection('input_iter')
