import logging
import logging.config
import os
import sys
import boto3
from botocore import UNSIGNED
from botocore.config import Config
import uuid

import numpy as np
import torch
import torch.nn as nn

def s3_upload(export_path, location = 'china'):
    s3_client_config = Config(s3={"addressing_style": "virtual"}, signature_version=UNSIGNED)  # 固定配置，不可更改

    endpoint_url = "http://bs3-hb1.internal"                       # 线上环境

    client = boto3.client("s3", endpoint_url=endpoint_url, config=s3_client_config)

    loc_name = '国内'
    bucket = "tmp-rc-algo-model"  # 国内存储桶

    if location.lower()=='singapore':
        loc_name = '新加坡'
        bucket = "tmp-rc-algo-model-informal"  # 新加坡存储桶

    name = str(uuid.uuid4())
    ext = '.pt'
    key = name + ext

    client.upload_file(export_path, bucket, key)
    print(f'上线模型，临时云文件存储为：{key}，位置：{loc_name}')


def mixup_data(x, y, l):
    """Returns mixed inputs, pairs of targets, and lambda"""
    indices = torch.randperm(x.shape[0]).to(x.device)

    mixed_x = l * x + (1 - l) * x[indices]
    y_a, y_b = y, y[indices]
    return mixed_x, y_a, y_b


def mixup_criterion(criterion, pred, y_a, y_b, l):
    return l * criterion(pred, y_a) + (1 - l) * criterion(pred, y_b)


def dump(model, opt, step, savename):
    torch.save({
        "step": step,
        "state_dict": model.state_dict(),
        "optim": opt.state_dict(),
    }, savename)


def script_tracing(model, savename, example):
    example = example.cuda()
    scripted = torch.jit.trace(model, example)
    scripted.save(savename + '_tracing')
    #if is_s3_upload:
    #    s3_upload(savename + '_tracing', location)


def get_resolution(original_resolution):
    """Takes (H,W) and returns (precrop, crop)."""
    area = original_resolution[0] * original_resolution[1]
    return (160, 128) if area < 96 * 96 else (512, 480)


known_dataset_sizes = {
    'cifar10': (32, 32),
    'cifar100': (32, 32),
    'oxford_iiit_pet': (224, 224),
    'oxford_flowers102': (224, 224),
    'imagenet2012': (224, 224),
}


def get_resolution_from_dataset(dataset):
    if dataset not in known_dataset_sizes:
        raise ValueError(f"Unsupported dataset {dataset}. Add your own here :)")
    return get_resolution(known_dataset_sizes[dataset])


def get_mixup(dataset_size):
    return 0.0 if dataset_size < 20_000 else 0.1


def get_schedule(dataset_size, batch_size):
    scale = 512 // batch_size
    # if dataset_size < 20_000:
    #     return list(np.array([100, 200, 300, 400, 500]) * scale)
    # elif dataset_size < 500_000:
    #     return list(np.array([500, 3000, 6000, 9000, 10_000]) * scale)
    # elif dataset_size < 1_000_000:
    #     return list(np.array([2000, 9000, 18_000, 27_000, 30_000]) * scale)
    # elif dataset_size < 5_000_000:
    #     return list(np.array([10_000, 45_000, 90_000, 135_000, 160_000]) * scale)
    # elif dataset_size < 10_000_000:
    #     return list(np.array([30_000, 80_000, 140_000, 160_000, 200_000]) * scale)
    # else:
    #     return list(np.array([50_000, 100_000, 160_000, 200_000, 240_000]) * scale)

    if dataset_size < 1000:
        return list(np.array([20, 30, 40, 60]) * scale)
    elif dataset_size < 5000:
        return list(np.array([40, 60, 80, 100]) * scale)
    elif dataset_size < 20_000:
        return list(np.array([100, 200, 300, 400, 500]) * scale)
    elif dataset_size < 500_000:
        return list(np.array([500, 3000, 6000, 9000, 10_000]) * scale)
    else:
        return list(np.array([500, 6000, 12_000, 18_000, 20_000]) * scale)


def get_lr(step, dataset_size, base_lr=0.003, batch_size=512):
    """Returns learning-rate for `step` or None at the end."""
    supports = get_schedule(dataset_size, batch_size)
    # Linear warmup
    if step < supports[0]:
        return base_lr * step / supports[0]
    # End of training
    elif step >= supports[-1]:
        return None
    # Staircase decays by factor of 10
    else:
        for s in supports[1:]:
            if s < step:
                base_lr /= 10
        return base_lr


def setup_logger(dir, name):
    """Creates and returns a fancy logger."""
    # return logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s")
    # Why is setting up proper logging so !@?#! ugly?
    os.makedirs(os.path.join(dir, name), exist_ok=True)
    log_filename = os.path.join(dir, name, "train.log")
    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": {
                "format": "%(asctime)s [%(levelname)s] : %(message)s"
            },
        },
        "handlers": {
            "stderr": {
                "level": "INFO",
                "formatter": "standard",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stderr",
            },
            "logfile": {
                "level": "DEBUG",
                "formatter": "standard",
                "class": "logging.FileHandler",
                "filename": log_filename,
                "mode": "a",
            }
        },
        "loggers": {
            "": {
                "handlers": ["stderr", "logfile"],
                "level": "DEBUG",
                "propagate": True
            },
        }
    })
    logger = logging.getLogger(__name__)
    logger.flush = lambda: [h.flush() for h in logger.handlers]
    logger.info(f'log file is stored at: {log_filename}')
    return logger


class ProgressMeter(object):
    def __init__(self, num_batches, meters, prefix=""):
        self.batch_fmtstr = self._get_batch_fmtstr(num_batches)
        self.meters = meters
        self.prefix = prefix

    def display(self, batch, printf=print):
        entries = [self.prefix + self.batch_fmtstr.format(batch)]
        entries += [str(meter) for meter in self.meters]
        printf('\t'.join(entries))
        sys.stdout.flush()

    def _get_batch_fmtstr(self, num_batches):
        num_digits = len(str(num_batches // 1))
        fmt = '{:' + str(num_digits) + 'd}'
        return '[' + fmt + '/' + fmt.format(num_batches) + ']'


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self, name, fmt=':f'):
        self.name = name
        self.fmt = fmt
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name} {val' + self.fmt + '} ({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)


def recycle(iterable):
    """Variant of itertools.cycle that does not save iterates."""
    while True:
        for i in iterable:
            yield i


def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred)).contiguous()

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


class ModelWrapper(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, x):
        self.model.eval()
        with torch.no_grad():
            logits = self.model(x)
            outputs = nn.functional.softmax(logits, dim=-1)
        self.model.train()
        return outputs
