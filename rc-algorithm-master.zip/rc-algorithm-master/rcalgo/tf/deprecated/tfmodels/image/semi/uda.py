# coding: utf-8

import os

import tensorflow as tf
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))

from rcalgo.tf.tfmodels.image.base.base_model import BaseModel
from rcalgo.tf.tfmodels.image.base import base_model, models
from rcalgo.tf.tfmodels.image.utils import input_pipeline
from rcalgo.tf.tfmodels.image.transfer import bit_hyperrule

HOROVOD_SUPPORT = base_model.HOROVOD_SUPPORT


class BiTLRSched(tf.keras.callbacks.Callback):
    def __init__(self, base_lr, num_samples):
        self.step = 0
        self.base_lr = base_lr
        self.num_samples = num_samples

    def on_train_batch_begin(self, batch, logs=None):
        lr = bit_hyperrule.get_lr(self.step, self.num_samples, self.base_lr)
        tf.keras.backend.set_value(self.model.optimizer.lr, lr)
        self.step += 1


class UDA(BaseModel):

    def __init__(self, args):
        super(UDA, self).__init__(args)
        self.unsup_batch_size = args.unsup_ratio * self.batch_size
        self.uda_softmax_temp = args.uda_softmax_temp
        self.uda_confidence_thresh = args.uda_confidence_thresh
        self.ent_min_coeff = args.ent_min_coeff
        self.unsup_coeff = args.unsup_coeff

    def _build_data(self, batch, train_data, test_data=None):
        """
        The original UDA impl prepares supervised and unsupervised data in a offline manner.
        Here we try it online
        """
        original_resolution = [320, 320]
        if 'resolution' in train_data:
            original_resolution = train_data['resolution']
        # here we follow the rule in big transfer since we train model based on
        resize_size, crop_size = bit_hyperrule.get_resolution(original_resolution)
        data_train = input_pipeline.get_semi_uda_data(
            mode='train', batch_size=batch,
            resize_size=resize_size, crop_size=crop_size,
            mixup_alpha=bit_hyperrule.get_mixup(len(train_data['image'])),
            unsup_ratio=self.args.unsup_ratio,
            aug_magnitude=self.args.aug_magnitude,
            aug_num_layers=self.args.aug_num_layers,
            sup_data=train_data,
            unsup_data=train_data['unsup'])

        data_test = None
        if test_data is not None:
            data_test = input_pipeline.get_bit_data(
                mode='test', batch_size=batch,
                resize_size=resize_size, crop_size=crop_size,
                mixup_alpha=bit_hyperrule.get_mixup(len(train_data['image'])), data=test_data)

        def uda_reshape(features):
            return (tf.concat([features["image"],
                               features["ori_image"],
                               features["aug_image"]], 0),
                    features['label'])
        data_train = data_train.map(uda_reshape)

        if data_test is not None:
            data_test = data_test.map(
                lambda x: input_pipeline.reshape_for_keras(x, batch_size=batch, crop_size=crop_size))
        return data_train, data_test, resize_size, crop_size

    def _build_model(self, num_classes):
        # reuse the BIT backbone
        args = self.args
        filters_factor = int(args.model[-1]) * 4
        x = tf.keras.Input(shape=(None, None, 3))
        model = models.ResnetV2WithAttention(
            num_units=models.NUM_UNITS[args.model],
            num_outputs=None,
            filters_factor=filters_factor,
            name="resnet",
            trainable=True,
            dtype=tf.float32)
        model._head = tf.keras.layers.Dense(
            units=num_classes,
            use_bias=True,
            kernel_initializer="zeros",
            trainable=True,
            name="new_head/dense")
        y = model(x)
        bit_model_file = os.path.join(args.bit_pretrained_dir, f'{args.model}.h5')
        model.load_weights(bit_model_file, by_name=True)
        model.summary()
        model = tf.keras.Model(inputs=x, outputs=y)
        return model

    def _get_epochs(self, num_examples):
        lr_supports = bit_hyperrule.get_schedule(num_examples, self.args.batch)
        schedule_length = lr_supports[-1]
        return schedule_length // self.args.eval_every

    def _build_custom_callbacks(self):
        return [BiTLRSched(self.args.base_lr, self.num_samples)]

    def _build_loss(self):
        # customize the loss
        def uda_loss(y_true, y_predict):
            # the sup loss
            sup_bsz = self.batch_size
            sup_logits = y_predict[:sup_bsz]
            sup_loss = tf.nn.softmax_cross_entropy_with_logits(
                labels=y_true,
                logits=sup_logits)
            # sup_prob = tf.nn.softmax(sup_logits, axis=-1)
            sup_loss = tf.reduce_mean(sup_loss)

            total_loss = sup_loss
            # the unsup loss
            aug_bsz = self.unsup_batch_size
            ori_logits = y_predict[sup_bsz: sup_bsz + aug_bsz]
            aug_logits = y_predict[sup_bsz + aug_bsz:]
            if self.uda_softmax_temp != -1:
                ori_logits_tgt = ori_logits / self.uda_softmax_temp
            else:
                ori_logits_tgt = ori_logits
            #
            # ori_prob = tf.nn.softmax(ori_logits, axis=-1)
            # aug_prob = tf.nn.softmax(aug_logits, axis=-1)

            def _kl_divergence_with_logits(p_logits, q_logits):
                p = tf.nn.softmax(p_logits)
                log_p = tf.nn.log_softmax(p_logits)
                log_q = tf.nn.log_softmax(q_logits)

                kl = tf.reduce_sum(p * (log_p - log_q), -1)
                return kl

            #TODO try kl divergence or use mse
            aug_loss = _kl_divergence_with_logits(
                p_logits=tf.stop_gradient(ori_logits_tgt),
                q_logits=aug_logits)

            if self.uda_confidence_thresh != -1:
                ori_prob = tf.nn.softmax(ori_logits, axis=-1)
                largest_prob = tf.reduce_max(ori_prob, axis=-1)
                loss_mask = tf.cast(tf.greater(
                    largest_prob, self.uda_confidence_thresh), tf.float32)
                loss_mask = tf.stop_gradient(loss_mask)
                aug_loss = aug_loss * loss_mask

            def get_ent(logits, return_mean=True):
                log_prob = tf.nn.log_softmax(logits, axis=-1)
                prob = tf.exp(log_prob)
                ent = tf.reduce_sum(-prob * log_prob, axis=-1)
                if return_mean:
                    ent = tf.reduce_mean(ent)
                return ent

            if self.ent_min_coeff > 0:
                ent_min_coeff = self.ent_min_coeff
                per_example_ent = get_ent(ori_logits)
                ent_min_loss = tf.reduce_mean(per_example_ent)
                total_loss = total_loss + ent_min_coeff * ent_min_loss

            aug_loss = tf.reduce_mean(aug_loss)
            total_loss += self.unsup_coeff * aug_loss
            return total_loss
        return uda_loss

    def _build_metric(self):
        def uda_metric(y_true, y_pred):
            sup_bsz = self.batch_size
            sup_logits = y_pred[:sup_bsz]
            sup_pred = tf.argmax(sup_logits, axis=-1, output_type=tf.int32)
            y_true = tf.cast(y_true, dtype=tf.int32)
            is_correct = tf.to_float(tf.equal(sup_pred, y_true))
            acc = tf.reduce_mean(is_correct)
            return acc
        return [uda_metric]
