import boto3
from botocore import UNSIGNED
from botocore.config import Config
import uuid

def s3_upload(export_path, location = 'china'):
    s3_client_config = Config(s3={"addressing_style": "virtual"}, signature_version=UNSIGNED)  # 固定配置，不可更改

    endpoint_url = "http://bs3-hb1.internal"                       # 线上环境

    client = boto3.client("s3", endpoint_url=endpoint_url, config=s3_client_config)

    loc_name = '国内'
    bucket = "tmp-rc-algo-model"  # 国内存储桶

    if location.lower()=='singapore':
        loc_name = '新加坡'
        bucket = "tmp-rc-algo-model-informal"  # 新加坡存储桶

    name = str(uuid.uuid4())
    ext = '.pb'
    key = name + ext

    client.upload_file(export_path, bucket, key)
    print(f'上线模型，临时云文件存储为：{key}，位置：{loc_name}')

if __name__=='__main__':
    # tf_test
    s3_upload('/home/web_server/antispam/project/zhouyalin/data/serving/femaleVulgarClassification/frozen.pb')
    # pytorch_test
    #s3_upload('')
