import tensorflow as tf

# data training inputs placeholders.
tf.compat.v1.GraphKeys.INPUTS = 'inputs'

tf.compat.v1.GraphKeys.INPUT_ITER = 'input_iter'

# data traning targets placeholders
tf.compat.v1.GraphKeys.TARGETS = 'targets'

# prediciton output variable
tf.compat.v1.GraphKeys.OUTPUTS = 'outputs'

#training op
tf.compat.v1.GraphKeys.TRAIN_OPS = 'trainops'

#the value of loss function
tf.compat.v1.GraphKeys.LOSS = 'loss'

#the metric of current model
tf.compat.v1.GraphKeys.METRICS = 'metrics'

#custom learning rate variable
tf.compat.v1.GraphKeys.LR_VARIABLES = 'lr_variables'

#current tasks (for multiple tasks)
tf.compat.v1.GraphKeys.TASKS = 'tasks'

#traning stage or test stage
tf.compat.v1.GraphKeys.IS_TRAINING = 'is_training'

#the input dict
tf.compat.v1.GraphKeys.INPUT_DICT = 'input_dict'

#the output dict
tf.compat.v1.GraphKeys.OUTPUT_DICT = 'output_dict'

#learning rate annealing variable
tf.compat.v1.GraphKeys.LR_ANNEALING_VARIABLES = 'lr_annealing_variables'

#the training steps for task (currently only used in  GAN)
tf.compat.v1.GraphKeys.TRAIN_STEPS = 'train_steps'

#the priority for multi task. Priority will be ranked to decide the execution sequence
# smaller value has higher priority
tf.compat.v1.GraphKeys.PRIORITY = 'priority'

#for beam_search_start_token
tf.compat.v1.GraphKeys.GO_VALUE = 'go_value'

#for beam_search_start_token
tf.compat.v1.GraphKeys.STATE_BOW = 'state_bow'

#EOS SENTENCE
tf.compat.v1.GraphKeys.EOS_FLAG = 'eos_flag'

#SOS SENTENCE
tf.compat.v1.GraphKeys.SOS_FLAG = 'sos_flag'

#task type
tf.compat.v1.GraphKeys.TASK_TYPE = 'task_type'

#for TopKSampleEmbeddingHelper
tf.compat.v1.GraphKeys.TOP_K_SAMPLE = 'top_k_sample'

tf.compat.v1.GraphKeys.SOFTMAX_TEMPERATURE = 'softmax_temperature'

tf.compat.v1.GraphKeys.MASKED_FLAG = 'masked_flag'
