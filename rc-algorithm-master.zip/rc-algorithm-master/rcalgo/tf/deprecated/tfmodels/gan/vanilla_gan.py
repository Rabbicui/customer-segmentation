import sys
import os
#sys.path.insert(0,'..')
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))

from rcalgo.tf.tftraining.tf_object import *
import math

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import PIL
from IPython.display import display, Image
from tftools.tf_collections import *
from tftools.tf_layer import my_full_connected
from rcalgo.tf.tftraining.multi_training import MultiTraining, MultiTask
from rcalgo.tf.tfmodels.gan.generator import *
from rcalgo.tf.tfmodels.gan.discriminator import *
from tftools.tf_float_type import get_default_float_type


def plot(samples, sample_size, output_dim=784):
    width = int(math.sqrt(sample_size))
    output_width = int(math.sqrt(output_dim))
    fig = plt.figure(figsize=(width, width))
    gs = gridspec.GridSpec(width, width)
    gs.update(wspace=0.05, hspace=0.05)

    for i, sample in enumerate(samples):
        ax = plt.subplot(gs[i])
        plt.axis('off')
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.set_aspect('equal')
        plt.imshow(sample.reshape(output_width, output_width), cmap='Greys_r')
    return fig


class VanillaGAN(TFModelBase):
    """
    There will various different generators and discriminators to pack a GAN model.
    Each component is controlled by caller (For test)
    """

    G_TASK = 'generator'
    D_TASK = 'discriminator'

    G_PRIORITY = 2
    D_PRIORITY = 1

    def __init__(self, config, graph,
                 generator_fn=vanilla_generator,
                 discriminator_fn=vanilla_discriminator):
        super(VanillaGAN, self).__init__(config, graph)
        self.input_dim = config.input_dim
        self.hidden_dim = config.hidden_dim
        self.generator_noise_dim = config.generator_noise_dim
        self.generate_sample_size = config.generate_sample_size
        self.g_learning_rate = config.generator_learning_rate
        if self.g_learning_rate is None:
            # if g_learning_rate is not set use the common default learning_rate
            assert self.learning_rate is not None
            self.g_learning_rate = self.learning_rate
        self.d_learning_rate = config.discriminator_learning_rate
        if self.d_learning_rate is None:
            self.d_learning_rate = self.learning_rate
        self.g_steps = config.generator_train_steps
        self.d_steps = config.discriminator_train_steps
        # create optimizer for D and G
        # TODO support decay for G and D
        g_lr_params = tf.contrib.training.HParams(learning_rate=self.g_learning_rate,
                                                  global_step=self.global_step,
                                                  decay_steps=None)
        opt_params = tf.contrib.training.HParams(optimizer='adam',
                                                 adam_epsilon=config.adam_epsilon,
                                                 adam_beta1=0.5,
                                                 adam_beta2=config.adam_beta2)
        self._add_optimizer(self.G_TASK, self.g_learning_rate, lr_params=g_lr_params, opt_params=opt_params)

        d_lr_params = tf.contrib.training.HParams(learning_rate=self.d_learning_rate,
                                                  global_step=self.global_step,
                                                  decay_steps=None)
        self._add_optimizer(self.D_TASK, self.d_learning_rate, lr_params=d_lr_params, opt_params=opt_params)

        self.generator = self._wrap_fn(generator_fn)
        self.discriminator = self._wrap_fn(discriminator_fn)

        self._add_step_and_priority()

    @replace_default_graph
    def _add_step_and_priority(self):
        # add steps info into the collection
        self._add_to_graph_collection('{}_{}'.format(self.G_TASK, tf.compat.v1.GraphKeys.TRAIN_STEPS),
                                      self.g_steps)
        self._add_to_graph_collection('{}_{}'.format(self.D_TASK, tf.compat.v1.GraphKeys.TRAIN_STEPS),
                                      self.d_steps)

        # add task type
        self._add_to_graph_collection('{}_{}'.format(self.G_TASK, tf.compat.v1.GraphKeys.TASK_TYPE),
                                      MultiTask.JOINT_TYPE)
        self._add_to_graph_collection('{}_{}'.format(self.D_TASK, tf.compat.v1.GraphKeys.TASK_TYPE),
                                      MultiTask.JOINT_TYPE)

        # set the priority
        self._add_to_graph_collection('{}_{}'.format(self.G_TASK, tf.compat.v1.GraphKeys.PRIORITY),
                                      self.G_PRIORITY)
        self._add_to_graph_collection('{}_{}'.format(self.D_TASK, tf.compat.v1.GraphKeys.PRIORITY),
                                      self.D_PRIORITY)

    def build_input(self):
        with tf.name_scope('input'):
            inputX = tf.compat.v1.placeholder(get_default_float_type(), [None, self.input_dim], name='real_inputX')
            # no input for G
            self._add_to_graph_inputs([inputX], self.D_TASK)
            self.split_inputX = tf.split(inputX, self.gpu_num, 0)
            self.input_dict['input'] = self.split_inputX[0]


    def build_gan(self, batch_size, gpu_id=0, clip_type='clip_value', check_shape=True):
        """
        Build the GAN body
        This function is inside the GPU scope
        """
        # generate fake data
        g_noise = self.generate_noise(batch_size)
        g_data = self.generator(g_noise, self.training)

        # check shape
        if check_shape:
            if not g_data.shape.is_compatible_with(self.split_inputX[gpu_id].shape):
                raise ValueError(
                    'Generator output shape (%s) must be the same shape as real data '
                    '(%s).' % (g_data.shape, self.split_inputX[gpu_id].shape))

        # save for later use
        generate_sample = self.generator(
            tf.random_uniform([self.generate_sample_size, self.generator_noise_dim], minval=-1.0,
                              maxval=1.0), self.training, reuse=True)
        self.tower_prediction_results.append(generate_sample)

        # use discriminator to create logits
        real_logits = self.discriminator(self.split_inputX[gpu_id])
        fake_logits = self.discriminator(g_data, reuse=True)

        # get losses
        g_loss = self.generator_loss(fake_logits)
        d_loss = self.discriminator_loss(real_logits, fake_logits)

        # create the train op
        g_params = tf.compat.v1.get_collection(self.G_TASK)
        g_grads, g_capped_gvs = my_compute_grad(self.opt[self.G_TASK], g_loss, g_params,
                                                clip_type=clip_type,
                                                max_clip_grad=self.clip_gradients)
        g_metric = - g_loss
        self._add_to_tower_list(g_grads, g_capped_gvs, g_loss, g_metric, task=self.G_TASK)

        d_params = tf.compat.v1.get_collection(self.D_TASK)
        d_grads, d_capped_gvs = my_compute_grad(self.opt[self.D_TASK], d_loss, d_params,
                                                clip_type=clip_type,
                                                max_clip_grad=self.clip_gradients)
        d_metric = - d_loss
        self._add_to_tower_list(d_grads, d_capped_gvs, d_loss, d_metric, task=self.D_TASK)

    @replace_default_graph
    def build_model(self):
        self.build_input()
        g_batch_size = int(self.batch_size / len(self.gpus))  # god hope is divisible
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % gpu_id) as name_scope:
                    reuse = idx != 0
                    gpu_scope = tf.compat.v1.variable_scope('gpu_gan', reuse=reuse)
                    with gpu_scope as vs:
                        self.build_gan(g_batch_size, gpu_id)

        # merge the loss, metric, gradient from gpus
        # a little tricky here, the job will be initiated in this func, thus all ops or states must
        # be written into collection before
        self.build_model_aggregation()

    def _wrap_fn(self, func):
        def wrapper(*args, **kw):
            return func(self, *args, **kw)

        return wrapper

    def _init_training_job(self):
        """
        Init the MultiTaskTraining
        """
        # create training procedure
        self.job = MultiTraining(model_input_dir=self.model_dir,
                                 model_name=self.model_name,
                                 model_output_dir=self.model_dir,
                                 logs_dir=self.logs_dir,
                                 save_checkpoint=self.epoch_save,
                                 graph=self.graph)

    def generate_noise(self, batch_size):
        """
        Generate noise tensor used as input for generator

        Args:
            batch_size:  The size of each batch

        Returns:
            A Tensor of shape [batch_size, self.generate_noise_dim]
        """
        with tf.name_scope('generate_noise') as scope:
            return tf.random_normal([batch_size, self.generator_noise_dim])

    def generator_loss(self, logits, label_smoothing=0.0, reduction=tf.losses.Reduction.SUM_BY_NONZERO_WEIGHTS):
        """
        The modified minimax generator loss for GAN
        L = -log(sigmoid(D(G(z))))

        Args:
            logits:    Discriminator output on generated data. Expected to be in the
                range of (-inf, inf).
            label_smoothing:  The amount of smoothing for positive labels. See
                (https://arxiv.org/abs/1606.03498)
            reduction:  A `tf.losses.Reduction` to apply to loss.

        Returns:
            A loss tensor
        """
        with tf.name_scope('generator_loss') as scope:
            return tf.reduce_mean(tf.losses.sigmoid_cross_entropy(logits=logits,
                                                                  multi_class_labels=tf.ones_like(
                                                                      logits),
                                                                  label_smoothing=label_smoothing,
                                                                  reduction=reduction))

    def discriminator_loss(self, real_logits, fake_logits, label_smoothing=0.25,
                           reduction=tf.losses.Reduction.SUM_BY_NONZERO_WEIGHTS):
        """
        The minimax discriminator loss for GAN
        L = log(sigmoid(D(x))) + log(1 - sigmoid(D(G(z))))

        Args:
            real_logits:  Discriminator output on real data.
            fake_logits:  Discriminator output on generated data. Expected to be in the
                range of (-inf, inf).
            label_smoothing: The amount of smoothing for positive labels. See
                (https://arxiv.org/abs/1606.03498)
            reduction:    A `tf.losses.Reduction` to apply to loss.:

        Returns:
            A loss tensor

        """
        with tf.name_scope('discriminator_loss') as scope:
            # -log((1 - label_smoothing) - sigmoid(D(x)))
            loss_real = tf.reduce_mean(tf.losses.sigmoid_cross_entropy(logits=real_logits,
                                                                       multi_class_labels=tf.ones_like(
                                                                           real_logits),
                                                                       label_smoothing=label_smoothing,
                                                                       reduction=reduction))

            # -log(- sigmoid(D(G(x))))
            loss_fake = tf.reduce_mean(tf.losses.sigmoid_cross_entropy(logits=fake_logits,
                                                                       multi_class_labels=tf.zeros_like(
                                                                           fake_logits),
                                                                       reduction=reduction))

            return loss_real + loss_fake

    def run(self, data_dict, task_names=['generator', 'discriminator'], default_random_seed=42):
        self.job.train(data_dict, joint_n_epochs=self.n_epochs, task_names=task_names)


class WGANModel(VanillaGAN):

    def __init__(self, config, graph):
        super(WGANModel, self).__init__(config, graph)

    def generator_loss(self, logits, reduction=tf.losses.Reduction.SUM_BY_NONZERO_WEIGHTS):
        """
        Wasserstein generator loss for GANs. (https://arxiv.org/abs/1701.07875)
        """

        with tf.name_scope('w_generator_loss') as scope:
            return -tf.reduce_mean(logits)

    def discriminator_loss(self, real_logits, fake_logits, reduction=tf.losses.Reduction.SUM_BY_NONZERO_WEIGHTS):
        with tf.name_scope("w_discriminator_loss") as scope:
            return tf.reduce_mean(fake_logits) - tf.reduce_mean(real_logits)

    # def build_model(self, type=['discriminator','generator'], clip_type=None):
    #     super(WGANModel, self).build_model(type=type)
    #     self.clip_D = [p.assign(tf.clip_by_value(p, -0.01, 0.01)) for p in tf.compat.v1.get_collection('discriminator')]
    #     self.fetch_dict['{}_prediction'.format(type[0])].append(self.clip_D)
    #     self.opt._momentum = 0.0
#
#
# class WGANGPModel(VillinaGANModel):
#     def __init__(self, config, sess):
#         super(WGANGPModel, self).__init__(config, sess)
#
#     def gradient_penalty(self, gpu_id, lam=10):
#         batch_size = array_ops.shape(self.split_inputX[gpu_id])[0]
#         eps = tf.random_uniform([batch_size, 1], minval=0., maxval=1.)
#         X_inter = eps*self.split_inputX[gpu_id] + (1. - eps)*self.G_sample[gpu_id]
#         grad = tf.gradients(self.discriminator(X_inter,True), [X_inter])[0]
#         grad_norm = tf.sqrt(tf.reduce_sum((grad)**2, axis=1))
#         grad_pen = lam * tf.reduce_mean(grad_norm - 1.)**2
#         return grad_pen
#
#     def get_discriminator_generator_loss(self, gpu_id, D_logit_real, D_logit_fake):
#         grad_pen = self.gradient_penalty(gpu_id)
#         D_loss = tf.reduce_mean(D_logit_fake) - tf.reduce_mean(D_logit_real) + grad_pen
#         G_loss = - tf.reduce_mean(D_logit_fake)
#         return D_loss, G_loss
#
#     @replace_default_graph
#     def build_model(self, type=['discriminator','generator'], clip_type=None):
#         super(WGANGPModel, self).build_model(type=type)
#         self.opt._beta1=0.5
