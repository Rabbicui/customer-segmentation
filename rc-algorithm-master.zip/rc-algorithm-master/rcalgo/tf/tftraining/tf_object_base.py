import os
import sys

sys.path.append(os.path.join(os.path.abspath(
    os.path.dirname(__file__)), "../"))

from rcalgo.tf.utils.hparams import *
from rcalgo.tf.utils.tf_float_type import get_default_float_type, set_default_float_type
from rcalgo.tf.optimizer.lr_schedule import *
from rcalgo.tf.optimizer.weight_decay_optimizers import AdamWOptimizer
from rcalgo.tf.utils.tf_func import replace_default_graph, average_gradients, get_from_collection_or_create, \
    model_logger_dir_prepare


lr_schedules = {
    'cosine':warm_up_cosine_decay,
    'linear':warm_up_linear_decay,
    'noam':noam_learning_rate_schedule
}

class TFModelBase(object):
    def __init__(self, config, graph):
        """
        model_name: record model with task name, for ckpt
        """
        self.graph = graph
        self.batch_size = config.batch_size  # batch size to use during training
        self.clip_gradients = config.clip_gradients  # max clip gradients

        self.n_epochs = config.n_epochs  # number of epoch to use during training
        self.epoch_save = config.epoch_save  # save checkpoint or not in each epoch
        self.logs_dir = config.logs_dir
        self.model_dir = config.model_dir
        self.serving_dir = config.serving_dir
        self.model_name = config.model_name
        self.label_smooth = config.label_smooth
        self.debug_mode = config.debug_mode
        if not os.path.isdir(self.logs_dir):
            os.makedirs(self.logs_dir)
        if not os.path.isdir(self.model_dir):
            os.makedirs(self.model_dir)

        self.dir_clear = config.dir_clear
        if self.dir_clear:
            model_logger_dir_prepare(
                self.logs_dir, self.model_dir, self.model_name)

        self.device_str = '/gpu:'
        #self.device_str = '/cpu:'
        self.gpu_num = config.gpu_num
        self.gpus = range(config.gpu_id, config.gpu_id + self.gpu_num)

        # for summary
        self.loss_list = []
        self.optim_list = []
        self.grad_list = []
        self.capped_grad_list = []
        self.metrics_list = []

        # for multiple gpus
        self.tower_grads = {}
        self.tower_capped_gvs = {}
        self.tower_loss = {}
        self.tower_metrics = {}
        self.tower_prediction_results = []
        self.params = None
        self.prediction_results = None

        # can be used default
        self.lr = {}
        self.lr_value_dict = {}
        self.opt = {}

        # there may be multi tasks, here we assume the default one (subclass set their own names)
        self.default_task_name = config.task_name if hasattr(
            config, 'task_name') else 'default'

        self.global_step = None
        # build default setting
        # TODO the global step should be related to task 
        self._build_global_setting(self.default_task_name)
        self._set_training_placeholder()

        self.learning_rate = config.learning_rate

        # mixed precision training
        self.mp_training = config.mp_training
        self.loss_scaling = config.loss_scaling
        self.loss_scale_factor = config.loss_scale_factor
        if self.mp_training:
            set_default_float_type(tf.float16)

        if self.learning_rate is not None:
            # the common learning_rate has been set, the lr_variable and opt will be bind to default_task_name
            # subclass can utilize this default one or parse their specific settings
            if hasattr(config, 'opt'):
                opt_str = config.opt.lower()
            else:
                opt_str = 'adam'

            # learning rate
            self.lr_annealing = True if opt_str == 'sgd' and config.total_update == None else config.lr_annealing
            self.lr_annealing_value = config.lr_annealing_value
            self.lr_stop_value = config.lr_stop_value

            # build learning_rate_params
            self.lr_params = HParams({'schedule': config.learning_rate_schedule,
                                      'learning_rate': self.learning_rate,
                                      'global_step': self.global_step,
                                      'decay_steps': config.total_update,
                                      'warmup_steps': config.learning_rate_warmup_steps,
                                      'warmup': config.learning_rate_warmup,
                                      'noam_hidden_size': config.learning_rate_noam_hidden_size})
            # build optimizer params
            self.opt_params = HParams({'optimizer': opt_str,
                                       'adam_epsilon': config.adam_epsilon,
                                       'adam_beta1': config.adam_beta1,
                                       'adam_beta2': config.adam_beta2,
                                       'adam_wd': config.adam_wd})

            self._add_optimizer(self.default_task_name,
                                self.lr_params.learning_rate,
                                self.lr_params,
                                self.opt_params)

        # TODO: remove the two dicts.
        self.input_dict = {}
        self.output_dict = {}

        self.use_tf_dataset = config.use_tf_dataset
        self.job = None


    ####################################   model init   ####################################

    @replace_default_graph
    def _set_training_placeholder(self):
        self.training = get_from_collection_or_create(
            tf.compat.v1.GraphKeys.IS_TRAINING,
            lambda: tf.compat.v1.placeholder_with_default(tf.constant(False), tf.TensorShape(None), name='training')
        )

    @replace_default_graph
    def _add_optimizer(self, task, learning_rate, lr_params, opt_params):
        """
        Create the optimizer, learning_rate and add to self.opt dict
        """

        # build learning rate
        lr_annealing_var = tf.Variable(1.0, trainable=False, dtype=tf.float32)
        self._add_to_graph_collection('{}_{}'.format(task, tf.compat.v1.GraphKeys.LR_ANNEALING_VARIABLES),
                                      lr_annealing_var)
        if lr_params.decay_steps is not None:
            lr_var = lr_annealing_var * lr_schedules[lr_params.schedule](lr_params)
        else:
            lr_var = learning_rate * lr_annealing_var

        self.lr[task] = lr_var
        self.lr_value_dict[task] = learning_rate
        # add lr to collection
        self._add_to_graph_collection('{}_{}'.format(task, tf.compat.v1.GraphKeys.LR_VARIABLES),
                                      self.lr[task])

        # build optimizer
        opt_str = opt_params.optimizer
        # set optimizer
        if opt_str == 'sgd':
            self.opt[task] = tf.train.GradientDescentOptimizer(self.lr[task],
                                                               name='GradientDescent_{}'.format(
                                                                   task))
        elif opt_str == 'rmsprop':
            self.opt[task] = tf.train.RMSPropOptimizer(self.lr[task],
                                                       momentum=0.9,
                                                       name='RMSProp_{}'.format(task))
        elif opt_str == 'adam':
            if get_default_float_type() == tf.float16:
                opt_params.adam_epsilon = max(1e-4, opt_params.adam_epsilon)
            self.opt[task] = tf.compat.v1.train.AdamOptimizer(self.lr[task],
                                                    opt_params.adam_beta1,
                                                    opt_params.adam_beta2,
                                                    opt_params.adam_epsilon,
                                                    name='Adam_{}'.format(task))
        elif opt_str == 'adamw':
            self.opt[task] = AdamWOptimizer(opt_params.adam_wd,
                                            self.lr[task],
                                            opt_params.adam_beta1,
                                            opt_params.adam_beta2,
                                            opt_params.adam_epsilon,
                                            name='AdamW_{}'.format(task))
        else:
            raise ValueError('the opt string must be in (sgd, rmsprop, adam, adamW)')

        if self.loss_scaling:
            loss_scale_manager = tf.contrib.mixed_precision.FixedLossScaleManager(self.loss_scale_factor)
            self.opt[task] = tf.contrib.mixed_precision.LossScaleOptimizer(self.opt[task], loss_scale_manager)

    @replace_default_graph
    def _update_optimizer(self, task, lr_params, opt_params, old_task=None, learning_rate=0.0):
        """
        update or add optimizer with learning rate
        """
        if old_task in self.lr_value_dict:
            self.lr_value_dict[task] = self.lr_value_dict.pop(old_task)
            self.lr[task] = self.lr.pop(old_task)
            self.opt[task] = self.opt.pop(old_task)
        else:
            self._add_optimizer(task, learning_rate, lr_params, opt_params)

    @replace_default_graph
    def _build_global_setting(self, task=None):
        """
        basic global setting for all dl models
        including:
            global_step for training&testing
            add optimizer with learning rate
        """
        with tf.name_scope('global'):
            self.global_step = tf.Variable(
                0.0, trainable=False, name='global_step', dtype=tf.float32)

####################################   tf collection variables   ####################################

    def _add_to_graph_collection(self, key, var_list):
        """
        add var_list to tensorflow collection via given key
        """
        if not isinstance(var_list, list):
            tf.compat.v1.add_to_collection(key, var_list)
        else:
            for each_input in var_list:
                if not isinstance(each_input, list):
                    tf.compat.v1.add_to_collection(key, each_input)

    # TODO: refactor this & the inference system to support multi-task inference
    def _add_to_graph_input_dict(self, var_list):
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.INPUT_DICT, var_list)
        
    def _add_to_graph_collection_by_key(self, var_list, graph_key, task=None):
        if task is None:
            task = self.default_task_name
        self._add_to_graph_collection('{}_{}'.format(
            task, graph_key), var_list)
 
    def _add_to_graph_inputs(self, var_list, task=None):
        self._add_to_graph_collection_by_key(var_list, tf.compat.v1.GraphKeys.INPUTS)

    def _add_to_graph_input_iter(self, var_list, task=None):
        self._add_to_graph_collection_by_key(var_list, tf.compat.v1.GraphKeys.INPUT_ITER)

    def _add_to_graph_targets(self, var_list, task=None):
        self._add_to_graph_collection_by_key(var_list, tf.compat.v1.GraphKeys.TARGETS)

    def _add_to_graph_outputs(self, var_list, task=None):
        self._add_to_graph_collection_by_key(var_list, tf.compat.v1.GraphKeys.OUTPUTS)


####################################    mutiple gpus results op   ####################################

    def _init_tower_list(self, task):
        """
        init tower dicts for multiple gpus
        """
        self.tower_grads[task] = []
        self.tower_capped_gvs[task] = []
        self.tower_loss[task] = []
        self.tower_metrics[task] = []

    def _add_to_tower_list(self, grads, capped_gvs, loss, metric, task=None):
        """
        add grads, clig grads, loss, metrics to tower dicts
        """
        if task is None:
            task = self.default_task_name
        if task not in self.tower_grads:
            self._init_tower_list(task)
        self.tower_grads[task].append(grads)
        self.tower_capped_gvs[task].append(capped_gvs)
        self.tower_loss[task].append(loss)
        self.tower_metrics[task].append(metric)


####################################    mutiple gpus results aggregation   ####################################

    def _prediction_aggregation(self):
        """
        merge prediction results
        """
        if len(self.tower_prediction_results) != 0:
            self.prediction_results = []
            for i in range(0, int(len(self.tower_prediction_results)/self.gpu_num)):
                temp = [self.tower_prediction_results[i] for i in range(i, len(
                    self.tower_prediction_results), int(len(self.tower_prediction_results)/self.gpu_num))]
                self.prediction_results.append(tf.concat(temp, 0))
                self.output_dict['prediction_{}'.format(
                    i)] = temp[0]
            if len(self.prediction_results) == 1:
                self.prediction_results = self.prediction_results[0]

    def build_model_aggregation(self):
        """
        aggregate the gradients, loss, metrics
        """
        for key in self.tower_grads.keys():
            grads_avg = average_gradients(self.tower_grads[key])
            capped_gvs_avg = average_gradients(self.tower_capped_gvs[key])
            # each tower has reduce_mean
            if len(self.tower_loss[key][0].shape) == 0:
                #loss = tf.reduce_mean(self.tower_loss[key])
                loss = tf.reduce_mean(self.tower_loss[key])
            else:  # each tower has a loss list
                #loss = tf.concat(self.tower_loss[key], 0)
                loss = tf.reduce_mean(tf.concat(self.tower_loss[key], 0))
            if len(self.tower_metrics[key][0].shape) == 0:
                metric = tf.reduce_mean(self.tower_metrics[key])
            else:
                metric = tf.reduce_mean(tf.concat(self.tower_metrics[key], 0))
            tmp_key = key if key in self.opt else self.default_task_name
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops):
                # force update the update ops
                train_op = self.opt[tmp_key].apply_gradients(capped_gvs_avg,
                                                             global_step=self.global_step)
            # add train_op loss to collection, task specific
            for graph_key, graph_var in zip([tf.compat.v1.GraphKeys.TRAIN_OPS, tf.compat.v1.GraphKeys.LOSS, tf.compat.v1.GraphKeys.METRICS], [train_op, loss, metric]):
                self._add_to_graph_collection("{}_{}".format(key, graph_key), graph_var)
            # add task collections without key prefix
            self._add_to_graph_collection(tf.compat.v1.GraphKeys.TASKS, key)
            self._add_details(loss, train_op, grads_avg,
                              capped_gvs_avg, metric)
        self._prediction_aggregation()
        # dump dict
        self._add_to_graph_collection(
            tf.compat.v1.GraphKeys.INPUT_DICT, list(self.input_dict.values()))
        self._add_to_graph_collection(
            tf.compat.v1.GraphKeys.OUTPUT_DICT, list(self.output_dict.values()))
        # init training job
        self._init_training_job()

###############################################################################################################################

    def _init_training_job(self):
        raise NotImplementedError

    def _add_details(self, loss, optim, grads, capped_gvs, metric):
        """
        add results for summary
        """
        self.loss_list.append(loss)
        self.optim_list.append(optim)
        self.grad_list.append(grads)
        self.capped_grad_list.append(capped_gvs)
        self.metrics_list.append(metric)

    @replace_default_graph
    def build_model_summary(self, summary_step=0):
        """
        build model summary op
        """
        self.job.build_model_summary(self.loss_list, self.metrics_list,
                                     self.grad_list, self.capped_grad_list, summary_step)

    @replace_default_graph
    def model_summary(self):
        return self.job.model_summary()

####################################    model training   ####################################
    def run(self, input_list, test_size, run_type=None, default_random_seed=42):
        raise NotImplementedError

    def model_run(self, input_list, test_size, run_type=None, mode='train', default_random_seed=42):
        raise NotImplementedError

    def model_run_output(self, input_list, run_type=None):
        raise NotImplementedError


    def dump_model(self, model_version, clear_devices=True):
        self.job.dump_model(self.serving_dir, model_version, clear_devices)

    def model_restore(self, model_path=None):
        self.job.restore_checkpoint_from_output(model_path)
