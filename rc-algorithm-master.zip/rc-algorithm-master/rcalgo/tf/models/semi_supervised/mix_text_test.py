import tensorflow as tf
from rcalgo.tf.models.semi_supervised.mix_text import MixText, MixTextData
from rcalgo.tf.models.semi_supervised.mix_bert import MixBertModel


class MixTextTest(tf.test.TestCase):

    def test_MixText(self):
        batch_size = 32
        unsup_ratio = 1
        gpu_num = 2
        num_epochs = 20
        num_train_steps = num_epochs * 400 // (batch_size * gpu_num)
        print(f"num_train_steps: {num_train_steps}")
        config = {
            # mix text config
            "mix_type": "mix_sentence_hidden",
            "lambda_u": 1,
            "lambda_u_hinge": 1,
            "batch_size": batch_size,
            "epoch_num": num_epochs,
            "num_train_steps": num_train_steps,
            "T": 0.5,
            "unsup_ratio": unsup_ratio,
            "aug_num": 1,
            "gpu_id": 0,
            "gpu_num": gpu_num,
            "num_classes": 2,

            # model config
            "max_seq_length": 128,
            "epochs": 4,
            "test_size": 0.1,
            "batch_size": 32,
            "warmup_proportion": 0.1,

            "learning_rate": 0.0001,

            "vocab_file": "/home/web_server/antispam/project/pretrained_models/"
                          "chinese_L-12_H-768_A-12/vocab.txt",
            "checkpoint_file": "/home/web_server/antispam/project/pretrained_models/"
                               "chinese_L-12_H-768_A-12/bert_model.ckpt"
        }
        tf.compat.v1.reset_default_graph()
        model = MixBertModel(config=config, name="default", distribute="tf_distribute")
        mix_text_model = MixText(config=config, execute_model=model, name="default", distribute="tf_distribute")
        mix_text_model.build_model()

        print(mix_text_model.model_summary())
        print(mix_text_model.loss)


if __name__ == "__main__":
    tf.test.main()
