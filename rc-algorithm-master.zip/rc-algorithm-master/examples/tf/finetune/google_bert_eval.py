import pandas as pd
import tensorflow as tf
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, accuracy_score

from rcalgo.tf.models.finetune.google_bert import BertClassificationModel
from rcalgo.tf.models.finetune.google_bert import BertIdSequenceClassificationModel
from rcalgo.tf.utils.preprocessors import BertSentencePreprocessor
from rcalgo.tf.training import Model


def calc_metrics(probs, labels, threshold=0.5):
    preds = (probs > threshold)
    accuracy = accuracy_score(labels, preds)
    precision = precision_score(labels, preds)
    recall = recall_score(labels, preds)
    f1 = f1_score(labels, preds)
    auc = roc_auc_score(labels, probs)
    print("positive num: %s" % sum(preds))
    print(f"accuracy: {accuracy}\nprecision: {precision}\nrecall: {recall}"
          f"\nf1_score: {f1}\nauc: {auc}\n")


config = {
    "batch_size": 128,
    "max_seq_length": 128,
    "vocab_file": "/home/web_server/antispam/project/pretrained_models/"
                  "chinese_L-12_H-768_A-12/vocab.txt",
}


def main(_):
    # 1. load train data
    input_file = "/home/web_server/antispam/project/datasets/female_vulgar/test.csv"
    test_data = pd.read_csv(input_file)
    preprocessor = BertSentencePreprocessor(config["vocab_file"])
    # input_ids, input_mask, segment_ids = preprocessor.process(
    #     test_data["text"], max_seq_length=config["max_seq_length"])
    test_data['input_ids'] = test_data['text'].map(
        lambda x: preprocessor.convert_text_to_ids_string(x))

    # model = Model.from_checkpoint("./saved_models/distilled_model-epoch35.ckpt")
    # model = Model.from_checkpoint("./saved_models/google_bert-epoch3.ckpt", name="default")

    # model = BertClassificationModel().build_model()
    model = BertIdSequenceClassificationModel().build_model()
    model.restore_weights("/home/web_server/antispam/project/zhouyalin/model_checkpoints/"
                          "google_bert_female_vulgar/google_bert-epoch3.ckpt")
    # model.restore_weights("./saved_models/google_bert-epoch3.ckpt")
    # model.restore_weights("./saved_models/google_bert_tmp-epoch0.ckpt")
    print(model.model_summary())

    # results = model.predict([input_ids, input_mask, segment_ids],
    results = model.predict([test_data['input_ids']],
                            batch_size=config["batch_size"],
                            hooks=[])
    calc_metrics(results[0][:, 1], test_data['label'], 0.5)


if __name__ == '__main__':
    tf.app.run()
