import os
import cv2
import torch
import torchvision
import numpy as np

from tqdm import tqdm
from torch.utils import data
from PIL import ImageDraw, Image
from IPython.display import display

use_cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if use_cuda else "cpu")


def clip_coords(boxes, img_shape):
    # Clip bounding xyxy bounding boxes to image shape (height, width)
    boxes[:, 0].clamp_(0, img_shape[1])  # x1
    boxes[:, 1].clamp_(0, img_shape[0])  # y1
    boxes[:, 2].clamp_(0, img_shape[1])  # x2
    boxes[:, 3].clamp_(0, img_shape[0])  # y2


def scale_coords(img1_shape, coords, img0_shape, ratio_pad=None):
    # Rescale coords (xyxy) from img1_shape to img0_shape
    if ratio_pad is None:  # calculate from img0_shape
        gain = min(
            img1_shape[0] /
            img0_shape[0],
            img1_shape[1] /
            img0_shape[1])  # gain  = old / new
        pad = (img1_shape[1] - img0_shape[1] * gain) / \
            2, (img1_shape[0] - img0_shape[0] * gain) / 2  # wh padding
    else:
        gain = ratio_pad[0][0]
        pad = ratio_pad[1]

    coords[:, [0, 2]] -= pad[0]  # x padding
    coords[:, [1, 3]] -= pad[1]  # y padding
    coords[:, :4] /= gain
    clip_coords(coords, img0_shape)
    return coords


def show_img(image_path, bboxs, labels, resize=None):
    image = Image.open(image_path)  # 打开一张图片
    if resize is not None:
        image = image.resize(resize)
    draw = ImageDraw.Draw(image)  # 在上面画画
    for bbox, lable in zip(bboxs, labels):
        xmin, ymin, xmax, ymax = bbox
        left_top = (xmin, ymin - 10)
        # [左上角x，左上角y，右下角x，右下角y]，outline边框颜色
        draw.rectangle(bbox, outline="yellow")
        draw.text(left_top, lable, (255, 100, 255))

    display(image)  # or other show method
    return


def image_process_manual(image_bytes,
                         new_shape=(640, 640),
                         pad_stride=640,
                         pad_color=(114, 114, 114),
                         gray=False):
    img = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)
    shape = img.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - \
        new_unpad[1]  # wh padding
    dw, dh = np.mod(dw, pad_stride), np.mod(dh, pad_stride)  # wh padding
    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left,
                             right, cv2.BORDER_CONSTANT,
                             value=pad_color)  # add border

    # Convert
    if gray:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, to 3x416x416

    img = img.astype(np.float)
    img /= 255.0  # 0 - 255 to 0.0 - 1.0
    img = np.ascontiguousarray(img)
    img_tensor = torch.from_numpy(img)
    img_tensor = img_tensor.float()

    return img_tensor


class Dataset(data.Dataset):
    def __init__(self, file_names, transform=None):
        self.dataset = file_names
        self.transform = transform  # Augmentation Transforms

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        file_name = self.dataset[idx]
        try:
            with open(file_name, 'rb') as f:
                image_bytes = f.read()
        except Exception as e:
            print("read file %s error!" % file_name)

        if self.transform is not None:
            img_tensor = self.transform(image_bytes)
        return img_tensor, file_name


def create_dataloader(file_names):
    valid_set = Dataset(file_names, transform=image_process_manual)
    valid_loader = torch.utils.data.DataLoader(
        valid_set, batch_size=1, shuffle=False,
        num_workers=1, pin_memory=True, drop_last=False)

    data_loader = tqdm(valid_loader)
    return data_loader


def fetch_model(model_path=""):
    model = torch.jit.load(model_path)
    model = model.to(device)
    model.eval()
    return model


def predict(model_path, test_imgs):
    """
    预测图片数据，返回预测结果
    :param model_path: tracing的模型路径，eg：'./demo/best.tracing.pt'
    :param test_imgs: 测试图片列表，eg: ['./test_imgs/**.jpg', './test_imgs/**.jpg']
    :return: 图片路径, 预处理的shape, 模型预测结果
    """
    model = fetch_model(model_path)
    data_loader = create_dataloader(test_imgs)

    outputs, img_paths, process_shape = [], [], []
    for x, f_name in data_loader:
        with torch.no_grad():
            x = x.to(device, non_blocking=True)
            img_shape = tuple(x.shape[2:])
            output = model(x)
            output_list = output.cpu().numpy().tolist()[0]
            outputs.append(output_list)
            img_paths.append(f_name[0])
            process_shape.append(img_shape)

    return img_paths, process_shape, outputs


def show_bbox(cls_map, img_paths, process_shape, outputs, thr=0.5):
    """
    根据模型的输出结果，在原图片中进行画框展示
    :param cls_map: 类别detail， eg：{0: "GuoQi", 1: "GuoHui", 2: "HongLingJin"}
    :param img_paths: 图片的路径，eg: ['./test_imgs/**.jpg', './test_imgs/**.jpg']
    :param process_shape: 经过预处理后的图片shape，用于bbox还原到原图时缩放比例的计算[(640,640), (640,640)]
    :param outputs: 模型的输出结果[out1, out2], out1和out2是长度为600的一维列表
    :param thr: 只展示大于thr的框
    :return:
    """
    for file_path, img_shape, obj_bbox in zip(
            img_paths, process_shape, outputs):
        img_raw = cv2.imread(file_path)
        obj_bbox_torch = torch.from_numpy(np.array(obj_bbox).reshape((-1, 6)))
        obj_bbox_torch[:, :4] = scale_coords(
            img_shape, obj_bbox_torch[:, :4], img_raw.shape).round()
        obj_bbox_np = obj_bbox_torch.numpy().reshape(-1)
        obj_bbox_detail = [obj_bbox_np[i: i + 6]
                           for i in range(0, len(obj_bbox_np), 6)]

        bboxs, labels = [], []
        for bbox_info in obj_bbox_detail:
            xmin = int(bbox_info[0])
            ymin = int(bbox_info[1])
            xmax = int(bbox_info[2])
            ymax = int(bbox_info[3])
            prob = bbox_info[4]
            if float(prob) < thr:  # threshold of display
                continue

            cls_idx = int(bbox_info[5])
            cls_name = cls_map[cls_idx]

            bbox_show = xmin, ymin, xmax, ymax
            bboxs.append(bbox_show)
            labels.append(f'{cls_name} {prob:.2f}')

        show_img(file_path, bboxs, labels)

    return


def filter_image(img_paths, process_shape, outputs, thr=0.5):
    """
    根据模型的输出结果，过滤出高于阈值的图片
    :param img_paths: 图片的路径，eg: ['./test_imgs/**.jpg', './test_imgs/**.jpg']
    :param process_shape: 经过预处理后的图片shape，用于bbox还原到原图时缩放比例的计算[(640,640), (640,640)]
    :param outputs: 模型的输出结果[out1, out2], out1和out2是长度为600的一维列表
    :param thr: 只保留置信度大于thr的图片数据
    :return: 保留的图片列表
    """
    filter_image_path = []
    for file_path, img_shape, obj_bbox in zip(
            img_paths, process_shape, outputs):
        img_raw = cv2.imread(file_path)
        obj_bbox_torch = torch.from_numpy(np.array(obj_bbox).reshape((-1, 6)))
        obj_bbox_torch[:, :4] = scale_coords(
            img_shape, obj_bbox_torch[:, :4], img_raw.shape).round()
        obj_bbox_np = obj_bbox_torch.numpy().reshape(-1)
        obj_bbox_detail = [obj_bbox_np[i: i + 6]
                           for i in range(0, len(obj_bbox_np), 6)]

        for bbox_info in obj_bbox_detail:
            prob = bbox_info[4]
            if float(prob) >= thr:  # threshold of filter
                filter_image_path.append(file_path)

    return filter_image_path


if __name__ == '__main__':

    # 以下仅供示例
    model_path = './***/best.tracing.pt'
    test_imgs = ['./test_imgs/**.jpg', './test_imgs/**.jpg']
    cls_map = {0: "Kfc", 1: "Mengniu", 2: "Yili", 3: "Jingdong"}

    img_paths, process_shape, outputs = predict(model_path, test_imgs)
    show_bbox(cls_map, img_paths, process_shape, outputs, thr=0.5)
