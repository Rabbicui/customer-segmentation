"""
Functional API Demo

类似于keras的下面这种用法：

```python
import tensorflow as tf

inputs = tf.keras.Input(shape=(3,))
x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
model = tf.keras.Model(inputs=inputs, outputs=outputs)
```

这个接口主要是为了方便快速跑一些实验, 现在这个接口的用法还没完全确定下来,
也容易产生误解，所以暂时放在experimental里面
"""

import pandas as pd
import tensorflow as tf

from rcalgo import training
from rcalgo.tf.metric.loss import my_sparse_cross_entropy_loss
from rcalgo.tf.models.classifier.text_classifier import FastText
from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.training.training_utils import get_or_create_is_training


def main(_):
    # 1. load data
    data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
    train_data = pd.read_csv(data_dir + 'train.csv')
    # test_data = pd.read_csv(data_dir + 'test.csv')

    # count word dict
    tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=2)
    word_dict = tokenizer.word2idx

    # 2. create graph
    input_text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
    label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_label')

    fasttext = FastText(hparams={}, word_dict=word_dict)
    logits, prediction = fasttext(input_text)

    loss = my_sparse_cross_entropy_loss(label, logits, 2)
    loss = tf.cast(tf.reduce_mean(loss), tf.float32)

    accuracy = tf.cast(tf.nn.in_top_k(prediction, label, k=1), dtype=tf.float32)

    # 3. train
    model = training.functional_model(input_text, prediction, label, loss, metrics=accuracy, name="default")
    model.set_optimizer(tf.compat.v1.train.AdamOptimizer(0.0001))
    model.train([train_data['text'], train_data['label']],
                batch_size=32,
                epochs=5,
                test_size=0.1,
                hooks=[])


if __name__ == '__main__':
    tf.app.run()
