from rcalgo.tf.models.augmentation.token_level.base_token_replace import TokenReplace
import numpy as np
import jieba
np.seterr(divide='ignore', invalid='ignore')


class UniformReplace(TokenReplace):
    """
    Uniformly replace word with random words in the vocab.
    """
    def __init__(self, sentences, need_cut=False):
        super(UniformReplace, self).__init__(sentences, need_cut)
        self.sentences = sentences
        self.reset_token_list()
        self.reset_random_prob()

    def _replace_tokens(self, tokens, token_prob, times):
        ret_tokens = []
        for i in range(times):
            new_tokens = []
            for j in range(len(tokens)):
                if self.get_random_prob() < token_prob:
                    new_tokens.append(self.get_random_token())
                else:
                    new_tokens.append(tokens[j])
            ret_tokens.append("".join(new_tokens))
        return ret_tokens

    def replace(self, token_prob=0.1, times=1):
        """
        :param token_prob: probability of token being replaced
        :param times: how many times do you want to augment
        :return:
        """
        ret_texts = []
        for i, text in enumerate(self.sentences):
            aug_texts = []
            if self.need_cut:
                tokens = list(jieba.cut(text))
            else:
                tokens = list(text)
            aug_texts.extend(self._replace_tokens(tokens, token_prob, times))
            ret_texts.append(aug_texts)
        return ret_texts

    def reset_token_list(self):
        """Generate many random tokens at the same time and cache them."""
        self.token_list = list(self.vocab.keys())
        self.token_ptr = len(self.token_list) - 1
        np.random.shuffle(self.token_list)


def test():
    sentences = ['实播突然人气低 k有私介', '怎样才能上热门', '我买的东西卖家不给退货怎么办', '不要屏蔽我好不好', '感谢官方']
    unif_rep = UniformReplace(sentences, need_cut=True)
    texts = unif_rep.replace(0.2, 5)
    print(texts)


if __name__ == '__main__':
    test()