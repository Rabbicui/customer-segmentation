import tensorflow as tf
import math


def gelu(x):
    return 0.5*x*(1+tf.tanh(math.sqrt(2/math.pi)*(x+0.044715*tf.pow(x, 3))))


def swish(x):
    return x*tf.nn.sigmoid(x)


def selu(x):
    alpha = 1.6732632423543772848170429916717
    scale = 1.0507009873554804934193349852946
    return scale*tf.where(x>0.0,x,alpha*tf.nn.elu(x))


def leaky_relu(x, name=None):
    return tf.nn.leaky_relu(x, alpha=0.01, name=name)


act_fns = {
    'relu': tf.nn.relu,
    'swish': swish,
    'gelu': gelu,
    'selu': selu,
    'leaky_relu': leaky_relu,
    'tanh': tf.nn.tanh
}
