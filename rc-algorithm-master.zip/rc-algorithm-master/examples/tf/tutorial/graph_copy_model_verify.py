import sys
sys.path.insert(0, "../../")

import pandas as pd
import tensorflow as tf
import numpy as np

from rcalgo.tf.models.classifier.text_classifier import TransformerClassifier
from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.utils.serving_utils import load_freeze_graph, infer_once


config = {
    "learning_rate": 0.0001,

    "num_classes": 2,
    "max_seq_len": 100,
    "embedding_size": 256,
    "num_layers": 2,
    "conv_num_filters": 256,
    # "keep_prob": 0.5,

    "gpu_id": 0,
    "gpu_num": 2,

    "model_output_dir": "./saved_models",
    "model_name": "transformer",

    "clip_type": "clip_value",
    "clip_gradient": 1.0,
    "use_placeholder_with_default": True
}


def main(_):
    # 1. load data
    data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
    train_data = pd.read_csv(data_dir + 'train.csv')
    test_data = pd.read_csv(data_dir + 'test.csv')
    # count word dict
    tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=1)
    word_dict = tokenizer.word2idx

    # 2. create model
    model = TransformerClassifier(config, word_dict, name="default",
                                    distribute="tf_distribute")
    model.build_model()
    print(model.model_summary())

    # 3. train
    model.train(
        [train_data['text'], train_data['label']],
        batch_size=128,
        test_size=0.1,
        epochs=2,
        hooks=[])
    
    # eval on test data
    eval_loss, eval_metric = model.evaluate([test_data['text'], test_data['label']], batch_size=128)
    print(f"eval loss: {eval_loss}, eval metric: {eval_metric}")
    predict_output = model.predict([test_data['text']], batch_size=128)
    predict_output_sample = list(predict_output.values())[0][0][0]
    print(f"original predict_output: {predict_output}, sample: {predict_output_sample}")

    # dump model as pb
    model.export_freeze_graph("freeze", 1, task_name="default")
    # load model from pb
    new_sess = load_freeze_graph("./freeze/1/frozen.pb")
    # infer
    pb_predict_output = infer_once(new_sess, [test_data['text'][:128]])
    print(f"pb_predict_output[0]: {pb_predict_output[0][0]}")
    # two predict result should be same
    assert(np.allclose(predict_output_sample, pb_predict_output[0][0]))


if __name__ == '__main__':
    tf.app.run()
