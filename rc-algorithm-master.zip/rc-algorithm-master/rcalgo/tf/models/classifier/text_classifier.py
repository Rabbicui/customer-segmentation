import tensorflow as tf

from rcalgo.tf.module import Module
from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.module.encoder.cnn import text_cnn_encoder, text_deep_cnn_encoder
from rcalgo.tf.module.layer.preprocessing import TFCharSequencePreprocessor
from rcalgo.tf.module.encoder.transformer import bi_conv_transformer_layer, conv_transformer_layer
from rcalgo.tf.module.layer.activations import act_fns
from rcalgo.tf.module.layer.attention import self_position_attention, self_position_attentive
from rcalgo.tf.module.layer.basic import my_full_connected, my_dropout
from rcalgo.tf.module.layer.rnn import my_bi_qrnn, my_bi_rnn
from rcalgo.tf.models.classifier.base_text_cls import TextClassifierBase


class FastText(TextClassifierBase):

    def __init__(self, hparams, word_dict, **kwargs):
        super(FastText, self).__init__(hparams=hparams, word_dict=word_dict, **kwargs)
        self.dropout_keep_prob = hparams.get('keep-prob', 1.0)

    def build_representation(self, embedding, seq_lengths, **kwargs):
        hidden = tf.reduce_mean(embedding, axis=1)
        with tf.name_scope("dropout"):
            hidden = my_dropout(hidden, rate=(1 - self.dropout_keep_prob), training=self.is_training)
        return hidden


class TextCNN(TextClassifierBase):

    def __init__(self, hparams, word_dict, **kwargs):
        super(TextCNN, self).__init__(hparams=hparams, word_dict=word_dict, **kwargs)
        self.max_conv_len = hparams.get('max_conv_len', 3)
        self.num_filters = hparams.get('num_filters', 128)
        self.dropout_keep_prob = hparams.get('keep_prob', 1.0)

    def build_representation(self, embedding, seq_lengths, **kwargs):
        hidden = text_cnn_encoder(
            embedding, self.is_training, self.max_conv_len, self.num_filters,
            self.dropout_keep_prob, reuse=self.model_reuse)
        return hidden


class TextDeepCNN(TextClassifierBase):

    def __init__(self, hparams, word_dict, **kwargs):
        super(TextDeepCNN, self).__init__(hparams=hparams, word_dict=word_dict, **kwargs)
        self.num_filters_per_size = hparams.get('num_filters_per_size', 64)
        self.filter_sizes = hparams.get('filter_sizes', [5, 5, 3, 3, 3, 3])
        self.pool_sizes = hparams.get('pool_sizes', [2, 2, None, None, None, -1])
        self.fully_layers = hparams.get('fully_layers', [128, 128])
        self.dropout_keep_prob = hparams.get('keep_prob', 1.0)
        self.add_mean_pooling = hparams.get('add_mean_pooling', True)

    def build_representation(self, embedding, seq_lengths, **kwargs):
        hidden = text_deep_cnn_encoder(
            embedding, self.is_training, self.num_filters_per_size, self.filter_sizes, self.pool_sizes,
            self.fully_layers, self.dropout_keep_prob, self.add_mean_pooling)
        return hidden


class AttentionRNNClassifier(TextClassifierBase):

    def __init__(self, hparams, word_dict, **kwargs):
        super(AttentionRNNClassifier, self).__init__(hparams=hparams, word_dict=word_dict, **kwargs)
        self.attention_size = hparams.get("attention_size", 256)
        self.num_layers = hparams.get("num_layers", 2)
        self.hidden_size = hparams.get("hidden_size", 256)  # rnn hidden size
        self.keep_prob = hparams.get("keep_prob", 1.0)  # keep probability of drop out
        self.use_residual = hparams.get("use_residual", False)
        self.use_qrnn = hparams.get("use_qrnn", False)
        # for quasi rnn
        self.zoneout = hparams.get("zoneout", 0.0)
        self.conv_length = hparams.get("conv_length", 2)
        self.pool_type = hparams.get("pool_type", 'ifo')

    def build_input_sequence(self, embedding, seq_lengths):
        if self.use_qrnn:
            state_list, rnn_output_list = my_bi_qrnn(
                embedding, seq_lengths, self.num_layers, self.hidden_size, self.conv_length,
                self.pool_type, self.zoneout, self.is_training, self.use_residual)
        else:
            state_list, rnn_output_list = my_bi_rnn(
                embedding, seq_lengths, self.hidden_size, self.keep_prob, self.num_layers, self.use_residual)
        return state_list, rnn_output_list

    def build_representation(self, embedding, seq_lengths, **kwargs):
        state_list, rnn_output_list = self.build_input_sequence(embedding, seq_lengths)
        if self.attention_size > 0:
            with tf.name_scope('attention'):
                last_flat, alphas = self_position_attention(state_list, self.attention_size)
        else:
            with tf.name_scope('pooling_over_time'):
                pool = tf.reduce_max(state_list, axis=1)
                last_flat = tf.reshape(pool, [-1, self.hidden_size*2])
        hidden = my_dropout(last_flat, rate=(1 - self.keep_prob), training=self.is_training)
        return hidden


class SelfAttentiveRNNClassifier(AttentionRNNClassifier):

    def __init__(self, hparams, word_dict, **kwargs):
        super(SelfAttentiveRNNClassifier, self).__init__(hparams=hparams, word_dict=word_dict, **kwargs)
        self.output_matrix_dim = hparams.get("output_matrix_dim", 16)
        self.last_fc_dim = hparams.get("last_fc_dim", 128)
        self.p_coef = hparams.get('p_coef', 0.0002)

    def _penalty(self):
        p_loss = self.p_coef * self.P
        return p_loss

    def build_representation(self, embedding, seq_lengths, **kwargs):
        state_list, rnn_output_list = self.build_input_sequence(embedding, seq_lengths)
        with tf.name_scope('attention'):
            last_flat, alphas, self.P = self_position_attentive(
                state_list, self.attention_size, self.output_matrix_dim)
        hidden = my_full_connected(my_dropout(last_flat, rate=(
            1-self.keep_prob), training=self.is_training), self.last_fc_dim, act=tf.nn.relu)
        return hidden


class TransformerClassifier(TextClassifierBase):

    def __init__(self, hparams, word_dict, **kwargs):
        super(TransformerClassifier, self).__init__(hparams=hparams, word_dict=word_dict, **kwargs)

        self.num_layers = hparams.get("num_layers", 2)
        self.conv_num_filters = hparams.get("conv_num_filters", 256)
        self.position_type = hparams.get("position_type", [3, 4, 5])
        self.n_head = hparams.get("n_head", 8)
        self.attn_drop = 1 - hparams.get("keep_prob", 1.0)
        self.ffn_act = act_fns[hparams.get("transformer_func", "relu")]
        self.ffn_drop = 1 - hparams.get("keep_prob", 1.0)
        self.bi_direction = hparams.get("bi_direction", False)
        self.attention_size = hparams.get("attention_size", 256)
        self.combine_mode = hparams.get("combine_mode", "ADD")
        self.mask = False

    def build_representation(self, embedding, seq_lengths, **kwargs):
        if self.bi_direction:
            layer_func = bi_conv_transformer_layer
            self.mask = True
        else:
            layer_func = conv_transformer_layer

        state_list, rnn_output_list = layer_func(
            embedding, self.num_layers,
            seq_lengths, self.conv_num_filters,
            self.position_type, n_head=self.n_head,
            combine_mode=self.combine_mode,
            attn_drop=self.attn_drop, mask=self.mask,
            ffn_act=self.ffn_act, ffn_drop=self.ffn_drop,
            training=self.is_training)

        if self.bi_direction:
            state_list = tf.concat(state_list, axis=-1)
        hidden, alphas = self_position_attention(state_list, self.attention_size)
        return hidden
