# rc-algorithm-tensorflow 
rc-algorithm-tensorflow是风控算法与架构团队开发的**tensorflow模型训练代码库**，面向所有风控同学，提供灵活易用的接口，丰富的模型组件，支持高性能训练。

## 1. 主要特点：
* 用户接口灵活易用：模块化、接口友好
* 支持单机多卡、多机多卡，加速比高
* 多种state-of-art模型开箱即用
* 支持高性能特性：混合精度、量化感知训练、高性能算子 (TODO)
* 格式统一、覆盖多种业务的checkpoint模型库 (TODO)


## 2. 目录结构

#### 主要目录
- demos: 大部分模型的demo演示，确保代码的正确性
- docs: 各类文档
- metric: accuracy、loss相关定义
- models: 模型定义
- module: 各类模块定义
- optimizer: optimizer相关定义
- scripts: 工具脚本
- training: 训练模块
- utils: 各种工具函数

#### legacy目录
- deprecated: 历史文件
- tfmodels: 历史模型定义，保留，仍能正常使用
- tftraining: 历史训练流程，保留，仍能正常使用

## 3. 说明文档
docs目录下提供了一些帮助上手的文档，推荐按顺序阅读
* [Subclassing API和Functional API介绍](docs/Subclassing API和Functional API介绍.md)
* [Subclassing API示例](docs/Subclassing API示例.md)
* [Functional API示例](docs/Functional API示例.md)
* [Module介绍](docs/Module介绍.md)
* [Horovod Trainer](docs/Horovod Trainer.md)
* [FAQ](docs/FAQ.md)

另外demos目录里也提供了大量的例子，可以作为参考。

如果发现文档中有问题或者有想到新的idea也欢迎直接补充

## 4. 开发规范

#### 编码规范
应遵循PEP8 coding style ( https://www.python.org/dev/peps/pep-0008/ )。

#### 注释规范
使用Python docstring进行注释，参考规范：PEP 257(https://www.python.org/dev/peps/pep-0257/ )。 

#### Unit Test规范
* 继承Tensorflow的TestCase基类(可以参考module/layer/basic_test.py)
* module层必须写UT
* UT可以先写一个 
* 每次修复bug之后应当增加一个针对该bug的UT


#### Code Review规范
Code Review时，reviewer需关注：
* 关键代码必须有注释；
* module级别的代码必须有UT，bugfix必须有UT。

## 5.Requirements
```
tensorflow==1.14
pandas==0.23.0
sklearn
numpy
horovod==0.19.5
jieba
tqdm
matplotlib
h5py
mpi4py
synonyms
```

## 6. 吐槽和建议
欢迎提供宝贵意见：https://www.wjx.cn/jq/99431114.aspx

