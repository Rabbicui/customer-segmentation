import sys
sys.path.append('..')

#from tf_object import *
from rcalgo.tf.tfmodels.gan.seq_gan import *
from rcalgo.tf.utils.train_config import *
from rcalgo.tf.training.data.train_data import *

args = parse_initial_training_args(
    [
        '--generator-learning-rate', '0.001',
        '--discriminator-learning-rate', '0.0001',
        '--g-pre-train-learning-rate', '0.01',
        '--generator-train-steps', '2',
        '--learning-rate', '1',
        '--discriminator-train-steps', '1',
        '--n-epochs', '10',
        '--batch-size', '32',
        '--p-coef', '2.5e-5',
        '--gpu-id', '4',
        '--gpu-num', '4',
        '--input-dim', '784',
        '--hidden-dim', '1024',
        '--model-name', 'gan_demo',
        '--clip-gradients', '2',
        '--embedding-size', '32',
        '--maxlen', '20',
        '--oov-buckets', '1',
        '--english-style',
        '--adam-beta1', '0.5',
    ]
)
args.model_version = 1
# build vocab
token2id = {}
id2Token = {}
id2Token[0] = '<PAD>'
token2id['<PAD>'] = 0
id = 1
with open('./data/vocab.txt', 'r') as f:
     lines = f.readlines()
     lines = [l.replace('\n', '') for l in lines]
     for l in lines:
        token2id[l] = id
        id2Token[id] = l
        id += 1
import codecs

with codecs.open('coco.train.txt', 'r') as f:
    data = f.readlines()
    data = [l.replace('\n', '') for l in data]
data = data[0: -(len(data) % 32)]
td = TrainingData([data], args.batch_size, 0, 1)
datas = {'discriminator': td, 'pretrain_generator': td, 'pretrain_discriminator': td}
def build_word_dict(texts, word_freq):
    word_freq_dict = word_count(texts, word_seg=True)
    term_id_map = build_word2idx(word_freq_dict, freq_threshold=word_freq)
    return term_id_map

map = build_word_dict(data, 10)
print(map)
print(token2id)

graph = tf.Graph()
gan = SeqGAN(args, graph, token2id)
gan.build_model()

with graph.as_default():
    output = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)[0]
    # print(tf.compat.v1.get_collection('{}_{}'.format('pretrain_generator', tf.compat.v1.GraphKeys.TRAIN_OPS))[0])
    # print(tf.compat.v1.get_collection('{}_{}'.format('pretrain_generator', tf.compat.v1.GraphKeys.INPUTS))[0])

gan.job.train(datas, standalone_n_epochs={'pretrain_generator': 1, 'pretrain_discriminator': 1},
              joint_n_epochs=1,
              task_names=['pretrain_generator'])
                # task_names=['generator', 'discriminator', 'pretrain_generator', 'pretrain_discriminator'])

from rcalgo.tf.utils.text_utils import *



id2Token[gan.nb_words - 2] = '<SOS>'
id2Token[gan.nb_words - 1] = '<EOS>'
samples = gan.job.session.run(output)


def infer():
    samples = gan.job.session.run(output)
    for sample in samples:
        word = []
        for id in sample:
            if id in id2Token:
                word.append(id2Token[id])
            else:
                word.append("<UNK>")
        print(word)


infer()

