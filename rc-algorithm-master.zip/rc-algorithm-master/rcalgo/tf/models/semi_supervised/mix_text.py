import numpy as np
import tensorflow as tf
from rcalgo.tf.training.data.data import Data
from rcalgo.tf.training import training_utils
from rcalgo.tf.models.semi_supervised.base_semi_supervised import SemiSupervisor
from rcalgo.tf.models.semi_supervised.semi_utils import kl_for_log_probs
from rcalgo.tf.models.semi_supervised.semi_utils import linear_rampup
from rcalgo.tf.models.semi_supervised.semi_utils import shuffle_multiple


class MixText(SemiSupervisor):
    """
    https://arxiv.org/pdf/2004.12239v1.pdf
    """
    def __init__(self, config, execute_model, name="mix_text", **kwargs):
        self.mix_method = config.get("mix_type", None)  # mix_sentence_hidden, mix_sentence, concat
        self.lambda_u = config.get("lambda_u", 1)
        self.lambda_u_hinge = config.get("lambda_u_hinge", 1)
        self.batch_size = config.get("batch_size", 32)
        self.sup_batch_size = self.batch_size
        self.unsup_ratio = config.get("unsup_ratio", 1)
        self.unsup_batch_size = self.batch_size * self.unsup_ratio
        self.epoch_num = config.get("epoch_num", 1)
        self.margin = config.get("margin", 0.7)
        self.aug_num = config.get("aug_num", 1)
        self.do_mix = config.get("do_mix", True)
        self.alpha = config.get("alpha", 0.75)
        self.T = config.get("T", 0.5)
        self.separate_mix = config.get("separate_mix", True)
        self.num_classes = config.get("num_classes", 0)
        self.num_train_steps = config.get("num_train_steps", 0)
        self.split_layer_num = config.get("split_layer_num", 1)
        self.num_epoch_steps = self.num_train_steps / self.epoch_num
        self.global_step = tf.train.get_or_create_global_step()
        self.epoch_tensor = tf.to_int32(tf.to_float(self.global_step) / tf.to_float(self.num_epoch_steps))
        self.consistency_loss = None
        self.self_training_loss = None
        self.unsup_input = None
        self.sup_ce_loss = None
        self.sup_kl_loss = None
        super(MixText, self).__init__(execute_model, config=config, name=name, **kwargs)

    def create_inputs(self):
        text = tf.placeholder(dtype=tf.string, shape=[None], name='input_text')
        org_unsup = tf.placeholder(dtype=tf.string, shape=[None, None], name='org_unsup')
        aug_unsup_list = []
        for i in range(self.aug_num):
            aug_unsup_list.append(tf.placeholder(dtype=tf.string, shape=[None, None], name=f'aug_unsup_{i}'))
        label = tf.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return [text, org_unsup] + aug_unsup_list, label

    def compute_sup_loss(self, state, label):
        sup_state = state[:self.sup_batch_size]
        sup_label = label[:self.sup_batch_size]
        sup_mix_state = state[self.sup_batch_size: 2 * self.sup_batch_size]
        sup_mix_label = label[self.sup_batch_size: 2 * self.sup_batch_size]
        with tf.variable_scope("sup_loss"):
            if self.mix_method == "mix_sentence_hidden" or self.mix_method == "mix_sentence":
                # cross entropy
                log_prob = tf.nn.log_softmax(sup_state, axis=1)
                self.sup_ce_loss = - tf.reduce_mean(tf.reduce_sum(log_prob * sup_label, axis=1))
            sup_mix_log_probs = tf.nn.log_softmax(sup_mix_state, axis=1)
            self.sup_kl_loss = tf.reduce_mean(kl_for_log_probs(sup_mix_label, sup_mix_log_probs))
        sup_loss = self.sup_ce_loss + self.sup_kl_loss
        return sup_loss

    def compute_unsup_loss(self, state, label):
        unsup_state = state[self.sup_batch_size * 2:]
        unsup_label = label[self.sup_batch_size * 2:]
        with tf.variable_scope("unsup_loss"):
            if self.mix_method == "mix_sentence_hidden" or self.mix_method == "mix_sentence":
                log_prob = tf.nn.log_softmax(unsup_state, axis=1)
                prob = tf.nn.softmax(unsup_state, axis=1)
                consistency_loss = tf.reduce_mean(kl_for_log_probs(log_prob, tf.log(unsup_label)))
                entropy = tf.reduce_sum(-prob * log_prob, axis=1)
                hinge_loss = tf.reduce_mean(tf.maximum(entropy - self.margin, 0))
            rampup_tensor = tf.to_float(linear_rampup(self.epoch_tensor, self.epoch_num))
            w_unsup = tf.to_float(self.lambda_u) * rampup_tensor
            w_hinge = tf.to_float(self.lambda_u_hinge) * rampup_tensor
            unsup_loss = w_unsup * consistency_loss + w_hinge * hinge_loss
            self.consistency_loss = consistency_loss
            self.self_training_loss = hinge_loss
        return unsup_loss

    def calc_mix_lambda(self):
        """
        Lambda used in MixUp
        Returns:
            float tensor.
        """
        lambda_ = tf.distributions.Beta(self.alpha, self.alpha).sample()
        if not self.separate_mix:
            lambda_ = tf.maximum(lambda_, 1 - lambda_)
        return lambda_

    def label_guessing(self, **kwargs):
        """
        Guess label of unsupervised data.
        Args:
            **kwargs: kwargs for `model.call()`

        Returns:
            float tensor.
        """
        unsup_states, unsup_outputs = self.execute_model.call(self.unsup_input,
                                                              is_mix=False, **kwargs)
        unsup_prob = tf.nn.softmax(unsup_states[0])
        unsup_prob_list = tf.split(unsup_prob, self.aug_num + 1)
        unsup_avg_prob = tf.reduce_mean(tf.stack(unsup_prob_list, axis=0), axis=0)
        # sharpen
        pt = unsup_avg_prob ** (1 / self.T)
        unsup_targets = pt / tf.reduce_sum(pt, axis=1, keep_dims=True)
        unsup_targets_no_grad = tf.stop_gradient(unsup_targets)
        return unsup_targets_no_grad

    def build_forward(self, **kwargs):
        inputs, label = self.create_inputs()
        text = inputs[0]
        target = tf.one_hot(label, depth=self.num_classes)
        org_unsup = inputs[1]
        aug_unsup_list = inputs[2:]
        org_unsup = tf.reshape(org_unsup, [self.unsup_batch_size])
        aug_unsup_list = [tf.reshape(aug_unsup, [self.unsup_batch_size]) for aug_unsup in aug_unsup_list]
        self.unsup_input = tf.concat([org_unsup] + aug_unsup_list, axis=0)
        unsup_targets_no_grad = self.label_guessing(**kwargs)

        mix_lambda = self.calc_mix_lambda()
        all_inputs = tf.concat([text, text, org_unsup] + aug_unsup_list, axis=0)
        all_targets = tf.concat([target, target] + [unsup_targets_no_grad for _ in range(self.aug_num + 1)], axis=0)
        total_mix_size = self.sup_batch_size + self.unsup_batch_size * (self.aug_num + 1)
        if self.separate_mix:
            # [sup, sup], [unsup, unsup_aug] mix [sup, sup_shuf], [unsup_shuf, unsup_aug_shuf]
            sup_indices = tf.range(self.sup_batch_size, self.sup_batch_size * 2)
            sup_indices_shf = tf.random.shuffle(sup_indices)
            unsup_indices = tf.range(self.sup_batch_size * 2, self.sup_batch_size + total_mix_size)
            unsup_indices_shf = tf.random.shuffle(unsup_indices)
            indices_shf = tf.concat([tf.range(self.sup_batch_size), sup_indices_shf, unsup_indices_shf], axis=0)
            all_inputs_shf = tf.gather(all_inputs, indices_shf)
            all_targets_shf = tf.gather(all_targets, indices_shf)
        else:
            # [sup], [sup, unsup, unsup_aug] mix [sup], [sup_shuf, unsup_shuf, unsup_aug_shuf]
            mix_indices = tf.range(self.sup_batch_size, self.sup_batch_size + total_mix_size)
            mix_indices_shf = tf.random.shuffle(mix_indices)
            indices_shf = tf.concat([tf.range(self.sup_batch_size), mix_indices_shf], axis=0)
            all_inputs_shf = tf.gather(all_inputs, indices_shf)
            all_targets_shf = tf.gather(all_targets, indices_shf)

        if self.mix_method == 'mix_sentence_hidden':
            # Mix sentences' hidden representations
            all_inputs_cat = tf.concat([all_inputs, all_inputs_shf], 0)
            states, outputs = self.execute_model.call(all_inputs_cat, is_mix=True,
                                                      split_layer_num=self.split_layer_num,
                                                      mix_lambda=mix_lambda, **kwargs)
            mixed_target = mix_lambda * all_targets + (1 - mix_lambda) * all_targets_shf

        if isinstance(states, (tuple, list)):
            states = states[0]
        loss = self.compute_loss(states, mixed_target)
        metrics = self.compute_metrics(outputs[:self.batch_size],
                                       label[:self.batch_size])

        self.inputs = inputs
        self.outputs = outputs
        self.labels = label
        self.loss = loss
        self.metrics = metrics

        training_utils.create_task_in_graph(
            inputs, outputs, label, loss, metrics, None, name=self.name)
        return self


class MixTextData(Data):
    def __init__(self, datasets, batch_size, mode="train", default_random_seed=None,
                 drop_remainder=False, name="Data", aug_num=1):
        self.aug_num = aug_num  # augment num
        super().__init__(datasets, batch_size, mode=mode, default_random_seed=default_random_seed,
                         drop_remainder=drop_remainder, name=name)
    @property
    def sup_data_size(self):
        return int(len(self.datasets[0]))

    @property
    def unsup_data_size(self):
        return int(len(self.datasets[1]))

    def to_tf_dataset(self):
        # text, org_unsup, aug_unsup_0, aug_unsup_1, ..., label
        self.build_schema()
        if self.mode == "train":
            text_ds = tf.data.Dataset.from_tensor_slices(self.data_schema[0])
            org_unsup_ds = tf.data.Dataset.from_tensor_slices(self.data_schema[1])
            aug_unsup_ds_list = []
            for aug_unsup in self.data_schema[2: -1]:
                aug_unsup_ds_list.append(tf.data.Dataset.from_tensor_slices(aug_unsup))
            label_ds = tf.data.Dataset.from_tensor_slices(self.data_schema[-1])
            all_ds = [text_ds, org_unsup_ds]
            for aug_unsup_ds in aug_unsup_ds_list:
                all_ds.append(aug_unsup_ds)
            all_ds.append(label_ds)
            all_ds[0] = all_ds[0].shuffle(self.sup_data_size, seed=0).repeat()  # text
            all_ds[1] = all_ds[1].shuffle(self.unsup_data_size, seed=1).repeat()  # org_unsup
            for i in range(2, len(all_ds) - 1):  # aug_unsup
                all_ds[i] = all_ds[i].shuffle(self.unsup_data_size, seed=1).repeat()
            all_ds[-1] = all_ds[-1].shuffle(self.sup_data_size, seed=0).repeat()  # label
            print(f"sup_data_size: {self.sup_data_size}, unsup_data_size: {self.unsup_data_size}")
            # since sup data and unsup data have different size,
            # they need to be repeat and shuffle seperately.
            total_ds = tf.data.Dataset.zip(tuple(all_ds))
            return total_ds.batch(self.batch_size).prefetch(tf.data.experimental.AUTOTUNE)
        else:
            return tf.data.Dataset.from_tensor_slices(self.data_schema).batch(self.batch_size)
