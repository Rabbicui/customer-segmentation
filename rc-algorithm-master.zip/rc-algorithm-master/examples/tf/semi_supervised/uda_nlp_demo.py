# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.6.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %%
import os
import pandas as pd
import tensorflow as tf
import numpy as np
import sys
import time
from sklearn.metrics import accuracy_score
from tqdm import tqdm_notebook as tqdm

sys.path.insert(0, "../../")

from rcalgo.tf.models.semi_supervised.uda import UDA, UDAData
from rcalgo.tf.utils.tokenizers import CharTokenizer
from rcalgo.tf.models.classifier.text_classifier import TextCNN
from rcalgo.tf.training.hook import TensorInfoPrintHook
from rcalgo.tf.training.data.data_iterator import DataIterator

# %%
# load data
data_dir = "/home/web_server/antispam/project/datasets/female_vulgar/"
train_df = pd.read_csv(data_dir + 'train_400.csv')
test_df = pd.read_csv(data_dir + 'test.csv')
# count word dict
tokenizer = CharTokenizer.build_from_corpus(test_df['text'], freq_threshold=2)
word_dict = tokenizer.word2idx

# %%
# augment unsupvised data with EDA
# warning: this step may be time-costing

org_unsup_file = data_dir + "unsup0.txt"
aug_unsup_file = data_dir + "unsup1.txt"

if not os.path.exists(aug_unsup_file):
    from rcalgo.tf.models.augmentation.token_level.eda import EDA
    eda = EDA(stopwords=[], need_cut=True, rand_seed=0)
    start_t = time.time()
    with open(org_unsup_file) as in_f, open(aug_unsup_file, "w") as out_f:
        sentences = [line.strip() for line in in_f]
        aug_sentences = eda.run(sentences, alpha_sr=0.1, alpha_ri=0.1, alpha_rs=0.1, p_rd=0.1, times=1)
        for line in aug_sentences:
            out_f.write(f"{line}\n")

    print(f"Unsup data augment time cost: {time.time() - start_t} s")

# %%
sup_texts = train_df['text']
labels = train_df['label']
batch_size = 32
unsup_ratio = 9
gpu_num = 2
num_epochs = 220
num_train_steps = num_epochs * (int(len(sup_texts)) // (batch_size * gpu_num))
print(f"num_train_steps: {num_train_steps}")

# %%
# create execute model
config = {
    # uda config
    "unsup_coeff": 1.5,  # unsup loss coeff 
    "tsa_schedule": None,  # linear_schedule, exp_schedule, log_schedule, None
    "batch_size": batch_size,
    "unsup_ratio": unsup_ratio,  # unsup data ratio
    "num_train_steps": num_train_steps - 200,  # num of train steps is needed for tas threshold calcuation
    "uda_softmax_temp": -1,
    "uda_confidence_thresh": -1,
    
    # model config
    "learning_rate": 0.003,

    "num_classes": 2,
    "max_seq_len": 100,
    "embedding_size": 128,
    "num_layers": 2,
    "conv_num_filters": 256,
    "keep_prob": 0.6,
    
    "gpu_id": 0,
    "gpu_num": gpu_num,

    "model_output_dir": "./saved_models",
    "model_name": "cnn"
}

# %%
test_sup_texts = test_df['text']
test_labels = test_df['label']

# %%
org_unsup_texts = []
aug_unsup_texts = []
with open(org_unsup_file) as org_f:
    all_org_unsup_texts = [line.strip() for line in org_f.readlines()]
with open(aug_unsup_file) as aug_f:
    all_aug_unsup_texts = [line.strip() for line in aug_f.readlines()]

unsup_size = len(all_org_unsup_texts) // unsup_ratio
for i in range(unsup_size):
    org_unsup_texts.append([all_org_unsup_texts[i * unsup_ratio + j] for j in range(unsup_ratio)])
    aug_unsup_texts.append([all_aug_unsup_texts[i * unsup_ratio + j] for j in range(unsup_ratio)])
    
test_size = len(test_labels)
test_org_unsup_texts = org_unsup_texts[:test_size]
test_aug_unsup_texts = aug_unsup_texts[:test_size]

# %%
print(f"sup_texts: ")
print(sup_texts[:5])
print(f"org_unsup_texts: ")
print(org_unsup_texts[:5])
print(len(org_unsup_texts))
print(f"aug_unsup_texts: ")
print(aug_unsup_texts[:5])
print(len(test_aug_unsup_texts))

# %% [markdown]
# ## training with original model

# %%
tf.compat.v1.reset_default_graph()
model = TextCNN(config, word_dict, name="default", distribute="tf_distribute")
model.build_model()
model.model_summary()

# %%
model.train_and_evaluate([sup_texts, labels], [test_sup_texts, test_labels], 
            batch_size=batch_size * config['gpu_num'],
            epochs=num_epochs,
            hooks=[])

# %% [markdown]
# ## training with UDA wrapper

# %%
tf.compat.v1.reset_default_graph()
model = TextCNN(config, word_dict, name="default", distribute="tf_distribute")
uda_model = UDA(config=config, execute_model=model, name="default", distribute="tf_distribute")

# %%
uda_model.build_model()

print(uda_model.loss)
uda_model.model_summary()

# %%
logging_hook = TensorInfoPrintHook({"unsup_loss": uda_model.unsup_loss,
#                                     "tsa_threshold": uda_model.tsa_threshold, 
                                    "sup_loss": uda_model.sup_loss})

# %%
train_data = UDAData([sup_texts, org_unsup_texts, aug_unsup_texts, labels],
                     mode="train", batch_size=batch_size * config['gpu_num'], 
                     drop_remainder=True, name="train_data")

test_data = UDAData([test_sup_texts, test_org_unsup_texts, test_aug_unsup_texts, test_labels],
                     mode="test", batch_size=batch_size * config['gpu_num'], 
                    drop_remainder=True, name="test_data")

# %%
print(len(sup_texts), len(org_unsup_texts), len(aug_unsup_texts), len(labels))
print(len(test_sup_texts), len(test_org_unsup_texts), len(test_aug_unsup_texts), len(test_labels))

# %%
uda_model.train_and_evaluate(train_data, test_data,
                batch_size=batch_size * config['gpu_num'],
                epochs=num_epochs,
                hooks=[logging_hook])

# %% [markdown]
# In my experiment, with 400 training data of `female_vulgar`, the validate accuracy improved from **0.6458** to **0.7283**.
#
# Suggestions: 
#
# - Keep the training steps long enough. Only then could we learn enough from the unsupervised data, which is huge compare to supervised data.
# - Data augmentation is important. Try more augmentation methods if you found one not worked.
# - Turn on the tsa-schdule if the supervised data is small. Otherwise you can turn it off.

# %% [markdown]
# ## Export and infer

# %%
uda_model.export_freeze_graph("freeze", 1, multi_replica_ckpt_path="saved_models/best_model/default-epoch177.ckpt")


# %%
def load_feeze_graph(model_fn):
    gpu_options = tf.compat.v1.GPUOptions(allow_growth=True)
    config = tf.compat.v1.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True)
    session = tf.compat.v1.Session(config=config, graph=tf.Graph())
    with session.graph.as_default():
        tf.compat.v1.train.import_meta_graph(model_fn)
        session.run(tf.compat.v1.tables_initializer())
    return session

sess = load_feeze_graph('freeze/1/frozen.pb')

# %%
with sess.graph.as_default():
    inputs = tf.get_collection('input_dict')
    outputs = tf.get_collection('output_dict')[0]

    data_iter = DataIterator([test_sup_texts], 
                             np.array(range(len(test_sup_texts))), batch_size=batch_size)
    data_iter_tqdm = tqdm(data_iter, leave=False)
    res = []
    for idx, batch in data_iter_tqdm:
        feed_data = dict(zip(inputs, batch))
        batch_res = sess.run(outputs, feed_dict=feed_data)
        res.append(batch_res)
       
    np_res = np.concatenate(res, axis=0)
    
print(np_res)

# %%
pos_predicts = np.argmax(np_res, axis=1)
pos_acc = accuracy_score(test_labels, pos_predicts)
print(f"acc on test: {pos_acc}")

# %%
