import six
import numpy as np
import tensorflow as tf
from tensorflow.python.ops import random_ops
import inspect


def _compute_fans(shape):
    """Computes the number of input and output units for a weight shape."""
    if len(shape) < 1:
        fan_in = fan_out = 1
    elif len(shape) == 1:
        fan_in = fan_out = shape[0]
    elif len(shape) == 2:
        fan_in, fan_out = shape[0], shape[1]
    else:
        # Assuming convolution kernels (2D, 3D, or more).
        # kernel shape: (..., input_depth, depth)
        receptive_field_size = 1
        for dim in shape[:-2]:
            receptive_field_size *= dim
        fan_in = shape[-2] * receptive_field_size
        fan_out = shape[-1] * receptive_field_size
    return int(fan_in), int(fan_out)


class HeUniformInitializer(object):
    """he_uniform initializer.

    See He et al. 2015 `http://arxiv.org/pdf/1502.01852v1.pdf`.

    TODO: do we need to inherite Module to support mix precision?
    """

    def __init__(self, scale=1.0, seed=None):
        self.scale = scale
        self.seed = seed

    def __call__(self, shape, dtype=tf.float32):
        fan_in, _ = _compute_fans(shape)
        limit = np.sqrt(6.0 * self.scale / fan_in)  # 老代码是1.0？ 这里改成了6.0
        return random_ops.random_uniform(shape, -limit, limit, dtype=dtype, seed=self.seed)


class XavierInitializer(object):
    """xavier initializer.

    See http://www.jmlr.org/proceedings/papers/v9/glorot10a/glorot10a.pdf

    TODO: do we need to inherite Module to support mix precision?
    """

    def __init__(self, scale=1.0, seed=None):
        self.scale = scale
        self.seed = seed

    def __call__(self, shape, dtype=tf.float32):
        # 老代码用的tf.contrib.layers.xavier_initializer，这里自己实现了一下
        fan_in, fan_out = _compute_fans(shape)
        s = np.sqrt(6.0 * self.scale / (fan_in + fan_out))
        return random_ops.random_uniform(shape, -s, s, dtype=dtype, seed=self.seed)


initializer_dict = {
    'ones': tf.initializers.ones,
    'zeros': tf.initializers.zeros,
    'norm': tf.initializers.random_normal,
    'uniform': tf.initializers.random_uniform,
    'identity': tf.initializers.identity,
    'glorot_uniform': tf.initializers.glorot_uniform,
    'glorot_normal': tf.initializers.glorot_normal,
    'truncated_norm': tf.initializers.truncated_normal,
    'he_uniform': HeUniformInitializer,
    'xavier': XavierInitializer,
}


def get(identifier):
    """Get activation function."""
    if identifier is None:
        # this is the initializer used by old tf-library
        return tf.initializers.truncated_normal(stddev=0.05)
    elif isinstance(identifier, six.string_types):
        identifier = str(identifier)
        obj = initializer_dict[identifier]
        if inspect.isclass(obj):
            return obj()
        return obj
    elif callable(identifier):
        return identifier
    else:
        raise TypeError("Could not interpret activation function"
                        "identifier: %s" % identifier)
