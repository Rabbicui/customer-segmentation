# coding: utf-8
import sys
import math
import copy
import tensorflow as tf

from rcalgo.tf.training import context
from rcalgo.tf.utils.text_utils import *


class TFDataset(object):
    def __init__(self, dataset, placeholders=[], raw_data=[], num_elements=0, default_random_seed=None):
        self._dataset = dataset
        self._placeholders = placeholders
        self._raw_data = raw_data
        self._num_elements = num_elements
        self._batch_size = 1

    @staticmethod
    def from_numpy(raw_data):
        """
        tf.data.Dataset.from_tensor_slices()会把数据转换成graph里的constants，导致
        meta graph特别大, 这里从placeholder动态写入，避免这个问题
        """
        dtypes = [ds.dtype if ds.dtype is not np.dtype(np.int64)
                  else np.dtype(np.int32) for ds in raw_data]
        shapes = [ds.shape for ds in raw_data]
        placeholders = [tf.compat.v1.placeholder(dtype, shape)
                        for dtype, shape in zip(dtypes, shapes)]
        dataset = tf.data.Dataset.from_tensor_slices(tuple(placeholders))
        num_elements = raw_data[0].shape[0]
        return TFDataset(dataset, placeholders, raw_data, num_elements)

    @staticmethod
    def from_tf_dataset(dataset, num_elements=None):
        if not num_elements:
            tensor = tf.data.experimental.cardinality(dataset)
            num_elements = context.get_session().run(tensor)
            if num_elements is None:
                raise ValueError("`num_elements` can not be inferenced for this dataset type")
        dataset = dataset.take(num_elements)
        return TFDataset(dataset, num_elements=num_elements)

    def make_iterator(self):
        iterator = self._dataset.make_initializable_iterator()
        return TFDataIterator(iterator, self._placeholders, self._raw_data)

    def batch(self, batch_size, drop_remainder=False, **kwargs):
        copied = copy.copy(self)
        copied._batch_size = batch_size
        copied._dataset = copied._dataset.batch(
            batch_size, drop_remainder=drop_remainder, **kwargs)
        return copied

    def shuffle(self, *args, **kwargs):
        copied = copy.copy(self)
        copied._dataset = copied._dataset.shuffle(*args, **kwargs)
        return copied

    def prefetch(self, *args, **kwargs):
        copied = copy.copy(self)
        copied._dataset = copied._dataset.prefetch(*args, **kwargs)
        return copied

    def shard(self, num_shards, index, drop_remainder=False):
        """
        数据分片, 每个GPU只取其中的一片

        Note:
        这里需要注意，如果num_elements不能被num_shards整除的话，shard函数会尽量去分配，例如
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        num_shards为3时，shard以后的结果是
            [0, 3, 6, 9], [1, 4, 7], [2, 5, 8]
        horovod需要保证每个gpu运行的batch数量一致，但这种不均匀分配有可能会导致不同gpu的batch
        数不一致。我这里是通过_num_elements // num_shards来让每个gpu知道最少的gpu有多少个element.
        所以_num_elements这个字段就是必须的。有些类型例如TFRecordsDataset没法直接从dataset
        推测出来num_elements，就需要从外部显式的传进来
        """
        copied = copy.copy(self)
        remainder_num = copied._num_elements % num_shards
        copied._num_elements = copied._num_elements // num_shards
        if index < remainder_num and drop_remainder:
            copied._num_elements += 1
        copied._dataset = copied._dataset.shard(num_shards, index)
        return copied

    def split(self, num_shards, index, drop_remainder=False):
        """
        数据分片, 每个GPU只取其中的一片, 这里的分片的方式和shard不同.
        如果输入为:
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        shard以后的结果是
            [0, 3, 6, 9], [1, 4, 7], [2, 5, 8]
        split以后的结果是:
            [0, 1, 2], [3, 4, 5], [6, 7, 8, 9]
        """
        copied = copy.copy(self)
        per_split_num = copied._num_elements // num_shards
        skip_num = per_split_num * index
        if index == num_shards - 1 and drop_remainder is False:
            take_num = copied._num_elements - per_split_num * index
        else:
            take_num = per_split_num
        copied._dataset = copied._dataset.skip(skip_num).take(take_num)
        copied._num_elements = take_num
        return copied

    def get_num_elements(self):
        return self._num_elements

    def get_batch_size(self):
        return self._batch_size

    def get_num_steps(self, ceil=False):
        if ceil:
            return math.ceil(self._num_elements / self._batch_size)
        else:
            return self._num_elements // self._batch_size


class TFDataIterator(object):
    def __init__(self, iterator, placeholders, raw_data, max_batch_index=None):
        self._iterator = iterator
        self._placeholders = placeholders
        self._raw_data = raw_data
        self._batch = iterator.get_next()
        self.max_batch_index = (sys.maxsize if max_batch_index is None
                                else max_batch_index)

    def reinitialize(self):
        session = context.get_session()
        feed_dict = dict(zip(self._placeholders, self._raw_data))
        session.run(self._iterator.initializer, feed_dict=feed_dict)

    def next_element(self):
        return self._batch
