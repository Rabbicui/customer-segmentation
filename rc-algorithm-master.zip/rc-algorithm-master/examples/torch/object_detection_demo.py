from rcalgo.torch.image.detection.object_detection import KwaiImageObjectDetectionModel
import os
import sys


config = {
    # 必要参数:
    "model_name": 'yolov5',     # 模型名: 目前支持yolov5
    "num_classes": 4,           # 分类个数
    "class_names": ["Kfc", "Mengniu", "Yili", "Jingdong"],      # 分类对应的名称

    # 默认参数，尽量别改
    "img_size": [640, 640],     # 输入图片的分辨率
    "resume": False,            # 重新恢复训练
    "notest": False,            # False: 只验证最后一个epoch的结果，True: 所有epoch都验证
    "nosave": False,            # False: 只保留最后一个epoch的checkpoint，True: 保last和best的ckpt
    "single_cls": False,        # 是否单类别，True: 单类别，False: 多类别
    "adam": False,              # True: Adam优化器，False: SGD优化器
    "workers": 8,               # maximum number of dataloader workers
    "logdir": './',             # 日志目录默认当前目录
    "logname": 'log_train',     # 日志名
}

model = KwaiImageObjectDetectionModel(config)

# 模型训练集、验证集（仅供示例）
train_path = '/home/web_server/antispam/project/objdet/logo_test/images/train/'
val_path = '/home/web_server/antispam/project/objdet/logo_test/images/val/'

if __name__ == '__main__':

    model.train(
        train_path,
        val_path,
        checkpoint_dir='./',
        checkpoint_name='demo',
        batch_size=16,  # batch_size=16 效果较好
        epochs=20)
