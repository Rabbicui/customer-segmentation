from rcalgo.tf.metric.loss import l2_loss
from rcalgo.tf.module.encoder.embedding_fusion import *

from rcalgo.tf.tftraining.tf_object import TFModel
from collections import defaultdict
import json

from rcalgo.tf.utils.tf_func import replace_default_graph, my_compute_grad

DEFAULT_SUBNET_FUSION_CONFIGS = {
    "block_attention": True,
    "block_attention_fc_layer_dropout": True,
    "block_attention_fc_layer_dropout_ratio": 0.2,
    "block_attention_n_layer": 8,
    "block_attention_n_head": 2,
    "block_attention_size": 64,
    "block_self_attention": True,
    "block_self_attention_size": 128,
    "block_attention_transformer_attention_dropout": 0.3,
    "block_attention_transformer_fc_dropout": 0.3,
    "lmf_fusion": False,
    "lmf_fusion_rank": 20,
    "self_attention": False,
    "additive_attention": False,
    "concat_fusion": False,
    "add_fusion": False,
    "lower_rank_fusion": False
}

DEFAULT_PREFUSION_CONFIGS = dict()
DEFAULT_PREFUSION_CONFIGS['multi'] = {
    "unary_attention": True,
    "pairwise_attention": False,
    "pairwise_attention_groups": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 1024,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": True,
    "post_fc_hidden_size": 1024,
    "post_fc_dropout_ratio": 0.2
}

DEFAULT_PREFUSION_CONFIGS['single'] = {
    "unary_attention": False,
    "pairwise_attention": False,
    "pairwise_attention_types": None,
    "max_pooling": False,
    "avg_pooling": False,
    "pre_fc_layer": True,
    "pre_fc_hidden_size": 1024,
    "pre_fc_dropout_ratio": 0.2,
    "post_fc_layer": True,
    "post_fc_hidden_size": 1024,
    "post_fc_dropout_ratio": 0.2
}


class EmbeddingFusionModel(TFModel):
    """
        The whole procedure follows: pre-process, pre-fusion, subnet fusion
            1. the pre-process is defined by sub class
            2. in pre-fusion stage, embeddings from same source (the group definition used in code)
                are merged to one
            3. in subnet-fusion stage, the merged embeddings from different source are combined
        Also this is the audit free model.
    """
    def __init__(self, config, graph):
        super(EmbeddingFusionModel, self).__init__(config, graph)
        self.init_std = config.init_std
        self.init_scale = config.init_scale
        self.p_coef = config.p_coef

        # subnet fusion config
        subnet_fusion_config_file = config.subnet_fusion_config_file
        self.subnet_fusion_config = None
        if subnet_fusion_config_file is not None:
            with open(subnet_fusion_config_file) as file:
                self.subnet_fusion_config = json.load(file)

        # parse the pre-fusion method for each group
        prefusion_config_file = config.prefusion_config_file
        # if the config is None, all config will be set to default
        self.prefusion_configs = None
        if prefusion_config_file is not None:
            with open(prefusion_config_file) as file:
                self.prefusion_configs = json.load(file)

        self.embedding_cnt = config.embedding_cnt
        self.embedding_sizes = config.embedding_sizes
        self.embedding_sizes = [int(size.strip()) for size in self.embedding_sizes.split(',')]
        assert self.embedding_cnt == len(self.embedding_sizes)
        # to generalize the usage, the group definition is used here same source embeddings
        # (like multiple frames from video) formed as a group. Then we don't need to consider what
        # the embedding really means.
        self.embedding_groups = config.embedding_groups
        self.embedding_groups = [g.strip() for g in self.embedding_groups.split(',')]

        self.idx_2_group_map = dict()
        for idx, g in enumerate(self.embedding_groups):
            self.idx_2_group_map[idx] = g

    ################## following functions need to be override for different task ###############

    def build_task_relative_input(self, extra_inputs):
        # build the specific input for different task
        # in our demo: we have user features which need to be normed
        self.user_input_mean = tf.constant(extra_inputs['user_mean'], dtype=tf.float32, name='mean_user')
        self.user_input_std = tf.constant(extra_inputs['user_std'], dtype=tf.float32, name='std_user')

    def preprocess_input(self, group, group_input_tensors):
        # task related pre-process for input
        # in our demo: we normalize the user features
        if group == 'user':
            return [(inp - self.user_input_mean) / self.user_input_std for inp in group_input_tensors]
        return group_input_tensors

    ##############################################################################################
    def build_input(self, extra_inputs):
        # build placeholder for each embedding group, we don't care what the embedding really means
        all_inputs = []
        for idx, size in enumerate(self.embedding_sizes):
            g = self.idx_2_group_map[idx]
            all_inputs.append(tf.placeholder(tf.float32, [None, size], name=g + '_' + str(idx)))

        input_label = tf.placeholder(tf.int32, [None], name='label')
        # add inputs to collection the sequence is reserved by definition
        self._add_to_graph_inputs(all_inputs)
        self._add_to_graph_targets(input_label)

        # split input feature
        split_all_inputs = []
        for inp in all_inputs:
            split_all_inputs.append(tf.split(inp, self.gpu_num, 0))
        self._add_to_graph_input_dict([split_inputs[0] for split_inputs in split_all_inputs])

        # split label
        self.split_input_labels = tf.split(input_label, self.gpu_num, 0)

        # set input from same source to same group for later pre-fusion
        self.group_inputs_map = defaultdict(list)
        for idx, split_inputs in enumerate(split_all_inputs):
            g = self.idx_2_group_map[idx]
            self.group_inputs_map[g].append(split_inputs)

        self.build_task_relative_input(extra_inputs)

        with tf.name_scope('last_layer'):
            self.last_layer = [[] for _ in range(0, self.gpu_num)]

    def build_classification_model(self, gpu_id=0):
        # pre-process procedure this is defined by specific task
        gpu_inputs_map = {group_name: self.preprocess_input(group_name, [inp[gpu_id] for inp in group_inputs])
                          for group_name, group_inputs in self.group_inputs_map.items()}

        # gpu_inputs_map: group ---> a list of embeddings
        # pre fc layer
        configs = {}
        pre_fc_layers_map = {}
        for group, inputs in gpu_inputs_map.items():
            if self.prefusion_configs is None:
                group_prefusion_config = DEFAULT_PREFUSION_CONFIGS['multi'] if len(inputs) > 1 \
                    else DEFAULT_PREFUSION_CONFIGS['single']
            else:
                group_prefusion_config = self.prefusion_configs[group]
            configs[group] = group_prefusion_config
            pre_fc_layers_map[group] = pre_fc(group, inputs, group_prefusion_config, self.training, self.init_std)

        # pre_fc_layers_map: group ---> a list of embeddings
        # pre-fusion procedure
        pre_fusion_layers_map = {}
        for group, inputs in pre_fc_layers_map.items():
            pw_other_inputs = []
            config = configs[group]
            if config.get('pairwise_attention', False):
                pw_groups = config["pairwise_attention_groups"]
                pw_groups = [g.strip() for g in pw_groups.split(',')]
                pw_other_inputs = [gpu_inputs_map[g] for g in pw_groups]
            layers, _ = pre_fusion(inputs, pw_other_inputs, config)
            layers = [l for l in layers if l is not None]
            if len(layers) > 1:
                # do concat
                pre_fusion_layers_map[group] = tf.concat(layers, axis=-1)
            elif len(layers) == 0:
                # no pre fusion so use the original inputs
                pre_fusion_layers_map[group] = tf.concat(inputs, axis=-1)
            else:
                pre_fusion_layers_map[group] = layers[0]

        # pre_fusion_layers: group ---> embedding since in pre-fusion layer we will merge embeddings
        # from same source to one
        # post fc layer
        layers_after_pre_fusion = []
        for group, layer in pre_fusion_layers_map.items():
            config = configs[group]
            if config.get('post_fc_layer', False):
                size = config['post_fc_hidden_size']
                layer = relu_fc_layer(layer, size, init_std=self.init_std)
                post_dropout = config['post_fc_dropout_ratio']
                if post_dropout > 0:
                    # apply dropout
                    layers_after_pre_fusion.append(my_dropout(layer, rate=post_dropout, training=self.training))

        # subnet-fusion procedure
        subnet_config = DEFAULT_SUBNET_FUSION_CONFIGS if self.subnet_fusion_config is None else self.subnet_fusion_config
        self.last_layer[gpu_id] = subnet_fusion(layers_after_pre_fusion, subnet_config, self.training, self.init_std)

    def build_prediction(self, gpu_id=0, num_classes=2, accK=1):
        prediction = my_full_connected(self.last_layer[gpu_id], num_classes, init_std=self.init_std)
        self.tower_prediction_results.append(tf.nn.softmax(prediction))
        if gpu_id == 0:
            self.output_dict['result'] = self.tower_prediction_results[0]
        with tf.name_scope('loss'):
            loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
                labels=self.split_input_labels[gpu_id], logits=prediction)
            loss = tf.reduce_mean(loss) + self.p_coef * l2_loss()
            grads, capped_gvs = my_compute_grad(self.opt, loss, self.params,
                                                clip_type='clip_value', task=self.default_task_name,
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            labels = self.split_input_labels[gpu_id]
            accuracy = tf.to_float(tf.nn.in_top_k(prediction, labels, k=accK))
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task=self.default_task_name)

    @replace_default_graph
    def build_model(self, num_classes=2, accK=1, *args, **kwargs):
        self.build_input(kwargs)
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('{}{}'.format(self.device_str, gpu_id)):
                with tf.name_scope('Tower_{}'.format(idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_classification_model(gpu_id=idx)
                        self.build_prediction(
                            gpu_id=idx, num_classes=num_classes, accK=accK)
        self.build_model_aggregation()
        self._add_to_graph_outputs(self.prediction_results)
