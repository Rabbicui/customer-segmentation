import os
import re
import sys
# sys.path.insert(0,'..')
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))
from tftools.tf_func import get_from_collection_or_create
from rcalgo.tf.tftraining.tf_object import *
from tensorflow.python.ops import rnn_cell
from tensorflow.keras.layers import LSTMCell, StackedRNNCells
from tensorflow.compat.v2.nn import RNNCellResidualWrapper
from tensorflow.python.ops.rnn import bidirectional_dynamic_rnn, dynamic_rnn


class TextModel(TFModel):
    def __init__(self, config, graph, word_dict=None):
        super(TextModel, self).__init__(config, graph)
        self._init_text_model(config, word_dict)

    def _init_text_model(self, config, word_dict):
        self.nb_words = config.nb_words  # term number in input sequence
        self.maxlen = config.maxlen  # the max length of input sequence
        self.embedding_size = config.embedding_size  # word embedding size
        self.init_std = config.init_std
        self.init_scale = config.init_scale
        self.raw_text = config.raw_text
        #rnn residual connection开关
        self.use_residual = config.use_residual
        self.oov_buckets = config.oov_buckets 
        # hack一下，开始符标记
        self.input_sos_flag = config.sos_flag if hasattr(
            config, 'sos_flag') else True
        self.expand_input = config.expand_input 
        if self.raw_text and word_dict is not None:
            self.word_table, self.nb_words = self._init_word_table(word_dict)
        else:
            self.word_table = None
        self.input_iter_handle = None

    @replace_default_graph
    def _init_word_table(self, word_dict):
        """
        word_dict转成tensorflow的hash_table
        """
        word_dict = dict([(ord(k),v) for (k, v) in word_dict.items() if len(k) == 1]) 
        kv_init = tf.lookup.KeyValueTensorInitializer(list(word_dict.keys()),list(word_dict.values()),
                                                      key_dtype=tf.int64, value_dtype=tf.int64)
        word_table = tf.lookup.StaticVocabularyTable(kv_init,num_oov_buckets=self.oov_buckets)
        nb_words = len(word_dict) + self.oov_buckets
        return word_table, nb_words

    def _get_dataset_output_types(self):
        if self.raw_text:
            return tf.string
        else:
            return [tf.int32]

    def _get_placeholder_default_value(self):
        if self.raw_text:
            return tf.constant('')
        else:
            return tf.constant([0])

    @replace_default_graph
    def _get_input_placeholder(self, maxlen, key='input'):
        """
        输入的placeholder，为tf.string 或者为 bow seq
        """
        input_iter_handle = tf.compat.v1.placeholder_with_default('', shape=[], name='{}_input_iter'.format(key))
        self.batch_input = tf.cond(tf.equal(input_iter_handle, ''),
                                   true_fn=lambda: self._get_placeholder_default_value(),
                                   false_fn=lambda: tf.compat.v1.data.Iterator.from_string_handle(
                                       input_iter_handle,
                                       self._get_dataset_output_types())
                                   .get_next())
        if self.raw_text:
            #raw text作为输入
            input_sents = tf.compat.v1.placeholder_with_default(self.batch_input[0], [None], name='{}_raw_sentence'.format(key))
        else:
            input_sents = tf.compat.v1.placeholder_with_default(self.batch_input[0], [None, maxlen], name='{}__sentence'.format(key))
        return input_sents, input_iter_handle

    def _init_sentence_placeholder_with_default(self):
        self.eos_flag = get_from_collection_or_create(
            tf.compat.v1.GraphKeys.EOS_FLAG,
            lambda: tf.compat.v1.placeholder_with_default(tf.constant(True), tf.TensorShape(None), name='eos_flag')
        )

        self.sos_flag = get_from_collection_or_create(
            tf.compat.v1.GraphKeys.SOS_FLAG,
            lambda: tf.compat.v1.placeholder_with_default(tf.constant(True), tf.TensorShape(None), name='sos_flag')
        )
    
    def _get_input_text_parameters(self, expand_input=False):
        if expand_input:
            self.nb_words = self.nb_words + 2
        return self.word_table, self.maxlen, self.nb_words

    def _get_target_text_parameters(self, expand_input=False):
        return self.word_table, self.maxlen, self.nb_words

    def _get_text_parameters(self, expand_input, key):
        return self._get_input_text_parameters(expand_input) if key.startswith('input') \
                else self._get_target_text_parameters(expand_input)
       
    def _add_text_to_graph(self, key, input_sents, input_iter_handle, split_inputSents):
        if key.startswith('input'):
            self._add_to_graph_inputs(input_sents)
            self._add_to_graph_input_iter(input_iter_handle)
            self.input_dict[key] = split_inputSents[0]
        else:
            self._add_to_graph_targets(input_sents)
   
    def _get_sos_flag(self, key, flag):
        return key.startswith('input') and self.input_sos_flag

    def build_text_input(self, expand_input=False, key='input'):
        """
        key must be start with 'input'(对应encoder) or 'target'（对应decoder）
        这里需要注意的是，RNNLM实际上属于decoder的训练，但是key是input
        """
        assert key.startswith('input') or key.startswith('target')
        with tf.name_scope(key):
            #获取输入相关参数
            word_table, maxlen, nb_words = self._get_text_parameters(expand_input, key)
            #对应的placeholder
            input_sents, input_iter_handle = self._get_input_placeholder(maxlen, key=key)
            split_inputSents = tf.split(input_sents, self.gpu_num, 0)
            include_sos = self._get_sos_flag(key, self.input_sos_flag)
            split_inputX = [self._text_to_bow(
                split_inputSents[i], word_table, maxlen, nb_words, expand_input, include_sos)
                for i in range(0, self.gpu_num)]
            self._add_text_to_graph(key, input_sents, input_iter_handle, split_inputSents)
            split_seqLengths = [tf.count_nonzero(
                split_inputX[i], 1) for i in range(0, self.gpu_num)]
            return split_inputX, split_seqLengths

    def _sos_token_id(self, nb_words):
        # avoid hack in each place
        return nb_words - 2

    def _eos_token_id(self, nb_words):
        return nb_words - 1

    def _expand_input_sequence(self, tensor, nb_words, include_sos=True):
        if isinstance(tensor, SparseTensor):
            return self._expand_sparse_input_sequence(tensor, nb_words, include_sos)
        elif isinstance(tensor, RaggedTensor):
            return self._expand_ragged_input_sequence(tensor, nb_words, include_sos)
        else:
            return tensor

    # add the ids of <SOS> and <EOS>
    def _expand_sparse_input_sequence(self, tensor, nb_words, include_sos=True):
        """
        对输入的tensor(tf sparse tensor)，进行sos和eos的concat
        返回dense tensor
        """
        self._init_sentence_placeholder_with_default()
        #添加，结束符号
        EOS = get_concat_sparse_tensor(tensor, self._eos_token_id(nb_words) * tf.cast(self.eos_flag, dtype=tensor.dtype), True)
        out = sparse_to_dense(tf.sparse_concat(1, [tensor, EOS]))
        #开始符号是否添加
        if include_sos:
            SOS = tf.ones_like(out[:, 0:1],dtype=tensor.dtype) * self._sos_token_id(nb_words) * tf.cast(self.sos_flag, dtype=tensor.dtype)
            out = tf.where(self.sos_flag, tf.concat([SOS, out],1), tf.concat([out, SOS],1))
        return out
    
    def _expand_ragged_input_sequence(self, tensor, nb_words, include_sos=True):
        """
        对输入的tensor(tf ragged tensor)，进行sos和eos的concat
        返回dense tensor
        """
        self._init_sentence_placeholder_with_default()
        #添加，结束符号
        EOS = tf.fill([tensor.nrows(), 1],
                      self._eos_token_id(nb_words) * tf.cast(self.eos_flag, dtype=tensor.dtype))
        out = tf.concat([tensor, EOS], axis=1)

        if include_sos:
            SOS = tf.fill([tensor.nrows(), 1],
                      self._sos_token_id(nb_words) * tf.cast(self.sos_flag, dtype=tensor.dtype))
            out = tf.where(self.sos_flag, tf.concat([SOS, out],1), tf.concat([out, SOS],1))
        return convert_to_dense(out)

    def _text_to_bow(self, split_inputSents, word_table, maxlen, nb_words, expand_input=False,
                     include_sos=True):
        """
        convert raw texts to bag of words
        """
        if split_inputSents.dtype == tf.string:
            # split string
            #out = word_table.lookup(tf.strings.unicode_split(split_inputSents, 'UTF-8').to_sparse())
            #out = tf.ragged.map_flat_values(lambda x: word_table.lookup(x), tf.strings.unicode_split(split_inputSents, 'UTF-8'))
            #hack blank
            split_inputSents = tf.strings.regex_replace(split_inputSents, '\\s+', ' ')
            out = tf.strings.unicode_decode(split_inputSents, input_encoding='UTF-8')#.to_sparse(), dtype=tf.int64)
            out = word_table.lookup(tf.cast(out.to_sparse(), dtype=tf.int64))
            if expand_input:
            #扩展前后标志位
                # add <SOS>(start of sentence) and <EOS> (end of sentence)
                inputX = self._expand_input_sequence(out, nb_words, include_sos) 
            else:
                inputX = convert_to_dense(out)
            if maxlen > 0:
                #每一个batch的文本长度需要统一，不然在某些场景下会报错
                paddings = tf.constant([[0, 0], [0, maxlen]])
                bow_paddings = tf.pad(inputX, paddings, "CONSTANT")[:, 0:maxlen]
                bow_paddings.set_shape([None, maxlen])
            else:
                # for dynamic length
                bow_paddings = inputX 
            return bow_paddings
        else:
            return split_inputSents

    def build_input(self, expand_input=False):
        """
        初始化输入文本相关
        返回输入的bow，长度
        """
        self.split_inputX, self.split_seqLengths = self.build_text_input(expand_input=expand_input,
                                                                         key='input')
        self.input_embedding = [[] for i in range(0, self.gpu_num)]
        self.dynamic_batch_size = tf.shape(self.split_inputX[0])[0]
        
    def loss_function(self, prediction, targets, nb_class):
        return 0.0
    
    def metrics_function(self, prediction, targets, accK):
        return 0.0
    
    def compute_metrics(self, logits, targets, metrics_name='accuracy', task=None, nb_class=None, accK=5):
        with tf.name_scope('loss'):
            if self.params is None:
                self.params = tf.compat.v1.trainable_variables()
            loss = self.loss_function(logits, targets, nb_class)
            grads, capped_gvs = my_compute_grad(self.opt, loss, self.params,
                                                clip_type='clip_value', task=task,
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope(metrics_name):
            accuracy = self.metrics_function(logits, targets, accK)
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task) 
        
        
    def _build_embedding_layer(self, gpu_id=0, variables_collections='encoder_embedding'):
        """
        embedding layer
        """
        with get_new_variable_scope('embedding', custom_getter=fp32_storage_getter) as embedding_scope:
            self.input_embedding[gpu_id] = my_embedding_layer(self.split_inputX[gpu_id],
                                                              self.nb_words, self.embedding_size,
                                                              variables_collections=variables_collections,
                                                              layer_name='embedding_layer', init_scale=self.init_scale,
                                                              dtype=get_default_float_type())

    def get_embedder(self, vocab, embedding_size=None,
                     variables_collections=None, layer_name='embedding_layer'):
        """
        embedder, 兼容texar
        """
        if embedding_size is None:
            embedding_size = self.embedding_size
        return WordEmbedder(vocab, embedding_size,
                            variables_collections=variables_collections,
                            layer_name=layer_name,
                            init_scale=self.init_scale)

    def _build_position_layer(self, gpu_id, position_type, conv_num_filters,
                              combine_mode='ADD', padding='LEFT_SAME', act=tf.nn.relu):
        """
        position embedding layer
        """
        self._build_embedding_layer(gpu_id)
        if position_type == 'pos':
            return self.input_embedding[gpu_id] + google_position_embedding(self.maxlen, self.embedding_size)
        else:
            try:
                return multi_width_cnn_block(self.input_embedding[gpu_id], conv_num_filters, position_type,
                                             combine_mode=combine_mode, padding=padding, act=act)
            except ValueError:
                return self.input_embedding[gpu_id]


    def build_cell(self, hidden_size, keep_prob, num_layers, use_old_version=False):
        if use_old_version:
            return my_rnn_cell_v1(hidden_size, keep_prob, num_layers, self.use_residual)
        else:
            return my_rnn_cell_v2(hidden_size, keep_prob, num_layers, self.use_residual)
