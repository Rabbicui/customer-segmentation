import tensorflow as tf

from rcalgo.tf.module.base_module import Module
from rcalgo.tf.modules_v2.layers.common import Dense, Dropout, LayerNormalization
from rcalgo.tf.modules_v2.module_utils import get_shape_list


def split_heads(inputs, num_heads):
    """Splits a tensor in depth."""
    shape = get_shape_list(inputs)
    depth = shape[-1]
    outputs = tf.reshape(
        inputs,
        shape[:-1] + [num_heads, depth // num_heads])
    outputs = tf.transpose(outputs, [0, 2, 1, 3])
    return outputs


def combine_heads(inputs):
    """Concatenate heads."""
    inputs = tf.transpose(inputs, [0, 2, 1, 3])
    shape = get_shape_list(inputs)
    depth = shape[-1]
    num_heads = shape[-2]
    outputs = tf.reshape(
        inputs,
        shape[:-2] + [depth * num_heads])
    return outputs


class FeedForward(Module):
    """Implements the Transformer's "Feed Forward" layer."""

    def __init__(self,
                 inner_dim,
                 output_dim,
                 activation=tf.nn.relu,
                 name=None):
        """Initialize this layer."""
        super(FeedForward, self).__init__(name=name)
        self.inner = Dense(
            inner_dim,
            activation=activation,
            name="inner")
        self.outer = Dense(output_dim, name="outer")

    def call(self, inputs):
        inner = self.inner(inputs)
        return self.outer(inner)


class MultiHeadAttention(Module):
    """Computes the multi-head attention as described in
    https://arxiv.org/abs/1706.03762.
    """
    def __init__(self,
                 num_heads,
                 num_units,
                 dropout=0.1,
                 return_attention=False,
                 name=None):
        """Initialize this layer."""
        super(MultiHeadAttention, self).__init__(name=name)

        if num_units % num_heads != 0:
            raise ValueError("Multi head attetion requires that num_units"
                             "is a multiple of %s" % num_heads)
        self.num_heads = num_heads
        self.num_units = num_units
        self.linear_queries = Dense(num_units, name="queries")
        self.linear_key = Dense(num_units, name="key")
        self.linear_value = Dense(num_units, name="value")
        self.linear_output = Dense(num_units, name="output")
        self.dropout = Dropout(rate=dropout)

    def call(self, inputs, memory=None, mask=None, training=None,
             return_attention=False):
        """Compute multi-head attention.

        Cache mechanism is not implemented.
        """
        def _compute_kv(x):
            return keys, values

        # compute queries
        queries = self.linear_key(inputs)
        queries = split_heads(queries, self.num_heads)
        queries *= (self.num_units // self.num_heads) ** -0.5

        # compute keys and values
        if memory is None:
            memory = inputs
        keys = self.linear_key(memory)
        keys = split_heads(keys, self.num_heads)
        values = self.linear_value(memory)
        values = split_heads(values, self.num_heads)

        # Dot product attention
        dot = tf.matmul(queries, keys, transpose_b=True)
        if mask is not None:
            mask = tf.expand_dim(tf.cast(mask, tf.float32), 1)
            dot = tf.cast(
                tf.cast(dot, tf.float32) * mask + ((1.0 - mask) * tf.float32.min),
                dot.dtype)
        attns = tf.cast(tf.nn.softmax(tf.cast(dot, tf.float32)), dot.dtype)
        dropped_attention = self.dropout(attns, training=training)
        heads = tf.matmul(dropped_attention, values)

        # concate all heads outputs
        combined = combine_heads(heads)
        outputs = self.linear_output(combined)
        if return_attention:
            return outputs, attns
        return outputs


class TransformerEncoderLayer(Module):
    """Transformer block layer."""

    def __init__(self,
                 num_units,
                 num_heads,
                 ffn_inner_dim,
                 attention_dropout=0.1,
                 hidden_dropout=0.1,
                 ffn_activation=tf.nn.relu,
                 name=None):
        """Initialize this layer."""
        super(TransformerEncoderLayer, self).__init__(name=name)
        self.mha = MultiHeadAttention(
            num_heads, num_units,
            dropout=attention_dropout,
            name="multi_head_attention")

        self.ffn = FeedForward(
            ffn_inner_dim, num_units,
            activation=ffn_activation,
            name="feed_forward")

        self.dropout1 = Dropout(hidden_dropout)
        self.dropout2 = Dropout(hidden_dropout)

        self.layer_norm1 = LayerNormalization()
        self.layer_norm2 = LayerNormalization()

    def call(self, inputs, mask=None, training=None):
        attn_output = self.mha(inputs, mask=mask, training=training)
        attn_output = self.dropout1(attn_output, training=training)
        hidden = self.layer_norm1(attn_output + inputs)

        ffn_output = self.ffn(hidden)
        ffn_output = self.dropout2(ffn_output, training=training)
        output = self.layer_norm2(ffn_output + hidden)
        return output
