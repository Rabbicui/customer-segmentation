# coding: utf-8

import argparse
import logging
import logging.config
import os
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))


def bit_parser(parser):
    parser.add_argument("--name", required=True,
                        help="Name of this run. Used for monitoring and checkpointing.")
    parser.add_argument("--model", type=str, default=None,
                        help="Which variant to use; BiT-M gives best results.")
    parser.add_argument("--logdir", required=True,
                        help="Where to log training info (small).")
    parser.add_argument("--bit_pretrained_dir", default='.',
                        help="Where to search for pretrained BiT models.")
    parser.add_argument("--batch", type=int, default=512,
                        help="Batch size.")
    parser.add_argument("--batch_split", type=int, default=1,
                        help="Number of batches to compute gradient on before updating weights.")
    parser.add_argument("--gpu_num", type=int, default=1,
                        help="gpu count for run")
    parser.add_argument("--base_lr", type=float, default=0.003,
                        help="Base learning-rate for fine-tuning. Most likely default is best.")
    parser.add_argument("--eval_every", type=int, default=None,
                        help="Run prediction on validation set every so many steps."
                             "Will always run one evaluation at the end of training.")
    parser.add_argument("--save_path", type=str, default=None,
                        help="save path for ckpt")
    parser.add_argument("--save_checkpoint", type=bool, default=True,
                        help="whether save checkpoint or only the weights.")
    return parser

def uda_parser(parser):
    parser.add_argument("--unsup_ratio", type=int, default=7,
                        help="the batch size for unsup part is ratio * batch_size.")
    parser.add_argument("--uda_softmax_temp", type=float, default=-1,
                        help="The temperature of the Softmax when making prediction on unlabeled,"
                             "-1 mean no effect")
    parser.add_argument("--uda_confidence_thresh", type=float, default=-1,
                        help="The threshold on predicted probability on unsupervised data. If set, "
                             "UDA loss will only be calculated on unlabeled examples whose largest "
                             "probability is larger than the threshold")
    parser.add_argument("--ent_min_coeff", type=float, default=0,
                        help="")
    parser.add_argument("--unsup_coeff", type=float, default=1,
                        help="The coefficient on the UDA loss.")
    parser.add_argument("--aug_magnitude", type=int, default=10,
                        help="The temperature of the Softmax when making prediction on unlabeled,"
                             "-1 mean no effect")
    parser.add_argument("--aug_num_layers", type=int, default=2,
                        help="Num of augs used sequentially for rand augumentation. ")
    return parser

def parser_for_bit():
    parser = argparse.ArgumentParser(description="Fine-tune BiT-M model.")
    return bit_parser(parser)

def parser_for_uda():
    parser = parser_for_bit()
    return uda_parser(parser)


def setup_logger(args):
    """Creates and returns a fancy logger."""
    # return logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s")
    # Why is setting up proper logging so !@?#! ugly?
    os.makedirs(os.path.join(args.logdir, args.name), exist_ok=True)
    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": {
                "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            },
        },
        "handlers": {
            # "stderr": {
            #     "level": "INFO",
            #     "formatter": "standard",
            #     "class": "logging.StreamHandler",
            #     "stream": "ext://sys.stderr",
            # },
            "logfile": {
                "level": "DEBUG",
                "formatter": "standard",
                "class": "logging.FileHandler",
                "filename": os.path.join(args.logdir, args.name, "train.log"),
                "mode": "a",
            }
        },
        "loggers": {
            "": {
                # "handlers": ["stderr", "logfile"],
                "handlers": ["logfile"],
                "level": "DEBUG",
                "propagate": True
            },
        }
    })
    logger = logging.getLogger(__name__)
    logger.flush = lambda: [h.flush() for h in logger.handlers]
    logger.info(args)
    return logger
