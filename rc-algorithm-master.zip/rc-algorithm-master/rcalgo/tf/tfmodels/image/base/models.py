import tensorflow as tf
from rcalgo.tf.tfmodels.image.base.layers import *
from rcalgo.tf.tfmodels.image.base.attentions import *


def add_name_prefix(name, prefix=None):
    return prefix + "/" + name if prefix else name


def covert_x(x, extras):
    """
    一些block 会输出多个结果，我们默认第一个是target tensor，其他的都是附加信息 会被加入到extras
    """
    if len(x) > 1:
        for y in x[1:]:
            if isinstance(y, list) or isinstance(y, tuple):
                extras += y
            else:
                extras.append(y)
        x = x[0]
    return x


class ResnetV2WithAttention(tf.keras.Model):
    #TODO extra the basic part
    """Generic ResnetV2 architecture, as used in the BiT paper.
       Various attentions are supported.
            in_block_attention_module: cbam
                configs: ratio, kernel size
            out_block_attention_module: learn to attention (自研)
                configs: out_block_attention_flags (a list of 0 or 1 corresponding to block units means
                    which block is used in final attention)
    """

    def __init__(self,
                 num_units=(3, 4, 6, 3),
                 num_outputs=1000,
                 filters_factor=4,
                 strides=(1, 2, 2, 2),
                 attention_params=None,
                 **kwargs):
        super(ResnetV2WithAttention, self).__init__(**kwargs)

        num_blocks = len(num_units)
        num_filters = tuple(16 * filters_factor * 2 ** b for b in range(num_blocks))

        self._in_block_attention_module = None
        self._out_block_attention_module = None
        if attention_params is not None:
            self._in_block_attention_module = attention_params.get('in_block_attention_module', None)
            self._out_block_attention_module = attention_params.get('out_block_attention_module', None)

        self._root = self._create_root_block(num_filters=num_filters[0])
        self._blocks = []
        self._out_block_attention_layers = []
        self._info_collector = []
        # collect extra output info
        for b, (f, u, s) in enumerate(zip(num_filters, num_units, strides), 1):
            n = "block{}".format(b)
            self._blocks.append(
                self._create_block(num_units=u, num_filters=f, stride=s, name=n,
                                   attention_module=self._in_block_attention_module,
                                   attention_config=attention_params,
                                   collector=self._info_collector))
            if self._out_block_attention_module is not None and self._out_block_attention_module == 'lta':
                self._out_block_attention_flags = attention_params['lta_attention_flags']
                if bool(self.flags[b]):
                    self._out_block_attention_layers.append(
                        LearnToAttentionLayer(f, False, 0,
                                              name='learn_to_attention_%2d' % num_filters))

        self._pre_head = [
            layers.GroupNormalization(name="group_norm"),
            ReLU(),
            tf.keras.layers.GlobalAveragePooling2D()
        ]
        self._head = None
        if num_outputs:
            self._head = tf.keras.layers.Dense(
                units=num_outputs,
                use_bias=True,
                kernel_initializer="zeros",
                trainable=self.trainable,
                name="head/dense")


    def _create_root_block(self,
                           num_filters,
                           conv_size=7,
                           conv_stride=2,
                           pool_size=3,
                           pool_stride=2):
        layers = [
            PaddingFromKernelSize(conv_size),
            StandardizedConv2D(
                filters=num_filters,
                kernel_size=conv_size,
                strides=conv_stride,
                trainable=self.trainable,
                use_bias=False,
                name="standardized_conv2d"),
            PaddingFromKernelSize(pool_size),
            tf.keras.layers.MaxPool2D(
                pool_size=pool_size, strides=pool_stride, padding="valid")
        ]
        return tf.keras.Sequential(layers, name="root_block")

    def _create_block(self, num_units, num_filters, stride, name, attention_module,
                      attention_config=None, collector=None):
        layers = []
        for i in range(1, num_units + 1):
            layers.append(
                BottleneckV2Unit(
                    num_filters=num_filters,
                    stride=(stride if i == 1 else 1),
                    name="unit%02d" % i,
                    attention_module=attention_module,
                    attention_config=attention_config,
                    collector=collector))
        return tf.keras.Sequential(layers, name=name)

    def compute_output_shape(self, input_shape):
        current_shape = self._root.compute_output_shape(input_shape)
        for block in self._blocks:
            current_shape = block.compute_output_shape(current_shape)
        for layer in self._pre_head:
            current_shape = layer.compute_output_shape(current_shape)
        if self._head is not None:
            batch_size, features = current_shape.as_list()
            current_shape = (batch_size, 1, 1, features)
            current_shape = self._head.compute_output_shape(current_shape).as_list()
            current_shape = (current_shape[0], current_shape[3])
        return tf.TensorShape(current_shape)

    def call(self, x):
        # clear the info collector
        self._info_collector.clear()
        x = self._root(x)
        l_units = []
        for block in self._blocks:
            x = block(x)
            l_units.append(x)
        for layer in self._pre_head:
            x = layer(x)
        if self._out_block_attention_module is not None:
            # 使用每个unit的attention输出合并作为logit
            new_xs = []
            idx = 0
            for l, f in zip(l_units, self._out_block_attention_flags):
                if bool(f):
                    new_x = self._out_block_attention_layers[idx]((l, x))
                    new_xs.append(new_x)
                    idx += 1
            x = tf.concat(new_xs, axis=1)
        if self._head is not None:
            x = self._head(x)
        return x


class ResnetWithMLP(ResnetV2WithAttention):
    def __init__(self, hidden_mlp, output_mlp, **kwargs):
        super(ResnetWithMLP, self).__init__(**kwargs)
        l1 = tf.keras.layers.Dense(hidden_mlp,
                                 kernel_initializer='he_normal',
                                 use_bias=True,
                                 bias_initializer='zeros',
                                 name='pre_linear_%2d' % hidden_mlp)
        l2 = tf.keras.layers.Dense(output_mlp,
                                 use_bias=True,
                                 bias_initializer='zeros',
                                 name='linear_%2d' % output_mlp)
        self._head = tf.keras.Sequential([l1, ReLU(), l2])

    def get_prototypes(self):
        return self._prototypes

    def call(self, x):
        # HACK blur and norm 放在这里做
        self._info_collector.clear()
        x = self._root(x)
        for block in self._blocks:
            x = block(x)
        for layer in self._pre_head:
            x = layer(x)
        self._info_collector.append(x)
        if self._head is not None:
            x = self._head(x)
        x = tf.math.l2_normalize(x, axis=1)
        self._info_collector.append(x)
        # collect the raw embedding
        return x


KNOWN_MODELS = {
    f'{bit}-R{l}x{w}': f'gs://bit_models/{bit}-R{l}x{w}.h5'
    for bit in ['BiT-S', 'BiT-M']
    for l, w in [(50, 1), (50, 3), (101, 1), (101, 3), (152, 4)]
}

NUM_UNITS = {
    k: (3, 4, 6, 3) if 'R50' in k else
    (3, 4, 23, 3) if 'R101' in k else
    (3, 8, 36, 3)
    for k in KNOWN_MODELS
}
