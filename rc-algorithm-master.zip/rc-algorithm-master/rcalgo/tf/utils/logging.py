import logging

FORMAT = '%(asctime)s  %(filename)s (%(lineno)d) (%(threadName)s) : %(levelname)s  %(message)s'
logger = logging.getLogger('tf_library')
logger.setLevel(logging.DEBUG)
console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter(FORMAT))
logger.addHandler(console_handler)
logger.propagate = False
