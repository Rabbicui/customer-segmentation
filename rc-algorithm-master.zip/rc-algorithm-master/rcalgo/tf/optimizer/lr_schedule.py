import tensorflow as tf
from tensorflow.python.framework import ops
from tensorflow.python.ops import math_ops
from rcalgo.tf.utils.tf_func import check_not_nan
from rcalgo.tf.utils.tf_float_type import get_default_float_type


def learning_rate_warm_up(lr_params, name=None):
    """
    warm up learning rate
    """
    if lr_params.global_step is None:
        raise ValueError("global_step is required for exponential_decay.")
    with ops.name_scope(name, "warm_up") as name:
        learning_rate = ops.convert_to_tensor(
            lr_params.learning_rate, name="learning_rate")
        dtype = learning_rate.dtype
        global_step = math_ops.cast(lr_params.global_step, dtype)
        total_steps = math_ops.cast(lr_params.decay_steps, dtype)
        warmup = tf.to_float(lr_params.warmup)
        p = global_step / total_steps
        return math_ops.multiply(learning_rate, math_ops.divide(p, warmup), name=name)


def warm_up_linear_decay(lr_params, name=None):
    if lr_params.global_step is None:
        raise ValueError("global_step is required for exponential_decay.")
    with ops.name_scope(name, "warm_up") as name:
        learning_rate = ops.convert_to_tensor(
            lr_params.learning_rate, name="learning_rate")
        dtype = learning_rate.dtype
        global_step = math_ops.cast(lr_params.global_step, dtype)
        total_steps = math_ops.cast(lr_params.decay_steps, dtype)
        warmup = tf.to_float(lr_params.warmup)
        p = global_step / total_steps
        s = tf.cast(p <= warmup, get_default_float_type())
        schedule = (s*(p/warmup) + (1-s))*(1-p)
        return math_ops.multiply(learning_rate, schedule, name=name)


def warm_up_cosine_decay(lr_params, name=None):
    if lr_params.global_step is None:
        raise ValueError("global_step is required for exponential_decay.")
    with ops.name_scope(name, "warm_up") as name:
        learning_rate = ops.convert_to_tensor(
            lr_params.learning_rate, name="learning_rate")
        dtype = learning_rate.dtype
        global_step = math_ops.cast(lr_params.global_step, dtype)
        total_steps = math_ops.cast(lr_params.decay_steps, dtype)
        warmup = tf.to_float(lr_params.warmup)
        p = global_step / total_steps
        s = tf.cast(p <= warmup, get_default_float_type())
        # the cosine decay steps from 0
        warmup_steps = warmup * total_steps
        return s*learning_rate_warm_up(lr_params, name) + (1-s)*tf.train.cosine_decay(learning_rate, global_step - warmup_steps, total_steps - warmup_steps, name=name)


def noam_learning_rate_schedule(lr_params, name=None):
    step_num = lr_params.global_step
    warmup_steps = lr_params.warmup_steps
    warmup_percentage = lr_params.warmup
    noam_hidden_size = lr_params.noam_hidden_size
    if warmup_steps is None:
        check_not_nan(warmup_percentage, 'warmup_percentage')
    check_not_nan([step_num, noam_hidden_size], ['global_step', 'noam_hidden_size'])
    with ops.name_scope(name, 'noam_schedule') as name:
        learning_rate = ops.convert_to_tensor(
            lr_params.learning_rate, name="learning_rate")
        if warmup_steps is not None:
            warmup_steps = tf.to_float(warmup_steps)
        else:
            warmup_steps = tf.to_float(warmup_percentage) * tf.to_float(lr_params.decay_steps)
        noam_hidden_size = tf.to_float(noam_hidden_size)
        learning_rate *= (noam_hidden_size ** -0.5)
        # apply linear warmup
        learning_rate *= tf.minimum(1.0, (step_num + 1) / warmup_steps)
        # apply rsqrt decay
        learning_rate *= tf.rsqrt(tf.maximum((step_num + 1), warmup_steps))
        return learning_rate
