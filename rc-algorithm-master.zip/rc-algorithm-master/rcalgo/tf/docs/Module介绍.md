

## Module介绍

我们实现模型的时候不可能每次都从最底层的op开始构建，更多的时候是像搭积木一样，使用一些已经搭好的基本模块来组装成自己需要的模型。这些基本模块都应该遵循一些相同的规则，这样在使用的时候才能更方便，Module类就是定义了这样一套规则，它是所有module的基类。

为了方便跟keras混用，我们的Module跟tf.keras.layers.Layer非常相似，它定义了跟tf.keras.layers.Layer相同的接口(`build()`和`call()`)，同时去除了keras中不相关的逻辑。

Module基类的定义如下：

```python
class Module(tf.Module):
    """Base class inherited by modules."""
    def __init__(self, *args, **kwargs):
      	# variable和sublayers都应该在这里或者在build()中进行定义
        super(Module, self).__init__(*args, **kwargs)
        self.built = False

    def build(self, input_shape):
      	# 只会在第一次调用__call__函数时被调用一次
      	# 有些variable和sublayer需要知道input_shape，可以在这里定义
        self.built = True

    @tf.Module.with_name_scope
    def __call__(self, inputs, *args, **kwargs):
        if not self.built:
            input_list = nest.flatten(inputs)
            input_shapes = None
            if all(hasattr(x, "shape") for x in input_list):
                input_shapes = nest.map_structure(
                    lambda x: x.shape.as_list(), inputs)
                self.build(input_shapes)
        return self.call(inputs, *args, **kwargs)

    def call(self, inputs, **kwargs):
      	# 构建前向图
        return input
```

>  pytorch的torch.nn.Module其实也是类似的接口，只是没有build(因为pytorch不需要预先构图)，并把call改名成了forward

> Module和model的区别是module只负责构图，它和训练无关，因此不会用到session。



### 使用方式

Module的使用和keras的layer是一样的，这里直接贴keras的例子：

```python
# In the tf.keras.layers package, layers are objects. To construct a layer,
# simply construct the object. Most layers take as a first argument the number
# of output dimensions / channels.
layer = tf.keras.layers.Dense(100)
# The number of input dimensions is often unnecessary, as it can be inferred
# the first time the layer is used, but it can be provided if you want to
# specify it manually, which is useful in some complex models.
layer = tf.keras.layers.Dense(10, input_shape=(None, 5))

# To use a layer, simply call it.
layer(tf.zeros([10, 5]))
```

因为layer继承了tf .Module，所以它自带track variable的功能(也就是知道self.xx里面到底用到了哪些variable)，也自带name_scope的功能(默认是Module名称的小写)

```python
# Layers have many useful methods. For example, you can inspect all variables
# in a layer using `layer.variables` and trainable variables using
# `layer.trainable_variables`. In this case a fully-connected layer
# will have variables for weights and biases.
layer.variables
```



### 实现自定义Module

自定义module需要继承Module，并实现以下几个接口：

1. \__init__: 解析参数，初始化与输入无关的variable
2. build: 初始化与input_shape相关的权重
3. call: 前向计算

一个自定义全连接层的例子：

```python
class MyDenseLayer(Module):
  def __init__(self, num_outputs):
    super(MyDenseLayer, self).__init__()
    self.num_outputs = num_outputs

  def build(self, input_shape):
    self.kernel = tf.Variable(name="kernel", shape=[int(input_shape[-1]), self.num_outputs])

  def call(self, input):
    return tf.matmul(input, self.kernel)

# usage
layer = MyDenseLayer(10)
_ = layer(tf.zeros([10, 5])) # Calling the layer `.builds` it.
print([var.name for var in layer.trainable_variables])
```
outputs:
```text
['my_dense_layer/kernel:0']
```



### 实现复杂的Module

更复杂的module可以一些基本的module组合得到:

```python
# 注意这里的Dense, Dropout等目前都还没实现，只是举个例子
class FeedForwardNetwork(Module):
  def __init__(self, inner_dim, output_dim, dropout=0.1, activation=tf.nn.relu):
    super(FeedForwardNetwork, self).__init__(**kwargs)
    self.inner = Dense(inner_dim, activation=activation)
    self.outer = Dense(output_dim)
    self.dropout = Dropout(dropout)
    
  def call(self, inputs, training=None):
    inner = self.inner(inputs)
    inner = self.dropout(inner, training=training)
    return self.outer(inner)
```





### 参考资料：

* [tensorflow中关于keras Layer的tutorial](https://www.tensorflow.org/tutorials/customization/custom_layers)