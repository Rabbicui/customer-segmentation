import tensorflow as tf
from tensorflow.python.ops.candidate_sampling_ops import learned_unigram_candidate_sampler

from rcalgo.tf.utils.tf_func import label_smoothing, shape_list


def l2_loss():
    """
    L2 Loss for trainable variables
    """
    train_vars = tf.compat.v1.trainable_variables()
    lossL2 = tf.add_n([tf.nn.l2_loss(v) for v in train_vars])
    return lossL2


def my_sparse_cross_entropy_loss(labels, prediction, num_classes, label_smooth=0.0):
    labels_dim = tf.shape(labels).shape.dims[0].value
    pred_dim = tf.shape(prediction).shape.dims[0].value
    if pred_dim - labels_dim == 1 and label_smooth == 0.0:
        loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
            labels=labels, logits=prediction)
    else:
        y_true = labels
        if pred_dim - labels_dim == 1:
            y_true = tf.one_hot(y_true, depth=num_classes)
        if label_smooth > 0.0:
            y_true = label_smoothing(y_true, label_smooth)
        loss = tf.nn.softmax_cross_entropy_with_logits_v2(
            labels=y_true, logits=prediction)
    return loss


def my_sampled_softmax_loss(inputs, labels, num_classes, num_sampled,
                            sampler_func=learned_unigram_candidate_sampler,
                            num_true=1, init_std=0.05, label_smooth=0.0, label_indices=None):
    """
    sampled softmax loss
    Main Args:
    inputs: [None, hidden_size]
    labels: [None]
    """
    # 获取非0的位置，从而减少计算loss的时候的计算量
    if label_indices is None:
        label_mask = tf.cast(tf.sign(tf.abs(labels)), dtype=tf.int32)
        label_indices = tf.reshape(tf.compat.v2.where(tf.not_equal(label_mask, tf.constant(0, label_mask.dtype))), [-1])
    # 获取真实的需要计算的inputs和labels
    inputs_true = tf.gather(inputs, label_indices)
    labels_reshape = tf.reshape(tf.gather(labels, label_indices), [-1, 1])
    # 基本的fc步骤
    weights_initializer = tf.truncated_normal_initializer(
        stddev=init_std)
    biases_initializer = tf.zeros_initializer()
    weights = tf.compat.v1.get_variable("W", [inputs.get_shape()[-1].value, num_classes],
                                        initializer=weights_initializer)
    biases = tf.compat.v1.get_variable(
        "B", [num_classes], initializer=biases_initializer)
    # sampler function
    # more details: https://www.orchome.com/1574
    sampled_values = sampler_func(
        labels_reshape, num_true, num_sampled, True, num_classes)
    sampled_softmax_loss = tf.nn.sampled_softmax_loss(tf.transpose(weights), biases, labels_reshape,
                                                      inputs_true, num_sampled, num_classes,
                                                      num_true, sampled_values)
    logits = tf.matmul(inputs, weights) + biases
    # loss = tf.cond(training, lambda: train_loss, lambda: my_sparse_cross_entropy_loss(labels, logits, num_classes, label_smooth))
    full_softmax_loss = my_sparse_cross_entropy_loss(
        labels, logits, num_classes, label_smooth)
    return [sampled_softmax_loss, full_softmax_loss], logits


def mask_seq_loss(seq_loss, mask):
    seq_loss *= mask
    seq_loss = tf.reduce_sum(seq_loss, 1)
    seq_loss /= tf.reduce_sum(mask, 1)
    seq_loss = tf.reduce_mean(seq_loss, 0)
    return seq_loss


def my_seq_sampled_softmax_loss(inputs, labels, num_classes, num_sampled,
                                sampler_func=learned_unigram_candidate_sampler,
                                num_true=1, init_std=0.05, label_smooth=0.0, seq_loss_by_example=False):
    """
    inputs: [None, maxlen, hidden_size] 或 [None, hidden_size]
    labels: [None, maxlen] 或者 [None]
    """
    inputs_shape = shape_list(inputs)
    labels_shape = shape_list(labels)
    inputs_flat = tf.reshape(inputs, [-1, inputs_shape[-1]])
    labels_flat = tf.reshape(labels, [-1])
    [sampled_softmax_loss, full_softmax_loss], logits = my_sampled_softmax_loss(
        inputs_flat, labels_flat, num_classes, num_sampled, sampler_func, num_true, init_std, label_smooth)
    if seq_loss_by_example and len(inputs_shape) == 3:
        label_mask = tf.cast(tf.sign(tf.abs(labels)), dtype=tf.int32)
        label_indices = tf.compat.v2.where(tf.not_equal(label_mask, tf.constant(0, label_mask.dtype)))
        sampled_softmax_loss = tf.sparse.to_dense(tf.SparseTensor(
            label_indices, sampled_softmax_loss, tf.shape(labels, out_type=tf.int64)))
        full_softmax_loss = tf.sparse.to_dense(tf.SparseTensor(
            label_indices, full_softmax_loss, tf.shape(labels, out_type=tf.int64)))
        sampled_softmax_loss = mask_seq_loss(sampled_softmax_loss, tf.cast(label_mask, tf.float32))
        full_softmax_loss = mask_seq_loss(full_softmax_loss, tf.cast(label_mask, tf.float32))
    else:
        sampled_softmax_loss = tf.reduce_mean(sampled_softmax_loss)
        full_softmax_loss = tf.reduce_mean(full_softmax_loss)

    if len(inputs_shape) == 3:
        logits = tf.reshape(logits, [-1, inputs_shape[-2], num_classes])
    return [sampled_softmax_loss, full_softmax_loss], logits
    # return loss, logits


# the seq loss for the targets which have variable length
# y_pred shape: [None, maxlen, nb_classes]    y_true shape: [None, maxlen]
def variable_seq_loss(y_pred, y_true, label_smooth=0.0, nb_class=0):
    if label_smooth > 0.0:
        if nb_class == 0:
            raise ValueError(
                'if using label smoothing, please input the nb_class for one_hot')
        else:
            y_true_smoothed = label_smoothing(
                tf.one_hot(y_true, depth=nb_class), label_smooth)
            cross_entropy = tf.nn.softmax_cross_entropy_with_logits_v2(
                labels=y_true_smoothed, logits=y_pred)
    else:
        cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(
            labels=y_true, logits=y_pred)
    mask = tf.cast(tf.sign(tf.abs(y_true)), dtype=tf.float32)
    cross_entropy *= mask
    cross_entropy = tf.reduce_sum(cross_entropy, 1)
    cross_entropy /= tf.reduce_sum(mask, 1)
    seq_loss = tf.reduce_mean(cross_entropy, 0)
    return seq_loss


def get_sample_score(logits, sample_ids):
    """
    获取sample_ids对应的分数
    logits: [batch_size, maxlen, vocab_size]
    sample_ids: [batch_size, (maxlen1)]
    """
    batch_size, max_len, _ = shape_list(logits)
    idxs_1 = tf.tile(tf.reshape(tf.range(batch_size),[-1, 1]), [1, max_len])
    idxs_2 = tf.reshape(tf.tile(tf.range(max_len), [batch_size]), [-1, max_len])
    idxs = tf.stack([idxs_1, idxs_2, sample_ids[:,1:]], axis=-1)
    #[batch_size, max_len]
    return tf.gather_nd(logits, idxs)


def reset_nan(input_tensor, number=1e-5):
    """
    reset nan for loss
    """
    input_tensor = tf.where(tf.math.is_nan(input_tensor), tf.ones_like(
        input_tensor) * number, input_tensor)
    return input_tensor
