import os
import numpy as np
import pandas as pd
import tensorflow as tf
import horovod.tensorflow as hvd
from mpi4py import MPI
from tqdm import tqdm

from rcalgo.tf.training import context
from rcalgo.tf.training.data.tf_dataset import TFDataset
from rcalgo.tf.training.data.data_utils import split_data
from rcalgo.tf.utils.pretty_print import simplify_print
from rcalgo.tf.training.hook import (BroadcastGlobalVariablesHook, CheckpointHook,
                                     TrainInfoPrintHook)
from rcalgo.tf.training.training_utils import (get_or_create_is_training,
                                               set_current_task)
from rcalgo.tf.training.trainer import Trainer, Task
from rcalgo.tf.utils.logging import logger
from rcalgo.tf.utils.s3_utils import s3_upload


class HorovodTrainer(Trainer):
    """ Horovod based Trainer

    This class use horovod to implement basic training interface like
    train(), evaluate(), predict()
    """
    def __init__(self, config=None, default_task_name="default"):
        if config is None:
            config = {}
        super(HorovodTrainer, self).__init__(config=config,
                                             default_task_name=default_task_name)

        self._task_name = default_task_name
        self._task = None

        self._prev_output_idxs = None

        hvd.init()

    def get_task(self, refresh=False):
        if self._task is None or refresh:
            self._task = Task(self._task_name)
        return self._task

    def _filter_hooks(self, hooks):
        if hvd.rank() != 0:
            hooks = [hook for hook in hooks if hook.chief_only is not True]
        return hooks

    def _make_train_function(self, **kwargs):
        # TODO: what if task.metric is empty?
        if getattr(self, "train_function", None) is None:
            task = self.get_task()
            is_training = get_or_create_is_training()
            with tf.name_scope("train"):
                # fn = tf.keras.backend.function(
                fn = context.GraphExecutionFunction(
                    inputs=task.inputs + task.targets + [is_training],
                    outputs=(task.loss, task.metric_list, task.lr_variable),
                    updates=[task.train_op],
                    name="train_function",
                    **kwargs)
                setattr(self, "train_function", fn)

    def _make_test_function(self, **kwargs):
        if getattr(self, "test_function", None) is None:
            task = self.get_task()
            is_training = get_or_create_is_training()
            with tf.name_scope("test"):
                fn = context.GraphExecutionFunction(
                    inputs=task.inputs + task.targets + [is_training],
                    outputs=(task.loss, task.metric_list, task.lr_variable),
                    updates=None,
                    name="test_function",
                    **kwargs)
                setattr(self, "test_function", fn)

    def _make_predict_function(self, output_idxs=None, **kwargs):
        if (getattr(self, "predict_function", None) is None or
                self._prev_output_idxs != output_idxs):
            task = self.get_task()
            task_outputs = [task.outputs[idx] for idx in output_idxs]

            with tf.name_scope("predict"):
                fn = context.GraphExecutionFunction(
                    inputs=task.inputs,
                    outputs=task_outputs,
                    updates=None,
                    name="predict_function",
                    **kwargs)
                setattr(self, "predict_function", fn)
            self._prev_output_idxs = output_idxs

    def _make_execution_function(self, mode, **kwargs):
        if mode == "train":
            self._make_train_function(**kwargs)
            return self.train_function
        elif mode == "test":
            self._make_test_function(**kwargs)
            return self.test_function
        elif mode == "predict":
            self._make_predict_function(**kwargs)
            return self.predict_function
        else:
            raise ValueError("mode %s not supported" % mode)

    def _run_batch(self, step_func, batch_data, batch_id, session, hooks=[]):
        for hook in hooks:
            hook.before_run(session, batch_id)

        step_results = step_func(batch_data)
        fetch_results = step_func.fetches_results \
            if step_func.fetches is not None else {}
        # after run
        extras = {}
        for hook in hooks:
            extras["fetch_results"] = fetch_results.get(hook, None)
            hook.after_run(session, batch_id, extras)
        return step_results

    def _run_epoch(self, iterator, num_steps, session,
                   hooks=[], mode="train", parallel=True):
        total_cnt, total_loss, total_metrics = 0, 0, 0

        # session.as_default() is necessary here because
        # tf.keras.backend.function will use keras session by default
        iterator.reinitialize()
        next_element = iterator.next_element()
        step_func = self._make_execution_function(mode=mode)
        is_training = (mode == "train")

        if hvd.rank() == 0:
            tqdm_iter = tqdm(range(num_steps), position=0, leave=True)
        else:
            tqdm_iter = range(num_steps)

        for batch_id in tqdm_iter:
            try:
                batch_loss, batch_metric, batch_lr = self._run_batch(
                    step_func, next_element + tuple([is_training]),
                    batch_id, session=session, hooks=hooks)
            except tf.errors.OutOfRangeError:
                break

            if np.isscalar(batch_metric[0]):
                batch_size = 1
                avg_metric = np.array(batch_metric)
            else:
                batch_size = batch_metric[0].shape[0]
                avg_metric = np.mean(batch_metric, axis=1)
            total_metrics += avg_metric * batch_size
            total_loss += batch_loss
            total_cnt += batch_size

            if hvd.rank() == 0:
                desc_str = "task:{}, lr:{:.4e}, loss:{:.4f}, metrics:" \
                    "{}".format(self._task_name, batch_lr, batch_loss,
                                np.around(avg_metric, 4))
                tqdm_iter.set_description_str(desc_str)

        if hvd.size() > 1 and parallel:
            recv_buf = np.empty(total_metrics.shape, dtype=total_metrics.dtype)
            MPI.COMM_WORLD.Allreduce(total_metrics, recv_buf, op=MPI.SUM)
            total_loss = MPI.COMM_WORLD.allreduce(total_loss, op=MPI.SUM)
            total_cnt = MPI.COMM_WORLD.allreduce(total_cnt, op=MPI.SUM)
            num_steps = MPI.COMM_WORLD.allreduce(num_steps, op=MPI.SUM)
            total_metrics = recv_buf

        epoch_loss = total_loss / num_steps
        epoch_metric = total_metrics / total_cnt
        return epoch_loss, epoch_metric.tolist()

    def _convert_to_dataset(self, data):
        if isinstance(data, (tf.data.Dataset)):
            dataset = TFDataset.from_tf_dataset(data)
        elif isinstance(data, TFDataset):
            dataset = data
        else:
            data = [np.array(feature) if isinstance(feature, list) else feature for feature in data]
            dataset = TFDataset.from_numpy(data)
        return dataset

    def train(self, data, test_size=0.1, *args, **kwargs):
        if isinstance(data, tf.data.Dataset):
            if test_size > 0:
                raise ValueError("`test_size is not supported when input_list"
                                 "is a tf.data.Dataset")
            self.train_and_evaluate(data, None, *args, **kwargs)
        elif test_size == 0:
            self.train_and_evaluate(data, None, *args, **kwargs)
        else:
            train_data, test_data = split_data(data, test_size=test_size, sync=True)
            self.train_and_evaluate(train_data, test_data, *args, **kwargs)

    def train_and_evaluate(self, train_data, test_data, batch_size=256,
                           epochs=10, shuffle_buffer_size=10000,
                           checkpoint_dir=None, checkpoint_name=None,
                           hooks=[], max_to_keep=None):
        """train loop
        """
        set_current_task(self._task_name)
        logger.info(f"add current task to collection: {self._task_name}")
        # add default hooks
        checkpoint_dir = self.model_output_dir if checkpoint_dir is None else checkpoint_dir
        checkpoint_name = self.model_name if checkpoint_name is None else checkpoint_name
        max_to_keep = self.max_to_keep if max_to_keep is None else max_to_keep
        default_hooks = [
            CheckpointHook(checkpoint_dir, checkpoint_name, max_to_keep=max_to_keep),
            BroadcastGlobalVariablesHook(root_rank=0),
            TrainInfoPrintHook(),
        ]
        hooks = self._filter_hooks(hooks + default_hooks)

        train_data = self._convert_to_dataset(train_data)
        if hvd.size() > 1:
            train_data = train_data.shard(hvd.size(), hvd.rank(), drop_remainder=True)
        # 注意先shard再shuffle
        train_data = train_data.shuffle(shuffle_buffer_size, reshuffle_each_iteration=True)
        train_data = train_data.batch(batch_size, drop_remainder=True).prefetch(10)

        session = context.get_session()
        # training begin
        for hook in hooks:
            hook.begin(session)

        train_iterator = train_data.make_iterator()
        if test_data:
            test_data = self._convert_to_dataset(test_data)
            if hvd.size() > 1:
                test_data = test_data.shard(hvd.size(), hvd.rank(),
                                            drop_remainder=False)
            test_data = test_data.batch(batch_size, drop_remainder=False)
            test_iterator = test_data.make_iterator()

        for epoch in range(epochs):
            # before epoch
            hook_fetches = {}
            for hook in hooks:
                fetch = hook.before_epoch(session, train_data, epoch)
                if fetch is not None:
                    hook_fetches[hook] = fetch
            # set extra fetches
            func = self._make_execution_function(mode="train")
            func.set_fetches(hook_fetches)

            # train for one epoch
            epoch_train_loss, epoch_train_metric = self._run_epoch(
                train_iterator,
                num_steps=train_data.get_num_steps(),
                session=session, hooks=hooks,
                mode="train", parallel=True)
            # validation
            if test_data:
                epoch_test_loss, epoch_test_metric = self._run_epoch(
                    test_iterator,
                    num_steps=test_data.get_num_steps(),
                    session=session, mode="test", parallel=True)
            else:
                epoch_test_loss, epoch_test_metric = 0.0, 0.0
            extras = {
                "train_loss": epoch_train_loss,
                "train_metric": epoch_train_metric,
                "validate_loss": epoch_test_loss,
                "validate_metric": epoch_test_metric
            }
            # after epoch
            for hook in hooks:
                hook.after_epoch(session, epoch, extras)
        # training end
        for hook in hooks:
            hook.end(session)

    def evaluate(self, test_data, batch_size=256, hooks=[], parallel=True):
        test_data = self._convert_to_dataset(test_data)
        if hvd.size() > 1 and parallel:
            test_data = test_data.shard(hvd.size(), hvd.rank(), drop_remainder=False)
        test_data = test_data.batch(batch_size, drop_remainder=False).prefetch(10)
        test_iterator = test_data.make_iterator()

        session = context.get_session()
        # evaluate begin
        for hook in hooks:
            hook.begin(session)
        # evaluation loop
        epoch_test_loss, epoch_test_metrics = self._run_epoch(
            test_iterator,
            num_steps=test_data.get_num_steps(ceil=True),
            session=session, mode="test", parallel=parallel)
        # evaluate end
        for hook in hooks:
            hook.end(session)
        simplify_print({
            "test_loss": epoch_test_loss, "test_metric": epoch_test_metrics
        })
        return epoch_test_loss, epoch_test_metrics

    def predict(self, test_data, output_idxs=None, batch_size=256,
                hooks=[], parallel=True):
        # TODO: this interface only support predicting task outputs, may be
        # we should change it to support predicting any specified tensor
        if output_idxs is None:
            output_idxs = list(range(len(self.get_task().outputs)))

        test_data = self._convert_to_dataset(test_data)
        if hvd.size() > 1 and parallel:
            test_data = test_data.split(hvd.size(), hvd.rank(), drop_remainder=False)

        test_data = test_data.batch(batch_size, drop_remainder=False).prefetch(10)
        iterator = test_data.make_iterator()

        session = context.get_session()
        # predict begin
        for hook in hooks:
            hook.begin(session)

        iterator.reinitialize()
        next_element = iterator.next_element()
        step_func = self._make_execution_function(
            mode="predict", output_idxs=output_idxs)

        if hvd.rank() == 0:
            tqdm_iter = tqdm(range(test_data.get_num_steps(ceil=True)), position=0, leave=True)
        else:
            tqdm_iter = range(test_data.get_num_steps(ceil=True))

        output_list = [[] for _ in range(len(output_idxs))]
        for batch_id in tqdm_iter:
            try:
                batch_outputs = self._run_batch(
                    step_func, next_element, batch_id,
                    session=session, hooks=hooks)
            except tf.errors.OutOfRangeError:
                break

            for i, bo in enumerate(batch_outputs):
                output_list[i].append(bo)

        outputs = [np.concatenate(out) for out in output_list]
        if hvd.size() > 1 and parallel:
            outputs = [np.concatenate(MPI.COMM_WORLD.allgather(output))
                       for output in outputs]
        # predict end
        for hook in hooks:
            hook.end(session)
        return outputs

    def train_on_batch(self, batch_data):
        is_training = True

        step_func = self._make_execution_function(mode="train")
        batch_loss, batch_metric, batch_lr = step_func(
            batch_data + [is_training])
        return batch_loss, np.mean(batch_metric, axis=1).tolist()

    def test_on_batch(self, batch_data):
        is_training = False

        step_func = self._make_execution_function(mode="test")
        batch_loss, batch_metric, batch_lr = step_func(
            batch_data + [is_training])
        return batch_loss, np.mean(batch_metric, axis=1).tolist()

    def predict_on_batch(self, batch_data, output_idxs=None):
        if output_idxs is None:
            output_idxs = list(range(len(self.get_task().outputs)))

        step_func = self._make_execution_function(
            mode="predict", output_idxs=output_idxs)
        batch_outputs = step_func(batch_data)
        return batch_outputs

    def restore_checkpoint_from_output(self, model_path=None, saver=None):
        session = context.get_session(init_variables=False)
        if not saver:
            saver = tf.compat.v1.train.Saver()

        if model_path is None:
            saver.restore(session, os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name)))
        else:
            saver.restore(session, model_path)
        print("Reload Model ...")

    def restore_variables_from_output(self, model_path=None, tvars=None):
        if not model_path:
            model_path = os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name))
        tvars = tf.trainable_variables() if tvars is None else tvars
        (assignment_map, _) = self.get_assignment_map_from_checkpoint(tvars, model_path)
        tf.train.init_from_checkpoint(model_path, assignment_map)
        context.get_session().run(tf.variables_initializer(assignment_map.values()))

    def dump_checkpoint(self, model_path=None):
        saver = tf.compat.v1.train.Saver()
        # TODO: fix the hacky code
        saver._max_to_keep = 0
        saver.saver_def.max_to_keep = 0
        if model_path is None:
            model_path = self._get_dump_path()
        directory = os.path.dirname(model_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        save_path = saver.save(context.get_session(), model_path)
        print("Model checkpoint saved in file: {}".format(save_path))

    def dump_model(self, serving_dir, model_version, input_index=None,
                   output_index=None, clear_devices=True):
        # here we use tf.compat.v1.GraphKeys.INPUTS instead of tf.compat.v1.GraphKeys.INPUT_DICT
        task = self.get_task()
        input_nodes = self._filter_nodes(task.inputs, input_index)
        output_nodes = self._filter_nodes(task.outputs, output_index)

        export_path = os.path.join(serving_dir, str(model_version))
        legacy_init_op = tf.group(
            tf.compat.v1.tables_initializer(), name="legacy_init_op")
        prediction_signature = (
            tf.compat.v1.saved_model.signature_def_utils.build_signature_def(
                inputs=self._build_dict("input", input_nodes),
                outputs=self._build_dict("output", output_nodes),
                method_name=tf.saved_model.PREDICT_METHOD_NAME))
        builder = tf.compat.v1.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            sess=context.get_session(),
            tags=[tf.saved_model.tag_constants.SERVING],
            clear_devices=clear_devices,
            signature_def_map={
                tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:
                prediction_signature},
            main_op=legacy_init_op
            # legacy_init_op=legacy_init_op
        )
        builder.save()

    def _filter_nodes(self, nodes, index=None):
        if index is None:
            return nodes
        if not isinstance(index, list):
            index = [index]
        nodes = [nodes[idx] for idx in index]
        return nodes

    def export_freeze_graph(self, graph_dir, model_version, input_index=None,
                            output_index=0, clear_devices=True,
                            as_text=False, export_mata_graph=True,
                            is_s3_upload=True, location='china'):
        """
        Export frozen graph. Note that this function fetches nodes from
        tf.compat.v1.GraphKeys.INPUTS instead of tf.compat.v1.GraphKeys.INPUT_DICT,
        which is different from its old version
        """
        export_path = os.path.join(graph_dir, str(model_version), "frozen.pb")
        logger.info(f"frozen pb exported to {export_path}")
        session = context.get_session()
        graph = session.graph
        task = self.get_task()

        # set INPUT_DICT collection
        input_nodes = self._filter_nodes(task.inputs, input_index)
        graph.clear_collection(tf.compat.v1.GraphKeys.INPUT_DICT)
        for node in input_nodes:
            tf.compat.v1.add_to_collection(
                tf.compat.v1.GraphKeys.INPUT_DICT, node)

        # set OUPPUT_DICT collection
        output_nodes = self._filter_nodes(task.outputs, output_index)
        graph.clear_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)
        for node in output_nodes:
            tf.compat.v1.add_to_collection(
                tf.compat.v1.GraphKeys.OUTPUT_DICT, node)

        # prune and convert variables to constants
        OUTPUT_NODE = [node.op.name for node in output_nodes]
        table_init_op = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TABLE_INITIALIZERS)
        for op in table_init_op:
            OUTPUT_NODE.append(op.name)
        graphdef_def = self.graph.as_graph_def()
        # tf.graph_util.remove_training_nodes(graphdef_def.as_graph_def())
        graphdef_frozen = \
            tf.compat.v1.graph_util.convert_variables_to_constants(
                session, graphdef_def, OUTPUT_NODE)

        if export_mata_graph:
            tf.compat.v1.train.export_meta_graph(
                filename=export_path, graph_def=graphdef_frozen,
                collection_list=[
                    tf.compat.v1.GraphKeys.TABLE_INITIALIZERS,
                    tf.compat.v1.GraphKeys.INPUT_DICT,
                    tf.compat.v1.GraphKeys.OUTPUT_DICT],
                as_text=as_text,
                clear_devices=clear_devices)
        else:
            if not os.path.isdir(os.path.join(graph_dir, str(model_version))):
                os.makedirs(os.path.join(graph_dir, str(model_version)))
            tf.train.write_graph(graphdef_frozen, './',
                                 export_path, as_text=as_text)

        if is_s3_upload:
            s3_upload(export_path, location)

    def model_summary(self, scope=None):
        columns = ['variable_name', 'variable_shape', 'parameters']
        df_summary = pd.DataFrame(columns=columns)
        parameter_count = 0
        for i, var in enumerate(tf.compat.v1.trainable_variables(scope=scope)):
            if var.get_shape().dims is None:
                sl = 'unknown'
                para_num = 0
            else:
                sl = var.get_shape().as_list()
                para_num = np.prod(sl)
            df_summary.loc[i] = [var.name, sl, para_num]
            parameter_count += para_num
        print("total parameter number:", parameter_count)
        return df_summary
