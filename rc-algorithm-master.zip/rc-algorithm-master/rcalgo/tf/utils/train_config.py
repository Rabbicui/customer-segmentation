from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
from .model_config import *
import os


def set_cuda_environment(config):
    if hasattr(config, 'gpu_id') and hasattr(config, 'gpu_num'):
        os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(
            [str(i) for i in range(config.gpu_id, config.gpu_id + config.gpu_num)])
        config.gpu_id = 0  # set default gpus


def build_model_parse_args(parser):
    parser.add_argument('--model-type', default='deepcnn',
                        type=str, help='the model type')
    parser.add_argument('--acc-k', default=1,
                        type=int, help='accK')
    parser.add_argument('--model-version', default=1,
                        type=int, help='model version')
    parser.add_argument('--p-coef', default=0.0002, type=float,
                        help='the coef of l2 loss')
    parser.add_argument('--init-std', default=0.05,
                        type=float, help='init std for variable')
    parser.add_argument('--init-scale', default=1.0, type=float,
                        help='init scale for variable')
    parser.add_argument('--clip-gradients', default=1.0,
                        type=float, help='the parameter for clip gradients')
    parser.add_argument('--label-smooth', default=0.0, type=float,
                        help='the epsilon parameter of label smoothing')
    parser.add_argument('--model-dir', default='model/',
                        type=str, help='model directory')
    parser.add_argument('--serving-dir', default='serving/',
                        type=str, help='serving dir')
    parser.add_argument('--logs-dir', default='logs/',
                        type=str, help='logs directory')
    parser.add_argument('--dir-clear', default=False, action='store_true',
                        help='clear the log and model directory')
    build_optimizer_args(parser)
    build_input_parse_args(parser)
    build_rnn_parse_args(parser)
    build_cnn_parse_args(parser)
    build_memory_qa_parse_args(parser)
    build_transformer_lm_qa_parse_args(parser)
    build_gan_parse_args(parser)
    build_image_parser(parser)
    build_multi_modal_parser(parser)


def build_optimizer_args(parser):
    parser.add_argument('--opt', default='adam',
                        type=str, help='the optimizer')
    parser.add_argument('--adam-epsilon', default=1e-8,
                        type=float, help='the epsilon value for adam')
    parser.add_argument('--adam-beta1', default=0.9,
                        type=float, help='the beta1 value for adam')
    parser.add_argument('--adam-beta2', default=0.9999,
                        type=float, help='the beta2 value for adam')
    parser.add_argument('--adam-wd', default=0.001, type=float,
                        help='the weight decay parameter of adamW')
    parser.add_argument('--loss-scaling', default=False, action='store_true',
                        help='using loss scale or not when mixed precision training is on')
    parser.add_argument('--loss-scale-factor', default=1000, type=int,
                        help='loss scale factor')

# the basic config parameters for all dl models
def build_basic_parse_args(parser):
    parser.add_argument('-f', '--file', help='notebook parametes')
    parser.add_argument('--train-dir',
                        default='/home/web_server/chengjun/classifier/data/',
                        type=str, help='the dir of training data')
    parser.add_argument('--batch-size', default=128, type=int,
                        help='batch size to use during training')
    parser.add_argument('--n-epochs', default=10, type=int,
                        help='number of epoch to use during training')
    parser.add_argument('--epoch-save', default=False, action='store_true',
                        help='save checkpoint or not in each epoch')
    parser.add_argument('--print-step', default=1, type=int,
                        help='print step duraing training')
    parser.add_argument('--model-name',
                        default='default_model', type=str, help='model name')
    parser.add_argument('--task-name',
                        default='default', type=str, help='task name')
    parser.add_argument('--gpu-id', default=0, type=int, help='default device')
    parser.add_argument('--gpu-num', default=1, type=int, help='gpu_num')
    parser.add_argument('--distinct', default=False,
                        action='store_true', help='distinct the raw text')
    parser.add_argument('--balance-data', default=0, type=int,
                        help='balancing the data')
    parser.add_argument('--debug-mode', default=False, action='store_true',
                        help='open debug mode or not')
    parser.add_argument('--attention-type', default='additive',
                        type=str, help='attention type, depends on model to use it or ignore it')
    parser.add_argument('--attention-size', default=256,
                        type=int, help='attention_size')
    parser.add_argument('--use-tf-dataset', default=False, action='store_true',
                        help='use tf dataset or not')
    parser.add_argument('--mp-training', default=False, action='store_true',
                        help='mixed precision training')
    build_learning_rate_args(parser)


def build_learning_rate_args(parser):
    parser.add_argument('--learning-rate', default=None,
                        type=float, help='learning rate')
    parser.add_argument('--learning-rate-schedule', default='linear',
                        type=str, help='learning rate schedule')
    parser.add_argument('--learning-rate-warmup-steps', default=4000,
                        type=int, help='learning rate warm up steps')
    parser.add_argument('--learning-rate-warmup', default=0.002,
                        type=float, help='learning rate warm up percentage')
    # the noam schedule currently works on transformer
    parser.add_argument('--learning-rate-noam-hidden-size', default=512,
                        type=int, help='learning rate noam schedule hidden size')
    parser.add_argument('--total-update', default=None,
                        type=int, help='total decay steps')
    parser.add_argument('--lr-annealing', default=False, action='store_true',
                        help='use lr annealing or not after each epoch')
    parser.add_argument('--lr-annealing-value', default=1.5,
                        type=float, help='lr /= lr_annealing_value')
    parser.add_argument('--lr-stop-value', default=1e-6,
                        type=float, help='stop training if lr less than stop value at the end of epoch')


def build_basic_transfer_parse_args(parser):
    parser.add_argument('--original-ckpt-path',
                        type=str, help='original checkpoint path to extract sub-graph and params')
    parser.add_argument('--original-task-name', default='default',
                        type=str, help='original task name')
    parser.add_argument('--original-output-index',
                        type=int,
                        help='index of tensor in output collection, which will be used to build the new model')
    parser.add_argument('--clear-devices', default=False, action='store_true',
                        help='whether or not to clear devices info in ckpt model')


def parse_incremental_training_args(args=None, use_test_args=False, namespace=None):
    parser = ArgumentParser(
        formatter_class=ArgumentDefaultsHelpFormatter)
    #         conflict_handler='resolve')
    # build basic config
    build_basic_parse_args(parser)

    parser.add_argument('--model-input-dir', default=None,
                        type=str, help='model input directory')
    parser.add_argument('--model-output-dir', default=None,
                        type=str, help='model output directory')
    parser.add_argument('--clear-devices', default=False, action='store_true',
                        help='whether or not to clear devices info in ckpt model')

    config = parser.parse_args(args=args, namespace=namespace)
    # cuda visiable gpu
    set_cuda_environment(config)
    return config


def parse_initial_training_args(args=None, use_test_args=False, namespace=None):
    parser = ArgumentParser(
        formatter_class=ArgumentDefaultsHelpFormatter)
    #         conflict_handler='resolve')
    # build basic config
    build_basic_parse_args(parser)
    # model config
    build_model_parse_args(parser)
    if use_test_args:
        build_test_args(parser)
    config = parser.parse_args(args=args, namespace=namespace)
    # cuda visiable gpu
    set_cuda_environment(config)
    config.serving_dir = os.path.join(config.serving_dir, config.model_name)
    return config


def parse_transfer_training_args(args=None, use_test_args=False, namespace=None):
    parser = ArgumentParser(
        formatter_class=ArgumentDefaultsHelpFormatter)
    #         conflict_handler='resolve')
    build_basic_transfer_parse_args(parser)
    build_basic_parse_args(parser)
    # model config
    build_model_parse_args(parser)
    if use_test_args:
        build_test_args(parser)
    config = parser.parse_args(args=args, namespace=namespace)
    # cuda visiable gpu
    set_cuda_environment(config)
    config.serving_dir = os.path.join(config.serving_dir, config.model_name)
    return config


