import tensorflow as tf

from tftools.tf_float_type import get_default_float_type
from .tf_func import *
from functools import reduce
from tensorflow.python.ops import variable_scope as vs
from tensorflow.python.ops import array_ops, math_ops, rnn_cell, init_ops
from tensorflow.python.training import moving_averages
from tensorflow.python.ops import rnn_cell
from tensorflow.keras.layers import LSTMCell, StackedRNNCells
from tensorflow.compat.v2.nn import RNNCellResidualWrapper
import collections


def _is_sequence(seq):
    return (isinstance(seq, collections.Sequence)
            and not isinstance(seq, six.string_types))

def _add_weight_to_collection(weight, variables_collections):
    if variables_collections is not None and isinstance(variables_collections, str):
        if weight not in tf.compat.v1.get_collection(variables_collections):
            tf.compat.v1.add_to_collection(variables_collections, weight)

def _linear(input_tensor, output_dim, bias, bias_start=0.0, scope=None, variables_collections=None):
    """
    Linear layer, return a vector, given args input, output size,`.

    Main Args:
      input_tensor: the input tensor
      output_dim: the  dimension of output vector
    Returns:
      A Tensor, Dimension: [batch, output_dim]
    """
    if input_tensor is None or (_is_sequence(input_tensor) and not input_tensor):
        raise ValueError("`input_tensor` must be specified")
    if not _is_sequence(input_tensor):
        input_tensor = [input_tensor]

    # Calculate the total size of arguments on dimension 1.
    total_arg_size = 0
    shapes = [a.get_shape().as_list() for a in input_tensor]
    for shape in shapes:
        if len(shape) != 2:
            raise ValueError(
                "Linear is expecting 2D arguments: %s" % str(shapes))
        if not shape[1]:
            raise ValueError(
                "Linear expects shape[1] of arguments: %s" % str(shapes))
        else:
            total_arg_size += shape[1]

    # Now the computation.
    with vs.variable_scope(scope or "Linear"):
        matrix = vs.get_variable("Matrix", [total_arg_size, output_dim])
        _add_weight_to_collection(matrix, variables_collections)
        if len(input_tensor) == 1:
            res = math_ops.matmul(input_tensor[0], matrix)
        else:
            res = math_ops.matmul(array_ops.concat(1, input_tensor), matrix)
        if not bias:
            return res
        bias_term = vs.get_variable(
            "Bias", [output_dim],
            initializer=init_ops.constant_initializer(bias_start))
        _add_weight_to_collection(bias_term, variables_collections)
        return res + bias_term


def my_full_connected(input_tensor, output_dim, add_bias=True,
                      layer_name='fully_connected', act=tf.identity, init_std=0.05,
                      weights_initializer=None, biases_initializer=None,
                      scope=None, reuse=False, variables_collections=None, bn=False,
                      training=True):
    """
    Full Connected Layer with activation function

    Main Args:
      input_tensor: the input tensor, [batch, input_dim]
      output_dim: the dimension of output vector [batch, output_dim]
      act: the activation function
    Returns:
      A Tensor, Dimension: [batch, output_size]
    """

    input_dim = input_tensor.get_shape()[-1].value
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        if weights_initializer is None:
            weights_initializer = tf.truncated_normal_initializer(
                stddev=init_std)
        weights = tf.compat.v1.get_variable("W", [input_dim, output_dim],
                                  initializer=weights_initializer, dtype=get_default_float_type())
        _add_weight_to_collection(weights, variables_collections)
        with tf.name_scope('Wx_plus_b'):
            preactivate = tf.matmul(input_tensor, weights)
            if add_bias:
                if biases_initializer is None:
                    biases_initializer = tf.zeros_initializer()
                    #biases_initializer = tf.truncated_normal_initializer(
                    #    stddev=init_std)
                biases = tf.compat.v1.get_variable(
                    "B", [output_dim], initializer=biases_initializer, dtype=get_default_float_type())
                preactivate = preactivate + biases
                _add_weight_to_collection(biases, variables_collections)
            if bn:
                if isinstance(training, bool):
                    training = tf.convert_to_tensor(training)
                preactivate = my_batch_norm(preactivate, training)
            activations = act(preactivate, name='activation')
            return activations

class WordEmbedder(object):

    def __init__(self, vocab_size, embedding_size,
               layer_name='embedding_layer', init_scale=1.0,
               dtype=tf.float32, zero_pad=True,
               scope=None, reuse=False, initializer=None,
               variables_collections=None):
        """
        Build the embedder for multiple use
        """
        self.embedding_size = embedding_size
        vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
        with vscope as scope:
            # if zero pad, only assign (vocab_size-1) * embed_size Matrix
            # vocab_size = vocab_size - int(zero_pad)
            if initializer is None:
                # tf.contrib.layers.xavier_initializer()
                initializer = tf.random_uniform_initializer(
                    -init_scale, init_scale)
            self.embedding_table = tf.compat.v1.get_variable('embedding_table',
                                              [vocab_size, embedding_size], dtype=dtype,
                                              initializer=initializer)
            # 注释掉，tf的framework.function 988行，compute_shape会更改
            # embedding_table = convert_gradient_to_dense_tensor(embedding_table)
            _add_weight_to_collection(self.embedding_table, variables_collections)

    def __call__(self, input_tensor, scale=False, embedding_size=None):
        """
        Reuse the embedding table to compute the tensor
        if the scale is True, embedding_size must be provided
        """
        input_embedding = tf.nn.embedding_lookup(self.embedding_table, input_tensor)
        if scale:
            input_embedding = input_embedding * (embedding_size ** 0.5)
        return input_embedding


def my_embedding_layer(input_tensor, vocab_size, embedding_size,
                       layer_name='embedding_layer', init_scale=1.0,
                       dtype=None, zero_pad=True, scale=False,
                       scope=None, reuse=False, initializer=None,
                       variables_collections=None):
    """
    Word Embedding Layer

    Main Args:
      input_tensor: the input sequence tensor [batch, maxlen]
      vocab_size:  vocabulary size for word embedding
      embedding_size: embedding size
      zero_pad: If True, all the values of the fist row (id 0)
        should be constant zeros.
      scale: If True. the outputs is multiplied by sqrt embedding_size
    Returns:
        A Tensor, Dimension: [batch, maxlen, embedding_size]
    """
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        # if zero pad, only assign (vocab_size-1) * embed_size Matrix
        vocab_size = vocab_size - int(zero_pad)
        if initializer is None:
            # tf.contrib.layers.xavier_initializer()
            initializer = tf.random_uniform_initializer(
                -init_scale, init_scale)
        embedding_table = tf.compat.v1.get_variable('embedding_table',
                                          [vocab_size, embedding_size], dtype=dtype,
                                          initializer=initializer)
        #注释掉，tf的framework.function 988行，compute_shape会更改
        #embedding_table = convert_gradient_to_dense_tensor(embedding_table)
        if zero_pad:
            embedding_table = tf.concat((tf.zeros(shape=[1, embedding_size], dtype=dtype),
                                         embedding_table), 0)
        _add_weight_to_collection(embedding_table, variables_collections)
        input_embedding = tf.nn.embedding_lookup(embedding_table, input_tensor)
        if scale:
            input_embedding = input_embedding * (embedding_size ** 0.5)
        return input_embedding
    

def google_position_embedding(length, embedding_size,
                              min_timescale=1.0, max_timescale=1.0e4):
    """
    Return positional encoding.
    code: https://github.com/tensorflow/models/blob/master/official/transformer/model/model_utils.py#L29:26

    Args:
        length: Sequence length.
        embedding_size: Size of the embedding
        min_timescale: Minimum scale that will be applied at each position
        max_timescale: Maximum scale that will be applied at each position
    """
    position = tf.to_float(tf.range(length))
    num_timescales = embedding_size // 2
    log_timescale_increment = (
        math.log(float(max_timescale) / float(min_timescale)) /
        (tf.to_float(num_timescales) - 1))
    inv_timescales = min_timescale * tf.exp(
        tf.to_float(tf.range(num_timescales)) * -log_timescale_increment)
    scaled_time = tf.expand_dims(position, 1) * \
        tf.expand_dims(inv_timescales, 0)
    signal = tf.concat([tf.sin(scaled_time), tf.cos(scaled_time)], axis=1)
    return signal


def position_embedding(length, embedding_size, seqlen, dtype=None,
                       trainiable=False, layer_name='pos_embedding',
                       init_scale=0.01, initializer=None, scale=False,
                       scope=None, variables_collections=None):
    """
        Return positional encoding.
        Paper:  https://arxiv.org/pdf/1706.03762.pdf Section3.5

        Args:
        length: Sequence length.
        embedding_size: Size of the embedding
        trainiable: when false, using static embedding according to the paper,
                    else init an embeeding table variable
    """
    vscope = get_new_variable_scope(layer_name, scope)
    with vscope as scope:
        if initializer is None:
            initializer = tf.random_uniform_initializer(
                -init_scale, init_scale)
        embedding_table = tf.compat.v1.get_variable('embedding_table',
                                                    [length, embedding_size], dtype=dtype,
                                                    initializer=initializer)
        _add_weight_to_collection(embedding_table, variables_collections)
        mask = tf.sequence_mask(seqlen, maxlen=length,
                                dtype=embedding_table.dtype)
        output = tf.reshape(tf.tile(embedding_table, [tf.shape(
            seqlen)[0], 1]), [-1, length, embedding_size]) * tf.expand_dims(mask, [-1])
        if scale:
            output = output * (embedding_size ** 0.5)
        return output


def my_onehot_layer(input_tensor, vocab_size, layer_name='onehot_layer'):
    """
    One Hot Layer

    Main Args:
      input_tensor: the input sequence tensor [batch, maxlen]
      vocab_size:  vocabulary size
    Returns:
      A Tensor, Dimension: [batch, maxlen, vocab_size]
    """
    with tf.name_scope(layer_name):
        input_one_hot = tf.one_hot(input_tensor, vocab_size)
        return input_one_hot


def my_flatten(input_tensor, layer_name='flatten'):
    """
    Flatten Layer

    Main Args:
      input_tensor: the input tensor [batch, d1, d2 ...]
    Returns:
      A Tensor, Dimension: [batch, d1 * d2 * ..]
    """
    with tf.name_scope(layer_name):
        shape = len(input_tensor.get_shape())
        if shape > 2:
            flatten_shape = reduce(
                lambda x, y: x*y, [input_tensor.get_shape()[i].value for i in range(1, shape)])
            flatten_layer = tf.reshape(input_tensor, [-1, flatten_shape])
            return flatten_layer
        else:
            return input_tensor


def highway(input_, layer_size=1, bias=0.0, f=tf.nn.relu, layer_name='highway',
            scope=None, reuse=False, variables_collections=None):
    """
    Highway Network (cf. http://arxiv.org/abs/1505.00387).
    t = sigmoid(Wy + b)
    z = t * g(Wy + b) + (1 - t) * y
   my where g is nonlinearity, t is transform gate, and (1 - t) is carry gate.
    """
    output = input_
    size = input_.get_shape()[-1]
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        for idx in range(layer_size):
            output = f(_linear(output, size, 0, scope='output_lin_%d' % idx,
                               variables_collections=variables_collections))
            transform_gate = tf.sigmoid(_linear(input_, size, 0, scope='transform_lin_%d' % idx,
                                                variables_collections=variables_collections) + bias)
            carry_gate = 1. - transform_gate
            output = transform_gate * output + carry_gate * input_
        return output

#cell.cells[-1]来获取最后一个cell
def my_rnn_cell_v2(hidden_size, keep_prob, num_layers, use_residual):
    def single_cell_v2(hidden_size, keep_prob, use_residual):
        #LSTMCell dafault parameter: https://www.tensorflow.org/api_docs/python/tf/keras/layers/LSTMCell
        cell = LSTMCell(hidden_size, dropout=(1-keep_prob))
        if use_residual:
            cell = RNNCellResidualWrapper(cell)
        return cell
    return StackedRNNCells([single_cell_v2(hidden_size, keep_prob, use_residual) for _ in range(num_layers)])


def my_rnn_cell_v1(hidden_size, keep_prob, num_layers, use_residual):
    """
    多层lstm cell
    """
    def single_cell_v1(hidden_size, keep_prob, use_residual):
        cell = rnn_cell.DropoutWrapper(rnn_cell.LSTMCell(hidden_size, use_peepholes=False),
                                       input_keep_prob=keep_prob, output_keep_prob=keep_prob)
        if use_residual:
            cell = rnn_cell.ResidualWrapper(cell)
        return cell
    return rnn_cell.MultiRNNCell([single_cell_v1(hidden_size, keep_prob,
                                                 use_residual) for _ in range(num_layers)],
                                  state_is_tuple=True)

    
def my_dropout(input_tensor, rate=0.5, training=False):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    """
    Applies Dropout to the input.
    """
    def dropped_inputs():
        # 0 or scaled by 1 / keep_prob
        # keep_prob = 1 - dropout_rate
        #return tf.nn.dropout(input_tensor, 1 - rate)
        return tf.nn.dropout(input_tensor, rate = rate)

    return tf.cond(training,
                   dropped_inputs,
                   lambda: array_ops.identity(input_tensor))

def my_conv_1d(input_tensor, conv_length, n_filters_out, add_bias=True,
               stride_step=1, padding='SAME', layer_name='conv_1d', act=tf.nn.tanh,
               bn=False, training=True, scope=None, reuse=False, variables_collections=None):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    n_filters_in = input_tensor.get_shape()[-1].value
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        conv_W = he_uniform('W', [conv_length, n_filters_in, n_filters_out], dtype=get_default_float_type())
        _add_weight_to_collection(conv_W, variables_collections)
        with tf.name_scope('conv_1d_operation'):
            if conv_length == 1:
                conv_x = tf.reshape(tf.matmul(tf.reshape(input_tensor, [-1, n_filters_in]),
                                              tf.reshape(conv_W, [-1, n_filters_out])),
                                    shape_list(input_tensor)[:-1] + [n_filters_out])
            else:
                pad_tensor = tf.zeros_like(
                    tf.tile(input_tensor[:, 0:1, :], [1, (conv_length-1), 1]))
                if padding == 'LEFT_SAME':
                    conv_x = tf.nn.conv1d(tf.concat([pad_tensor, input_tensor], axis=1),
                                          conv_W, stride=stride_step, padding='VALID')
                elif padding == 'RIGHT_SAME':
                    conv_x = tf.nn.conv1d(tf.concat([input_tensor, pad_tensor], axis=1),
                                          conv_W, stride=stride_step, padding='VALID')
                else:
                    conv_x = tf.nn.conv1d(
                        input_tensor, conv_W, stride=stride_step, padding=padding)
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer(), dtype=get_default_float_type())
                _add_weight_to_collection(biases, variables_collections)
                conv_x = tf.nn.bias_add(conv_x, biases)
            if bn:
                conv_x = my_batch_norm(conv_x, training)
            conv_x = act(conv_x, name='activation')
        return conv_x


def my_atrous_conv_1d(input_tensor, conv_length, n_filters_out, rate, add_bias=True,
                      padding='SAME', layer_name='atrous_conv_1d', act=tf.nn.tanh,
                      bn=False, training=True, scope=None, reuse=False, variables_collections=None):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    n_filters_in = input_tensor.get_shape()[-1].value
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        conv_W = he_uniform('W', [1, conv_length, n_filters_in, n_filters_out])
        if padding == 'SAME':
            pad_len = (conv_length - 1) * rate
            x = tf.expand_dims(
                tf.pad(input_tensor, [[0, 0], [pad_len, 0], [0, 0]]), 1)
        with tf.name_scope('atrous_conv_1d_operation'):
            conv_x = tf.nn.atrous_conv2d(x, conv_W, rate=rate, padding='VALID')
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer())
                conv_x = tf.nn.bias_add(conv_x, biases)
            if bn:
                conv_x = my_batch_norm(
                    conv_x, training, variables_collections=variables_collections)
            conv_x = tf.squeeze(act(conv_x, name='activation'), [1])
        return conv_x


def my_conv_2d(input_tensor, n_filters_out, kernel_size, strides=[1, 1, 1, 1], add_bias=True,
               padding='SAME', layer_name='conv_2d', act=tf.nn.tanh,
               bn=False, training=True, scope=None, reuse=False, variables_collections=None):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    if isinstance(strides, int):
        strides = [1, strides, strides, 1]

    n_filters_in = input_tensor.get_shape()[-1].value

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        conv_W = tf.compat.v1.get_variable('W', shape=[*kernel_size, n_filters_in, n_filters_out],
                                 initializer=tf.contrib.layers.xavier_initializer())
        _add_weight_to_collection(conv_W, variables_collections=variables_collections)
        with tf.name_scope('conv_2d_operation'):
            conv_x = tf.nn.conv2d(input_tensor, conv_W,
                                  strides=strides, padding=padding)
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer())
                conv_x = tf.nn.bias_add(conv_x, biases)
            if bn:
                conv_x = my_batch_norm(conv_x, training)
        conv_x = act(conv_x, name='activation')
        return conv_x

def my_conv_2d_transpose(input_tensor, n_filters_out, kernel_size, strides, padding='SAME', add_bias=True,
                         layer_name='conv_2d_transpose', act=tf.nn.relu, bn=False, training=True,
                         scope=None, reuse=False, variables_collections=None):
    # input_tensor 4d Tensor [batch, height, weight, in_channels]
    # kernel_size a list of length 2 holding [height, width]
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    if isinstance(strides, int):
        strides = [strides, strides]

    batch_size = input_tensor.get_shape()[0].value
    input_h = input_tensor.get_shape()[1].value
    input_w = input_tensor.get_shape()[2].value
    n_filters_in = input_tensor.get_shape()[3].value

    kernel_h, kernel_w = kernel_size
    stride_h, stride_w = strides

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        conv_W = tf.compat.v1.get_variable('W', shape=[*kernel_size, n_filters_out, n_filters_in],
                                 initializer=tf.contrib.layers.xavier_initializer())
        _add_weight_to_collection(conv_W, variables_collections=variables_collections)

        # Infer the dynamic output shape:
        out_height = deconv_output_length(input_h, kernel_h, padding, stride_h)
        out_width = deconv_output_length(input_w, kernel_w, padding, stride_w)
        output_shape = (batch_size, out_height, out_width, n_filters_out)
        output_shape_tensor = array_ops.stack(output_shape)
        # re set the strides to 4 dimension
        strides = (1, stride_h, stride_w, 1)
        with tf.name_scope('conv_2d_transpose_operation'):
            conv_x = tf.nn.conv2d_transpose(input_tensor, conv_W, output_shape_tensor,
                                            strides=strides, padding=padding)
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer())
                conv_x = tf.nn.bias_add(conv_x, biases)
                _add_weight_to_collection(biases, variables_collections)
            if bn:
                conv_x = my_batch_norm(conv_x, training)
        conv_x = act(conv_x, name='activation')
        return conv_x

def my_pool_layer_2d(input_tensor, k, stride=None, padding='VALID', layer_name='pool_2d', act=tf.nn.max_pool2d):
    with tf.name_scope(layer_name):
        if stride is None:
            stride = k
        pool = act(input_tensor, ksize=[1, k, k, 1], strides=[
                   1, stride, stride, 1], padding=padding)
        return pool


##############################  Normalization  Layer  ##############################

def my_layer_norm(input_tensor, epsilon=1e-8, layer_name='ln_layer', scope=None, reuse=None):
    """
    Based on the paper: "Layer Normalization"
    https://arxiv.org/abs/1607.06450.
    Can be used as a normalizer function for conv and fully_connected.

    Main Args:
      input_tensor: the input tensor, [batch, input_dim]
    """
    vscope = get_new_variable_scope(layer_name, scope=scope, reuse=reuse)
    with vscope as scope:
        x_shape = input_tensor.get_shape()
        params_shape = x_shape[-1:]
        mean, variance = tf.nn.moments(input_tensor, [-1], keep_dims=True)
        beta = tf.compat.v1.get_variable('beta', params_shape,
                               initializer=tf.constant_initializer(0.0), dtype=get_default_float_type())
        gamma = tf.compat.v1.get_variable('gamma', params_shape,
                                initializer=tf.constant_initializer(1.0), dtype=get_default_float_type())
        normalized = (input_tensor - mean) / (tf.sqrt(variance + epsilon))
        outputs = gamma * normalized + beta
    return outputs


def my_batch_norm(input_tensor, training, recurrent=False, epsilon=1e-3, decay=0.999,
                  layer_name='bn_layer', scope=None, variables_collections=None):
    """
    Based on paper:
    "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift"
    http://arxiv.org/abs/1502.03167
    support recurrent bn
    momoent shape: [input_tensor.get_shape[-1],]


    Main Args:
      input_tensor: the input tensor, [batch, input_dim]
      training: whether to return the output in training mode
      recurrent: bn or reccurent bn
    """
    if recurrent:
        vscope = get_new_variable_scope(layer_name, scope=layer_name, custom_getter=fp32_storage_getter)
    else:
        vscope = get_new_variable_scope(layer_name, scope=scope, custom_getter=fp32_storage_getter)
    x_shape = input_tensor.get_shape()
    axis = list(range(len(x_shape) - 1))
    params_shape = x_shape[-1:]
    with vscope as scope:
        # print scope.name
        scale = tf.compat.v1.get_variable('scale', params_shape,
                                initializer=tf.constant_initializer(1.0))
        offset = tf.compat.v1.get_variable(
            'offset', params_shape, initializer=tf.constant_initializer(0.0))
        _add_weight_to_collection(scale, variables_collections)
        _add_weight_to_collection(offset, variables_collections)
        pop_mean = tf.compat.v1.get_variable(
            'pop_mean', params_shape, initializer=tf.constant_initializer(0), trainable=False)
        pop_var = tf.compat.v1.get_variable(
            'pop_var', params_shape, initializer=tf.constant_initializer(1.0), trainable=False)

        #train_mean = moving_averages.assign_moving_average(pop_mean, batch_mean, decay)
        #train_var = moving_averages.assign_moving_average(pop_var, batch_var, decay)

        def batch_statistics():
            batch_mean, batch_var = tf.nn.moments(input_tensor, axis)
            train_mean = tf.assign(pop_mean, pop_mean *
                                   decay + batch_mean * (1 - decay))
            train_var = tf.assign(pop_var, pop_var * decay +
                                  batch_var * (1 - decay))
            with tf.control_dependencies([train_mean, train_var]):
                return tf.nn.batch_normalization(input_tensor, batch_mean, batch_var, offset, scale, epsilon)

        def population_statistics():
            return tf.nn.batch_normalization(input_tensor, pop_mean, pop_var, offset, scale, epsilon)

        return tf.cond(training, batch_statistics, population_statistics)


def relu_fc_layer(tensor, size, init_std, layer_name='relu_fc_layer', reuse=False):
    return my_full_connected(tensor, size, act=tf.nn.relu, init_std=init_std,
                             layer_name=layer_name, reuse=reuse,
                             weights_initializer=tf.variance_scaling_initializer(scale=2.0, mode='fan_in', distribution='normal'))
