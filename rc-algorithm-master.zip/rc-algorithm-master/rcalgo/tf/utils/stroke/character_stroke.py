import urllib.request as urllib2
import urllib
from bs4 import BeautifulSoup
from imp import reload


class Stroke(object):
    dictionary_filepath = "./default_stroke.txt"
    # baiduhanyu_url = 'http://hanyu.baidu.com/zici/s?ptype=zici&wd=%s'
    hanzi5_url = "http://www.hanzi5.com/bishun/%s.html"

    def __init__(self):
        self.dictionary = {}

    def get_stroke(self, word):
        """用于获取汉字的笔画信息
        
        例如word="掠", 返回的结果如下:
        ['一', '丨', '一', '丶', '一', '丨', 'フ', '一', '丨', 'ノ', '丶']
        """
        if word in self.dictionary:
            return self.dictionary[word]
        else:
            #print("From hanzi5:    word {}".format(word), end=" ")
            word = hex((ord(word)))[2:]
            word = urllib.parse.quote(word)
            return self.get_stroke_from_hanzi5(word)

    def get_stroke_from_hanzi5(self, word):
        url = self.hanzi5_url % word
        # print("url", url)
        html = self.post_baidu(url)
        # print(html)
        if html is None:
            return None
        char_stroke = self.anlysis_stroke_from_html(html)
        if char_stroke is not None:
            self.dictionary[word] = char_stroke
        # print("char_stroke {}".format(char_stroke))
        return char_stroke

    def anlysis_stroke_from_html(self, html_doc):
        soup = BeautifulSoup(html_doc, 'html.parser')
        li = soup.find("div", {"class", "site-article-content hanzi5-article-hanzi-info"})
        for tabb in li.findAll('table'):
            for trr in tabb.findAll('tr')[3:4]:
                for tdd in trr.findAll('td')[1:2]:
                    zh_stroke = tdd.contents
        zh_stroke_list = []
        for st in zh_stroke[0]:
            zh_stroke_list.append(st)
        return zh_stroke_list

    def post_baidu(self, url):
        try:
            timeout = 5
            request = urllib2.Request(url)
            request.add_header('User-agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
            request.add_header('connection','keep-alive')
            request.add_header('referer', url)
            response = urllib2.urlopen(request, timeout=timeout)
            html = response.read()
            response.close()
            return html
        except Exception as e:
            print('URL Request Error:', e)
            return None


