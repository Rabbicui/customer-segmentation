import tensorflow as tf
from rcalgo.tf.training.data.data import Data


class SemiSupTrainData(Data):
    @property
    def sup_data_size(self):
        return int(len(self.datasets[0]))

    @property
    def unsup_data_size(self):
        return int(len(self.datasets[1]))

    def to_tf_dataset(self):
        self.build_schema()
        text, org_unsup, label = self.data_schema
        if self.mode == "train":
            text_ds = tf.data.Dataset.from_tensor_slices(text)
            org_unsup_ds = tf.data.Dataset.from_tensor_slices(org_unsup)
            label_ds = tf.data.Dataset.from_tensor_slices(label)
            print(f"sup_data_size: {self.sup_data_size}, unsup_data_size: {self.unsup_data_size}")
            # since sup data and unsup data have different size,
            # they need to be repeat and shuffle seperately.
            total_ds = tf.data.Dataset.zip((text_ds.shuffle(self.sup_data_size, seed=0).repeat(),
                                            org_unsup_ds.shuffle(self.unsup_data_size, seed=1).repeat(),
                                            label_ds.shuffle(self.sup_data_size, seed=0).repeat()))
            return total_ds.batch(self.batch_size).prefetch(tf.data.experimental.AUTOTUNE)
        else:
            return tf.data.Dataset.from_tensor_slices(self.data_schema).batch(self.batch_size)
