import numpy as np
import tensorflow as tf

from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.utils.tf_func import get_new_variable_scope, fp32_storage_getter
from rcalgo.tf.utils.tf_func import shape_list
from .basic import my_conv_1d, my_dropout, my_full_connected


def _build_attention_output(attention, value):
    _, sequence_len, embedding_size = shape_list(value)
    return tf.reshape(
        tf.matmul(
            tf.reshape(attention, [-1, 1, sequence_len]),
            value
        ), [-1, embedding_size]
    )


# https://arxiv.org/abs/1703.03130
def self_position_attentive(contexts, attention_size, output_dim_size):
    _, sequence_length, hidden_size = shape_list(contexts)
    with get_new_variable_scope('self_position_attentive'):
        W1 = tf.compat.v1.get_variable('W1', [hidden_size, attention_size],
                             initializer=tf.contrib.layers.xavier_initializer())
        W2 = tf.compat.v1.get_variable('W2', [attention_size, output_dim_size],
                             initializer=tf.contrib.layers.xavier_initializer())
        # A: batch_size, output_dim_size, sequence_length
        A = tf.nn.softmax(
            tf.transpose(
                tf.reshape(
                    tf.matmul(
                        tf.tanh(
                            tf.matmul(tf.reshape(contexts, [-1, hidden_size]), W1)
                        ),
                        W2
                    ),
                    [-1, sequence_length, output_dim_size]
                ),
                perm=[0,2,1]
            )
        )
        
        # output: batch_size, output_dim_size * hidden_size
        output = tf.reshape(tf.matmul(A, contexts), [-1, output_dim_size * hidden_size])
        A_T = tf.transpose(A, perm=[0,2,1])
        # penalty(based on orthogonal assumption): batch_size
        penalty = tf.square(
            tf.norm(
                tf.matmul(A, A_T) - tf.eye(output_dim_size),
                axis=[-2, -1], ord='fro'
            )
        )
        # final_A: batch_size, sequence_length
        final_A = tf.reduce_mean(A, axis=1)
        return output, final_A, penalty


# https://www.cs.cmu.edu/~hovy/papers/16HLT-hierarchical-attention-networks.pdf
def self_position_attention(contexts, attention_size, softmax=True, attention_only=False):
    _, sequence_length, hidden_size = shape_list(contexts)
    with get_new_variable_scope('self_position_attentive', custom_getter=fp32_storage_getter):
        W = tf.compat.v1.get_variable('W', [hidden_size, attention_size],
                            initializer=tf.truncated_normal_initializer(stddev=0.05), dtype=get_default_float_type())
        b = tf.compat.v1.get_variable('b', [attention_size],
                            initializer=tf.truncated_normal_initializer(stddev=0.05), dtype=get_default_float_type())
        u = tf.compat.v1.get_variable('u', [attention_size, 1],
                            initializer=tf.truncated_normal_initializer(stddev=0.05), dtype=get_default_float_type())
        v = tf.tanh(
            tf.matmul(
                tf.reshape(contexts, [-1, hidden_size]),
                W
            ) + b
        )
        final_A = tf.reshape(
            tf.matmul(v, u),
            [-1, sequence_length]
        )
        if softmax:
            final_A = tf.nn.softmax(final_A, axis=-1)
        if attention_only:
            return final_A
        return _build_attention_output(final_A, contexts), final_A

# q . k
def dot_production_attention(query, key, value=None):
    if value is None:
        value = key
    _, sequence_len, hidden_size = shape_list(key)
    # assert query shape: batch_size, hidden_size
    A = tf.nn.softmax(
        tf.reshape(
            tf.matmul(
                key, tf.reshape(query, [-1, hidden_size, 1])
            ), [-1, sequence_len]
        )
    )
    return _build_attention_output(A, value), A


# q^T . W . k
def multiplicative_attention(query, key, value=None):
    if value is None:
        value = key
    _, sequence_len, key_hidden_size = shape_list(key)
    _, query_hidden_size = shape_list(query)
    with get_new_variable_scope('multiplicative_attention') as embedding_scope:
        W = tf.compat.v1.get_variable('W', [query_hidden_size, key_hidden_size],
                            initializer=tf.truncated_normal_initializer(stddev=0.05))
        
        A = tf.reshape(
            tf.matmul(
                key,
                tf.reshape(
                    tf.matmul(query, W), [-1, key_hidden_size, 1]
                )
            ), [-1, sequence_len]
        )
        return _build_attention_output(A, value), A


# v^T tanh(W1 . k + W2 . q)
def additive_attention(query, key, value=None, attention_size=2048):
    if value is None:
        value = key
    _, sequence_len, key_hidden_size = shape_list(key)
    _, query_hidden_size = shape_list(query)
    with get_new_variable_scope('additive_attention') as embedding_scope:
        W1 = tf.compat.v1.get_variable('W1', [key_hidden_size, attention_size],
                            initializer=tf.truncated_normal_initializer(stddev=0.05))
        W2 = tf.compat.v1.get_variable('W2', [query_hidden_size, attention_size],
                            initializer=tf.truncated_normal_initializer(stddev=0.05))
        v = tf.compat.v1.get_variable('v', [attention_size, 1],
                            initializer=tf.truncated_normal_initializer(stddev=0.05))
        # batch_size, sequence_len, attention_size
        kq = tf.reshape(
            tf.matmul(
                tf.reshape(key, [-1, key_hidden_size]),
                W1
            ), [-1, sequence_len, attention_size]
        ) + tf.reshape(tf.matmul(query, W2), [-1, 1, attention_size])
        A = tf.reshape(
            tf.matmul(
                tf.reshape(
                    tf.tanh(kq), [-1, attention_size]
                ), v
            ), [-1, sequence_len]
        )
        return _build_attention_output(A, value), A


# compute the attention (weight) for each
def pairwise_attention(inputs_a, inputs_b, fc_first=True, scale=True, init_std=0.00001):
    dim = shape_list(inputs_a)[-1]
    cnt_a = shape_list(inputs_a)[-2]
    cnt_b = shape_list(inputs_b)[-2]
    if fc_first:
        # 这边在过fc的话直接用 identity
        inputs_a = my_conv_1d(inputs_a, 1, n_filters_out=dim, act=tf.identity)
        inputs_b = my_conv_1d(inputs_b, 1, n_filters_out=dim, act=tf.identity)
    # compute attention
    inputs_b = tf.transpose(inputs_b, (0, 2, 1))
    weight = tf.matmul(inputs_a, inputs_b)
    if scale:
        weight = weight / tf.sqrt(tf.cast(dim, tf.float32))
    # row is a col is b
    weight_view_a = my_full_connected(tf.reshape(weight, (-1, cnt_b)), 1, act=tf.nn.tanh,
                                      init_std=init_std,
                                      weights_initializer=tf.variance_scaling_initializer(mode='fan_avg', distribution='uniform'))
    weight_view_a = tf.reshape(weight_view_a, (-1, cnt_a))

    weight_view_b = my_full_connected(tf.reshape(tf.transpose(weight, (0, 2, 1)), (-1, cnt_a)), 1,
                                      act=tf.nn.tanh,
                                      init_std=init_std,
                                      weights_initializer=tf.variance_scaling_initializer(mode='fan_avg', distribution='uniform'))
    weight_view_b = tf.reshape(weight_view_b, (-1, cnt_b))
    # weight a, b in shape (batch, cnt_a)   (batch, cnt_b)
    return weight_view_a, weight_view_b


# https://github.com/tensorflow/models/blob/master/official/transformer/model/attention_layer.py
# https://github.com/OpenNMT/OpenNMT-tf/blob/master/opennmt/layers/transformer.py

def mask_attention_weights(input_tensor, epsilon=-1e9):
    """
    mask attention, only consider the left part
    """
    mask_n = shape_list(input_tensor)[-1]
    # Lower triangular with one
    mask = tf.linalg.band_part(tf.ones([mask_n, mask_n]), -1, 0)
    mask = tf.reshape(mask, [1, 1, mask_n, mask_n])
    # matrix broadcast
    return input_tensor*mask + epsilon*(1-mask)


def attention(query, key, value, attn_drop=0.1,
              training=False, scale=False, mask=True):
    """
    Scaled Dot-Product Attention

    """
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    #  key:    batch * n_head * n_state * n_word
    #  query:  batch * n_head * n_word * n_ state
    n_state = shape_list(query)[-1]
    weight = tf.matmul(query, key)
    if scale:
        weight = weight / tf.sqrt(tf.cast(n_state, get_default_float_type()))
    if mask:
        weight = mask_attention_weights(weight)
    attention = my_dropout(tf.nn.softmax(weight), attn_drop, training)
    attention_qkv = tf.matmul(attention, value)
    return attention_qkv


def split_states(input_tensor, n):
    shapes = shape_list(input_tensor)
    m = shapes[-1]
    new_shapes = shapes[:-1] + [n, m//n]
    return tf.reshape(input_tensor, new_shapes)


def merge_states(input_tensor):
    shapes = shape_list(input_tensor)
    new_shapes = shapes[:-2] + [np.prod(shapes[-2:])]
    return tf.reshape(input_tensor, new_shapes)


def split_heads(input_tensor, n_head, key_flag=False):
    if key_flag:
        return tf.transpose(split_states(input_tensor, n_head), [0, 2, 3, 1])
    else:
        return tf.transpose(split_states(input_tensor, n_head), [0, 2, 1, 3])


def merge_heads(input_tensor):
    return merge_states(tf.transpose(input_tensor, [0, 2, 1, 3]))


def multi_head_attention_v2(query, key, value, n_head, layer_name='multi_head_attention',
                            attn_drop=0.001, scale=False, mask=False,
                            scope=None, reuse=False, training=False):
    shapes = shape_list(query)
    n_state = shapes[-1]
    if len(shapes) == 2:
        query = tf.reshape(query, [-1, 1, n_state])

    if value is None:
        value = key
    assert n_state % n_head == 0
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        # the implementation here is very precise, use conv1d, everything is matrix matmul
        n_heads_query = split_heads(query, n_head)
        n_heads_key = split_heads(key, n_head, key_flag=True)
        n_heads_value = split_heads(value, n_head)
        attn = attention(n_heads_query, n_heads_key, n_heads_value, attn_drop=attn_drop,
                         training=training, scale=scale, mask=mask)
        attn = merge_heads(attn)
        # 之前这里有个bug，用的是tanh
        attn_conv = my_dropout(my_conv_1d(attn, 1, n_state, act=tf.identity),
                               attn_drop, training=training)
        return tf.reshape(attn_conv, [-1, n_state])


def multi_head_attention(input_tensor, n_state, n_head, layer_name='multi_head_attention',
                        attn_drop=0.1, scale=False, mask=True,
                        scope=None, reuse=False, training=False):
    assert n_state % n_head == 0

    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        # the implementation here is very precise, use conv1d, everything is matrix matmul
        c = my_conv_1d(input_tensor, 1, n_state*3, act=tf.identity, layer_name="conv_before")
        query, key, value = tf.split(c, 3, 2)
        n_heads_query = split_heads(query, n_head)
        n_heads_key = split_heads(key, n_head, key_flag=True)
        n_heads_value = split_heads(value, n_head)
        attn = attention(n_heads_query, n_heads_key, n_heads_value, attn_drop=attn_drop,
                         training=training, scale=scale, mask=mask)
        attn = merge_heads(attn)
        #之前这里有个bug，用的是tanh
        attn_conv = my_dropout(my_conv_1d(attn, 1, n_state, act=tf.identity, layer_name="conv_after"),
                               attn_drop, training=training)
        return attn_conv


# For debug only
def query_key_value_attention(query, key, value=None, attention_type='dot_production'):
    if attention_type == 'dot_production':
        return dot_production_attention(query, key, value)
    elif attention_type == 'multiplicative':
        return multiplicative_attention(query, key, value)
    elif attention_type == 'additive':
        return additive_attention(query, key, value)
    elif attention_type == 'multi_head_attention':
        return multi_head_attention_v2(query, key, value, n_head=8), None
