"""
Subclassing API Demo

运行脚本的命令:
单卡:
    PYTHONPATH=.. python horovod_subclassing_demo.py
单机8卡:
    PYTHONPATH=.. horovodrun -np 8 python horovod_subclassing_demo.py
多机多卡:
    PYTHONPATH=.. horovodrun -np 16 -H server1:8,server2:8 python horovod_subclassing_demo.py
"""

import horovod.tensorflow as hvd
import pandas as pd
import tensorflow as tf

from rcalgo.tf.models.finetune.google_bert import BertClassificationModel
from rcalgo.tf.utils.preprocessors import BertSentencePreprocessor


config = {
    "max_seq_length": 128,
    "epochs": 5,
    "test_size": 0.1,
    "batch_size": 32,
    "warmup_proportion": 0.1,

    "num_hidden_layers": 2,

    "learning_rate": 0.0003,

    "vocab_file": "/home/web_server/antispam/project/pretrained_models/"
                  "chinese_L-12_H-768_A-12/vocab.txt",
    "checkpoint_file": "/home/web_server/antispam/project/pretrained_models/"
                       "chinese_L-12_H-768_A-12/bert_model.ckpt"
}


def main(_):
    # 1. load train data
    train_file = "/home/web_server/antispam/project/datasets/female_vulgar/train.csv"
    test_file = "/home/web_server/antispam/project/datasets/female_vulgar/test.csv"
    train_data = pd.read_csv(train_file)
    test_data = pd.read_csv(test_file)
    preprocessor = BertSentencePreprocessor(config["vocab_file"])
    input_ids, input_mask, segment_ids = preprocessor.process(
        train_data["text"], max_seq_length=config["max_seq_length"])
    input_ids_t, input_mask_t, segment_ids_t = preprocessor.process(
        test_data["text"], max_seq_length=config["max_seq_length"])

    # compute num_train_steps and num_warmup_steps
    hvd.init()
    n_examples = int(train_data.shape[0] * (1 - config["test_size"]))
    config["num_train_steps"] = int(n_examples * config["epochs"] / config["batch_size"] / hvd.size())
    config["num_warmup_steps"] = int(config["num_train_steps"] * config["warmup_proportion"])
    print(config)

    # 2. define model
    model = BertClassificationModel(config).build_model()
    model.restore_weights(config["checkpoint_file"])
    print(model.tvars)
    print(model.model_summary())

    model.train_and_evaluate(
        [input_ids, input_mask, segment_ids, train_data['label']],
        [input_ids_t, input_mask_t, segment_ids_t, test_data['label']],
        batch_size=config["batch_size"],
        epochs=config["epochs"],
        # test_size=config["test_size"],
        checkpoint_dir="./saved_models",
        checkpoint_name="first_2_layers",
        hooks=[])


if __name__ == '__main__':
    tf.app.run()
