import os
import math
from collections.abc import Iterable
from multiprocessing import Process, Queue
import pathlib
import h5py
import numpy as np
import collections
import tensorflow as tf

from rcalgo.tf.training.data.tf_dataset import TFDataset


class Consumer(Process):
    def __init__(self, queue, output_file,
                 float_columns=[],
                 int64_columns=[],
                 bytes_columns=[]):
        super().__init__()
        self._queue = queue
        self._output_file = output_file
        self._float_columns = float_columns
        self._int64_columns = int64_columns
        self._bytes_columns = bytes_columns
        self._writer = None
        self._processed = 0

    def get_feature(self, value, dtype):
        if not isinstance(value, Iterable):
            value = [value]

        if dtype in ('int'):
            feature = tf.train.Feature(
                int64_list=tf.train.Int64List(value=list(value)))
        elif dtype in ('float'):
            feature = tf.train.Feature(
                float_list=tf.train.FloatList(value=list(value)))
        elif dtype in ('string', 'image'):
            feature = tf.train.Feature(
                bytes_list=tf.train.BytesList(value=list(value)))
        else:
            raise ValueError(f"Invalid dtype for colume: {dtype}")
        return feature

    def process_data(self, data):
        block, idx = data
        for i in range(len(idx)):
            features = collections.OrderedDict()
            for key in self._float_columns:
                features[key] = self.get_feature(block[key][i], 'float')
            for key in self._int64_columns:
                features[key] = self.get_feature(block[key][i], 'int')
            for key in self._bytes_columns:
                features[key] = self.get_feature(block[key][i], 'string')

            tf_example = tf.train.Example(
                features=tf.train.Features(feature=features))
            self._writer.write(tf_example.SerializeToString())
            self._processed += 1

    def run(self):
        self._processed = 0

        self._writer = tf.python_io.TFRecordWriter(self._output_file)
        while True:
            data = self._queue.get()
            if data is None:
                break
            self.process_data(data)
        self._writer.close()
        print(f"Processed {self._processed} examples")


class Producer(Process):
    def __init__(self, proc_id, queue, h5_path, features, indices, block_size=1024):
        super().__init__()
        self._proc_id = proc_id
        self._queue = queue
        self._h5_path = h5_path
        self._features = features
        self._indices = indices
        self._block_size = block_size

    def run(self):
        hf = h5py.File(self._h5_path, "r", libver='latest', swmr=True)
        n_examples = len(self._indices)
        for i in range(0, len(self._indices), self._block_size):
            idx = self._indices[i:i+self._block_size]
            idx = sorted(idx)
            while True:
                try:
                    print(f"Worker-{self._proc_id} reading: {i + self._block_size} / {n_examples}")
                    block = {key: hf[key][idx] for key in self._features}
                    break
                except Exception:
                    print(f"Worker-{self._proc_id} reading failed, retrying...")
            self._queue.put((block, idx))
        hf.close()


def convert_h5_to_tfrecord(h5_path, output_file, feature_names, label_names, indices, n_worker=5):
    """将h5文件转换成tfrecord.

    Note:
        shuffle以后读h5py文件太慢了, 所以这里不shuffle, 在训练时依靠tfrecord的shuffle功能.
    """
    print(f"n_examples: {len(indices)}")

    print("Processing train dataset...")
    n_producer, n_consumer = n_worker, n_worker * 2
    producers, consumers = [], []

    queue = Queue(maxsize=n_worker*4)
    for i in range(n_consumer):
        p = Consumer(queue, f'{output_file}-{i}',
                     float_columns=feature_names,
                     int64_columns=label_names)
        p.daemon = True
        p.start()
        consumers.append(p)

    num_per_producer = math.ceil(len(indices) / n_producer)
    for i in range(n_producer):
        sub_indices = indices[i*num_per_producer:(i+1)*num_per_producer]
        p = Producer(i, queue, h5_path, feature_names + label_names, sub_indices)
        p.daemon = True
        p.start()
        producers.append(p)

    for p in producers:
        p.join()

    for _ in range(n_consumer):
        queue.put(None)

    print("Waiting for queue to be empty...")
    for p in consumers:
        p.join()


def split_and_convert_h5_to_tfrecord(h5_path, output_dir, feature_names, label_names,
                                     test_size=0.1, n_worker=10):
    hf = h5py.File(h5_path, "r", libver='latest', swmr=True)
    n_examples = len(hf[feature_names[0]])
    hf.close()  # This line is very important!
    print(f"n_examples: {n_examples}")

    indices = np.random.permutation(n_examples)
    train_size = int(n_examples * (1 - test_size))
    train_indices, valid_indices = sorted(indices[:train_size]), sorted(indices[train_size:])

    # process train data
    pathlib.Path(f'{output_dir}/train').mkdir(parents=True, exist_ok=True)
    convert_h5_to_tfrecord(h5_path, f'{output_dir}/train/data.tfrecord',
                           feature_names, label_names,
                           train_indices, n_worker=n_worker)

    # process validation data
    pathlib.Path(f'{output_dir}/valid').mkdir(parents=True, exist_ok=True)
    if valid_indices:
        convert_h5_to_tfrecord(h5_path, f'{output_dir}/valid/data.tfrecord',
                               feature_names, label_names,
                               valid_indices, n_worker=n_worker)


def get_tfrecord_size(tfrecord_dir):
    print("Counting tfrecord size...")
    tfrecord_files = [os.path.join(tfrecord_dir, f) for f in os.listdir(tfrecord_dir)]
    count = 0
    for fn in tfrecord_files:
        for record in tf.python_io.tf_record_iterator(fn):
            count += 1
    return count


def load_tfrecord(tfrecord_dir, feature_keys, feature_dims, label_keys):
    tfrecord_files = [os.path.join(tfrecord_dir, f) for f in os.listdir(tfrecord_dir)]

    name_to_features = {}
    for key, dim in zip(feature_keys, feature_dims):
        name_to_features[key] = tf.FixedLenFeature([dim], tf.float32)
    for key in label_keys:
        name_to_features[key] = tf.FixedLenFeature([], tf.int64, default_value=0)

    def _decode_record(record):
        """Decodes a record to a TensorFlow example."""
        record = tf.parse_single_example(record, name_to_features)
        return record
    dataset = tf.data.TFRecordDataset(tfrecord_files, num_parallel_reads=4)
    dataset = dataset.map(_decode_record)
    return dataset


def load_tfrecord_for_train(tfrecord_dir, feature_keys, feature_dims, label_keys, n_examples=None):
    dataset = load_tfrecord(tfrecord_dir, feature_keys, feature_dims, label_keys)

    if n_examples is None:
        n_examples = get_tfrecord_size(tfrecord_dir)
        print(f"------dataset size: {n_examples}-------")

    dataset = dataset.map(lambda x: [x[key] for key in feature_keys + label_keys])
    dataset = TFDataset.from_tf_dataset(dataset, num_elements=n_examples)
    return dataset
