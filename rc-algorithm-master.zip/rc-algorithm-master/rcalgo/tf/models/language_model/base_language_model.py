import tensorflow as tf

from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.module.encoder.transformer import conv_transformer_layer
from rcalgo.tf.module.layer.tf_preprocess import TFPreprocessor
from rcalgo.tf.module.layer.activations import act_fns
from rcalgo.tf.training.model import Model
from rcalgo.tf.training.training_utils import create_task_in_graph, get_or_create_is_training
from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.utils.tf_func import get_new_variable_scope


class LanguageModel(Model):
    def __init__(self, config, **kwargs):
        """LM基类. """
        super(LanguageModel, self).__init__(config, **kwargs)

        self.sampled_softmax = config.get("sampled_softmax", True)
        self.num_sampled = config.get("num_sampled", 500)
        self.nb_words = config.get("nb_words", 10000)
        self.max_seq_length = config.get("max_seq_length", 128)

    def create_inputs(self):
        """构建默认输入placeholder.

        Returns:
            placeholder: input text
        """
        input_ids = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None, self.max_seq_length], name='input_ids')
        return input_ids, []

    def transform_inputs(self, inputs):
        """Transform inputs before processing.

        预处理、词语转id等都可以在这里实现, 通常是先实现一个以input_ids为输入的类, 比如
        TransformerLM，再继承它, 重写`create_inputs`和`transform_inputs`, 得
        到TFTransformerLM(以raw text为输入的TransformerLM)
        """
        return inputs

    def build_lm_representation(self, inputs):
        """Build forward network.

        Returns:
            tensor or list of tensors: hidden representation of input sequence
        """
        raise NotImplementedError

    def build_lm_outputs(self, states):
        """在这里经过dense层映射成vocab的分布.
        """
        raise NotImplementedError

    def call(self, inputs):
        """Forward propagation."""
        input_ids = self.transform_inputs(inputs)
        states = self.build_lm_representation(input_ids)
        logits = self.build_lm_outputs(states)
        targets = tf.concat([input_ids[:, 1:], tf.zeros_like(input_ids[:, 0:1])], 1)
        return {
            "input_ids": input_ids,
            "states": states,
            "logits": logits,
            "targets": targets
        }

    def get_decoding_weights(self):
        """Get weights of decoding layer.

        Returns:
            tensor of shape (hidden_size, vocab_size): weights
            tensor of shape (vocab_size): bias
        """
        raise NotImplementedError

    def compute_loss(self, outputs, labels):
        """Compute loss of the model."""
        input_ids, logits = outputs['input_ids'], outputs['logits']
        input_ids_flat = tf.reshape(input_ids, [-1, input_ids.shape.as_list()[-1]])
        logits_flat = tf.reshape(logits, [-1, logits.shape.as_list()[-1]])
        weights, bias = self.get_decoding_weights()

        with get_new_variable_scope('loss'):
            # 这里可以根据实际情况实现一下
            sampled_softmax_loss, full_softmax_loss = self._seq_sampled_softmax_loss(
                input_ids_flat,
                logits_flat,
                weights,
                bias,
                labels,
                self.nb_words,
                self.num_sampled)
        if self.sampled_softmax:
            loss = sampled_softmax_loss
        else:
            loss = full_softmax_loss

        loss = tf.reduce_mean(loss)
        return loss

    def compute_metrics(self, outputs, labels):
        """Compute metrics of the model."""
        metrics = ... # 基类里把metrics实现掉
        return metrics

    def compute_predictions(self, outputs):
        """Get predictions of the model."""
        return (outputs["states"], tf.nn.softmax(outputs["logits"]))

    def build_forward(self, **kwargs):
        """Build forward.

        Note:
            后面会把`Model`的`build_forward`的函数修改成这样，这里先实现一下，后面基类
            改完之后这里就不用实现`build_forward`了
        """
        self.inputs, self.labels = self.create_inputs()
        self.outputs = self(self.inputs)
        self.loss = self.compute_loss(self.outputs, self.labels)
        self.metrics = self.compute_metrics(self.outputs, self.labels)
        self.predictions = self.compute_predictions(self.outputs)

        create_task_in_graph(
            self.inputs, self.predictions, self.labels, self.loss,
            self.metrics, name=self.name)


class MaskedLanguageModel(Model):
    def __init__(self, config, **kwargs):
        super(MaskedLanguageModel, self).__init__(config, **kwargs)
        self.nb_words = config.get("nb_words", 10000)

    def create_inputs(self):
        """构建默认输入placeholder.

        Returns:
            placeholder: input text
        """
        input_ids = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_ids')
        input_mask = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_mask')
        return [input_ids, input_mask], []

    def transform_inputs(self, inputs):
        """Transform inputs before processing."""
        raise inputs

    def build_lm_representation(self, inputs):
        """Build forward network.

        Returns:
            tensor or list of tensors: hidden representation of input sequence
        """
        raise NotImplementedError

    def build_lm_outputs(self, states):
        """在这里经过dense层映射成vocab的分布.
        """
        raise NotImplementedError

    def call(self, inputs):
        """Forward propagation."""
        input_ids, input_mask = self.transform_inputs(inputs)
        states = self.build_lm_representation(input_ids)
        logits = self.build_lm_outputs(states)
        targets = ... # 从input_ids里面取到mask位置的label
        pred_targets = ... # 从logits里面取到mask位置的预测结果
        return {
            "input_ids": input_ids,
            "states": states,
            "logits": logits,
            "targets": targets,
            "pred_targets": pred_targets
        }

    def compute_loss(self, outputs, labels):
        """Compute loss of the model."""
        targets, pred_targets = outputs['targets'], outputs['pred_targets']
        loss = ... # 基类里把loss实现掉
        return loss

    def compute_metrics(self, outputs, labels):
        """Compute metrics of the model."""
        metrics = ... # 基类里把metrics实现掉
        return metrics

    def compute_predictions(self, outputs):
        """Get predictions of the model."""
        return (outputs["states"], tf.nn.softmax(outputs["logits"]))

    def build_forward(self, **kwargs):
        """Build forward.

        Note:
            后面会把`Model`的`build_forward`的函数修改成这样，这里先实现一下，后面基类
            改完之后这里就不用实现`build_forward`了
        """
        self.inputs, self.labels = self.create_inputs()
        self.outputs = self(self.inputs)
        self.loss = self.compute_loss(self.outputs, self.labels)
        self.metrics = self.compute_metrics(self.outputs, self.labels)
        self.predictions = self.compute_predictions(self.outputs)

        create_task_in_graph(
            self.inputs, self.predictions, self.labels, self.loss,
            self.metrics, name=self.name)
