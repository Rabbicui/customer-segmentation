import tensorflow as tf

from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.training.training_utils import get_or_create_is_training, create_task_in_graph
from rcalgo.tf.module.layer.basic import my_full_connected
from rcalgo.tf.models.classifier.text_classifier import TextCNN, TextClassifierBase
from rcalgo.tf.module.encoder.cnn import text_cnn_encoder
from rcalgo.tf.training.model import Model
from rcalgo.tf.training.data.data import Data


class MultiOutputWrapper(Model):
    def __init__(self, execute_model, config, **kwargs):
        self.execute_model = execute_model
        self.num_classes_list = config.get('num_classes_list')
        self.output_num = len(self.num_classes_list)
        self.loss_weights = config.get('loss_weights')
        if self.loss_weights is None:
            self.loss_weights = [1 for _ in range(self.output_num)]
        super().__init__(config, **kwargs)

    def compute_loss(self, logits_list, labels_list):
        loss_list = []
        for logits, labels in zip(logits_list, labels_list):
            loss = self.execute_model.compute_loss(logits, labels)
            loss_list.append(loss)
        final_loss = self.execute_model._penalty()
        for i in range(self.output_num):
            final_loss += loss_list[i] * self.loss_weights[i]
        return final_loss

    def compute_metrics(self, outputs_list, labels_list):
        accs = []
        for outputs, labels in zip(outputs_list, labels_list):
            accuracy = tf.cast(tf.nn.in_top_k(outputs, labels, k=1),  # TODO: fix magic number
                               dtype=tf.float32)
            accs.append(accuracy)
        return accs

    def create_inputs(self):
        text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
        label_list = []
        for i in range(self.output_num):
            label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name=f'input_label_{i}')
            label_list.append(label)
        return text, label_list

    def call(self, inputs, **kwargs):
        is_training = get_or_create_is_training()
        embedding, seq_lengths = self.execute_model.build_embedding(inputs)
        hidden = self.execute_model.build_representation(embedding, seq_lengths, **kwargs)
        logits_list = []
        prediction_list = []
        for i, num_classes in enumerate(self.num_classes_list):
            print(num_classes, hidden)
            logits = my_full_connected(hidden, num_classes, layer_name=f"full_connect_{i}")
            prediction = tf.nn.softmax(logits)
            logits_list.append(logits)
            prediction_list.append(prediction)
        return logits_list, prediction_list