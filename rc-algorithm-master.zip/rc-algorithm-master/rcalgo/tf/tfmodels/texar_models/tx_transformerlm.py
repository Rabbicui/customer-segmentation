from .tx_rnnlm import *
import texar.tf as tx
from rcalgo.tf.tfmodels.rnnlm import *
import os
import sys
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))


class TxTransformerLMModel(TxRNNLMModel):
    def __init__(self, config, graph, word_dict=None):
        super(TxTransformerLMModel, self).__init__(
            config, graph, word_dict)
        self.position_type = config.position_type
        self.state_length = config.state_length if hasattr(
            config, 'state_length') else 1
        self.n_head = config.n_head
        self.add_memory_seq = config.add_memory_seq if hasattr(
            config, 'add_memory_seq') else False
        self._init_config()
        # debug 代码
        self.add_conv_flag = config.add_conv_flag if hasattr(
            config, 'add_conv_flag') else False
        self.pos_zero_pad = config.pos_zero_pad if hasattr(
            config, 'pos_zero_pad') else True

    def _init_config(self):
        """
        the config for transformer
        """
        ffn_config = tx.modules.default_transformer_poswise_net_hparams(output_dim=self.embedding_size)
        ffn_config['layers'][1]['kwargs']['rate'] = 1.0 - self.keep_prob
        self.config_decoder = {
            "num_blocks": self.num_layers,
            "dim": self.embedding_size,
            "embedding_dropout": 1.0 - self.keep_prob,
            "residual_dropout": 1.0 - self.keep_prob,
            "poswise_feedforward": ffn_config,
            "multihead_attention": {
                "num_units": self.embedding_size,
                "num_heads": self.n_head,
                "dropout_rate": 1.0 - self.keep_prob,
                "output_dim": self.embedding_size,
            },
            # "initializer": None,
            "name": "transformer_decoder",
        }
        self.pos_embed = {"dim": self.embedding_size}

    def build_input(self, expand_input=False):
        super(TxRNNLMModel, self).build_input(expand_input)
        # go_value, eos_value, top_k, softmax_temperature
        self.build_sentence_flag(self.nb_words)
        self.build_topk_input()

    def _build_topk_input_placeholder(self, split_input_context):
        """
        预测的时候，infer_sample支持自定义输入的文本，
        将文本转BOW，且添加SOS
        """
        if self.word_level_seg:
            out = tf.string_split(split_input_context, result_type="SparseTensor")
        else:
            out = tf.to_int64(tf.strings.unicode_decode(
                split_input_context, input_encoding='UTF-8').to_sparse())
        out = self.word_table.lookup(out)
        SOS = get_concat_sparse_tensor(out, tf.to_int64(self.go_value), False)
        return tf.to_int32(sparse_to_dense(tf.sparse_concat(1, [SOS, out])))

    def build_topk_input(self):
        """
        自定义输入
        """
        self.input_context = tf.compat.v1.placeholder_with_default(
            tf.fill([self.dynamic_batch_size * self.gpu_num], ''), [None], name='input_context')
        self.split_input_context = tf.split(
            self.input_context, self.gpu_num, 0)
        self.split_input_context_id = [
            self._build_topk_input_placeholder(x) for x in self.split_input_context]
        self.split_input_context_id_len = [tf.count_nonzero(x, 1, dtype=tf.int32) for x in self.split_input_context_id]
        # self._add_to_graph_inputs(self.input_context)
        self.input_dict['input_context'] = self.split_input_context[0]

    def init_rnn_state(self):
        """
        初始状态，用来对应encoder部分的state
        """
        if self.add_memory_seq:
            # 初始encoder的长度
            self.split_mem_length = [tf.fill([self.dynamic_batch_size], self.state_length)
                                     for i in range(self.gpu_num)]
            self.init_state, self.split_init_state = self._init_rnn_state(
                self.state_length)
            self.input_dict['input_state'] = self.split_init_state[0]
            if self.state_fc_convert:
                if self.state_length == 1:
                    self.split_init_state = [tf.stack([my_full_connected(x, self.hidden_size, act=tf.nn.tanh,
                                                                         scope='fully_connected', reuse=tf.AUTO_REUSE)
                                                       for i in range(self.state_length)], axis=1) for x in
                                             self.split_init_state]
                else:
                    self.split_init_state = [my_conv_1d(x, 1, self.hidden_size, scope='1_1_conv', reuse=tf.AUTO_REUSE)
                                             for x in self.split_init_state]

        else:
            self.split_mem_length = [None for i in range(self.gpu_num)]
            self.split_init_state = [None for i in range(self.gpu_num)]

    def _conv_fn(self, input_tensor):
        if self.add_conv_flag:
            # relu和tanh效果相比，整体relu会好点
            return multi_width_cnn_block(input_tensor, self.hidden_size, self.position_type,
                                         combine_mode='ADD', padding='LEFT_SAME', act=tf.nn.relu,
                                         scope='mw_conv_block')
        else:
            return tf.identity(input_tensor)

    def build_training_decoder(self, gpu_id, input_tensor, intput_seqlen, maxlen, nb_words):
        if gpu_id == 0:
            self.decoder_pos_embedder = tx.modules.PositionEmbedder(
                position_size=maxlen, hparams=self.pos_embed)
            self.decoder = tx.modules.TransformerDecoder(vocab_size=nb_words,
                                                         hparams=self.config_decoder)
        with tf.variable_scope(self.decoder.variable_scope):
            position = tf.tile(tf.expand_dims(tf.range(maxlen, dtype=tf.int32), [0]), [
                self.dynamic_batch_size, 1])
            if self.pos_zero_pad:
                seq_len = tf.cast(intput_seqlen, dtype=tf.int32)
            else:
                seq_len = tf.fill([self.dynamic_batch_size], maxlen)
            pos_embeeding = self.decoder_pos_embedder(position, seq_len)
            outputs = self.decoder(inputs=self._conv_fn(input_tensor) + pos_embeeding,
                                   memory=self.split_init_state[gpu_id],
                                   memory_sequence_length=self.split_mem_length[gpu_id],
                                   mode='train',
                                   decoding_strategy='train_greedy')
            self.logits[gpu_id] = outputs

    def build_input_sequence(self, gpu_id=0):
        self._build_embedding_layer(gpu_id, 'decoder_embedding')
        self.build_training_decoder(
            gpu_id, self.input_embedding[gpu_id], self.split_seqLengths[gpu_id], self.maxlen, self.nb_words)
        with tf.variable_scope(self.decoder.variable_scope, reuse=tf.AUTO_REUSE):
            self.build_inference(gpu_id, self.maxlen)

    def _infer_fn(self, gpu_id, decoder, decoder_start_token, eos_value, maxlen, embedding, *args, **kwargs):
        # 需要在feed_dict里面，tx.global_mode()：'infer'
        return decoder(decoding_strategy='infer_sample',
                       start_tokens=decoder_start_token,
                       end_token=eos_value,
                       embedding=embedding,
                       memory=self.split_init_state[gpu_id],
                       memory_sequence_length=self.split_mem_length[gpu_id],
                       impute_finished=True,
                       mode='infer',
                       max_decoding_length=maxlen,
                       *args, **kwargs)

    def _build_inference(self, gpu_id, decoder, go_value, eos_value, maxlen, embedding):
        # decoder_start_token = self.split_input_context_id[gpu_id][:, 0]
        decoder_start_token = tf.fill([self.dynamic_batch_size], 1) * self.go_value
        # print(decoder_start_token)
        topk_helper = tx.modules.TopKSampleEmbeddingHelper(embedding,
                                                           start_tokens=decoder_start_token,
                                                           end_token=eos_value,
                                                           top_k=self.top_k,
                                                           softmax_temperature=self.softmax_temperature
                                                           )

        infer_sample_outputs, a1 = self._infer_fn(gpu_id, decoder,
                                                  decoder_start_token, eos_value,
                                                  maxlen, embedding)
        infer_beam_outputs = self._infer_fn(gpu_id, decoder,
                                            decoder_start_token, eos_value,
                                            maxlen, embedding,
                                            beam_width=self.beam_width)
        infer_topk_outputs, a2 = self._infer_fn(gpu_id, decoder,
                                                decoder_start_token, eos_value,
                                                maxlen, embedding,
                                                context=self.split_input_context_id[gpu_id],
                                                context_sequence_length=self.split_input_context_id_len[gpu_id],
                                                helper=topk_helper)
        self.inference_decoder_output[gpu_id] = [
            infer_sample_outputs, infer_topk_outputs, infer_beam_outputs]

    def build_inference(self, gpu_id, maxlen):
        dec_embeddings = tf.compat.v1.get_collection('decoder_embedding')[0]

        def _embedding_fn(x, y):
            # return tf.nn.embedding_lookup(dec_embeddings, x) + self.pos_embedder(y)
            return tf.reshape(self._conv_fn(tf.nn.embedding_lookup(dec_embeddings, tf.reshape(x, [-1, 1]))
                                            ), [-1, self.hidden_size]) + self.decoder_pos_embedder(y)

        # TransformerDecoder在训练的时候,直接不考虑序列长度
        self._build_inference(gpu_id, decoder=self.decoder, go_value=self.go_value,
                              eos_value=self.eos_value, maxlen=maxlen, embedding=_embedding_fn)

    def build_sequence_prediction(self, task=None, gpu_id=0, nb_class=None, accK=1):
        predictions = self.logits[gpu_id].logits
        self.tower_prediction_results.append(predictions)
        super(RNNLMModel, self).compute_metrics(predictions, self.split_targets[gpu_id],
                                                task=task, nb_class=nb_class, accK=accK)

    def _dump_rnn_decoder_beamsearch_output(self):
        self.output_dict['beam_search_results'] = tf.identity(
            self.inference_decoder_output[0][2]['sample_id'], name='beam_search_results')
