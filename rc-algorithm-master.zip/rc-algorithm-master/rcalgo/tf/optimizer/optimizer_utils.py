import horovod.tensorflow as hvd
import tensorflow as tf

from rcalgo.tf.optimizer.weight_decay_optimizers import AdamWOptimizer
from rcalgo.tf.utils.tf_float_type import get_default_float_type


def build_optimizer(task, learning_rate, opt_params):
    """ build optimizer.
    :param task: task_name, default = 'default'
    :param learning_rate: learning rate, a Tensor
    :param opt_params:  a param dict
    :return: optimizer built
    """
    opt_str = opt_params.optimizer
    # set optimizer
    if opt_str == 'sgd':
        optimizer = tf.train.GradientDescentOptimizer(learning_rate,
                                                      name='GradientDescent_{}'.format(task))
    elif opt_str == 'rmsprop':
        optimizer = tf.train.RMSPropOptimizer(learning_rate,
                                              momentum=0.9,
                                              name='RMSProp_{}'.format(task))
    elif opt_str == 'adam':
        if get_default_float_type() == tf.float16:
            opt_params.adam_epsilon = max(1e-4, opt_params.adam_epsilon)
        optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate,
                                                     opt_params.adam_beta1,
                                                     opt_params.adam_beta2,
                                                     opt_params.adam_epsilon,
                                                     name='Adam_{}'.format(task))
    elif opt_str == 'adamw':
        optimizer = AdamWOptimizer(opt_params.adam_wd,
                                   learning_rate,
                                   opt_params.adam_beta1,
                                   opt_params.adam_beta2,
                                   opt_params.adam_epsilon,
                                   name='AdamW_{}'.format(task))
    else:
        raise ValueError('the opt string must be in (sgd, rmsprop, adam, adamW)')

    if opt_params.loss_scaling:  # TODO: add comments or wiki url
        loss_scale_manager = tf.contrib.mixed_precision.FixedLossScaleManager(opt_params.loss_scale_factor)
        optimizer = tf.contrib.mixed_precision.LossScaleOptimizer(optimizer, loss_scale_manager)

    return optimizer


def clip_gradients(grads_and_vars, clip_type=None, max_clip_grad=1.0):
    if clip_type == 'clip_value':
        capped_gvs = [(None if grad is None else tf.clip_by_value(
            grad, -max_clip_grad, max_clip_grad), var) for grad, var in grads_and_vars]
    elif clip_type == 'clip_norm':
        capped_gvs = [(None if grad is None else tf.clip_by_norm(
            grad, max_clip_grad), var) for grad, var in grads_and_vars]
    elif clip_type == 'clip_global_norm':
        capped_gvs, grads_and_vars_norm = tf.clip_by_global_norm(
            [grad for grad, var in grads_and_vars], max_clip_grad)
        tvars = [var for grad, var in grads_and_vars]
        capped_gvs = list(zip(capped_gvs, tvars))
    else:
        capped_gvs = grads_and_vars
    return capped_gvs


class OptimizerWrapper(object):
    def __init__(self, optimizer, clip_type=None, max_clip_grad=1.0):
        self._optimizer = optimizer
        self._clip_type = clip_type
        self._max_clip_grad = max_clip_grad

    def compute_gradients(self, loss, tvars, *args, **kwargs):
        if hasattr(self._optimizer, "compute_gradients"):
            grads_and_vars = self._optimizer.compute_gradients(loss, tvars, *args, **kwargs)
        else:
            grads_and_vars = self._optimizer.get_gradients(loss, tvars, *args, **kwargs)

        capped_gvs = clip_gradients(grads_and_vars, clip_type=self._clip_type,
                                    max_clip_grad=self._max_clip_grad)
        return capped_gvs

    def apply_gradients(self, grads_and_vars, global_step=None, *args, **kwargs):
        if global_step is None:
            global_step = tf.train.get_or_create_global_step()
        return self._optimizer.apply_gradients(grads_and_vars, global_step=global_step,
                                               *args, **kwargs)

    def minimize(self, loss, tvars, global_step=None, name=None):
        grads_and_vars = self.compute_gradients(loss, tvars)
        return self.apply_gradients(grads_and_vars, global_step=global_step, name=name)


class HorovodOptimizerWrapper(OptimizerWrapper):
    def __init__(self, optimizer, sparse_as_dense=True, **kwargs):
        optimizer = hvd.DistributedOptimizer(
            optimizer, sparse_as_dense=sparse_as_dense)

        super(HorovodOptimizerWrapper, self).__init__(
            optimizer, **kwargs)


class GraphCopyOptimizerWrapper(OptimizerWrapper):
    def compute_gradients(self, *args, **kwargs):
        with tf.name_scope('loss'):
            grads_and_vars = super(
                GraphCopyOptimizerWrapper, self).compute_gradients(*args, **kwargs)

            grads_and_vars = [
                (tf.convert_to_tensor(grad), var)
                if isinstance(grad, tf.IndexedSlices) else (grad, var)
                for (grad, var) in grads_and_vars
            ]
            for grad, var in grads_and_vars:
                if isinstance(grad, tf.IndexedSlices):
                    print(grad)
            return grads_and_vars
