from rcalgo.tf.module.layer.ngram_process import TFNgramSpanMaskProcessor
from rcalgo.tf.training import context
import tensorflow as tf


class TFDatasetTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()
        tf.set_random_seed(42)

    def test_span_mask(self):
        config_dict = {
            'seq_length': 16,
            'oov_buckets': 5,
            'do_regex': False,
            'low_threshold': 2,
            'high_threshold': 3}
        text_list = [
            'hello, world',
            'antispam',
            'py  torch'
        ]
        word_dict = {'<PAD>': 0, 'hel': 1, 'ell': 2, 'llo': 3, 'lo,': 4,
                     'o, ': 5, ', w': 6, ' wo': 7, 'wor': 8, 'orl': 9,
                     'rld': 10, 'ant': 11, 'tis': 12, 'isp': 13,
                     'pam': 14, 'py ': 15, 'y t': 16, ' to': 17,
                     'tor': 18, 'orc': 19, 'rch': 20}
        processor = TFNgramSpanMaskProcessor(config_dict, word_dict)
        inputs = tf.placeholder(tf.string, [None], name='raw_inputs')
        masked_flag = tf.placeholder(tf.float32, [None], name='masked_flag')
        outputs = processor([inputs, masked_flag])
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: text_list,
                                                      masked_flag: [1., 1., 1.]})
        # [SOS]:26, [EOS]:27, [MASK]:28, [UNK]:21
        expected_results = [[[26, 1, 2, 3, 4, 5, 6, 7, 8, 9, 28, 28, 0, 0, 0, 0],
                             [26, 11, 21, 12, 13, 28, 28,
                                 27, 0, 0, 0, 0, 0, 0, 0, 0],
                             [26, 15, 28, 28, 18, 19, 20, 27, 0, 0, 0, 0, 0, 0, 0, 0]],
                            [[0, 10], [0, 11], [1, 5], [1, 6],
                                [2, 1], [2, 2], [2, 3]],
                            [10, 27, 21, 14, 15, 16, 17],
                            [2, 2, 3]]
        self.assertAllEqual(actual_results[0], expected_results[0])
        self.assertAllEqual(actual_results[1], expected_results[1])
        self.assertAllEqual(actual_results[2], expected_results[2])
        self.assertAllEqual(actual_results[3], expected_results[3])
        return None


if __name__ == "__main__":
    tf.test.main()
