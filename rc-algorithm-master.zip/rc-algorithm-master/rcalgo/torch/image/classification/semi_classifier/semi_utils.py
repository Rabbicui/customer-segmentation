import os
import sys
from typing import List

import torch
import torchvision.models as models


class DataKeyRegistry:
    image = 'image'
    label = 'label'


class FinetuneConfig:
    arch = 'resnet50'  # net architecture
    workers = 32
    epochs = 300
    start_epoch = 0
    batch_size = 256
    lr = 0.01
    schedule = [60, 80]
    momentum = 0.9
    weight_decay = 0.
    print_freq = 10
    evaluate = True
    seed = 25

    num_classes = 1000
    model_name = ''
    eval_every = -1
    aug_mode = 1
    freeze = False
    checkpoint_dir = './ckpt4few'

    pretrained = ''
    use_torchvision = True
    resume = ''


class PseudoLabelConfig:
    arch = 'resnet50'  # net architecture
    workers = 32
    batch_size = 256
    resume = ''
    use_torchvision = True
    num_classes = 1000
    eval_every = -1
    fuse_data = True
    aug_mode = 1
    label_teacher = 'MoCo'  # choices=['MoCo', 'BiTm', 'torchvision'],
    # pseudo_data_path = f'./data/pseudo/{label_teacher.lower()}/noisy_data.csv'


class NoisyTrainConfig(FinetuneConfig):
    arch = 'resnet50'  # net architecture
    workers = 32
    epochs = 300
    start_epoch = 0
    batch_size = 256
    lr = 0.01
    schedule = [60, 80]
    momentum = 0.9
    weight_decay = 0.
    print_freq = 10
    evaluate = True
    seed = 25

    num_classes = 1000
    model_name = ''
    eval_every = -1
    aug_mode = 1
    freeze = False,
    checkpoint_dir = './ckpt4semi'

    use_torchvision = True
    pretrained = ''
    resume = ''


def insert_parameters_into_config(config, params: dict):
    members = [x for x in config.__dir__() if not x.startswith('_')]
    # assert len(set(members) - set(params.keys())) == 0, f'members of config must be subset of params'
    for key in members:
        setattr(config, key, params.get(key))

    return config


def resume_previous_checkpoint(config, model, optimizer, printf=print):
    checkpoint_path = config.resume
    assert os.path.isfile(checkpoint_path), "=> no checkpoint found at '{}'".format(checkpoint_path)
    printf("=> [Resuming]: Loading checkpoint '{}'".format(checkpoint_path))
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer'])

    config.start_epoch = checkpoint['epoch']
    config.best_acc1 = checkpoint['best_acc1']
    printf("=> [Resumed]: Loaded checkpoint '{}' (epoch {})".format(checkpoint_path, checkpoint['epoch']))
    return model, config, optimizer


def load_pretrained_checkpoint(config, model, printf=print):
    checkpoint_path = config.pretrained
    assert os.path.isfile(checkpoint_path), f"=> no checkpoint found at '{checkpoint_path}'"
    printf(f"=> [Loading]: loading checkpoint '{checkpoint_path}'")
    checkpoint = torch.load(checkpoint_path, map_location="cpu")

    state_dict = checkpoint['state_dict']

    new_state_dict = dict()
    for k in list(state_dict.keys()):
        if k.startswith('module.encoder_q') and not k.startswith('module.encoder_q.fc'):
            new_state_dict.__setitem__(k[len('module.encoder_q.'):], state_dict[k])

    msg = model.load_state_dict(new_state_dict, strict=False)
    printf(f'=> [Miss]: missing keys: {msg.missing_keys}')
    assert len(msg.missing_keys) == 0 or set(msg.missing_keys) == {"fc.weight", "fc.bias"}
    printf("=> [Loaded]: loaded pre-trained model '{}'".format(checkpoint_path))

    config.start_epoch = 0
    return model, config


def load_torchvision_checkpoint(config):
    return models.__dict__[config.arch](pretrained=config.use_torchvision)


def check_data_integrality(train_data, val_data, unlabeled_data):
    assert isinstance(train_data, dict) and isinstance(val_data, dict) and isinstance(unlabeled_data, dict)
    assert 'image' in train_data and 'image' in val_data and 'image' in unlabeled_data
    assert 'label' in train_data and 'label' in val_data

    assert len(train_data['image']) == len(train_data['label']) != 0
    assert len(val_data['image']) == len(val_data['label']) != 0
    assert len(unlabeled_data['image']) != 0


def save_checkpoint(state, is_best, best_checkpoint_path, printf=print):
    if not os.path.exists(os.path.dirname(best_checkpoint_path)): os.makedirs(os.path.dirname(best_checkpoint_path))

    if is_best:
        torch.save(state, best_checkpoint_path)
        printf(f'find new best checkpoint, saved at {best_checkpoint_path}')


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self, name, fmt=':f'):
        self.name = name
        self.fmt = fmt
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name} {val' + self.fmt + '} ({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)


class ProgressMeter(object):
    def __init__(self, num_batches, meters, prefix=""):
        self.batch_fmtstr = self._get_batch_fmtstr(num_batches)
        self.meters = meters
        self.prefix = prefix

    def display(self, batch, printf=print):
        entries = [self.prefix + self.batch_fmtstr.format(batch)]
        entries += [str(meter) for meter in self.meters]
        printf('\t'.join(entries))
        sys.stdout.flush()

    def _get_batch_fmtstr(self, num_batches):
        num_digits = len(str(num_batches // 1))
        fmt = '{:' + str(num_digits) + 'd}'
        return '[' + fmt + '/' + fmt.format(num_batches) + ']'


def adjust_learning_rate(optimizer, epoch, args):
    """Decay the learning rate based on schedule"""
    lr = args.lr
    for milestone in args.schedule:
        lr *= 0.1 if epoch >= milestone else 1.
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred)).contiguous()

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


def inference_labels(output):
    with torch.no_grad():
        labels = output.argmax(dim=1).cpu().numpy().tolist()
    return labels


def dump_lines(lines: List[str], data_path: str):
    print(f'Preparing to dump lines into {data_path}')
    with open(data_path, 'w', encoding='utf-8') as wf:
        for li in lines:
            assert li.endswith('\n')
            wf.write(li)
    print(f'Have dumped lines into {data_path}')
