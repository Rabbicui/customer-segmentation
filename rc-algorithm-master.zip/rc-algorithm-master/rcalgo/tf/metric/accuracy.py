import tensorflow as tf


# the accuracy for the targets which have variable length
def varibale_accuracy(y_pred, y_true):
    if tf.shape(y_pred).shape[0].value == tf.shape(y_true).shape[0].value:
        pred_idx = y_pred
    else:
        pred_idx = tf.cast(tf.argmax(y_pred, 2), dtype=tf.int32)
    accuracy_flag = tf.cast(tf.equal(pred_idx, y_true), dtype=tf.float32)
    mask = tf.cast(tf.sign(tf.abs(y_true)), dtype=tf.float32)
    accuracy_flag *= mask
    accuracy = tf.reduce_sum(accuracy_flag)/tf.reduce_sum(mask)
    return accuracy


def varibale_topk_accuracy(y_pred, y_true, k):
    y_pred_new = tf.reshape(y_pred, [-1, y_pred.get_shape()[-1].value])
    y_true_new = tf.reshape(y_true, [-1])
    y_true_mask = tf.cast(tf.sign(tf.abs(y_true_new)), dtype=tf.int32)
    y_true_indices = tf.reshape(tf.compat.v2.where(tf.not_equal(y_true_mask, tf.constant(0, y_true_mask.dtype))), [-1])
    accuracy_flag = tf.cast(tf.nn.in_top_k(
        tf.gather(y_pred_new, y_true_indices), tf.gather(y_true_new,y_true_indices), k=k), dtype=tf.float32)
    # mask = tf.cast(tf.sign(tf.abs(y_true)), dtype=tf.float32)
    # mask = tf.reshape(mask, [-1])
    # accuracy_flag *= mask
    # tok_accuracy = tf.reduce_sum(accuracy_flag)/tf.reduce_sum(mask)
    tok_accuracy = tf.reduce_sum(accuracy_flag)/tf.cast(tf.reduce_sum(y_true_mask), tf.float32)
    return tok_accuracy
