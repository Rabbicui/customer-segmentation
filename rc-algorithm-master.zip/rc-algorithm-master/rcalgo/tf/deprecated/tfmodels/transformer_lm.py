from rcalgo.tf.tfmodels.bi_rnnlm import *
import sys
import os
# sys.path.insert(0,'..')
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))


"""
args.position_type = '2,3,4,5'
args.n_head = 8
args.transformer_func = 'relu'
args.keep_prob = 1.0
args.conv_num_filters = 256
"""


class TransformerLMModel(RNNLMModel):
    def __init__(self, config, gragh, word_dict=None):
        super(TransformerLMModel, self).__init__(
            config, gragh, word_dict)
        self.n_head = config.n_head
        self.position_type = config.position_type
        self.attn_drop = 1 - config.keep_prob
        self.mask = True
        self.ffn_act = act_fns[config.transformer_func]
        self.ffn_drop = 1 - config.keep_prob
        self.conv_num_filters = config.conv_num_filters
        self.position_info = config.position_info
        self.combine_mode = config.combine_mode
        self.output_reduce_size = config.output_reduce_size

    def init_rnn_state(self):
        pass

    def build_input_sequence(self, gpu_id=0):
        self._build_embedding_layer(gpu_id)
        self.state_list[gpu_id], self.rnn_output_list[gpu_id] = conv_transformer_layer(self.input_embedding[gpu_id], self.num_layers, self.split_seqLengths[gpu_id], self.conv_num_filters, self.position_type, combine_mode = self.combine_mode, output_reduce_size=self.output_reduce_size, position_info=self.position_info, n_head=self.n_head, attn_drop=self.attn_drop, mask=self.mask, ffn_act=self.ffn_act, ffn_drop=self.ffn_drop, training=self.training)
        self.output_list[gpu_id] = self.rnn_output_list[gpu_id]


class BiTransformerLMModel(BiRNNLMModel):
    def __init__(self, config, gragh, word_dict=None):
        super(BiTransformerLMModel, self).__init__(
            config, gragh, word_dict)
        self.n_head = config.n_head
        self.position_type = config.position_type
        self.attn_drop = 1-config.keep_prob
        self.mask = True
        self.ffn_act = act_fns[config.transformer_func]
        self.ffn_drop = 1-config.keep_prob
        self.combine_mode = config.combine_mode
        self.conv_num_filters = config.conv_num_filters
        self.output_reduce_size = config.output_reduce_size

    def init_rnn_state(self):
        pass

    def build_input_sequence(self, gpu_id=0):
        self._build_embedding_layer(gpu_id)
        self.state_list[gpu_id], self.rnn_output_list[gpu_id] = bi_conv_transformer_layer(self.input_embedding[gpu_id], self.num_layers, self.split_seqLengths[gpu_id], self.conv_num_filters, self.position_type, combine_mode = self.combine_mode, output_reduce_size=self.output_reduce_size,  n_head=self.n_head, attn_drop=self.attn_drop, mask=self.mask, ffn_act=self.ffn_act, ffn_drop=self.ffn_drop, training=self.training)
        #self.output_list[gpu_id] = tf.concat(self.rnn_output_list[gpu_id], 1)
        seqlen_exp_dim = array_ops.tile(tf.cast(array_ops.expand_dims(
            self.split_seqLengths[gpu_id], [-1]), dtype=tf.float32), [1, self.state_list[gpu_id][0].shape[-1].value*2])
        self.output_list[gpu_id] = tf.reduce_sum(
            tf.concat(self.state_list[gpu_id], -1), axis=1) / seqlen_exp_dim


class MaskedTransformerLMModel(TransformerLMModel):
    """
    自研的Dynamic Span Masked LM
    """

    def __init__(self, config, gragh, word_dict=None):
        super(MaskedTransformerLMModel, self).__init__(
            config, gragh, word_dict)
        # mask关闭，双向mask操作
        self.mask = False
        # 默认归一化长度参数, 区间[self.default_low_sent_scale_length, self.default_high_sent_scale_length)
        self.default_low_sent_scale_length = config.low_sent_scale_length
        self.default_high_sent_scale_length = config.high_sent_scale_length+1
        self.mask_bound = True
        # 使用span bert中的玩法，从几何分布中获取长度（这部分操作在外进行，feed至placeholder）
        self.use_geometric_distribution = False

    @replace_default_graph
    def _set_masked_placeholder(self):
        self.masked_flag = get_from_collection_or_create(
            tf.compat.v1.GraphKeys.MASKED_FLAG,
            lambda: tf.compat.v1.placeholder_with_default(
                tf.constant(False), tf.TensorShape(None), name='masked_flag')
        )
        self._add_to_graph_inputs([self.masked_flag])

    @replace_default_graph
    def _set_masked_lm_parameter(self):
        # MASK标志位
        self.mark_label = self.nb_words
        self.nb_words = self.nb_words + 1
        # 80%换成MASK
        self.prob1 = tf.compat.v1.placeholder_with_default(
            0.8*tf.cast(self.training, tf.float32)*tf.cast(self.masked_flag, tf.float32), tf.TensorShape(None), name='prob1')
        # 余下10%换成随机
        self.prob2 = tf.compat.v1.placeholder_with_default(
            0.9*tf.cast(self.training, tf.float32)*tf.cast(self.masked_flag, tf.float32), tf.TensorShape(None), name='prob2')
        # 基于上下界的均匀采样，可以改成
        self.threshold = tf.compat.v1.placeholder_with_default(tf.random.uniform(
            [self.dynamic_batch_size*self.gpu_num], self.default_low_sent_scale_length, self.default_high_sent_scale_length, tf.int64), [None], name='threshold')
        self._add_to_graph_inputs([self.threshold])

    def build_input(self, expand_input=False):
        super(MaskedTransformerLMModel, self).build_input(expand_input)
        self._set_masked_placeholder()
        # mask标志位
        self._set_masked_lm_parameter()
        split_threshold = tf.split(self.threshold, self.gpu_num, 0)
        with tf.name_scope('masked_lm_array'):
            self.indices_list = [[] for i in range(0, self.gpu_num)]
            self.origin_bow_list = [[] for i in range(0, self.gpu_num)]
            self.split_targets = [[] for i in range(0, self.gpu_num)]
            self.state_list = [[] for i in range(0, self.gpu_num)]
            self.logits = [[] for i in range(0, self.gpu_num)]
        for i in range(self.gpu_num):
            masked_input_bow, indices, origin_bow, _ = generate_span_masked_bow(
                self.split_inputX[i], self.split_seqLengths[i], self.maxlen, self.nb_words,
                expand_input=(self.mask_bound & self.expand_input), prob1=self.prob1,
                prob2=self.prob2, threshold=split_threshold[i], 
                mask_length=split_threshold[i] if self.use_geometric_distribution else None)
            self.split_inputX[i] = masked_input_bow
            self.indices_list[i] = indices
            self.origin_bow_list[i] = origin_bow
            self.split_targets[i] = tf.sparse.to_dense(tf.SparseTensor(
                indices, origin_bow, tf.shape(masked_input_bow, out_type=tf.int64)))

    def build_input_sequence(self, gpu_id=0):
        super(MaskedTransformerLMModel, self).build_input_sequence(gpu_id)
        seqlen_exp_dim = array_ops.tile(tf.cast(array_ops.expand_dims(
            self.split_seqLengths[gpu_id], [-1]), dtype=tf.float32), [1, self.state_list[gpu_id][0].shape[-1].value])
        self.output_list[gpu_id] = tf.reduce_sum(
            self.state_list[gpu_id], axis=1) / seqlen_exp_dim

    def build_sequence_prediction(self, task=None, gpu_id=0, nb_class=None, accK=5):
        nb_class = self.nb_words if nb_class is None else nb_class
        task = self.default_task_name if task is None else task
        with get_new_variable_scope('prediction') as pred_scope:
            self.compute_metrics(tf.gather_nd(self.state_list[gpu_id], self.indices_list[gpu_id]),
                                 self.origin_bow_list[gpu_id],
                                 task=task, nb_class=nb_class, accK=accK)
            self.tower_prediction_results.append(self.indices_list[gpu_id])