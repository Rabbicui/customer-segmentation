import json
import threading

import tensorflow as tf
from tensorflow.contrib.distribute import CollectiveAllReduceStrategy
from tensorflow.python.distribute.cross_device_ops import CollectiveCommunication
from tensorflow.python.distribute.cross_device_utils import CollectiveKeys

from rcalgo.tf.training.single_worker_graph_copy_trainer import SingleWorkerGraphCopyTrainer
from rcalgo.tf.training.data.data_utils import split_data
from rcalgo.tf.training.trainer import Trainer


class TaskType(object):
    MASTER = 'master'
    PS = 'ps'
    WORKER = 'worker'
    CHIEF = 'chief'
    EVALUATOR = 'evaluator'


def _build_distribution_strategy(cluster_spec, task_type, task_id, num_gpu_per_worker):
    sess_config = tf.compat.v1.ConfigProto(allow_soft_placement=True)
    sess_config.gpu_options.allow_growth = True
    sess_config.allow_soft_placement = True
    sess_config.log_device_placement = False
    strategy = CollectiveAllReduceStrategy(num_gpus_per_worker=num_gpu_per_worker,
                                           communication=CollectiveCommunication.NCCL)
    strategy.configure(session_config=sess_config, cluster_spec=cluster_spec, task_type=task_type,
                       task_id=task_id)
    target = 'grpc://' + cluster_spec[task_type][task_id]
    if tf.__version__ == "1.14.0":
        collective_keys = CollectiveKeys(
            group_key_start=100010,
            instance_key_start=100100,
            instance_key_with_id_start=1010000)
    else:
        collective_keys = CollectiveKeys(
            group_key_start=100010,
            op_instance_key_start=100100,
            variable_instance_key_start=1010000)
    strategy.extended._collective_keys = collective_keys
    strategy.extended._cross_device_ops._collective_keys = collective_keys
    return strategy, target, sess_config


class MultiWorkerGraphCopyTrainer(Trainer):
    """ multi worker graph copy trainer.
    Requirements:
        1. tf 1.15
        2. CUDA 10+
    """

    def __init__(self, graph=None,
                 cluster_spec_json=None,
                 lr_annealing=False,
                 lr_annealing_stop_value=None,
                 default_task_name="default",
                 save_trace=False,
                 trace_json_path="./timeline.json",
                 log_train_graph=False,
                 train_graph_log_path="./train_log",
                 *args, **kwargs):
        super(MultiWorkerGraphCopyTrainer, self).__init__(default_task_name=default_task_name, *args, **kwargs)
        if graph is None:
            self.org_graph = tf.compat.v1.get_default_graph()
        else:
            self.org_graph = graph
        self.lr_annealing = lr_annealing
        self.lr_annealing_stop_value = lr_annealing_stop_value
        self.save_trace = save_trace
        self.trace_json_path = trace_json_path
        self.log_train_graph = log_train_graph
        self.train_graph_log_path = train_graph_log_path

        with open(cluster_spec_json) as cluster_spec_file:
            self.cluster_spec = json.load(cluster_spec_file)
            self.num_gpu_per_worker = self.cluster_spec['num_gpu_per_worker']
            self.cluster_spec.pop('num_gpu_per_worker', None)
        self.trainer_dict = dict()
        threads = []
        for task_type in [TaskType.CHIEF, TaskType.WORKER]:
            for task_id in range(len(self.cluster_spec.get(task_type, []))):
                strategy, session_target, session_config = _build_distribution_strategy(self.cluster_spec,
                                                                                        task_type,
                                                                                        task_id,
                                                                                        self.num_gpu_per_worker)
                t = threading.Thread(target=self._init_single_worker_trainer,
                                     args=(self.org_graph, task_id, task_type, strategy, session_target, session_config),
                                     name='{}_{}'.format(task_type, task_id))
                t.start()
                threads.append(t)

        for t in threads:
            t.join()

        self.chief_trainer = self.trainer_dict['chief_0']
        self._initialized = False

    def initialize(self, hooks=[]):
        threads = []
        for worker_key in self.trainer_dict:
            t = threading.Thread(target=self.trainer_dict[worker_key].initialize,
                                 args=[hooks],
                                 name=worker_key)
            t.start()
            threads.append(t)

        for t in threads:
            t.join()
        self._initialized = True

    def train(self, data, task_names=None, epochs=10, hooks=[], test_size=0.1, batch_size=256, reinitialize=False):
        if isinstance(data, tf.data.Dataset):
            if test_size > 0:
                raise ValueError("`test_size is not supported when input_list"
                                 "is a tf.data.Dataset")
            else:
                train_data = data
                test_data = None
        elif test_size == 0:
            train_data = data
            test_data = None
        else:
            train_data, test_data = split_data(data, test_size=test_size, sync=False)
        self.train_and_evaluate(train_data, test_data, task_names, epochs, hooks, batch_size, reinitialize)

    def train_and_evaluate(self, train_data, test_data, task_names=None, epochs=10, hooks=[], batch_size=256, reinitialize=False):
        threads = []
        if not self._initialized or reinitialize:
            self.initialize()
        for key in self.trainer_dict:
            t = threading.Thread(target=self.trainer_dict[key].train_and_evaluate,
                                 args=(train_data, test_data, task_names, epochs, hooks, batch_size),
                                 name=key)
            t.start()
            threads.append(t)
        for t in threads:
            t.join()

    def evaluate(self, data, task_names, hooks=[]):
        pass

    def predict(self, data, task_name, output_indexes=None, hooks=[]):
        pass

    def _init_single_worker_trainer(self, org_graph, task_id, task_type, strategy, session_target, session_config):
        if self.save_trace is True:
            last_dot_idx = self.trace_json_path.rindex(".")
            trace_json_path = '{}_{}_{}.json'.format(self.trace_json_path[:last_dot_idx], task_type, task_id)
        else:
            trace_json_path = self.trace_json_path
        if self.log_train_graph is True:
            train_graph_log_path = '{}_{}_{}'.format(self.train_graph_log_path, task_type, task_id)
        else:
            train_graph_log_path = self.train_graph_log_path
        self.trainer_dict['{}_{}'.format(task_type, task_id)] = SingleWorkerGraphCopyTrainer(
            default_task_name=self.default_task_name,
            graph=org_graph,
            multi_worker_training=True,
            distribute_strategy=strategy,
            session_target=session_target,
            session_config=session_config,
            save_trace=self.save_trace,
            trace_json_path=trace_json_path,
            log_train_graph=self.log_train_graph,
            train_graph_log_path=train_graph_log_path,
            lr_annealing=self.lr_annealing,
            lr_annealing_stop_value=self.lr_annealing_stop_value)
