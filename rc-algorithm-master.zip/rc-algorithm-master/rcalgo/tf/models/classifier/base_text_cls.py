import tensorflow as tf

from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.module.layer.preprocessing import TFCharSequencePreprocessor
from rcalgo.tf.module.layer.basic import my_full_connected
from rcalgo.tf.training.model import Model
from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.metric.loss import l2_loss


class TextClassifierBase(Model):
    """Base class for text classifier

    Args:
        hparams (dict, optional): Hyper parameters of the module. See
        word_dict: word dict
    """

    def __init__(self, hparams, word_dict, name=None, distribute="horovod", **kwargs):
        super(TextClassifierBase, self).__init__(config=hparams, name=name,
                                                 distribute=distribute, **kwargs)
        self.oov_buckets = hparams.get("oov_buckets", 10)
        self.max_seq_len = hparams.get("max_seq_len", 128)
        self.embedding_size = hparams.get("embedding_size", 256)
        self.init_scale = hparams.get("init_scale", 1.0)
        self.num_classes = hparams.get("num_classes", 2)
        self.mark_boundary = hparams.get("mark_boundary", False)
        self.model_reuse = hparams.get("model_reuse", False)
        self.p_coef = hparams.get('p_coef', 0.)
        self.is_training = get_or_create_is_training()

        with self.name_scope:
            self.preprocessor = TFCharSequencePreprocessor(
                word_dict, self.oov_buckets, self.mark_boundary)
            self.nb_words = self.preprocessor.nb_words

    def _penalty(self):
        p_loss = self.p_coef * l2_loss()
        return p_loss

    def compute_loss(self, logits, labels):
        loss = super(TextClassifierBase, self).compute_loss(logits, labels)
        return loss + self._penalty()

    def create_inputs(self):
        text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
        label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return text, label

    def add_extra_attrs(self, hiddens):
        self.add_extra_attr("logits", hiddens)

    def call(self, text, **kwargs):
        embedding, seq_lengths = self.build_embedding(text)
        hidden = self.build_representation(embedding, seq_lengths)

        logits = my_full_connected(hidden, self.num_classes, reuse=self.model_reuse)
        prediction = tf.nn.softmax(logits)
        return logits, prediction

    def build_embedding(self, text):
        sequence, seq_lengths = self.preprocessor(text, max_length=self.max_seq_len)
        embedding = my_embedding_layer(
            sequence, self.nb_words, self.embedding_size,
            variables_collections="encoder_embedding",
            layer_name="embedding_layer",
            init_scale=self.init_scale,
            dtype=tf.float32,
            reuse=self.model_reuse)
        return embedding, seq_lengths

    def build_representation(self, embedding, seq_lengths, **kwargs):
        """
        text representation
        Args:
            embedding:
            seq_lengths:
            **kwargs:

        Returns:
            hidden representation for text
        """
        raise NotImplementedError
