"""数据预处理，由标注数据 ==> 模型需要的格式."""
import os
import json
import shutil
import random
from PIL import Image
import xml.etree.ElementTree as ET


def parse_labelimg_format(img_dir, anno_dir, save_file, classid_map):
    """
    解析labelimg工具标注产生的文件
    图片数据1.jpg，2.jpg，3.jpg...；对应产生标注数据文件1.xml,2.xml,3.xml....
    :param img_dir: 原始图片的文件夹
    :param anno_dir: 存放标注数据的路径
    :param save_file: 解析后存放的文件
    :param classid_map: 类目字典，class name ==> class id的映射
    :return:
    """
    # classid_map = {"Kfc": 0, "Mengniu":1, "Yili":2, "Jingdong":3}  # 示例类目

    with open(save_file, "w") as f:
        for img_name in os.listdir(img_dir):
            image_id = img_name.split('.')[0]
            xml_path = '%s/%s.xml' % (anno_dir, image_id)
            if not os.path.exists(xml_path):
                continue

            one_img_info = [img_name]
            in_file = open(xml_path)

            tree = ET.parse(in_file)
            root = tree.getroot()

            for obj in root.iter('object'):
                cls = obj.find('name').text
                if cls not in classid_map:
                    print("class name %s not in classid map" % cls)
                    continue

                cls_id = classid_map[cls]
                xmlbox = obj.find('bndbox')
                bb = (xmlbox.find('xmin').text, xmlbox.find('ymin').text,
                      xmlbox.find('xmax').text, xmlbox.find('ymax').text,
                      cls_id)
                bb_info = ",".join([str(a) for a in bb])
                one_img_info.append(bb_info)

            f.write(" ".join(one_img_info) + '\n')
            f.flush()

    return


def parse_mmuplat_format(anno_file, save_file, classid_map):
    """
    解析MMU标注平台标注产生的文件，每行是一个json串，对应一个图片数据标注结果
    :param anno_file: mmu标注平台导出的数据
    :param save_file: 解析完的数据存文件
    :param classid_map: 类目字典，class name ==> class id的映射
    :return:
    """
    # classid_map = {"Kfc": 0, "Mengniu":1, "Yili":2, "Jingdong":3}  # 示例类目

    with open(save_file, "w") as f:
        for line in open(anno_file, 'r').readlines():
            one_anno = line.strip()
            one_anno_dict = json.loads(one_anno)

            photo_path = one_anno_dict['photoId']
            base_name = os.path.basename(photo_path.rsplit("_", 1)[0])
            one_img_info = [base_name]

            bbox_infos = one_anno_dict['positionList']
            for bbox_info in bbox_infos:
                if bbox_info['extraContent'] in ["无法标注", "可以标注"]:
                    continue

                label_name = json.loads(bbox_info['extraContent'])['value']
                if label_name not in classid_map:
                    print("class name %s not in classid map" % label_name)
                    continue

                cls_id = classid_map[label_name]

                left_top = bbox_info['positionTuple'][0]
                right_bottom = bbox_info['positionTuple'][2]
                xmin, ymin = map(float, left_top.split(':')[:2])
                xmax, ymax = map(float, right_bottom.split(':')[:2])
                bbox_show = int(xmin), int(ymin), int(xmax), int(ymax), cls_id
                bb_info = ",".join(list(map(str, bbox_show)))
                one_img_info.append(bb_info)

            if len(one_img_info) < 2:
                continue

            f.write(" ".join(one_img_info) + '\n')
            f.flush()

    return


def convert_to_relative_values(size, box):
    """
    坐标转化，xmin, ymin, xmax, ymax ==>  x, y, w, h
    :param size: (width, height) of the image
    :param box: (xmin, ymin, xmax, ymax) of the bounding box
    :return:
    """
    dw = 1. / (size[0])
    dh = 1. / (size[1])
    cx = (box[2] + box[0]) / 2.0
    cy = (box[3] + box[1]) / 2.0

    w = box[2] - box[0]
    h = box[3] - box[1]

    x = round(cx * dw, 3)
    y = round(cy * dh, 3)
    w = round(w * dw, 3)
    h = round(h * dh, 3)

    return (x, y, w, h)


def get_image_info(img_path):
    """
    获取原始图像信息
    :param img_path: 图片路径
    :return: 图像的宽，高，格式
    """
    img_m = Image.open(img_path)
    w = img_m.width  # 图片的宽
    h = img_m.height  # 图片的高
    f = img_m.format  # 图像格式

    return w, h, f


def process_to_yolov5_format(
        file_path,
        save_dir_image,
        save_dir_label,
        img_dir):
    """
    将解析后的labelimg或者是mmu标注平台的数据，转化成yolov5模型的训练格式
    :param file_path: 解析后的labelimg或者是mmu标注平台的数据,eg: './logo_test_raw/logo_test_train.txt'
    :param save_dir_image: 存放训练或验证集image的路径, eg: './logo_test_raw/images/train/'
    :param save_dir_label: 存放训练或验证集label的路径, eg: './logo_test_raw/labels/train/'
    :param img_dir: 存放标注的图片的路径
    :return:
    """
    for line in open(file_path, 'r'):
        arrs = line.strip().split(' ')

        img_name = arrs[0]
        img_name_no_suffix = os.path.splitext(img_name)[0]

        img_path = os.path.join(img_dir, img_name)
        shutil.copy(img_path, save_dir_image)
        w_img, h_img, f_img = get_image_info(img_path)
        size_raw = w_img, h_img

        with open(os.path.join(save_dir_label, img_name_no_suffix + '.txt'), "w") as f:
            bbox_infos = arrs[1:]
            for bbox_info in bbox_infos:
                xmin, ymin, xmax, ymax, clf_id = list(
                    map(int, bbox_info.split(',')))[:5]
                bbox = xmin, ymin, xmax, ymax
                x, y, w, h = convert_to_relative_values(size_raw, bbox)
                need_info = list(map(str, [clf_id, x, y, w, h]))
                f.write(' '.join(need_info))
                f.write('\n')
                f.flush()

    return


def train_test_split(anno_file, train_file, test_file, ratio=0.1, shuffle=True):
    """
    将标注数据划分为训练集和测试集
    :param anno_file: 标注文件
    :param train_file: split的训练集
    :param test_file: split的测试集
    :param ratio: 测试集的占比
    :param shuffle: 是否打乱顺序
    :return:
    """

    anno_list = []
    with open(anno_file, "r") as f:
        for datas in f.readlines():
            datas = datas.replace('\n', '')
            anno_list.append(datas)

    traindatas, testdatas = split(anno_list, shuffle=shuffle, ratio=ratio)
    with open(train_file, "w") as f:
        for traindata in traindatas:
            f.write(traindata + '\n')

    with open(test_file, "w") as f:
        for testdata in testdatas:
            f.write(testdata + '\n')


def split(all_list, shuffle=True, ratio=0.1):
    num = len(all_list)
    offset = int(num * ratio)
    if num == 0 or offset < 1:
        return all_list, []

    if shuffle:
        random.shuffle(all_list)  # 列表随机排序

    test = all_list[:offset]
    train = all_list[offset:]
    return train, test
