import pandas as pd
import os
import tensorflow as tf
from rcalgo.tf.models.language_model.rnn_lm import RNNLM, BiRNNLM
from rcalgo.tf.models.language_model.transformer_lm import TransformerLM, BiTransformerLM
from rcalgo.tf.models.language_model.quasi_rnn_lm import QuasiRNNLM, BiQuasiRNNLM

from rcalgo.tf.utils.tokenizers import CharTokenizer

def main(_):
    data_dir = "/home/web_server/antispam/project/da_datasets/female_vulgar"
    train_path = os.path.join(data_dir, 'train_1w.csv')
    test_path = os.path.join(data_dir, 'test.csv')
    train_df = pd.read_csv(train_path, header=0)
    train_texts = train_df['text']

    test_df = pd.read_csv(test_path, header=0)
    test_texts = test_df['text']

    tokenizer = CharTokenizer.build_from_corpus(train_texts, freq_threshold=1)
    word_dict = tokenizer.word2idx
    
    config = {
        "num_layers": 2,
        "hidden_size": 256,
        "model_name": 'lm',
        "acc_k": 5
    }
    model = BiRNNLM(config, word_dict)
    model.build_model()
    print(model.model_summary())

    # train
    model.train([train_texts],
               batch_size=128,
               test_size=0.1,
               epochs=5,
               hooks=[])
    # predict
    model.restore_weights('saved_models/best_model/lm-epoch4.ckpt')
    pred_res = model.predict([test_texts[:8]])
    print(pred_res[0].shape)


if __name__=='__main__':
    tf.app.run()

