
import numpy as np
def get_resolution(original_resolution):
    """Takes (H,W) and returns (precrop, crop)."""
    area = original_resolution[0] * original_resolution[1]
    return (160, 128) if area < 96 * 96 else (512, 480)


known_dataset_sizes = {
    'cifar10': (32, 32),
    'cifar100': (32, 32),
    'oxford_iiit_pet': (224, 224),
    'oxford_flowers102': (224, 224),
    'imagenet2012': (224, 224),
}


def get_resolution_from_dataset(dataset):
    if dataset not in known_dataset_sizes:
        raise ValueError(f"Unsupported dataset {dataset}. Add your own here :)")
    return get_resolution(known_dataset_sizes[dataset])


def get_mixup(dataset_size):
    return 0.0 if dataset_size < 20_000 else 0.1


def get_schedule(dataset_size, batch_size):
    scale = 512 // batch_size
    if dataset_size < 20_000:
        return list(np.array([100, 200, 300, 400, 500]) * scale)
    elif dataset_size < 500_000:
        return list(np.array([500, 3000, 6000, 9000, 10_000]) * scale)
    elif dataset_size < 1_000_000:
        return list(np.array([2000, 9000, 18_000, 27_000, 30_000]) * scale)
    elif dataset_size < 5_000_000:
        return list(np.array([10_000, 45_000, 90_000, 135_000, 160_000]) * scale)
    elif dataset_size < 10_000_000:
        return list(np.array([30_000, 80_000, 140_000, 160_000, 200_000]) * scale)
    else:
        return list(np.array([50_000, 100_000, 160_000, 200_000, 240_000]) * scale)

def get_lr(step, dataset_size, base_lr=0.003, batch_size=512):
    """Returns learning-rate for `step` or None at the end."""
    supports = get_schedule(dataset_size, batch_size)
    # Linear warmup
    if step < supports[0]:
        return base_lr * step / supports[0]
    # End of training
    elif step >= supports[-1]:
        return None
    # Staircase decays by factor of 10
    else:
        for s in supports[1:]:
            if s < step:
                base_lr /= 10
        return base_lr
