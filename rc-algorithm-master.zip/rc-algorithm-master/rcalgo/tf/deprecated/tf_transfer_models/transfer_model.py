import tensorflow as tf

from tftools.tf_func import replace_default_graph
from tftools.tf_func import my_compute_grad
from tftools.tf_func import shape_list
from tftools.tf_layer import my_dropout
from tftools.tf_layer import my_full_connected
from rcalgo.tf.tftraining.incremental_training import IncrementalTraining
from rcalgo.tf.tftraining.tf_object import TFModel

class TransferTFModel(TFModel):
    def __init__(self, config, graph):
        self.graph = graph
        self.original_ckpt_path = config.original_ckpt_path
        self.original_task_name = config.original_task_name
        self.original_output_index = config.original_output_index
        self.last_fc_dim = config.last_fc_dim

        self._load_meta_graph(clear_devices=config.clear_devices)
        super(TransferTFModel, self).__init__(config, graph)
        self._detect_original_outputs()
        assert config.clear_devices or self.gpu_num == self.original_tower_num
        if config.task_name == 'default':
            print('WARN: task name default may conflict with original checkpoint tasks')


    @replace_default_graph
    def _load_meta_graph(self, clear_devices):
        self.restore_saver = tf.compat.v1.train.import_meta_graph("{}.meta".format(self.original_ckpt_path), clear_devices=clear_devices)


    @replace_default_graph
    def _detect_original_outputs(self):
        print("{}_outputs".format(self.original_task_name))
        print(tf.compat.v1.get_collection("{}_outputs".format(self.original_task_name)))
        self.concated_original_output = tf.compat.v1.get_collection("{}_outputs".format(self.original_task_name))[self.original_output_index]
        self.original_outputs = [t for t in self.concated_original_output.op.inputs._inputs if t.name.startswith("Tower_")]
        self.original_tower_num = len(self.original_outputs)


    @replace_default_graph
    def _on_model_built(self):
        gpu_config = tf.compat.v1.ConfigProto(allow_soft_placement=True)
        gpu_config.gpu_options.allow_growth = True
        self.session = tf.compat.v1.Session(config=gpu_config, graph=self.graph)
        init_ops = [tf.compat.v1.global_variables_initializer(), tf.compat.v1.local_variables_initializer(),
                    tf.compat.v1.tables_initializer()]
        self.session.run(init_ops)

        self.restore_saver.restore(self.session, self.original_ckpt_path)


    @replace_default_graph
    def _init_training_job(self):
        self._on_model_built()
        # Reload from ckpt
        self.job = IncrementalTraining(model_input_dir=self.model_dir,
                                       model_name=self.model_name,
                                       model_output_dir=self.model_dir,
                                       session=self.session,
                                       lr_annealing=self.lr_annealing,
                                       lr_annealing_value=self.lr_annealing_value,
                                       lr_annealing_stop_value=self.lr_stop_value,
                                       logs_dir=self.logs_dir, save_checkpoint=self.epoch_save)


    def build_prediction(self, gpu_id=0, num_classes=2, accK=1):
        prediction = my_full_connected(
            self.pool_flat_drop_list[gpu_id], num_classes)
        self.tower_prediction_results.append(tf.nn.softmax(prediction))
        if self.fix_lm_layer:
            self.params = [v for v in tf.compat.v1.trainable_variables() if v not in self.original_trainable_variables]
        else:
            self.params = tf.compat.v1.trainable_variables()
        with tf.name_scope('loss'):
            # labels == 1: 输入为1维ID，表示onehot向量
            # labels > 1: 输入为labels维, 对应多标签分类
            if self.labels == 1 and self.label_smooth == 0.0:
                loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
                    labels=self.split_inputLabel[gpu_id], logits=prediction)
            else:
                y_true = self.split_inputLabel[gpu_id]
                if self.labels == 1:
                    y_true = tf.one_hot(y_true, depth=num_classes)
                if self.label_smooth > 0.0:
                    y_true = label_smoothing(y_true, self.label_smooth)
                loss = tf.nn.softmax_cross_entropy_with_logits_v2(
                    labels=y_true, logits=prediction)
            loss = tf.reduce_mean(loss) + self._penalty()
            grads, capped_gvs = my_compute_grad(self.opt, loss, self.params,
                                                clip_type='clip_value', task=self.default_task_name,
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            labels = self.split_inputLabel[gpu_id] if self.labels == 1 else tf.argmax(
                self.split_inputLabel[gpu_id], axis=1)
            accuracy = tf.to_float(tf.nn.in_top_k(prediction, labels, k=accK))
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy)