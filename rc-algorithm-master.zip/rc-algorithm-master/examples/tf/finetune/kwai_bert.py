"""
Finetune Model Demo

运行脚本的命令:
单卡:
    PYTHONPATH=.. python horovod_finetune_demo.py
单机8卡:
    PYTHONPATH=.. horovodrun -np 8 python horovod_finetune_demo.py
多机多卡:
    PYTHONPATH=.. horovodrun -np 16 -H server1:8,server2:8 python horovod_finetune_demo.py
"""

import pandas as pd
import tensorflow as tf

from rcalgo.tf.models.finetune.kwai_bert import KwaiBertClassificationModel, SpanBertClassificationModel


config = {
    "fix_lm_layer": False
}


def main(_):
    # 1. load train data
    input_file = "/home/web_server/antispam/project/datasets/female_vulgar/train.csv"
    train_data = pd.read_csv(input_file)

    # 2. define model
    model = KwaiBertClassificationModel(
        config=config, name="finetune").build_model()
    print(model.model_summary())

    model.train([train_data['text'], train_data['label']],
                batch_size=128, epochs=5, test_size=0.1,
                checkpoint_dir="./saved_models",
                checkpoint_name="kwai_bert")


if __name__ == '__main__':
    tf.app.run()
