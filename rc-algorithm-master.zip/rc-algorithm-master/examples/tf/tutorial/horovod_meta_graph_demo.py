"""
Create model from meta graph demo

运行脚本的命令:
单卡:
    PYTHONPATH=../.. python horovod_meta_graph_demo.py
单机8卡:
    PYTHONPATH=../.. horovodrun -np 8 python horovod_meta_graph_demo.py
多机多卡:
    PYTHONPATH=../.. horovodrun -np 16 -H server1:8,server2:8 python horovod_meta_graph_demo.py
"""

import pandas as pd
import tensorflow as tf

from rcalgo.tf.training import Model


def main(_):
    # 1. load data
    data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
    train_data = pd.read_csv(data_dir + 'train.csv')
    test_data = pd.read_csv(data_dir + 'test.csv')

    # 2. create graph
    # model = Model.from_meta_graph('saved_models/default_model-epoch0.ckpt.meta',
    #                                    name="finetune")
    # model.restore_weights("saved_models/default_model-epoch0.ckpt")
    # model = Model.from_checkpoint('saved_models/transformer-epoch0.ckpt', name="transformer")
    model = Model.from_checkpoint('saved_models/kwai_bert-epoch0.ckpt',
                                  name="finetune")
    model.model_summary()
    model.evaluate([test_data['text'], test_data['label']])
    print(model.predict([test_data['text']]))

    # 3. train
    model.set_optimizer(tf.compat.v1.train.AdamOptimizer(0.0001, name="new_opt"))
    model.train([train_data['text'], train_data['label']],
                batch_size=64,
                epochs=1,
                test_size=0.1,
                hooks=[])

    model.dump_checkpoint("./saved_models/manually_saved_checkpoint.ckpt")
    model.dump_model("./saved_models", "1")
    model.export_freeze_graph("./saved_models", "2")


if __name__ == '__main__':
    tf.app.run()
