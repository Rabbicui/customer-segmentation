import tensorflow as tf

from rcalgo.tf.training import context
from rcalgo.tf.module.layer.preprocessing import TFCharSequencePreprocessor


class TFDatasetTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_char_sequence(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, False)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs)

        texts = ["测试a", "c测试abc"]
        expected_results = [[1, 2, 3, 0, 0, 0], [5, 1, 2, 3, 4, 5]]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)

    def test_char_sequence_with_padding(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, False)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs, max_length=7)

        texts = ["测试a", "c测试abc"]
        expected_results = [[1, 2, 3, 0, 0, 0, 0], [5, 1, 2, 3, 4, 5, 0]]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)

    def test_char_sequence_with_boundary(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, True)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs, max_length=10)

        texts = ["测试a", "d测试abc"]
        expected_results = [
            [5, 1, 2, 3, 6, 0, 0, 0, 0, 0],
            [5, 7, 1, 2, 3, 4, 7, 6, 0, 0]
        ]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)

    def test_char_sequence_with_boundary_and_cutting(self):
        word_dict = {"测": 1, "试": 2, "a": 3, "b": 4}
        preprocessor = TFCharSequencePreprocessor(word_dict, 1, True)

        inputs = tf.placeholder(tf.string, [None], name="inputs")
        outputs, _ = preprocessor(inputs, max_length=4)

        texts = ["测试a", "d测试abc"]
        expected_results = [
            [5, 1, 2, 6],
            [5, 7, 1, 6]
        ]
        sess = context.get_session()
        actual_results = sess.run(outputs, feed_dict={inputs: texts})
        self.assertAllEqual(actual_results, expected_results)


if __name__ == "__main__":
    tf.test.main()
