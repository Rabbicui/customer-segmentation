import tensorflow as tf

from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.training.training_utils import get_or_create_is_training, create_task_in_graph
from rcalgo.tf.module.layer.basic import my_full_connected
from rcalgo.tf.models.classifier.text_classifier import TextCNN, TextClassifierBase
from rcalgo.tf.module.encoder.cnn import text_cnn_encoder
from rcalgo.tf.models.semi_supervised.base_semi_supervised import SemiSupervisor
from rcalgo.tf.models.semi_supervised.semi_utils import kl_for_logits, kl_for_log_probs, \
    compute_tsa_threshold, get_normalized_vector, linear_rampup, step_rampup, sigmoid_rampup
from rcalgo.tf.utils.tf_func import label_smoothing


class AdversarialTraining(SemiSupervisor):
    """
    VAT(Virtual Adversarial Training) + AT(Adversarial Training)
    https://arxiv.org/pdf/1605.07725.pdf
    https://arxiv.org/pdf/1704.03976.pdf
    """

    def __init__(self, execute_model, config, name="uda", **kwargs):
        # linear_schedule, exp_schedule, log_schedule, None
        self.batch_size = config.get("batch_size", 32)
        self.sup_batch_size = self.batch_size
        self.unsup_ratio = config.get("unsup_ratio", 1)
        self.unsup_batch_size = self.batch_size * self.unsup_ratio
        self.num_train_steps = config.get("num_train_steps", 0)
        self.num_classes = config.get("num_classes", 2)
        self.xi = config.get("xi", 1e-1)  # small constant for finite difference
        self.epsilon = config.get("epsilon", 5)  # norm length for (virtual) adversarial training
        self.rampup_method = config.get("rampup_method", None)  # None, linear, step, sigmoid
        self.rampup_steps = config.get("rampup_steps", self.num_train_steps // 2)
        self.use_adv_train = config.get("use_adv_train", True)
        self.tsa_schedule = config.get("tsa_schedule", None)
        self.uda_softmax_temp = config.get("uda_softmax_temp", -1)
        self.uda_confidence_thresh = config.get("uda_confidence_thresh", -1)
        self.label_smooth = config.get("label_smooth", 0.0)
        self.global_step = tf.train.get_or_create_global_step()
        self.tsa_threshold = None
        if self.rampup_method is not None:
            if self.rampup_method == "linear":
                self.epsilon *= linear_rampup(self.global_step, self.rampup_steps)
            elif self.rampup_method == "step":
                self.epsilon *= step_rampup(self.global_step, self.rampup_steps)
            elif self.rampup_method == "sigmoid":
                self.epsilon *= sigmoid_rampup(self.global_step, self.rampup_steps)

        super().__init__(execute_model, config=config, name=name, **kwargs)

    def create_inputs(self):
        text = tf.placeholder(dtype=tf.string, shape=[None], name='input_text')
        unsup = tf.placeholder(dtype=tf.string, shape=[None, None], name='unsup')
        labels = tf.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return [text, unsup], labels

    def export_freeze_graph(self, *args, **kwargs):
        input_nodes = [self.input_concat]
        return self.trainer.export_freeze_graph(*args, input_nodes=input_nodes, **kwargs)

    def build_forward(self, **kwargs):
        inputs, labels = self.create_inputs()
        text, unsup = inputs
        unsup = tf.reshape(unsup, [self.unsup_batch_size])
        self.input_concat = tf.concat([text, unsup], axis=0)

        with tf.variable_scope('AdvTrain', reuse=tf.AUTO_REUSE):
            states, outputs = self.execute_model.call(self.input_concat, add_adv_pert=False, **kwargs)
            sup_pert_states, _ = self.execute_model.call(text, add_adv_pert=True,
                                                         epsilon=self.epsilon, label=labels, **kwargs)
            unsup_pert_states, _ = self.execute_model.call(unsup, add_vadv_pert=True,
                                                           xi=self.xi, epsilon=self.epsilon, **kwargs)

        loss = self.compute_loss([states, sup_pert_states, unsup_pert_states], labels)
        metrics = self.compute_metrics(outputs[:self.batch_size],
                                       labels[:self.batch_size])

        self.inputs = inputs
        self.outputs = [outputs]
        self.labels = [labels]
        self.loss = loss
        self.metrics = metrics
        create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)
        return self

    def calc_sup_ce(self, tgt_label_prob, sup_log_probs):
        per_example_loss = -tf.reduce_sum(tgt_label_prob * sup_log_probs, axis=-1)

        if self.tsa_schedule:
            loss_mask = tf.ones_like(per_example_loss, dtype=per_example_loss.dtype)
            correct_label_probs = tf.reduce_sum(
                tgt_label_prob * tf.exp(sup_log_probs), axis=-1)
            print(f"use tsa schedule: {self.tsa_schedule}")
            tsa_start = 1. / self.num_classes
            if self.tsa_threshold is None:
                tsa_threshold = compute_tsa_threshold(
                    self.tsa_schedule, self.global_step, self.num_train_steps,
                    tsa_start, end=1)
                self.tsa_threshold = tf.math.minimum(1.0, tsa_threshold)
            larger_than_threshold = tf.greater(
                correct_label_probs, self.tsa_threshold)
            loss_mask = loss_mask * (1 - tf.cast(larger_than_threshold, tf.float32))

            loss_mask = tf.stop_gradient(loss_mask)
            per_example_loss = per_example_loss * loss_mask
            sup_loss = (tf.reduce_sum(per_example_loss) /
                        tf.maximum(tf.reduce_sum(loss_mask), 1))
        else:
            sup_loss = tf.reduce_mean(per_example_loss)
        return sup_loss

    def sup_loss_core(self, sup_state, sup_pert_state, labels):
        with tf.variable_scope("sup_loss"):
            one_hot_labels = tf.one_hot(labels, depth=self.num_classes, dtype=tf.float32)
            if self.label_smooth > 0.0:
                one_hot_labels = label_smoothing(one_hot_labels, self.label_smooth)
            if self.use_adv_train:
                sup_pert_log_probs = tf.nn.log_softmax(sup_pert_state)
                sup_pert_loss = self.calc_sup_ce(one_hot_labels, sup_pert_log_probs)
                sup_loss = sup_pert_loss
            else:
                sup_log_probs = tf.nn.log_softmax(sup_state)
                sup_loss = self.calc_sup_ce(one_hot_labels, sup_log_probs)
        return sup_loss

    def compute_sup_loss(self, states, labels):
        sup_pert_state = states[1][:self.sup_batch_size]
        sup_state = states[0][:self.sup_batch_size]

        sup_loss = self.sup_loss_core(sup_state, sup_pert_state, labels)

        return sup_loss

    def unsup_loss_core(self, unsup_state, unsup_pert_state):
        with tf.variable_scope("unsup_loss"):
            unsup_log_probs = tf.nn.log_softmax(unsup_state)
            unsup_pert_log_probs = tf.nn.log_softmax(unsup_pert_state)
            unsup_loss_mask = 1
            if self.uda_softmax_temp != -1:
                tgt_ori_log_probs = tf.nn.log_softmax(
                    unsup_state / self.uda_softmax_temp,
                    axis=-1)
                tgt_ori_log_probs = tf.stop_gradient(tgt_ori_log_probs)
            else:
                tgt_ori_log_probs = tf.stop_gradient(unsup_log_probs)

            if self.uda_confidence_thresh != -1:
                largest_prob = tf.reduce_max(tf.exp(unsup_log_probs), axis=-1)
                unsup_loss_mask = tf.cast(tf.greater(
                    largest_prob, self.uda_confidence_thresh), tf.float32)
                unsup_loss_mask = tf.stop_gradient(unsup_loss_mask)

            per_example_kl_loss = kl_for_log_probs(
                tgt_ori_log_probs, unsup_pert_log_probs) * unsup_loss_mask
            unsup_loss = tf.reduce_mean(per_example_kl_loss)
        return unsup_loss

    def compute_unsup_loss(self, states, labels):
        unsup_loss_mask = None
        unsup_state = states[0][self.sup_batch_size:]
        # unsup_pert_state = states[1][self.sup_batch_size:]
        unsup_pert_state = states[2]

        unsup_loss = self.unsup_loss_core(unsup_state, unsup_pert_state)

        # 暂时不返回unsup_loss_mask
        return unsup_loss


class AdversarialTextClassWrapper(TextClassifierBase):
    def __init__(self, execute_model, hparams, word_dict, **kwargs):
        self.execute_model = execute_model
        self.execute_model.model_reuse = tf.AUTO_REUSE
        super().__init__(hparams, word_dict, **kwargs)

    def forward(self, embedding, seq_lengths):
        hidden = self.build_representation(embedding, seq_lengths)
        logits = my_full_connected(hidden, self.num_classes, reuse=tf.AUTO_REUSE)
        return logits

    def build_representation(self, embedding, seq_lengths, **kwargs):
        hidden = self.execute_model.build_representation(embedding, seq_lengths, **kwargs)
        return hidden

    def build_embedding(self, text):
        sequence, seq_lengths = self.preprocessor(text, max_length=self.max_seq_len)
        embedding = my_embedding_layer(
            sequence, self.nb_words, self.embedding_size,
            variables_collections="encoder_embedding",
            layer_name="embedding_layer",
            init_scale=self.init_scale,
            reuse=tf.AUTO_REUSE,
            dtype=tf.float32)
        return embedding, seq_lengths

    def call(self, inputs, **kwargs):
        is_training = get_or_create_is_training()
        add_adv_pert = kwargs.get("add_adv_pert", False)
        add_vadv_pert = kwargs.get("add_vadv_pert", False)
        epsilon = kwargs.get("epsilon")
        xi = kwargs.get("xi")
        label = kwargs.get("label")
        embedding, seq_lengths = self.build_embedding(inputs)
        if add_adv_pert:
            one_hot_label = tf.one_hot(label, depth=self.num_classes, dtype=tf.float32)
            logit = self.forward(embedding, seq_lengths)
            loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_label, logits=logit))
            grad = tf.gradients(loss, [embedding], aggregation_method=tf.AggregationMethod.EXPERIMENTAL_ACCUMULATE_N)[0]
            grad = tf.stop_gradient(grad)
            adv_pert = epsilon * get_normalized_vector(grad)
            embedding += adv_pert
        elif add_vadv_pert:
            d = tf.random_normal(shape=tf.shape(embedding))
            d = xi * get_normalized_vector(d)
            logit_p = self.forward(embedding, seq_lengths)
            logit_q = self.forward(embedding + d, seq_lengths)
            loss = kl_for_logits(logit_p, logit_q)
            grad = tf.gradients(loss, [d], aggregation_method=tf.AggregationMethod.EXPERIMENTAL_ACCUMULATE_N)[0]
            grad = tf.stop_gradient(grad)
            vadv_pert = epsilon * get_normalized_vector(grad)
            embedding += vadv_pert

        logit = self.forward(embedding, seq_lengths)
        prediction = tf.nn.softmax(logit)
        return logit, prediction

