import os
import sys

sys.path.append(os.path.join(os.path.abspath(
    os.path.dirname(__file__)), "../../"))

from rcalgo.tf.training.data.data_iterator import DataIterator
import pandas as pd
import pickle as pkl
from rcalgo.tf.utils.text_utils import *
from sklearn.model_selection import train_test_split

import time
from multiprocessing import Queue
import multiprocessing
import math
import h5py
import tensorflow as tf


class TrainingData(object):
    def __init__(self, datasets, batch_size, test_size, default_random_seed=None):
        self.ignored_input_index = [idx for idx, col in enumerate(datasets) if col is None]
        datasets = [col for col in datasets if col is not None]
        self.datasets = [np.array(dataset) if isinstance(dataset, list) else dataset for dataset in
                         datasets]
        self.batch_size = batch_size
        self.test_size = test_size
        self.default_random_seed = default_random_seed
        self.index_list = np.arange(0, len(self.datasets[0]))
        self.resplit(self.default_random_seed)
        self.test_index_list = np.sort(self.test_index_list)
    
    def to_tf_dataset(self, mode="train"):
        if mode == "train":
            train_data = tuple(tf.compat.v1.placeholder(dataset.dtype if dataset.dtype is not np.dtype(np.int64) else np.dtype(np.int32),
                                              tuple(d * (1-self.test_size)
                                                    if idx2 == 0 else d
                                                    for idx2, d in enumerate(dataset.shape)),
                                              name='train_col_{}'.format(idx))
                               for idx, dataset in enumerate(self.datasets))
            return tf.data.Dataset.from_tensor_slices(train_data).shuffle(self.get_dataset_size(mode="train")).batch(self.batch_size)
        else:
            test_data = tuple(tf.compat.v1.placeholder(dataset.dtype if dataset.dtype is not np.dtype(np.int64) else np.dtype(np.int32),
                                             tuple(d * self.test_size
                                                   if idx2 == 0 else d
                                                   for idx2, d in enumerate(dataset.shape)),
                                              name='test_col_{}'.format(idx))
                               for idx, dataset in enumerate(self.datasets))
            return tf.data.Dataset.from_tensor_slices(test_data).shuffle(self.get_dataset_size(mode="test")).batch(self.batch_size)

    def get_dataset_size(self, mode="train"):
        if mode == "train":
            return int(len(self.datasets[0]) * (1 - self.test_size))
        else:
            return int(len(self.datasets[0]) * self.test_size)

    def get_batch_size(self):
        return self.batch_size

    def get_tf_dataset_feed_dict(self):
        feed_dict = dict(zip(['train_col_{}:0'.format(idx) for idx in range(len(self.datasets))],
                        [dataset[self.train_index_list] for dataset in self.datasets]))
        feed_dict.update(dict(zip(['test_col_{}:0'.format(idx) for idx in range(len(self.datasets))],
                        [dataset[self.test_index_list] for dataset in self.datasets])))
        return feed_dict

    def resplit(self, random_seed=None):
        self.train_index_list, self.test_index_list = train_test_split(
            self.index_list, test_size=self.test_size, random_state=self.default_random_seed)
        self.train_index_list = np.sort(self.train_index_list)
        self.test_index_list = np.sort(self.test_index_list)

    def create_iterator(self, mode="train", batch_size=None):
        if batch_size is None:
            batch_size = self.batch_size
        if mode == "train":
            np.random.shuffle(self.train_index_list)
            return DataIterator(datasets=self.datasets, index_list=self.train_index_list,
                                batch_size=batch_size)
        elif mode == "test":
            return DataIterator(datasets=self.datasets, index_list=self.test_index_list,
                                batch_size=batch_size)
        else:  # "all"
            return DataIterator(datasets=self.datasets, index_list=self.index_list,
                                batch_size=batch_size)

    def prepare_texts(self, texts, strip=True, maxlen=200):
        res = []
        for text in texts:
            if strip:
                text = text.strip()
            if len(text) > maxlen:
                text = text[:maxlen]
            res.append(text)
        return res

    # input: texts, labels
    # in case that one text with multiple labels
    # 基于场景的模型，应分别将每个场景下的数据dedup
    def dedup(self, texts, labels, distinct=False, balance_data=True):
        df = pd.DataFrame({'texts': texts, 'labels': labels})
        text_label_counter = df.groupby('texts')['labels'].nunique().reset_index(
            name='unique_label')
        dup_text_indices = text_label_counter['unique_label'] > 1
        dup_count = dup_text_indices.sum()
        non_dup_text_indices = -dup_text_indices

        non_dup_df = pd.merge(df, text_label_counter[non_dup_text_indices], on='texts')
        dup_df = pd.merge(df, text_label_counter[dup_text_indices], on='texts')
        print('duplicated sentences number : {}'.format(dup_count))

        if distinct:
            # remove texts with mutiple labels and de-dup
            df = non_dup_df.drop_duplicates(['texts', 'labels'])
        else:
            label_counter = df.groupby('labels')['texts'].count().reset_index(name='label_count')
            text_in_label_counter = df.groupby(['texts', 'labels']).size().reset_index().rename(
                columns={0: 'text_count_in_label'})
            detail_count = pd.merge(label_counter, text_in_label_counter, on='labels')
            detail_count['ratio'] = detail_count['text_count_in_label'] / detail_count[
                'label_count']
            label_dedup = detail_count[['texts', 'labels', 'ratio']].sort_values(['texts', 'ratio'],
                                                                                 ascending=[True,
                                                                                            False]).groupby(
                'texts').head(1)  # groupby keep order
            dup_df = pd.merge(dup_df, label_dedup, on=['texts', 'labels'])
            df = pd.concat([dup_df[['texts', 'labels']], non_dup_df[['texts', 'labels']]])

        texts = np.array(df['texts'].tolist())
        labels = np.array(df['labels'].tolist())

        if balance_data:
            texts, labels = self.balance_data(texts, labels)

        label_counter = Counter(labels)
        print('final label counter: {}'.format(label_counter))
        return texts, labels

    def balance_data(self, texts, labels):
        label_counter = Counter(labels)
        print('label counter before balance: {}'.format(label_counter))
        balance_size = min(label_counter.values())
        label_counter = Counter({label: balance_size for label in label_counter})
        balanced_index_list = np.concatenate(
            [
                np.random.choice(np.arange(len(labels))[labels == label], balance_size, False)
                for label in label_counter
            ]
        )
        texts = texts[balanced_index_list]
        labels = labels[balanced_index_list]
        return texts, labels

    def build_word_dict(self, texts, word_freq):
        self.word_freq_dict = word_count(texts, word_seg=False)
        self.term_id_map = build_word2idx(self.word_freq_dict, freq_threshold=word_freq)
        return self.term_id_map

    def dump_dict(self, path):
        with open(path, 'wb') as f:
            pkl.dump(self.term_id_map, f)


class SceneSpiteTextTrainingData(TrainingData):
    def __init__(self, train_dir, word_freq=2, distinct=False, balance_data=False, batch_size=256,
                 test_size=0.2, default_random_seed=42):
        self.train_dir = train_dir
        self.scene_data = defaultdict(lambda: defaultdict(list))

        self.read_data()

        all_texts = []
        all_scenes = []
        all_labels = []
        for scene, data_dict in self.scene_data.items():
            scene_texts, scene_labels = self.dedup(
                self.prepare_texts(data_dict['texts']),
                data_dict['labels'], distinct, balance_data)
            data_dict['texts'] = scene_texts
            data_dict['labels'] = scene_labels
            all_texts.extend(scene_texts)
            all_scenes.extend([scene] * len(scene_labels))
            all_labels.extend(scene_labels)

        all_texts = np.array(all_texts)
        all_scenes = np.array(all_scenes)
        all_labels = np.array(all_labels)
        self.build_word_dict(all_texts, word_freq)

        super(SceneSpiteTextTrainingData, self).__init__(
            datasets=[all_texts, all_scenes, all_labels], batch_size=batch_size,
            test_size=test_size, default_random_seed=default_random_seed)

    def parse_scene(self, raw_text):
        if raw_text.startswith('[场景:女性] '):
            return 1, raw_text[len('[场景:女性] '):]
        else:
            return 0, raw_text

    def _add_sample(self, text, scene, label):
        self.scene_data[scene]['texts'].append(text)
        self.scene_data[scene]['labels'].append(label)

    def read_data(self):
        for idx, file in enumerate(sorted(os.listdir(self.train_dir))):
            file_name = os.path.join(self.train_dir, file)
            with open(file_name, 'r', errors='replace') as f:
                for line in f:
                    parts = line.replace('\n', '').split('\t')
                    scene, text = self.parse_scene(parts[0])
                    if len(parts) == 1:
                        if file == 'neg.txt':
                            result = '白'
                        elif file == 'pos.txt':
                            result = '黑'
                        else:
                            raise Exception('result not found')
                    else:
                        result = parts[1]
                    if result == '黑' or result == '灰':
                        self._add_sample(text, 0, 1)
                    elif result == '白':
                        self._add_sample(text, scene, 0)
                        if scene != 0:
                            self._add_sample(text, 0, 0)
                    else:  # 场景黑
                        self._add_sample(text, 0, 0)
                        self._add_sample(text, scene, 1)


class TextTrainingData(TrainingData):
    def __init__(self, train_dir, word_freq=2, distinct=False, balance_data=False, batch_size=256,
                 test_size=0.2, default_random_seed=42, maxlen=200):
        self.maxlen = maxlen
        self.train_dir = train_dir
        self.word_freq = word_freq
        self.distinct = distinct
        self.sentences = []
        self.labels = []
        self.label_name = {}
        self.label_counter = {}
        self.sents_dict = {}
        # read text from train_dir
        self._read_data()
        self._remove_duplicated_text()
        self.sentences = np.array(self.sentences)
        self.labels = np.array(self.labels)
        self.build_word_dict(self.sentences, self.word_freq)

        if balance_data:
            print('balancing data ...')
            balance_size = np.min(list(Counter(self.labels).values()))
            balanced_index_list = np.concatenate([np.random.choice(np.arange(len(self.labels))[
                                                                       self.labels == label],
                                                                   balance_size, False) for label in
                                                  set(self.labels)])
            self.sentences = self.sentences[balanced_index_list]
            self.labels = self.labels[balanced_index_list]

        if len(set(self.labels)) == 1:
            datasets = [self.sentences]
        else:
            datasets = [self.sentences, self.labels]
        super(TextTrainingData, self).__init__(datasets=datasets, batch_size=batch_size,
                                               test_size=test_size,
                                               default_random_seed=default_random_seed)

    def _read_data(self):
        for idx, file in enumerate(sorted(os.listdir(self.train_dir))):
            file_name = os.path.join(self.train_dir, file)
            self.label_name[idx] = file.split('.')[0]
            with open(file_name, 'r', errors='replace') as f:
                content = f.readlines()
                content = [line.replace('\n', '')[0:self.maxlen] for line in content]
                # content = [line.replace('\n', '') for line in content if len(line) <= self.maxlen]
                self.label_counter[idx] = len(content)
                content = Counter(content)
                self.sents_dict[idx] = content

    def _remove_duplicated_text(self):
        sent_counter = defaultdict(int)
        for idx, values in self.sents_dict.items():
            for key in values.keys():
                sent_counter[key] += 1
        repetition = [key for key in sent_counter.keys()
                      if sent_counter[key] > 1]
        print('duplicated sentences number : {}'.format(len(repetition)))

        # 过滤重复的句子
        for sent in repetition:
            sent_value = {}
            for idx in self.sents_dict.keys():
                if sent in self.sents_dict[idx]:
                    sent_value[idx] = self.sents_dict[idx][sent] * 1.0 / self.label_counter[idx]
            # filter the redundant sentences
            for idx in self.sents_dict.keys():
                if sent in self.sents_dict[idx]:
                    if self.distinct:
                        # if distinct, remove all duplicated sentences
                        self.sents_dict[idx].pop(sent)
                    else:
                        if self.sents_dict[idx][sent] * 1.0 / self.label_counter[idx] < max(
                                sent_value.values()):
                            self.sents_dict[idx].pop(sent)

        for idx, content in self.sents_dict.items():
            for sent, cnt in content.items():
                self.sentences += [sent.strip()] * (1 if self.distinct else cnt)
                self.labels += [idx] * (1 if self.distinct else cnt)

        print('current length: {}'.format(str(Counter(self.labels))))


class H5DataIterator(DataIterator):
    def __init__(self, datasets, index_list, batch_size, max_batch_index=None, limit=10,
                 thread_cnt=1):  # data is a list of np array
        self.datasets = datasets
        self.index_list = index_list
        self.batch_size = batch_size
        self.batch_index = 0
        self.batch_num = math.ceil(len(self.index_list) * 1.0 / self.batch_size)
        self.processed = 0
        self.max_batch_index = max_batch_index if max_batch_index is not None else self.batch_num - 1
        self.dataset_delegate = {}
        # figure out the h5 dataset
        self.readers = None
        self.h5_datasets = {idx: d for idx, d in enumerate(datasets) if 'H5Object' in str(type(d))}
        if len(self.h5_datasets) > 0:
            # start a new thread to read data in advance
            # if the data queue is full the reading thread will sleep for given time
            from itertools import islice
            size = int(len(self.h5_datasets) / thread_cnt)

            def chunks(data, size):
                it = iter(data)
                dicts = []
                for i in range(0, len(data), size):
                    dicts.append({k: data[k] for k in islice(it, size)})
                return dicts

            self.dataset_delegate = {i: Queue() for i, _ in self.h5_datasets.items()}
            h5_dataset_splits = chunks(self.h5_datasets, size)
            self.readers = []
            for h5_dataset in h5_dataset_splits:
                h5_reader = H5Worker(limit, h5_dataset, self.dataset_delegate, self.batch_size,
                                     self.max_batch_index, self.batch_num, self.index_list)
                self.readers.append(h5_reader)
            time.sleep(30)
            for i, queue in self.dataset_delegate.items():
                print(str(i) + ' size ' + str(queue.qsize()))

    def __iter__(self):
        return self

    def __len__(self):
        return self.batch_num

    def __next__(self):
        if self.batch_index > self.max_batch_index:
            raise StopIteration()
        else:
            begin = (self.batch_index % self.batch_num) * self.batch_size
            self.batch_index += 1
            batch = self.index_list[
                    begin: begin + self.batch_size]  # ignore values >= len(index_list)
            self.processed += len(batch)
            sorted_batch = sorted(batch)
            # sort index in case datasets is h5py.Dataset
            return self.batch_index - 1, [
                data[sorted_batch] if i not in self.dataset_delegate else self.dataset_delegate[
                    i].get() for i, data in enumerate(self.datasets)]

    def close(self):
        if self.readers is not None:
            for reader in self.readers:
                reader.process.terminate()
                reader.process.join()

    def reset(self):
        self.batch_index = 0

    def processed_rows(self):
        return self.processed


class H5TrainingData(TrainingData):
    def __init__(self, datasets, batch_size, test_size, default_random_seed=42, limit=None,
                 shuffle=True, thread_cnt=100, queue_limit=5, iterator_factory=H5DataIterator):
        self.ignored_input_index = [idx for idx, col in enumerate(datasets) if col is None]
        self.datasets = [np.array(dataset) if isinstance(dataset, list) else dataset for dataset in
                         datasets]
        self.batch_size = batch_size
        self.test_size = test_size
        self.default_random_seed = default_random_seed
        if limit is None:
            self.index_list = np.arange(0, len(self.datasets[0]))
        else:
            # explicit limit in case the data can't be divided evenly
            self.index_list = np.arange(0, limit)
        self.resplit(self.default_random_seed)
        self.test_index_list = np.sort(self.test_index_list)

        self.shuffle = shuffle
        self.thread_cnt = thread_cnt
        self.queue_limit = queue_limit
        self.iterators = []
        self.iterator_factory = iterator_factory

    def create_iterator(self, mode="train", batch_size=None):
        if batch_size is None:
            batch_size = self.batch_size
        if mode == "train":
            if self.shuffle:
                np.random.shuffle(self.train_index_list)
            it = self.iterator_factory(datasets=self.datasets, index_list=self.train_index_list,
                                       batch_size=batch_size, limit=self.queue_limit,
                                       thread_cnt=self.thread_cnt)
            self.iterators.append(it)
        elif mode == "test":
            it = self.iterator_factory(datasets=self.datasets, index_list=self.test_index_list,
                                       batch_size=batch_size, limit=self.queue_limit,
                                       thread_cnt=self.thread_cnt)
            self.iterators.append(it)

        else:  # "all"
            it = self.iterator_factory(datasets=self.datasets, index_list=self.index_list,
                                       batch_size=batch_size, limit=self.queue_limit,
                                       thread_cnt=self.thread_cnt)
            self.iterators.append(it)
        return it

    def close(self):
        for it in self.iterators:
            it.close()


class H5Object(object):
    # the h5 object wraps a path and a name to read from
    def __init__(self, path, name):
        self.path = path
        self.name = name


class H5Worker(object):
    # the worker is responsible for read data from disk
    def __init__(self, limit, h5_objects, h5_queues, batch_size, max_batch_index, batch_num,
                 index_list):
        self.process = multiprocessing.Process(target=self.run, args=(
        limit, h5_objects, h5_queues, batch_size, max_batch_index, batch_num, index_list))
        self.process.start()
        print('worker with datasets ' + str(h5_objects))

    def run(self, limit, h5_objects, h5_queues, batch_size, max_batch_index, batch_num, index_list):
        # open those datasets
        h5_datasets = {}
        file_to_close = []
        for i, h5object in h5_objects.items():
            file = h5py.File(h5object.path, "r", swmr=True)
            file_to_close.append(file)
            h5_datasets[i] = file[h5object.name]
        finish_cnt = 0
        batch_idx_list = {i: 0 for i, _ in h5_datasets.items()}
        while True:
            for i, dataset in h5_datasets.items():
                queue = h5_queues[i]
                if queue.qsize() < limit and batch_idx_list[i] <= max_batch_index:
                    begin = (batch_idx_list[i] % batch_num) * batch_size
                    batch_idx_list[i] = batch_idx_list[i] + 1
                    batch = index_list[begin: begin + batch_size]
                    sorted_batch = sorted(batch)
                    batch = dataset[sorted_batch]
                    queue.put(batch)
                if batch_idx_list[i] > max_batch_index:
                    finish_cnt += 1
            if finish_cnt == len(h5_datasets):
                break
        for file in file_to_close:
            file.close()


class MultiH5Iterator(DataIterator):
    def __init__(self, iter1, iter2):
        # 较小的
        if len(iter1) > len(iter2):
            tmp = iter1
            iter1 = iter2
            iter2 = tmp

        self.iter1 = iter1
        self.iter2 = iter2

    def __iter__(self):
        return self

    def __next__(self):
        idx1, data1 = self.iter1.__next__()
        idx2, data2 = self.iter2.__next__()
        # merge data1 data2
        data = [np.concatenate((d1, d2), axis=0) for d1, d2 in zip(data1, data2)]
        return idx1, data

    def __len__(self):
        return len(self.iter1)

    def close(self):
        self.iter1.close()
        self.iter2.close()

    def reset(self):
        self.iter1.reset()
        self.iter2.reset()

    def processed_rows(self):
        return self.iter1.processed_rows()


class MultiH5TrainingData(TrainingData):
    def __init__(self, h5data1, h5data2):
        self.d1 = h5data1
        self.d2 = h5data2

    def create_iterator(self, mode="train", batch_size=None):
        return MultiH5Iterator(self.d1.create_iterator(mode=mode),
                               self.d2.create_iterator(mode=mode))

    def close(self):
        return


class FusionTrainingData(H5TrainingData):
    ##  for training with raw bytes and embeddings
    def __init__(self, datasets, batch_size, test_size, default_random_seed=42, limit=None,
                 shuffle=True, thread_cnt=100, queue_limit=5):
        super(FusionTrainingData, self).__init__(datasets, batch_size, test_size,
                                                 default_random_seed, limit, shuffle, thread_cnt,
                                                 queue_limit, FusionIterator)


class FusionIterator(H5DataIterator):
    # the fusion data (bytes) are stored in disk each filename is the id
    def __init__(self, datasets, index_list, batch_size, max_batch_index=None, limit=100,
                 thread_cnt=1):  # data is a list of np array
        self.datasets = datasets
        self.index_list = index_list
        self.batch_size = batch_size
        self.batch_index = 0
        self.batch_num = math.ceil(len(self.index_list) * 1.0 / self.batch_size)
        self.processed = 0
        self.max_batch_index = max_batch_index if max_batch_index is not None else self.batch_num - 1
        self.dataset_delegate = {}
        self.bytes_datasets = {idx: d for idx, d in enumerate(datasets) if
                               'BytesObject' in str(type(d))}
        if len(self.bytes_datasets):
            self.readers = []
            for idx, bytes_dataset in self.bytes_datasets.items():
                queue = Queue()
                self.dataset_delegate[idx] = queue
                reader = BytesWorker(limit, bytes_dataset.files, queue, self.batch_size,
                                     self.max_batch_index, self.batch_num, self.index_list)
                self.readers.append(reader)
            time.sleep(30)
            for i, queue in self.dataset_delegate.items():
                print(str(i) + ' size ' + str(queue.qsize()))


class BytesObject(object):
    def __init__(self, files):
        self.files = files

    def __len__(self):
        return len(self.files)


class BytesWorker(object):
    def __init__(self, queue_limit, dataset, queue, batch_size, max_batch_index, batch_num,
                 index_list):
        self.process = multiprocessing.Process(target=self.run, args=(
        queue_limit, dataset, queue, batch_size, max_batch_index, batch_num, index_list))
        self.process.start()
        print('bytes worker started')

    def run(self, queue_limit, files, queue, batch_size, max_batch_index, batch_num, index_list):
        batch_idx = 0
        while True:
            if queue.qsize() < queue_limit and batch_idx <= max_batch_index:
                begin = (batch_idx % batch_num) * batch_size
                batch = index_list[begin: begin + batch_size]
                batch_idx += 1
                sorted_batch = sorted(batch)
                files_to_read = [files[idx] for idx in sorted_batch]
                bytes_batch = []
                for file in files_to_read:
                    with open(file, 'rb') as f:
                        bytes_batch.append(f.read())
                queue.put(bytes_batch)
            if batch_idx > max_batch_index:
                break

