import tensorflow as tf
from rcalgo.tf.models.language_model.base_lm import LanguageModel
from rcalgo.tf.module.layer.rnn import my_rnn_cell_v2
from tensorflow.python.ops import array_ops


class RNNLM(LanguageModel):
    def __init__(self, config, word_dict, **kwargs):
        super(RNNLM, self).__init__(config, word_dict, **kwargs)
        self.hidden_size = config.get("hidden_size", 512)
        self.keep_prob = config.get("keep_prob", 1.0)
        self.use_residual = config.get("use_residual", False)

    def build_rnn(self, input_seq, seq_lengths, go_backward=False):
        cell = my_rnn_cell_v2(self.hidden_size, self.keep_prob, self.num_layers, self.use_residual)
        encoder = tf.keras.layers.RNN(cell, return_sequences=True, return_state=True, stateful=False, dynamic=False)
        mask = tf.sequence_mask(seq_lengths, maxlen=self.max_seq_len, dtype=tf.int32)
        if go_backward:
            input_seq = array_ops.reverse_sequence(input_seq, seq_lengths=seq_lengths, seq_axis=1, batch_axis=0)

        init_state = encoder.get_initial_state(input_seq)
        encoder_results = encoder(input_seq, mask=mask, initial_state=init_state)
        if go_backward:
            encoder_results[0] = array_ops.reverse_sequence(encoder_results[0], seq_lengths=seq_lengths, seq_axis=1,
                                                            batch_axis=0)
        states = encoder_results[0]
        rnn_outputs = tuple(encoder_results[1:])
        return states, rnn_outputs

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        states, rnn_outputs = self.build_rnn(embedding, seq_lengths)
        outputs = rnn_outputs[-1][0]
        targets = tf.concat([sequence[:, 1:], tf.zeros_like(sequence[:, 0:1])], 1)
        return states, outputs, targets


class BiRNNLM(RNNLM):
    def __init__(self, config, word_dict, **kwargs):
        super(BiRNNLM, self).__init__(config, word_dict, **kwargs)

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        states_fw, rnn_outputs_fw = self.build_rnn(embedding, seq_lengths)
        states_bw, rnn_outputs_bw = self.build_rnn(embedding, seq_lengths, go_backward=True)

        states = [states_fw, states_bw]
        rnn_outputs = rnn_outputs_fw + rnn_outputs_bw
        outputs = tf.concat([rnn_outputs[self.num_layers - 1][0], rnn_outputs[-1][0]], axis=1)

        targets_fw = tf.concat([sequence[:, 1:], tf.zeros_like(sequence[:, 0:1])], 1)
        targets_bw = tf.concat([tf.zeros_like(sequence[:, 0:1]), sequence[:, 0:-1]], 1)
        targets = [targets_fw, targets_bw]

        return states, outputs, targets
