python training/train_server.py --cluster_spec_path=demo/multiworker_training_demo/cluster_config.json --task_type=chief --task_index=0 --gpu_id=0
