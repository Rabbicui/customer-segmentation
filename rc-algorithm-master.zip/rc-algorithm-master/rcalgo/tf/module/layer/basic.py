import six
import collections
from functools import reduce

import tensorflow as tf
from tensorflow.python.ops import variable_scope as vs
from tensorflow.python.ops import array_ops, math_ops, init_ops
# from tensorflow.python.training import moving_averages

from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.utils.tf_func import get_new_variable_scope, fp32_storage_getter, he_uniform, shape_list, deconv_output_length
from rcalgo.tf.utils.tf_func import add_weight_to_collection


def _is_sequence(seq):
    return (isinstance(seq, collections.Sequence)
            and not isinstance(seq, six.string_types))


def _linear(input_tensor, output_dim, bias, bias_start=0.0, scope=None, variables_collections=None):
    """
    Linear layer, return a vector, given args input, output size,`.

    Main Args:
      input_tensor: the input tensor
      output_dim: the  dimension of output vector
    Returns:
      A Tensor, Dimension: [batch, output_dim]
    """
    if input_tensor is None or (_is_sequence(input_tensor) and not input_tensor):
        raise ValueError("`input_tensor` must be specified")
    if not _is_sequence(input_tensor):
        input_tensor = [input_tensor]

    # Calculate the total size of arguments on dimension 1.
    total_arg_size = 0
    shapes = [a.get_shape().as_list() for a in input_tensor]
    for shape in shapes:
        if len(shape) != 2:
            raise ValueError(
                "Linear is expecting 2D arguments: %s" % str(shapes))
        if not shape[1]:
            raise ValueError(
                "Linear expects shape[1] of arguments: %s" % str(shapes))
        else:
            total_arg_size += shape[1]

    # Now the computation.
    with vs.variable_scope(scope or "Linear"):
        matrix = vs.get_variable("Matrix", [total_arg_size, output_dim])
        add_weight_to_collection(matrix, variables_collections)
        if len(input_tensor) == 1:
            res = math_ops.matmul(input_tensor[0], matrix)
        else:
            res = math_ops.matmul(array_ops.concat(1, input_tensor), matrix)
        if not bias:
            return res
        bias_term = vs.get_variable(
            "Bias", [output_dim],
            initializer=init_ops.constant_initializer(bias_start))
        add_weight_to_collection(bias_term, variables_collections)
        return res + bias_term


def my_full_connected(input_tensor, output_dim, add_bias=True,
                      layer_name='fully_connected', act=tf.identity, init_std=0.05,
                      weights_initializer=None, biases_initializer=None,
                      scope=None, reuse=False, variables_collections=None, bn=False,
                      training=True):
    """
    Full Connected Layer with activation function

    Main Args:
      input_tensor: the input tensor, [batch, input_dim]
      output_dim: the dimension of output vector [batch, output_dim]
      act: the activation function
    Returns:
      A Tensor, Dimension: [batch, output_size]
    """

    input_dim = input_tensor.get_shape()[-1].value
    vscope = get_new_variable_scope(layer_name, scope=scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        if weights_initializer is None:
            weights_initializer = tf.truncated_normal_initializer(
                stddev=init_std)
        weights = tf.compat.v1.get_variable("W", [input_dim, output_dim],
                                  initializer=weights_initializer, dtype=get_default_float_type())
        add_weight_to_collection(weights, variables_collections)
        with tf.name_scope('Wx_plus_b'):
            preactivate = tf.matmul(input_tensor, weights)
            if add_bias:
                if biases_initializer is None:
                    biases_initializer = tf.zeros_initializer()
                    #biases_initializer = tf.truncated_normal_initializer(
                    #    stddev=init_std)
                biases = tf.compat.v1.get_variable(
                    "B", [output_dim], initializer=biases_initializer, dtype=get_default_float_type())
                preactivate = preactivate + biases
                add_weight_to_collection(biases, variables_collections)
            if bn:
                if isinstance(training, bool):
                    training = tf.convert_to_tensor(training)
                preactivate = my_batch_norm(preactivate, training)
            activations = act(preactivate, name='activation')
            return activations


def my_onehot_layer(input_tensor, vocab_size, layer_name='onehot_layer'):
    """
    One Hot Layer

    Main Args:
      input_tensor: the input sequence tensor [batch, maxlen]
      vocab_size:  vocabulary size
    Returns:
      A Tensor, Dimension: [batch, maxlen, vocab_size]
    """
    with tf.name_scope(layer_name):
        input_one_hot = tf.one_hot(input_tensor, vocab_size)
        return input_one_hot


def my_flatten(input_tensor, layer_name='flatten'):
    """
    Flatten Layer

    Main Args:
      input_tensor: the input tensor [batch, d1, d2 ...]
    Returns:
      A Tensor, Dimension: [batch, d1 * d2 * ..]
    """
    with tf.name_scope(layer_name):
        shape = len(input_tensor.get_shape())
        if shape > 2:
            flatten_shape = reduce(
                lambda x, y: x*y, [input_tensor.get_shape()[i].value for i in range(1, shape)])
            flatten_layer = tf.reshape(input_tensor, [-1, flatten_shape])
            return flatten_layer
        else:
            return input_tensor


def highway(input_, layer_size=1, bias=0.0, f=tf.nn.relu, layer_name='highway',
            scope=None, reuse=False, variables_collections=None):
    """
    Highway Network (cf. http://arxiv.org/abs/1505.00387).
    t = sigmoid(Wy + b)
    z = t * g(Wy + b) + (1 - t) * y
   my where g is nonlinearity, t is transform gate, and (1 - t) is carry gate.
    """
    output = input_
    size = input_.get_shape()[-1]
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        for idx in range(layer_size):
            output = f(_linear(output, size, 0, scope='output_lin_%d' % idx,
                               variables_collections=variables_collections))
            transform_gate = tf.sigmoid(_linear(input_, size, 0, scope='transform_lin_%d' % idx,
                                                variables_collections=variables_collections) + bias)
            carry_gate = 1. - transform_gate
            output = transform_gate * output + carry_gate * input_
        return output


def my_dropout(input_tensor, rate=0.5, training=False):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    """
    Applies Dropout to the input.
    """
    def dropped_inputs():
        # 0 or scaled by 1 / keep_prob
        # keep_prob = 1 - dropout_rate
        #return tf.nn.dropout(input_tensor, 1 - rate)
        return tf.nn.dropout(input_tensor, rate = rate)

    return tf.cond(training,
                   dropped_inputs,
                   lambda: array_ops.identity(input_tensor))

def my_conv_1d(input_tensor, conv_length, n_filters_out, add_bias=True,
               stride_step=1, padding='SAME', layer_name='conv_1d', act=tf.nn.tanh,
               bn=False, training=True, scope=None, reuse=False, variables_collections=None):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    n_filters_in = input_tensor.get_shape()[-1].value
    vscope = get_new_variable_scope(layer_name, scope=scope, reuse=reuse, custom_getter=fp32_storage_getter)
    with vscope as scope:
        conv_W = he_uniform('W', [conv_length, n_filters_in, n_filters_out], dtype=get_default_float_type())
        add_weight_to_collection(conv_W, variables_collections)
        with tf.name_scope('conv_1d_operation'):
            if conv_length == 1:
                conv_x = tf.reshape(tf.matmul(tf.reshape(input_tensor, [-1, n_filters_in]),
                                              tf.reshape(conv_W, [-1, n_filters_out])),
                                    shape_list(input_tensor)[:-1] + [n_filters_out])
            else:
                pad_tensor = tf.zeros_like(
                    tf.tile(input_tensor[:, 0:1, :], [1, (conv_length-1), 1]))
                if padding == 'LEFT_SAME':
                    conv_x = tf.nn.conv1d(tf.concat([pad_tensor, input_tensor], axis=1),
                                          conv_W, stride=stride_step, padding='VALID')
                elif padding == 'RIGHT_SAME':
                    conv_x = tf.nn.conv1d(tf.concat([input_tensor, pad_tensor], axis=1),
                                          conv_W, stride=stride_step, padding='VALID')
                else:
                    conv_x = tf.nn.conv1d(
                        input_tensor, conv_W, stride=stride_step, padding=padding)
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer(), dtype=get_default_float_type())
                add_weight_to_collection(biases, variables_collections)
                conv_x = tf.nn.bias_add(conv_x, biases)
            if bn:
                conv_x = my_batch_norm(conv_x, training)
            conv_x = act(conv_x, name='activation')
        return conv_x


def my_atrous_conv_1d(input_tensor, conv_length, n_filters_out, rate, add_bias=True,
                      padding='SAME', layer_name='atrous_conv_1d', act=tf.nn.tanh,
                      bn=False, training=True, scope=None, reuse=False, variables_collections=None):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    n_filters_in = input_tensor.get_shape()[-1].value
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        conv_W = he_uniform('W', [1, conv_length, n_filters_in, n_filters_out])
        if padding == 'SAME':
            pad_len = (conv_length - 1) * rate
            x = tf.expand_dims(
                tf.pad(input_tensor, [[0, 0], [pad_len, 0], [0, 0]]), 1)
        with tf.name_scope('atrous_conv_1d_operation'):
            conv_x = tf.nn.atrous_conv2d(x, conv_W, rate=rate, padding='VALID')
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer())
                conv_x = tf.nn.bias_add(conv_x, biases)
            if bn:
                conv_x = my_batch_norm(
                    conv_x, training, variables_collections=variables_collections)
            conv_x = tf.squeeze(act(conv_x, name='activation'), [1])
        return conv_x


def my_conv_2d(input_tensor, n_filters_out, kernel_size, strides=[1, 1, 1, 1], add_bias=True,
               padding='SAME', layer_name='conv_2d', act=tf.nn.tanh,
               bn=False, training=True, scope=None, reuse=False, variables_collections=None):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    if isinstance(strides, int):
        strides = [1, strides, strides, 1]

    n_filters_in = input_tensor.get_shape()[-1].value

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        conv_W = tf.compat.v1.get_variable('W', shape=[*kernel_size, n_filters_in, n_filters_out],
                                 initializer=tf.contrib.layers.xavier_initializer())
        add_weight_to_collection(conv_W, variables_collections=variables_collections)
        with tf.name_scope('conv_2d_operation'):
            conv_x = tf.nn.conv2d(input_tensor, conv_W,
                                  strides=strides, padding=padding)
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer())
                conv_x = tf.nn.bias_add(conv_x, biases)
            if bn:
                conv_x = my_batch_norm(conv_x, training)
        conv_x = act(conv_x, name='activation')
        return conv_x

def my_conv_2d_transpose(input_tensor, n_filters_out, kernel_size, strides, padding='SAME', add_bias=True,
                         layer_name='conv_2d_transpose', act=tf.nn.relu, bn=False, training=True,
                         scope=None, reuse=False, variables_collections=None):
    # input_tensor 4d Tensor [batch, height, weight, in_channels]
    # kernel_size a list of length 2 holding [height, width]
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    if isinstance(strides, int):
        strides = [strides, strides]

    batch_size = input_tensor.get_shape()[0].value
    input_h = input_tensor.get_shape()[1].value
    input_w = input_tensor.get_shape()[2].value
    n_filters_in = input_tensor.get_shape()[3].value

    kernel_h, kernel_w = kernel_size
    stride_h, stride_w = strides

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        conv_W = tf.compat.v1.get_variable('W', shape=[*kernel_size, n_filters_out, n_filters_in],
                                 initializer=tf.contrib.layers.xavier_initializer())
        add_weight_to_collection(conv_W, variables_collections=variables_collections)

        # Infer the dynamic output shape:
        out_height = deconv_output_length(input_h, kernel_h, padding, stride_h)
        out_width = deconv_output_length(input_w, kernel_w, padding, stride_w)
        output_shape = (batch_size, out_height, out_width, n_filters_out)
        output_shape_tensor = array_ops.stack(output_shape)
        # re set the strides to 4 dimension
        strides = (1, stride_h, stride_w, 1)
        with tf.name_scope('conv_2d_transpose_operation'):
            conv_x = tf.nn.conv2d_transpose(input_tensor, conv_W, output_shape_tensor,
                                            strides=strides, padding=padding)
            if add_bias:
                biases = tf.compat.v1.get_variable(
                    "B", [n_filters_out], initializer=tf.zeros_initializer())
                conv_x = tf.nn.bias_add(conv_x, biases)
                add_weight_to_collection(biases, variables_collections)
            if bn:
                conv_x = my_batch_norm(conv_x, training)
        conv_x = act(conv_x, name='activation')
        return conv_x

def my_pool_layer_2d(input_tensor, k, stride=None, padding='VALID', layer_name='pool_2d', act=tf.nn.max_pool2d):
    with tf.name_scope(layer_name):
        if stride is None:
            stride = k
        pool = act(input_tensor, ksize=[1, k, k, 1], strides=[
                   1, stride, stride, 1], padding=padding)
        return pool


##############################  Normalization  Layer  ##############################

def my_layer_norm(input_tensor, epsilon=1e-8, layer_name='ln_layer', scope=None, reuse=None):
    """
    Based on the paper: "Layer Normalization"
    https://arxiv.org/abs/1607.06450.
    Can be used as a normalizer function for conv and fully_connected.

    Main Args:
      input_tensor: the input tensor, [batch, input_dim]
    """
    vscope = get_new_variable_scope(layer_name, scope=scope, reuse=reuse)
    with vscope as scope:
        x_shape = input_tensor.get_shape()
        params_shape = x_shape[-1:]
        mean, variance = tf.nn.moments(input_tensor, [-1], keep_dims=True)
        beta = tf.compat.v1.get_variable('beta', params_shape,
                               initializer=tf.constant_initializer(0.0), dtype=get_default_float_type())
        gamma = tf.compat.v1.get_variable('gamma', params_shape,
                                initializer=tf.constant_initializer(1.0), dtype=get_default_float_type())
        normalized = (input_tensor - mean) / (tf.sqrt(variance + epsilon))
        outputs = gamma * normalized + beta
    return outputs


def my_batch_norm(input_tensor, training, recurrent=False, epsilon=1e-3, decay=0.999,
                  layer_name='bn_layer', scope=None, variables_collections=None):
    """
    Based on paper:
    "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift"
    http://arxiv.org/abs/1502.03167
    support recurrent bn
    momoent shape: [input_tensor.get_shape[-1],]


    Main Args:
      input_tensor: the input tensor, [batch, input_dim]
      training: whether to return the output in training mode
      recurrent: bn or reccurent bn
    """
    if recurrent:
        vscope = get_new_variable_scope(layer_name, scope=layer_name, custom_getter=fp32_storage_getter)
    else:
        vscope = get_new_variable_scope(layer_name, scope=scope, custom_getter=fp32_storage_getter)
    x_shape = input_tensor.get_shape()
    axis = list(range(len(x_shape) - 1))
    params_shape = x_shape[-1:]
    with vscope as scope:
        # print scope.name
        scale = tf.compat.v1.get_variable('scale', params_shape,
                                initializer=tf.constant_initializer(1.0))
        offset = tf.compat.v1.get_variable(
            'offset', params_shape, initializer=tf.constant_initializer(0.0))
        add_weight_to_collection(scale, variables_collections)
        add_weight_to_collection(offset, variables_collections)
        pop_mean = tf.compat.v1.get_variable(
            'pop_mean', params_shape, initializer=tf.constant_initializer(0), trainable=False)
        pop_var = tf.compat.v1.get_variable(
            'pop_var', params_shape, initializer=tf.constant_initializer(1.0), trainable=False)

        #train_mean = moving_averages.assign_moving_average(pop_mean, batch_mean, decay)
        #train_var = moving_averages.assign_moving_average(pop_var, batch_var, decay)

        def batch_statistics():
            batch_mean, batch_var = tf.nn.moments(input_tensor, axis)
            train_mean = tf.assign(pop_mean, pop_mean *
                                   decay + batch_mean * (1 - decay))
            train_var = tf.assign(pop_var, pop_var * decay +
                                  batch_var * (1 - decay))
            with tf.control_dependencies([train_mean, train_var]):
                return tf.nn.batch_normalization(input_tensor, batch_mean, batch_var, offset, scale, epsilon)

        def population_statistics():
            return tf.nn.batch_normalization(input_tensor, pop_mean, pop_var, offset, scale, epsilon)

        return tf.cond(training, batch_statistics, population_statistics)


def relu_fc_layer(tensor, size, init_std, layer_name='relu_fc_layer', reuse=False):
    return my_full_connected(tensor, size, act=tf.nn.relu, init_std=init_std,
                             layer_name=layer_name, reuse=reuse,
                             weights_initializer=tf.variance_scaling_initializer(scale=2.0, mode='fan_in', distribution='normal'))
