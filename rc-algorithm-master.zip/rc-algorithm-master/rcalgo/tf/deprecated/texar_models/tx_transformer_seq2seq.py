import os
import sys
import copy
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))
from texar_models.tx_transformerlm import *


class TxTransformerSeq2SeqModel(TxTransformerLMModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(TxTransformerSeq2SeqModel, self).__init__(
            config, graph, word_dict)
        #for encoder
        self.mask = False
        self.attn_drop = 1 - config.keep_prob
        self.ffn_act = act_fns[config.transformer_func]
        self.ffn_drop = 1 - config.keep_prob
        self.conv_num_filters = config.embedding_size
        self.position_info = config.position_info
        self.combine_mode = config.combine_mode
        #for decoder
        self.output_maxlen = config.output_maxlen
        self.num_decoder_symbols = self.nb_words
        self.share_embed = True
        # self.eos_value = 0
        self.target_word_dict = target_word_dict if word_dict is None else word_dict
        if self.raw_text and self.target_word_dict is not None:
            self.target_word_table, self.num_decoder_symbols = self._init_word_table(
                self.target_word_dict)
        else:
            self.target_word_table = None

    def _get_target_text_parameters(self, expand_input=False):
        if expand_input:
            self.num_decoder_symbols = self.num_decoder_symbols + 2
        return self.target_word_table, self.output_maxlen, self.num_decoder_symbols

    def build_input(self, expand_input=True):
        super(TxRNNLMModel, self).build_input(expand_input)
        if self.share_embed:
            self.build_sentence_flag(self.nb_words)
        with tf.name_scope('states_array'):
            self.training_decoder_output = [[] for i in range(0, self.gpu_num)]

    def build_output(self, expand_input=True, key='target'):
        # expand_input为True且key为’target‘的时候，只添加EOS部分
        split_targets, split_targets_seqLengths = self.build_text_input(
            expand_input=expand_input, key=key)    
        self._build_output_attr(split_targets, split_targets_seqLengths)
        

    def _build_output_attr(self, split_targets, split_targets_seqLengths):
        # ADD GO_VALUE
        if not self.share_embed:
            self.build_sentence_flag(self.num_decoder_symbols)
        self.split_targets = [tf.cast(t, tf.int32) for t in split_targets]
        self.split_targets_seqLengths = [
            tf.cast(t, tf.int32) for t in split_targets_seqLengths]
        self.build_topk_input()
        #self.split_input_context_id = [None for i in range(self.gpu_num)]
        #self.split_input_context_id_len = [None for i in range(self.gpu_num)]
    
    def build_input_sequence(self, gpu_id=0):
        self._build_embedding_layer(gpu_id)
        self.state_list[gpu_id], _ = conv_transformer_layer(self.input_embedding[gpu_id], self.num_layers,
                                                            self.split_seqLengths[gpu_id],self.hidden_size,
                                                            self.position_type, combine_mode=self.combine_mode,
                                                            position_info=self.position_info, n_head=self.n_head,
                                                            attn_drop=self.attn_drop, mask=self.mask,
                                                            ffn_act=self.ffn_act, ffn_drop=self.ffn_drop,
                                                            training=self.training)
        self.split_init_state[gpu_id] = self.state_list[gpu_id]
        self.split_mem_length[gpu_id] = self.split_seqLengths[gpu_id]

    def build_output_sequence(self, gpu_id):
        dec_input = tf.concat(
            [tf.fill([self.dynamic_batch_size, 1], 1) * self.go_value, self.split_targets[gpu_id][:, 0:-1]], axis=1)
        dec_embed_input = my_embedding_layer(
            dec_input,
            max(self.num_decoder_symbols, self.nb_words),
            self.embedding_size,
            layer_name='{}embedding_layer'.format('embedding/' if self.share_embed else ''),
            variables_collections='decoder_embedding',
        )
        self.build_training_decoder(
            gpu_id, dec_embed_input, self.split_targets_seqLengths[gpu_id],
            self.output_maxlen, self.num_decoder_symbols)
        with tf.variable_scope(self.decoder.variable_scope, reuse=tf.AUTO_REUSE):
            self.build_inference(gpu_id, self.output_maxlen)

    @replace_default_graph
    def build_model(self, task=None, accK=1, nb_class=None):
        self.build_input()
        self.build_output()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    # 这一处也是坑，必须使用tf.AUTO_REUSE才可以
                    reuse = tf.AUTO_REUSE  # (idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_input_sequence(
                            gpu_id=idx)
                        self.build_output_sequence(
                            gpu_id=idx)
                        self.build_sequence_prediction(
                            gpu_id=idx, accK=accK)
        self._dump_rnn_output()
        self._add_to_graph_outputs(self.prediction_results)


class TxMaskedTransformerSeq2SeqModel(TxTransformerSeq2SeqModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(TxMaskedTransformerSeq2SeqModel, self).__init__(
            config, graph, word_dict)
        self.default_low_sent_scale_length = config.low_sent_scale_length
        self.default_high_sent_scale_length = config.high_sent_scale_length+1
        self.mask_bound = True
        self.use_geometric_distribution = False
        self.predict_self = True
        # the MASS of microsoft
        self.MASS = False
        #self.share_embed = False

    @replace_default_graph
    def _set_masked_placeholder(self):
        self.masked_flag = get_from_collection_or_create(
            tf.compat.v1.GraphKeys.MASKED_FLAG,
            lambda: tf.compat.v1.placeholder_with_default(
                tf.constant(True), tf.TensorShape(None), name='masked_flag')
        )
        self._add_to_graph_inputs([self.masked_flag])
        self.input_dict['masked_flag'] = self.masked_flag

    @replace_default_graph
    def _set_masked_lm_parameter(self):
        # MASK标志位
        self.mark_label = self.nb_words
        self.nb_words = self.nb_words + 1
        # 80%换成MASK
        self.prob1 = tf.compat.v1.placeholder_with_default(
            0.8*tf.cast(self.masked_flag, tf.float32), tf.TensorShape(None), name='prob1')
        # 余下10%换成随机
        self.prob2 = tf.compat.v1.placeholder_with_default(
            0.9*tf.cast(self.masked_flag, tf.float32), tf.TensorShape(None), name='prob2')
        # 基于上下界的均匀采样，可以改成
        self.threshold = tf.random.uniform(
            [self.dynamic_batch_size*self.gpu_num], self.default_low_sent_scale_length,
            self.default_high_sent_scale_length, tf.int64)

    def build_input(self, expand_input=True):
        super(TxMaskedTransformerSeq2SeqModel, self).build_input(expand_input)
        self._set_masked_placeholder()
        # mask标志位
        self._set_masked_lm_parameter()
        split_threshold = tf.split(self.threshold, self.gpu_num, 0)
        with tf.name_scope('masked_lm_array'):
            self.indices_list = [[] for i in range(0, self.gpu_num)]
            self.origin_bow_list = [[] for i in range(0, self.gpu_num)]
            self.split_targets = [[] for i in range(0, self.gpu_num)]
            self.masked_targets = [[] for i in range(0, self.gpu_num)]
        for i in range(self.gpu_num):
            masked_input_bow, indices, origin_bow, mask_length = generate_span_masked_bow(
                self.split_inputX[i], self.split_seqLengths[i], self.maxlen, self.nb_words,
                expand_input=(self.mask_bound & self.expand_input), prob1=self.prob1,
                prob2=self.prob2, threshold=split_threshold[i],
                mask_length=split_threshold[i] if self.use_geometric_distribution else None)
            self.origin_bow_list[i] = self.split_inputX[i] 
            self.split_inputX[i] = masked_input_bow
            self.indices_list[i] = indices
            
            if self.MASS:
                #new_indices = tf.RaggedTensor.from_row_lengths(values=origin_bow,
                #                                               row_lengths=mask_length).to_sparse().indices
                range_idxs = tf.tile(tf.reshape(tf.range(self.maxlen,
                                                         dtype=mask_length.dtype), [1, -1]),
                                     [self.dynamic_batch_size, 1])
                new_indices = tf.compat.v2.where(range_idxs < tf.reshape(mask_length, [-1, 1]))
                ##tf.reduce_max(mask_length)
                output_shape = [self.dynamic_batch_size, math.ceil(self.maxlen/self.default_low_sent_scale_length)]
                #output_shape = tf.shape(masked_input_bow, out_type=tf.int64)
                out = tf.SparseTensor(new_indices, origin_bow, output_shape)
                EOS = get_concat_sparse_tensor(
                    out, self._eos_token_id(self.nb_words), True)
                self.tmp1 = out
                self.tmp2 = EOS
                self.masked_targets[i] = sparse_to_dense(
                    tf.sparse_concat(1, [out, EOS]))
        self.input_dict['bow'] = self.origin_bow_list[0]
        self.input_dict['indices'] = self.indices_list[0]
        self.input_dict['masked_bow'] = self.split_inputX[0]

    def build_output(self, expand_input=True, key='target'):
        if self.MASS:
            self.output_maxlen = math.ceil(self.maxlen/self.default_low_sent_scale_length)+1#self.maxlen+1
            self.num_decoder_symbols = self.nb_words
            #remove the go_value
            split_targets = self.masked_targets
            split_targets_seqLengths = [tf.count_nonzero(t, 1) for t in split_targets]
            self._build_output_attr(split_targets, split_targets_seqLengths)
        else:
            if self.predict_self:
                self.output_maxlen = self.maxlen-1
                self.num_decoder_symbols = self.nb_words
                # remove the go_value
                split_targets = [bow[:, 1:] for bow in self.origin_bow_list]
                split_targets_seqLengths = [(l-1) for l in self.split_seqLengths]
                self._build_output_attr(split_targets, split_targets_seqLengths)
            else:
                super(TxMaskedTransformerSeq2SeqModel,
                      self).build_output(expand_input, key)