import os
import sys

sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))

from rcalgo.tf.tfmodels.texar_models.tx_rnnlm import *


class TxSeq2SeqModel(TxRNNLMModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(TxSeq2SeqModel, self).__init__(
            config, graph, word_dict)
        # target相关
        self.output_maxlen = config.output_maxlen
        self.num_decoder_symbols = self.nb_words
        self.training_decoder_output = [[] for i in range(0, self.gpu_num)]
        self.target_word_dict = target_word_dict if word_dict is None else word_dict
        if self.raw_text and self.target_word_dict is not None:
            self.target_word_table, self.num_decoder_symbols = self._init_word_table(
                self.target_word_dict)
        else:
            self.target_word_table = None
        self.decoder_hidden_size = self.hidden_size * 2
        self._init_config()
    
    def _init_config(self):
        self.config_encoder = {
            'rnn_cell_fw': {
                'kwargs': {
                    'num_units': self.hidden_size,
                },
                'num_layers': self.num_layers,
            }
        }
        self.config_decoder = {
            'rnn_cell': {
                'kwargs': {
                    'num_units': self.decoder_hidden_size
                },
                'num_layers': self.num_layers,
            },
            'attention': {
                'kwargs': {
                    'num_units': self.decoder_hidden_size,
                },
                'attention_layer_size': self.decoder_hidden_size,
            }
        }
    
    
    def _get_target_text_parameters(self, expand_input=False):
        if expand_input:
            self.num_decoder_symbols = self.nb_words + 2
        return self.target_word_table, self.output_maxlen, self.num_decoder_symbols

    def build_input(self, expand_input=False):
        super(TxSeq2SeqModel, self).build_input(expand_input)

    def build_output(self, expand_input=True, key='target'):
        """
        target部分
        """
        self.build_sentence_flag(self.num_decoder_symbols)
        split_targets, split_targets_seqLengths = self.build_text_input(
            expand_input=expand_input, key=key)
        self.split_targets = [tf.to_int32(t) for t in split_targets]
        self.split_targets_seqLengths = [
            tf.to_int32(t) for t in split_targets_seqLengths]

    def build_input_sequence(self, gpu_id=0, reuse=None):
        self._build_embedding_layer(gpu_id)
        if gpu_id == 0:
            self.encoder = tx.modules.BidirectionalRNNEncoder(
                hparams=self.config_encoder)
        self.state_list[gpu_id], self.rnn_output_list[gpu_id] = self.encoder(self.input_embedding[gpu_id],
                                                                             self.split_seqLengths[gpu_id])
        self.state_list[gpu_id] = tf.concat(self.state_list[gpu_id], axis=2)
        if self.num_layers == 1:
            self.rnn_output_list[gpu_id] = tuple([[self.rnn_output_list[gpu_id][0]],
                                                  [self.rnn_output_list[gpu_id][1]]])
        self.output_list[gpu_id] = tuple([rnn_cell.LSTMStateTuple(h=tf.concat((fw.h, bw.h), axis=-1),
                                                                  c=tf.concat((fw.c, bw.c), axis=-1))
                                          for fw, bw in zip(self.rnn_output_list[gpu_id][0],
                                                            self.rnn_output_list[gpu_id][1])])

    def build_output_sequence(self, gpu_id, reuse=None):
        decoder_start_token = tf.ones_like(
            self.split_inputX[gpu_id][:, 0:1], dtype=tf.int32) * self.go_value
        dec_input = tf.concat(
            [decoder_start_token, self.split_targets[gpu_id][:, 0:-1]], axis=1)
        dec_embed_input = my_embedding_layer(
            dec_input,
            self.num_decoder_symbols,
            self.embedding_size,
            zero_pad=True,
            variables_collections='decoder_embedding',
            layer_name='decoder_embedding_layer',
            init_scale=self.init_scale)
        dec_embeddings = tf.compat.v1.get_collection('decoder_embedding')[0]

        cell = self.build_cell(self.decoder_hidden_size, 1.0, self.num_layers)
        # the encoder is bi_direction so the decoder use 2 * hidden size
        decoder = tx.modules.AttentionRNNDecoder(
            memory=self.state_list[gpu_id],
            memory_sequence_length=self.split_seqLengths[gpu_id],
            cell=cell,
            vocab_size=self.num_decoder_symbols,
            hparams=self.config_decoder)
        
        helper = tf.contrib.seq2seq.ScheduledEmbeddingTrainingHelper(
            inputs=dec_embed_input,
            sequence_length=self.split_targets_seqLengths[gpu_id],
            embedding=dec_embeddings,
            sampling_probability=self.sampling_probability)

        #print(decoder.zero_state(self.dynamic_batch_size, tf.float32))
        self.training_decoder_output[gpu_id], _, _ = decoder(
            decoding_strategy='train_greedy',
            initial_state=self.output_list[gpu_id],
            helper=helper)
        # inputs=dec_embed_input,
        # sequence_length=self.split_targets_seqLengths[gpu_id])

        self.build_inference(decoder, self.output_list[gpu_id], gpu_id)

    def build_inference(self, decoder, init_state, gpu_id=0):
        dec_embeddings = tf.compat.v1.get_collection('decoder_embedding')[0]
        self._build_inference(gpu_id, decoder=decoder, init_state=init_state, go_value=self.go_value,
                              eos_value=self.eos_value, maxlen=self.output_maxlen, embedding=dec_embeddings)

    def build_output_sequence_prediction(self, gpu_id, task=None, accK=1):
        current_max_length = tf.reduce_max(
            self.split_targets_seqLengths[gpu_id])
        paddings = tf.constant([[0, 0], [0, self.output_maxlen]])
        predictions = self.training_decoder_output[gpu_id].logits
        self.tower_prediction_results.append(predictions)
        self.compute_metrics(predictions, self.split_targets[gpu_id][:, 0:current_max_length],
                             task=task, nb_class=self.num_decoder_symbols, accK=accK)

    @replace_default_graph
    def build_model(self, task=None, accK=1, nb_class=None):
        self.build_input()
        self.build_output()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_input_sequence(
                            gpu_id=idx, reuse=reuse)
                        self.build_output_sequence(
                            gpu_id=idx, reuse=reuse)
                        self.build_output_sequence_prediction(
                            gpu_id=idx, accK=accK)
        self._dump_rnn_output()
        self._add_to_graph_outputs(self.prediction_results)
        
        
class TxTransformerSeq2SeqModel(TxSeq2SeqModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(TxTransformerSeq2SeqModel, self).__init__(
            config, graph, word_dict, target_word_dict)
        self.n_head = config.n_head
        self.position_type = config.position_type
        self.attn_drop = 1-config.keep_prob
        self.mask = False
        self.ffn_act = act_fns[config.transformer_func]
        self.ffn_drop = 1-config.keep_prob
        self.combine_mode = config.combine_mode
        self.conv_num_filters = config.conv_num_filters
        self.decoder_hidden_size = self.conv_num_filters
        self._init_config()
        
    def build_input_sequence(self, gpu_id=0, reuse=None):
        self._build_embedding_layer(gpu_id)
        self.state_list[gpu_id], self.rnn_output_list[gpu_id] = conv_transformer_layer(self.input_embedding[gpu_id], self.num_layers, self.split_seqLengths[gpu_id], self.conv_num_filters,
                                                                                       self.position_type, n_head=self.n_head, attn_drop=self.attn_drop, mask=self.mask, ffn_act=self.ffn_act, ffn_drop=self.ffn_drop, training=self.training)
        self.output_list[gpu_id] = tuple([rnn_cell.LSTMStateTuple(h=x, c=x)
                                          for x in tf.split(tf.tile(self.rnn_output_list[gpu_id],
                                                                    [1, self.num_layers]), self.num_layers, axis=-1)])

