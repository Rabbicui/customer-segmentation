import tensorflow as tf

from rcalgo.tf.modules_v2.base_module import Module
from rcalgo.tf.modules_v2.layers.common import Dense


class SelfPositionAttention(Module):
    """Self position attention

    https://www.cs.cmu.edu/~hovy/papers/16HLT-hierarchical-attention-networks.pdf
    """
    def __init__(self,
                 attn_dim,
                 name=None):
        super(SelfPositionAttention, self).__init__(name=name)
        self.attn_dim = attn_dim
        self.initializer_w = tf.initializers.truncated_normal(stddev=0.05)
        self.initializer_b = tf.initializers.truncated_normal(stddev=0.05)
        self.initializer_u = tf.initializers.truncated_normal(stddev=0.05)

    def build(self, input_shape):
        last_dim = input_shape[-1]
        self.kernel_w = tf.Variable(
            self.initializer_w(shape=[last_dim, self.attn_dim]),
            dtype=self.dtype,
            name='kernel_w')
        self.kernel_b = tf.Variable(
            self.initializer_b(shape=[self.attn_dim]),
            dtype=self.dtype,
            name='kernel_b')
        self.key = tf.Variable(
            self.initializer_u(shape=[1, self.attn_dim]),
            dtype=self.dtype,
            name='key')

    def call(self, inputs, return_only_attention=False):
        v = tf.nn.bias_add(tf.matmul(inputs, self.kernel_w), self.kernel_b)
        v = tf.nn.tanh(v)
        attention = tf.matmul(tf.expand_dims(self.key, -2), v, transpose_b=True)
        attention = tf.nn.softmax(attention)
        # attention: (batch_size, seq_length)
        output_attn = tf.squeeze(attention, -2)
        if return_only_attention:
            return output_attn
        output = tf.squeeze(tf.matmul(attention, inputs), -2)
        return output, output_attn


def dot_production_attention(query, keys, values=None):
    """Dot production attention as function."""
    if values is None:
        values = keys

    input_shape = keys.shape.as_list()
    if len(input_shape) != 3:
        raise ValueError("Shape of keys should have three dimensions!")

    attention = tf.matmul(tf.expand_dims(query, -2), keys, transpose_b=True)
    attention = tf.nn.softmax(attention)

    attn_output = tf.squeeze(attention, -2)
    output = tf.squeeze(tf.matmul(attention, values), -2)
    return output, attn_output


class DotProductionAttention(Module):
    """Dot production attention as class."""
    def __init__(self, name=None):
        super(DotProductionAttention, self).__init__(name=name)

    def call(self, inputs):
        if len(inputs) == 2:
            query, keys, values = inputs[0], inputs[1], inputs[1]
        elif len(inputs) == 3:
            query, keys, values = inputs[0], inputs[1], inputs[2]
        else:
            raise ValueError("Length of inputs should be 2 or 3!")
        return dot_production_attention(query, keys, values)


class MultiplicativeAttention(Module):
    """Multiplicative attention."""
    def __init__(self, name=None):
        super(MultiplicativeAttention, self).__init__(name=name)
        self.kernel_initializer = tf.truncated_normal_initializer(stddev=0.05)

    def build(self, input_shape):
        query_dim, key_dim = input_shape[0][-1], input_shape[1][-1]
        self.kernel = tf.Variable(
            self.kernel_initializer(shape=[query_dim, key_dim]),
            dtype=self.dtype,
            name='kernel')

    def call(self, inputs):
        if len(inputs) == 2:
            query, keys, values = inputs[0], inputs[1], inputs[1]
        elif len(inputs) == 3:
            query, keys, values = inputs[0], inputs[1], inputs[2]
        else:
            raise ValueError("Length of inputs should be 2 or 3!")

        query = tf.matmul(query, self.kernel)
        attention = tf.matmul(tf.expand_dims(query, -2), keys, transpose_b=True)
        # attention = tf.nn.softmax(attention)  # no softmax here
        attn_output = tf.squeeze(attention, -2)

        output = tf.squeeze(tf.matmul(attention, values), -2)
        return output, attn_output


class AdditiveAttention(Module):
    """Additive attention."""
    def __init__(self, attn_dim=2048, name=None):
        super(AdditiveAttention, self).__init__(name=name)
        self.attn_dim = attn_dim
        self.initializer_q = tf.truncated_normal_initializer(stddev=0.05)
        self.initializer_k = tf.truncated_normal_initializer(stddev=0.05)
        self.initializer_v = tf.truncated_normal_initializer(stddev=0.05)

    def build(self, input_shape):
        query_dim, key_dim = input_shape[0][-1], input_shape[1][-1]
        self.kernel_q = tf.Variable(
            self.initializer_q(shape=[query_dim, self.attn_dim]),
            dtype=self.dtype,
            name='kernel_q')
        self.kernel_k = tf.Variable(
            self.initializer_k(shape=[key_dim, self.attn_dim]),
            dtype=self.dtype,
            name='kernel_k')
        self.kernel_v = tf.Variable(
            self.initializer_v(shape=[1, self.attn_dim]),
            dtype=self.dtype,
            name='kernel_v')

    def call(self, inputs):
        if len(inputs) == 2:
            query, keys, values = inputs[0], inputs[1], inputs[1]
        elif len(inputs) == 3:
            query, keys, values = inputs[0], inputs[1], inputs[2]
        else:
            raise ValueError("Length of inputs should be 2 or 3!")

        query = tf.expand_dims(tf.matmul(query, self.kernel_q), -2)
        keys = tf.matmul(keys, self.kernel_k)
        qk = tf.nn.tanh(query + keys)
        v = tf.expand_dims(self.kernel_v, -2)
        attention = tf.matmul(v, qk, transpose_b=True)
        # attention = tf.nn.softmax(attention)
        attn_output = tf.squeeze(attention, -2)

        output = tf.squeeze(tf.matmul(attention, values), -2)
        return output, attn_output


class PairwiseAttention(Module):
    """Pairewise attention."""
    def __init__(self, use_fc=True, attn_dim=2048, use_scale=True, name=None):
        super(PairwiseAttention, self).__init__(name=name)

        self.use_fc = use_fc
        self.use_scale = use_scale
        self.attn_dim = attn_dim
        with self.name_scope:
            if use_fc:
                self.fc_a = Dense(attn_dim, activation='identity')
                self.fc_b = Dense(attn_dim, activation='identity')
            self.dense_a = Dense(1, activation='tanh')
            self.dense_b = Dense(1, activation='tanh')

    def call(self, inputs):
        if len(inputs) != 2:
            raise ValueError("Length of inputs should be 2!")
        inputs_a, inputs_b = inputs[0], inputs[1]
        if self.use_fc:
            inputs_a = self.fc_a(inputs_a)
            inputs_b = self.fc_b(inputs_b)

        scores = tf.matmul(inputs_a, inputs_b, transpose_b=True)
        if self.use_scale:
            scores = scores / tf.sqrt(tf.cast(self.attn_dim, tf.float32))

        scores_a = tf.squeeze(self.dense_a(scores), -1)
        scores = tf.transpose(scores, perm=(0, 2, 1))
        scores_b = tf.squeeze(self.dense_b(scores), -1)
        return scores_a, scores_b
