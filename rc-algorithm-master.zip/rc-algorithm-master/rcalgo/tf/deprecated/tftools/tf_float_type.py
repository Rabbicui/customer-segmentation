import functools
import inspect
import tensorflow as tf

from tensorflow.python.framework import dtypes
from tensorflow.python.framework import ops
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import math_ops


__DEFAULT_FLOAT_TYPE = tf.float32
tf_func_replaced = False


def get_default_float_type():
    return __DEFAULT_FLOAT_TYPE


def set_default_float_type(dtype):
    global __DEFAULT_FLOAT_TYPE
    __DEFAULT_FLOAT_TYPE = dtype
    # replace_tf_funcs()


original_funcs = [tf.nn.moments]


@functools.wraps(tf.nn.moments)
def hack_moments(
        x,
        axes,
        shift=None,  # pylint: disable=unused-argument
        name=None,
        keep_dims=False):
    with ops.name_scope(name, "moments", [x, axes]):
        y = x
        mean = math_ops.reduce_mean(y, axes, keepdims=True, name="mean")
        variance = math_ops.reduce_mean(
            math_ops.squared_difference(y, array_ops.stop_gradient(mean)),
            axes,
            keepdims=True,
            name="variance")
        if not keep_dims:
            mean = array_ops.squeeze(mean, axes)
            variance = array_ops.squeeze(variance, axes)
        return (mean, variance)


def default_dtype_wrapper(func):
    original_funcs.append(func)
    args = inspect.getfullargspec(func).args
    if "dtype" in args:
        dtype_index = args.index("dtype")
    else:
        dtype_index = None

    @functools.wraps(func)
    def wrapper(*params, **kwargs):
        if dtype_index is not None and len(params) > dtype_index:
            if params[dtype_index] is None:
                params[dtype_index] = get_default_float_type()
        elif kwargs.get("dtype") is None:
            kwargs["dtype"] = get_default_float_type()
        return func(*params, **kwargs)
    return wrapper


def fill(dims, value, name=None):
    if isinstance(value, float):
        return tf.fill(dims, get_default_float_type().as_numpy_dtype(value), name)
    else:
        return tf.fill(dims, value, name)


def replace_tf_funcs():
    global tf_func_replaced
    if tf_func_replaced:
        return
    tf.compat.v1.get_variable = default_dtype_wrapper(tf.compat.v1.get_variable)
    tf.ones = default_dtype_wrapper(tf.ones)
    tf.ones_like = default_dtype_wrapper(tf.ones_like)
    tf.zeros = default_dtype_wrapper(tf.zeros)
    tf.zeros_like = default_dtype_wrapper(tf.zeros_like)
    tf.zeros_initializer = default_dtype_wrapper(tf.zeros_initializer)
    tf.random_uniform_initializer = default_dtype_wrapper(tf.random_uniform_initializer)
    tf.truncated_normal_initializer = default_dtype_wrapper(tf.truncated_normal_initializer)
    tf.contrib.layers.xavier_initializer = default_dtype_wrapper(tf.contrib.layers.xavier_initializer)
    tf.constant_initializer = default_dtype_wrapper(tf.constant_initializer)

    tf.nn.moments = hack_moments

    tf_func_replaced = True
