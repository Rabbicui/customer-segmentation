
import os

import tensorflow as tf
import tensorflow_probability as tfp
import sys

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))

from rcalgo.tf.tfmodels.image.utils.autoaugment import *
from rcalgo.tf.tfmodels.image.utils.aug_util import *

# Adjust depending on the available RAM.
MAX_IN_MEMORY = 500000

try:
    import horovod.tensorflow.keras as hvd
    HOROVOD_SUPPORT = True
except ImportError:
    pass


def _gen_(data):
    for i in data:
        yield i


def _build_data(mode, batch_size, raw_decoder, np_decoder, mixup_alpha, data):
    is_np = data['is_numpy']
    size = len(data['image'])
    images = data['image']
    labels = data['label']
    if not is_np:
        data = tf.data.Dataset.zip((tf.data.Dataset.from_generator(lambda: _gen_(images), tf.string),
                                    tf.data.Dataset.from_generator(lambda: _gen_(labels), tf.int32)))
    else:
        data = tf.data.Dataset.zip((tf.data.Dataset.from_tensor_slices(images),
                                    tf.data.Dataset.from_tensor_slices(labels)))
    data = data.map(lambda x, y: {'image': x, 'label': y}, tf.data.experimental.AUTOTUNE)

    data = data.cache()
    data = data.repeat()
    if mode == 'train':
        data = data.shuffle(min(size, MAX_IN_MEMORY))
    if is_np:
        data = data.map(np_decoder, tf.data.experimental.AUTOTUNE)
    else:
        data = data.map(raw_decoder, tf.data.experimental.AUTOTUNE)

    data = data.batch(batch_size, drop_remainder=True)

    def _mixup(data):
        beta_dist = tfp.distributions.Beta(mixup_alpha, mixup_alpha)
        beta = tf.cast(beta_dist.sample([]), tf.float32)
        data['image'] = (beta * data['image'] +
                         (1 - beta) * tf.reverse(data['image'], axis=[0]))
        data['label'] = (beta * data['label'] +
                         (1 - beta) * tf.reverse(data['label'], axis=[0]))
        return data

    if mixup_alpha is not None and mixup_alpha > 0.0 and mode == 'train':
        data = data.map(_mixup, tf.data.experimental.AUTOTUNE)
    return data


def _build_bit_data(mode, batch_size, resize_size, crop_size, mixup_alpha, data):
    num_classes = data['num_classes']
    def _decode_pp(data):
        file = data['image']
        raw_bytes = tf.io.read_file(file)
        im = tf.io.decode_image(raw_bytes, channels=3)
        im.set_shape([None, None, 3])
        return _pp({'image': im, 'label': data['label']})

    def _pp(data):
        im = data['image']
        if mode == 'train':
            im = tf.image.resize(im, [resize_size, resize_size])
            im = tf.image.random_crop(im, [crop_size, crop_size, 3])
            im = tf.image.flip_left_right(im)
        else:
            # usage of crop_size here is intentional
            im = tf.image.resize(im, [crop_size, crop_size])
        im = (im - 127.5) / 127.5
        label = tf.one_hot(data['label'], num_classes)
        return {'image': im, 'label': label}

    return _build_data(mode, batch_size, _decode_pp, _pp, mixup_alpha, data)


def parse_str(str_x, resize, norm=True):
    def _do_parse(x):
        im = tf.io.decode_image(x, channels=3)
        im.set_shape([None, None, 3])
        im = tf.cast(im, dtype=tf.float32)
        if resize is not None:
            im = tf.image.resize(im, [resize, resize])
        if norm:
            im = (im - 127.5) / 127.5
        else:
            im = tf.image.convert_image_dtype(im, dtype=tf.float32)
        return im

    wrap_layer = tf.keras.layers.Lambda(lambda i: tf.keras.backend.map_fn(_do_parse, i, dtype=tf.float32))
    return wrap_layer(str_x)


def get_bit_data(mode, batch_size,
                 resize_size, crop_size,
                 mixup_alpha,
                 data):
    data = _build_bit_data(mode, batch_size, resize_size, crop_size, mixup_alpha, data)
    return data.prefetch(10)


def get_semi_uda_data(mode, batch_size, resize_size, crop_size,
                      mixup_alpha, unsup_ratio,
                      aug_magnitude, aug_num_layers,
                      sup_data, unsup_data):
    is_np = sup_data['is_numpy']
    size = len(sup_data['image'])
    sup_data = _build_bit_data(mode, batch_size, resize_size, crop_size, mixup_alpha, sup_data)

    # handle unsupervised data
    if mode == 'train' and unsup_ratio > 0 and unsup_data is not None:
        # no unsupervised data for test
        images = unsup_data['image']
        if not is_np:
            unsup_data = tf.data.Dataset.from_generator(lambda: _gen_(images), tf.string)
        else:
            unsup_data = tf.data.Dataset.from_tensor_slices(images)

        unsup_data = unsup_data.cache()
        unsup_data = unsup_data.repeat()
        unsup_data = unsup_data.shuffle(min(size, unsup_ratio * MAX_IN_MEMORY))

        def _decode_unsup_pp(file):
            raw_bytes = tf.io.read_file(file)
            im = tf.io.decode_image(raw_bytes, channels=3)
            im.set_shape([None, None, 3])
            # for aug purpose
            im = tf.cast(im, dtype=tf.float32)
            im = tf.clip_by_value(im, 0, 255)
            im = tf.cast(im, dtype=tf.uint8)
            return _unsup_pp(im)

        def _unsup_pp(ori_im):
            # create aug img
            aug_im = distort_image_with_randaugment(ori_im, aug_num_layers, aug_magnitude)
            aug_im = tf.cast(aug_im, dtype=tf.float32)

            def resize_crop(im):
                im = tf.image.resize(im, [resize_size, resize_size])
                im = tf.image.random_crop(im, [crop_size, crop_size, 3])
                im = tf.image.random_flip_left_right(im)
                im = (im - 127.5) / 127.5
                im = tf.cast(im, dtype=tf.float32)
                return im

            ori_im = resize_crop(ori_im)
            aug_im = resize_crop(aug_im)

            return {"ori_image": ori_im, "aug_image": aug_im}

        if is_np:
            unsup_data = unsup_data.map(_unsup_pp, tf.data.experimental.AUTOTUNE)
        else:
            unsup_data = unsup_data.map(_decode_unsup_pp, tf.data.experimental.AUTOTUNE)
        unsup_data = unsup_data.batch(unsup_ratio * batch_size, drop_remainder=True)

        # merge and flatten sup data and unsup data
        def flatten_input(*features):
            result = {}
            for feature in features:
                for key in feature:
                    assert key not in result
                    result[key] = feature[key]
            return result

        data = tf.data.Dataset.zip((sup_data, unsup_data))
        data = data.map(flatten_input)

    else:
        data = sup_data

    # no need to shard
    # # Shard data such that it can be distributed across devices
    # def _shard(data):
    #     data['image'] = tf.reshape(data['image'],
    #                                [num_devices, -1, crop_size, crop_size, 3])
    #     data['label'] = tf.reshape(data['label'],
    #                                [num_devices, -1, num_classes])
    #     return data
    #
    # if num_devices is not None:
    #     data = data.map(_shard, tf.data.experimental.AUTOTUNE)

    return data.prefetch(10)


def reshape_for_keras(features, batch_size, crop_size):
    features["image"] = tf.reshape(features["image"], (batch_size, crop_size, crop_size, 3))
    features["label"] = tf.reshape(features["label"], (batch_size, -1))
    return (features["image"], features["label"])


def get_multi_crop_data(mode, batch_size, size_crops, nmb_crops,
                          min_scale_crops, max_scale_crops, data):

    assert len(size_crops) == len(nmb_crops)
    assert len(min_scale_crops) == len(nmb_crops)
    assert len(max_scale_crops) == len(nmb_crops)

    def _decode_pp(data):
        file = data
        raw_bytes = tf.io.read_file(file)
        im = tf.io.decode_image(raw_bytes, channels=3)
        im.set_shape([None, None, 3])
        return _pp(im)

    def _pp(data):
        raw_im = data
        # do the multi crop here
        crop_ims = []
        for i in range(len(size_crops)):
            for _ in range(nmb_crops[i]):
                im = raw_im
                im = tf.image.convert_image_dtype(im, dtype=tf.float32)
                im = crop_and_resize_with_scale(im, size_crops[i], size_crops[i],
                                                min_scale_crops[i], max_scale_crops[i])
                # random horizontal flip
                im = tf.image.random_flip_left_right(im)
                # color transform
                im = random_color_jitter(im)
                # gaussian blur
                # TODO CPU 做blur 太慢了， 尝试放在GPU
                im = random_blur(im, size_crops[i], size_crops[i], p=0.5)
                # norm
                # im = (im - 127.5) / 127.5
                crop_ims.append(im)
        return crop_ims

    is_np = data['is_numpy']
    size = len(data['image'])
    images = data['image']
    if not is_np:
        data = tf.data.Dataset.from_generator(lambda: _gen_(images), tf.string)
    else:
        data = tf.data.Dataset.from_tensor_slices(images)

    data = data.cache()
    data = data.repeat()
    if mode == 'train':
        data = data.shuffle(min(size, MAX_IN_MEMORY))
    if is_np:
        data = data.map(_pp, tf.data.experimental.AUTOTUNE)
    else:
        data = data.map(_decode_pp, tf.data.experimental.AUTOTUNE)

    data = data.batch(batch_size, drop_remainder=True)

    return data.prefetch(10)


def get_infomin_data(batch_size, crop_size, resize_size, data, random_aug_num_layer=2,
                     random_aug_mag=10, crop_min_scale=0.2):
    # Info min is self-supervised learning
    def _decode_pp(file):
        raw_bytes = tf.io.read_file(file)
        im = tf.io.decode_image(raw_bytes, channels=3)
        im.set_shape([None, None, 3])
        return _pp(im)

    def _pp(im):
        im = tf.image.convert_image_dtype(im, dtype=tf.float32)
        im = tf.image.resize(im, [resize_size, resize_size])
        ims = []
        for _ in range(2):
            tmp_im = crop_and_resize_with_scale(im, crop_size, crop_size, crop_min_scale, 1)
            # random horizontal flip
            tmp_im = tf.image.random_flip_left_right(tmp_im)
            # color transform ( gray is included)
            tmp_im = random_color_jitter(tmp_im, p=0.8)
            # gaussian blur
            tmp_im = random_blur(tmp_im, crop_size, crop_size, p=0.5)
            # do rand aug
            tmp_im = distort_image_with_randaugment(tmp_im, random_aug_num_layer, random_aug_mag)
            ims.append(tmp_im)
        return tuple(ims)

    is_np = data['is_numpy']
    size = len(data['image'])
    images = data['image']
    if not is_np:
        data = tf.data.Dataset.from_generator(lambda: _gen_(images), tf.string)
    else:
        data = tf.data.Dataset.from_tensor_slices(images)

    data = data.cache()
    data = data.repeat()
    data = data.shuffle(min(size, MAX_IN_MEMORY))
    if is_np:
        data = data.map(_pp, tf.data.experimental.AUTOTUNE)
    else:
        data = data.map(_decode_pp, tf.data.experimental.AUTOTUNE)

    data = data.batch(batch_size, drop_remainder=True)

    return data.prefetch(10)



