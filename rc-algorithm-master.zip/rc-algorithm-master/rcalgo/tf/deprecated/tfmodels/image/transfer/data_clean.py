import os
import sys

from rcalgo.tf.tftraining.incremental_training import IncrementalTraining
from rcalgo.tf.tftraining.train_data import *
from tqdm import tqdm_notebook as tqdm

import numpy as np

sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../../"))


def compute_probs(filepaths, ckpt_path=None, pb_path=None):
    if ckpt_path is not None:
        dir_name = os.path.dirname(ckpt_path)
        job = IncrementalTraining(dir_name, ckpt_path.split('/')[-1])
        session = job.session

    else:
        session = None

    file_obj = BytesObject(filepaths)
    file_data = FusionTrainingData(file_obj, batch_size=128, test_size=0, limit=len(filepaths),
                                   shuffle=False, thread_cnt=4, queue_limit=100)
    iterator = file_data.create_iterator()
    with session.graph.as_default():
        oup = tf.get_collection('output_dict')[0]
        inp = tf.get_collection('input_dict')[0]
        probs = []
        for _, batch in tqdm(iterator):
            probs.append(session.run(oup, {inp: batch[0]}))
        probs = np.concatenate(probs, axis=0)
    return probs


def filter_by_threshold(raw_data, raw_labels, probs, threshold):
    # the prediction == raw label and prob > threshold
    probs = np.array(probs)
    raw_labels = np.array(raw_labels)
    idxs = np.argmax(probs, axis=1)
    mask_a = raw_labels == idxs
    mask_b = np.max(probs, axis=1) >= threshold
    idxs = np.where(mask_a & mask_b)
    probs = probs[idxs]
    raw_labels = raw_labels[idxs]
    raw_data = [raw_data[i] for i in idxs]
    return raw_data, raw_labels, probs














