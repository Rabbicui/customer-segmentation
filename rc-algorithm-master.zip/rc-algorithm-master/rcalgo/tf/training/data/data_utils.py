# coding: utf-8
import numpy as np
from mpi4py import MPI


def split_data(features, test_size, sync=False):
    features = [np.array(feature) if isinstance(feature, list) else feature for feature in features]
    n_examples = features[0].shape[0]
    train_size = int(n_examples * (1 - test_size))

    indices = np.random.permutation(n_examples)
    if sync:
        comm = MPI.COMM_WORLD
        comm.Bcast(indices, root=0)
    train_idx, test_idx = indices[:train_size], indices[train_size:]
    train_features = [feature[train_idx] for feature in features]
    test_features = [feature[test_idx] for feature in features]
    return train_features, test_features
