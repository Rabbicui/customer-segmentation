import tensorflow as tf
from rcalgo.tf.training.model import ModelWrapper
from rcalgo.tf.metric.loss import l2_loss


class SemiSupervisor(ModelWrapper):
    """
    Semi-Supervised learner basic class.
    Most Semi-supervised framework has a executing model (except co-training).
    Thus it is inherited from `ModelWrapper`.
    """
    def __init__(self, execute_model, **kwargs):
        config = kwargs.get("config", dict())
        self.unsup_coeff = config.get("unsup_coeff", 1)  # 无监督损失的权重
        self.p_coef = config.get('p_coef', 0.)
        self.sup_loss = None
        self.unsup_loss = None

        super(SemiSupervisor, self).__init__(execute_model, **kwargs)

    def compute_sup_loss(self, states, labels):
        """
        Compute the supervised loss.
        Args:
            states: list of float tensors.
            labels: list of float tensors.

        Returns:
            float tensor.
        """
        raise NotImplementedError

    def compute_unsup_loss(self, states, labels):
        """
        Compute the unsupervised loss.
        Args:
            states: list of float tensors.
            labels: list of float tensors.

        Returns:
            float tensor.
        """
        raise NotImplementedError

    def _penalty(self):
        p_loss = self.p_coef * l2_loss()
        return p_loss

    def compute_loss(self, states, labels):
        """
        loss = supervised loss + unsupervised loss
        Args:
            states: list of float tensors.
            labels: list of float tensors.

        Returns:
            float tensor.
        """
        sup_loss = self.compute_sup_loss(states, labels)
        unsup_loss = self.compute_unsup_loss(states, labels)
        self.sup_loss = sup_loss
        self.unsup_loss = unsup_loss
        penalty_loss = self._penalty()
        loss = tf.identity(sup_loss + self.unsup_coeff * unsup_loss + penalty_loss, name="semi-sup-loss")
        return loss
