import os
import sys
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../../"))

import tensorflow as tf
from rcalgo.tf.tftraining.tf_object import TFModel
from tftools.tf_layer import my_conv_2d
from tftools.tf_layer import my_full_connected
from tftools.tf_layer import my_pool_layer_2d
from tftools.tf_func import my_compute_grad
from tftools.tf_func import replace_default_graph

class ImageModel(TFModel):

    def __init__(self, config, graph):
        super(ImageModel, self).__init__(config, graph)
        self._init_std = config.init_std
        self._use_byte_input = config.image_byte_input
        self._channel_num = config.image_channel_num
        self._resize_to = config.image_resize_to

    def _build_image_input(self):
        if self._use_byte_input:
            byte_inputs = tf.placeholder(tf.string, [None], name='image_byte_inputs')
            self._add_to_graph_inputs(byte_inputs)
            self.split_byte_inputs = tf.split(byte_inputs, self.gpu_num)
            self._add_to_graph_input_dict(self.split_byte_inputs[0])
        else:
            pixel_inputs = tf.placeholder(tf.float32, [None, None, None, self._channel_num],
                                          name='image_pixel_inputs')
            self._add_to_graph_inputs(pixel_inputs)
            self.split_pixel_inputs = tf.split(pixel_inputs, self.gpu_num)
            self._add_to_graph_input_dict(self.split_pixel_inputs[0])

    def _build_label_input(self):
        labels = tf.placeholder(tf.int32, [None], name='label')
        self.split_labels = tf.split(labels, self.gpu_num)
        self._add_to_graph_targets(labels)

    def build_input(self):
        self._build_image_input()
        self._build_label_input()
        with tf.name_scope('nets'):
            self.nets = [None for _ in range(self.gpu_num)]

    def _decode_image(self, gpu_id):
        def decode(raw_bytes):
            image = tf.io.decode_image(raw_bytes, channels=self._channel_num)
            image.set_shape([None, None, self._channel_num])
            return tf.image.resize(image, [self._resize_to, self._resize_to])

        if self._use_byte_input:
            inputs = tf.map_fn(decode, self.split_byte_inputs[gpu_id], dtype=tf.float32)
        else:
            inputs = self.split_pixel_inputs[gpu_id]
            inputs = tf.image.resize(inputs, [self._resize_to, self._resize_to])
        return inputs


    def build_classification_model(self, gpu_id=0):
        # inception v3 model
        inputs = self._decode_image(gpu_id)
        inputs = inputs / 255.0
        net = my_conv_2d(inputs, 32, [3, 3], strides=2, bn=True, training=self.training,
                         padding='VALID')
        net = my_conv_2d(net, 32, [3, 3], bn=True, training=self.training, padding='VALID')
        net = my_conv_2d(net, 64, [3, 3], bn=True, training=self.training, padding='SAME')
        net = my_pool_layer_2d(net, k=3, stride=2)
        net = my_conv_2d(net, 80, [1, 1], bn=True, training=self.training, padding='VALID')
        net = my_conv_2d(net, 192, [3, 3], bn=True, training=self.training, padding='VALID')
        net = my_pool_layer_2d(net, k=3, stride=2)

        # net is 35 * 35 * 192
        # do mix 1
        # depth: -1 is max pool -2 is avg pool
        # ops: 1 is concat
        def mix(net,
                depths=[[64], [48, 64], [64, 96, 96], [-1, 32]],
                kernel_sizes_l=[[1], [1, 5], [1, 3, 3], [3, 1]],
                kernel_sizes_r=[[1], [1, 5], [1, 3, 3], [3, 1]],
                paddings=None,
                strides=None,
                ops=None):
            branches = []
            stride_idx = 0
            if kernel_sizes_r is None:
                kernel_sizes_r = kernel_sizes_l

            def fill(value):
                values = []
                for da in depths:
                    values.append(len(da) * [value])
                return values

            if ops is None:
                ops = fill(0)
            if paddings is None:
                paddings = fill('SAME')
            if strides is None:
                strides = fill(1)
            for depth_arr, kernel_size_arr_l, kernel_size_arr_r, pad_arr, op_arr, stride_arr in zip(
                    depths, kernel_sizes_l, kernel_sizes_r, paddings, ops, strides):
                branch = net
                to_concat = []
                for depth, ks_l, ks_r, pad, op, stride in zip(depth_arr, kernel_size_arr_l,
                                                              kernel_size_arr_r, pad_arr, op_arr,
                                                              stride_arr):
                    if depth == -1:
                        tmp = my_pool_layer_2d(branch, ks_l, stride=stride, padding=pad)
                        stride_idx += 1
                    elif depth == -2:
                        tmp = my_pool_layer_2d(branch, ks_l, stride=stride, act=tf.nn.avg_pool, padding=pad)
                        stride_idx += 1
                    else:
                        tmp = my_conv_2d(branch, depth, [ks_l, ks_r], bn=True, padding=pad,
                                         strides=stride, training=self.training)
                    if op == 1:
                        to_concat.append(tmp)
                    else:
                        branch = tmp
                if len(to_concat) > 0:
                    branches.append(tf.concat(to_concat, axis=3))
                else:
                    branches.append(branch)
            return tf.concat(branches, axis=3)

        net = mix(net)
        net = mix(net, depths=[[64], [48, 64], [64, 96, 96], [-2, 64]])
        net = mix(net, depths=[[64], [48, 64], [64, 96, 96], [-2, 64]])
        net = mix(net, depths=[[384], [64, 96, 96], [-1]],
                  kernel_sizes_l=[[3], [1, 3, 3], [3]],
                  kernel_sizes_r=[[3], [1, 3, 3], [3]],
                  strides=[[2], [1, 1, 2], [2]],
                  paddings=[['VALID'], ['SAME', 'SAME', 'VALID'], ['VALID']])
        net = mix(net, depths=[[192], [128, 128, 192], [128, 128, 128, 128, 192], [-2, 192]],
                  kernel_sizes_l=[[1], [1, 1, 7], [1, 7, 1, 7, 1], [3, 1]],
                  kernel_sizes_r=[[1], [1, 7, 1], [1, 1, 7, 1, 7], [3, 1]])
        net = mix(net, depths=[[192], [160, 160, 192], [160, 160, 160, 160, 192], [-2, 192]],
                  kernel_sizes_l=[[1], [1, 1, 7], [1, 7, 1, 7, 1], [3, 1]],
                  kernel_sizes_r=[[1], [1, 7, 1], [1, 1, 7, 1, 7], [3, 1]])
        net = mix(net, depths=[[192], [160, 160, 192], [160, 160, 160, 160, 192], [-2, 192]],
                  kernel_sizes_l=[[1], [1, 1, 7], [1, 7, 1, 7, 1], [3, 1]],
                  kernel_sizes_r=[[1], [1, 7, 1], [1, 1, 7, 1, 7], [3, 1]])
        net = mix(net, depths=[[192], [192, 192, 192], [192, 192, 192, 192, 192], [-2, 192]],
                  kernel_sizes_l=[[1], [1, 1, 7], [1, 7, 1, 7, 1], [3, 1]],
                  kernel_sizes_r=[[1], [1, 7, 1], [1, 1, 7, 1, 7], [3, 1]])
        net = mix(net, depths=[[192, 320], [192, 192, 192, 192], [-1]],
                  kernel_sizes_l=[[1, 3], [1, 1, 7, 3], [3]],
                  kernel_sizes_r=[[1, 3], [1, 7, 1, 3], [3]],
                  strides=[[1, 2], [1, 1, 1, 2], [2]], paddings=[['SAME', 'VALID'],
                                                                 ['SAME', 'SAME', 'SAME', 'VALID'],
                                                                 ['VALID']])
        net = mix(net, depths=[[320], [384, 384, 384], [448, 384, 384, 384], [-2, 192]],
                  kernel_sizes_l=[[1], [1, 1, 3], [1, 3, 1, 3], [3, 1]],
                  kernel_sizes_r=[[1], [1, 3, 1], [1, 3, 3, 1], [3, 1]],
                  ops=[[0], [0, 1, 1], [0, 0, 1, 1], [0, 0]])
        net = mix(net, depths=[[320], [384, 384, 384], [448, 384, 384, 384], [-2, 192]],
                  kernel_sizes_l=[[1], [1, 1, 3], [1, 3, 1, 3], [3, 1]],
                  kernel_sizes_r=[[1], [1, 3, 1], [1, 3, 3, 1], [3, 1]],
                  ops=[[0], [0, 1, 1], [0, 0, 1, 1], [0, 0]])
        # max pooling
        net = my_pool_layer_2d(net, 8)
        net = tf.reshape(net, [-1, 2048])
        self.nets[gpu_id] = net

    def build_prediction(self, gpu_id=0, num_classes=10, accK=1):
        prediction = my_full_connected(self.nets[gpu_id], num_classes, init_std=self._init_std,
            weights_initializer=tf.contrib.layers.variance_scaling_initializer())
        self.tower_prediction_results.append(tf.nn.softmax(prediction))
        if gpu_id == 0:
            self.output_dict['result'] = self.tower_prediction_results[0]
        with tf.name_scope('loss'):
            loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.split_labels[gpu_id],
                                                                  logits=prediction)
            loss = tf.reduce_mean(loss)
            grads, capped_gvs = my_compute_grad(self.opt, loss, self.params,
                                                clip_type='clip_value',
                                                task=self.default_task_name,
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            labels = self.split_labels[gpu_id]
            accuracy = tf.to_float(tf.nn.in_top_k(prediction, labels, k=accK))
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task=self.default_task_name)

    @replace_default_graph
    def build_model(self, num_classes=10, accK=1, *args, **kwargs):
        self.build_input()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('{}{}'.format(self.device_str, gpu_id)):
                with tf.name_scope('Tower_{}'.format(idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_classification_model(gpu_id=idx)
                        self.build_prediction(gpu_id=idx, num_classes=num_classes, accK=accK)
        self.build_model_aggregation()
        self._add_to_graph_outputs(self.prediction_results)
