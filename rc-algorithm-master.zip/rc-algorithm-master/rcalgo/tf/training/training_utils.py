import tensorflow.compat.v1 as tf
from tensorflow.python.framework import ops

from rcalgo.tf.utils import tf_collections
from rcalgo.tf.utils.logging import logger


def get_from_task_collection(name, collection, graph=None):
    """Get an attribute from collections."""
    key = "{}_{}".format(name, collection) if name is not None else collection
    return tf.get_collection(key) if graph is None else graph.get_collection(key)


def clear_task_collection(name, collection):
    """Clear attribute of a collection."""
    graph = tf.get_default_graph()
    key = "{}_{}".format(name, collection)
    graph.clear_collection(key)


def add_to_task_collection(name, collection, var_list, graph=None):
    if var_list is None:
        return
    key = "{}_{}".format(name, collection) if name is not None else collection
    if not isinstance(var_list, (list, tuple)):
        if graph is None:
            tf.add_to_collection(key, var_list)
        else:
            graph.add_to_collection(key, var_list)
    else:
        for each_input in var_list:
            if graph is None:
                tf.add_to_collection(key, each_input)
            else:
                graph.add_to_collection(key, each_input)


def set_task_collection(name, collection, var_list, graph=None):
    clear_task_collection(name, collection)
    add_to_task_collection(name, collection, var_list, graph)


def set_current_task(name, graph=None):
    graph = tf.get_default_graph() if graph is None else graph
    graph.clear_collection(tf.GraphKeys.CURRENT_TASK)
    graph.add_to_collection(tf.GraphKeys.CURRENT_TASK, name)


def get_tasks_in_graph():
    task_collection = [name.decode() if isinstance(name, bytes) else name
                       for name in tf.get_collection(tf.GraphKeys.TASKS)]
    return task_collection


def create_task_in_graph(inputs=[],
                         outputs=[],
                         labels=[],
                         loss=None,
                         metrics=[],
                         train_op=None,
                         lr_variable=None,
                         tvars=None,
                         name="default"):
    """Create a task in current graph."""
    if name in get_tasks_in_graph():
        raise KeyError(f'名为{name}的模型已存在! \n'
                       f'如果要覆盖之前的模型，可以使用model.build_model(clear_session=True);\n'
                       f'如果是要创建多个模型，请在构造函数中给它们指定不同的name参数;')
    else:
        tf.add_to_collection(tf.GraphKeys.TASKS, name)

    tvars = tf.trainable_variables() if tvars is None else tvars
    collections = [
       tf.GraphKeys.INPUTS,
       tf.GraphKeys.OUTPUTS,
       tf.GraphKeys.TARGETS,
       tf.GraphKeys.LOSS,
       tf.GraphKeys.METRICS,
       tf.GraphKeys.TRAIN_OPS,
       tf.GraphKeys.LR_VARIABLES,
       tf.GraphKeys.TVARS
    ]
    var_lists = [inputs, outputs, labels, loss, metrics, train_op,
                 lr_variable, tvars]
    for collection, var_list in zip(collections, var_lists):
        if var_list is not None:
            set_task_collection(name, collection, var_list)


def set_task_opt_params(name, opt_params):
    if opt_params is not None:
        for key in opt_params.__dict__:
            add_to_task_collection(
                name, tf.GraphKeys.OPT_PARAMS,
                ops.convert_to_tensor(opt_params.__dict__[key], name=key))


def set_task_learning_rate(name, learning_rate):
    if tf.is_tensor(learning_rate) is not True:
        learning_rate = tf.convert_to_tensor(learning_rate)
    set_task_collection(name, tf.GraphKeys.LR_VARIABLES, learning_rate)


def set_task_train_op(name, train_op):
    set_task_collection(name, tf.GraphKeys.TRAIN_OPS, train_op)


def set_task_train_op_and_lr(name, train_op, learning_rate):
    set_task_train_op(name, train_op)
    set_task_learning_rate(name, learning_rate)


def set_task_tvars(name, tvars):
    set_task_collection(name, tf.GraphKeys.TVARS, tvars)


def add_task_extra_attr(name, key, values):
    attr_key = "attr_{}".format(key)
    set_task_collection(name, attr_key, values)
    if key not in get_from_task_collection(name, tf.GraphKeys.ATTRS):
        add_to_task_collection(name, tf.GraphKeys.ATTRS, key)


def get_task_extra_attrs(name):
    """
    Get extra attributes from graph collection
    """
    attrs = {}
    keys = get_from_task_collection(name, tf.GraphKeys.ATTRS)
    for key in keys:
        if isinstance(key, bytes):
            key = key.decode()
        attr_key = "attr_{}".format(key)
        values = get_from_task_collection(name, attr_key)
        attrs[key] = values
    return attrs


def get_lr_from_optimizer(optimizer):
    # TODO: some optmizers may not compatible with this.
    learning_rate = optimizer._lr
    return learning_rate


def get_or_create_is_training():
    """create is_training placeholder
    """
    mode = tf.get_collection_ref(tf.GraphKeys.IS_TRAINING)
    if len(mode) < 1:
        # mode_tensor = tf.placeholder(tf.string, name="global_mode")
        mode_tensor = tf.placeholder_with_default(
            input=tf.constant(False),
            shape=(),
            name="is_training")
        mode.append(mode_tensor)
    return mode[0]
