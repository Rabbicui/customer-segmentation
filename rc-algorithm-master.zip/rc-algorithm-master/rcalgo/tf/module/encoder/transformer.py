import numpy as np
import tensorflow as tf
from tensorflow.python.ops import array_ops

from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.utils.tf_func import shape_list, get_new_variable_scope, fp32_storage_getter
from rcalgo.tf.module.layer.activations import gelu
from rcalgo.tf.module.layer.basic import my_dropout, my_conv_1d, my_layer_norm
from rcalgo.tf.module.layer.attention import multi_head_attention
from rcalgo.tf.module.embedder.position_embedding import position_embedding


def ffn_mlp(input_tensor, n_state, layer_name='ffn_mlp', act=gelu, ffn_drop=0.1,
            training=False, scope=None, reuse=False):
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        h = act(my_conv_1d(input_tensor, 1, n_state, act=tf.identity, layer_name="conv_before"))
        re_input_tensor = my_dropout(my_conv_1d(h, 1, shape_list(
            input_tensor)[-1], act=tf.identity, layer_name="conv_after"), ffn_drop, training)
        return re_input_tensor


def transformer_block(input_tensor, n_head,
                      attn_drop=0.1, scale=True, mask=True,
                      ffn_act=gelu, ffn_drop=0.1,
                      use_t2t_transformer=False,
                      layer_name='transform2_block', scope=None, reuse=False,
                      training=False):
    """
    https://arxiv.org/pdf/1801.10198.pdf
    """
    if isinstance(training, bool):
        training = tf.convert_to_tensor(training)
    # tensor2tensor中的实际顺序不太一样
    def identity(x, layer_name=None):
        return tf.identity(x, name=layer_name)

    if use_t2t_transformer:
        fun_list = [my_layer_norm, identity]
    else:
        fun_list = [identity, my_layer_norm]
        
    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse)
    with vscope as scope:
        n_state = shape_list(input_tensor)[-1]
        m_head_attn = multi_head_attention(
            fun_list[0](input_tensor, layer_name="func_0_0"), n_state, n_head, attn_drop=attn_drop,
            scale=scale, mask=mask, training=training)
        m_head_attn_ln = fun_list[1](input_tensor+m_head_attn, layer_name="func_1_0")
        m_head_attn_ln_ffn = ffn_mlp(
            fun_list[0](m_head_attn_ln, layer_name="func_0_1"), n_state*4, act=ffn_act, ffn_drop=ffn_drop, training=training)
        t_block = fun_list[1](m_head_attn_ln+m_head_attn_ln_ffn, layer_name="func_1_1")
        return t_block
    
    
def conv_transformer_layer(input_tensor, num_layers, seq_len, conv_num_filters,
                           conv_length_list, combine_mode='ADD', output_reduce_size=0,
                           reverse=False, position_info=False, *args, **kwargs):
    """
    Position embedding + conv + transformer
    Main Args:
      input_tensor: the input tensor [batch, d1, d2 ...]
      num_layers: the number of transformer block
      seq_len: the seq length [batch]
      conv_num_filters:  conv parameter
      conv_length_list:  conv parameter
    Returns:
      A Tensor, Dimension: [batch, d1 * d2 * ..]
    """
    # 翻转部分
    if reverse:
        state = array_ops.reverse_sequence(
            input=input_tensor, seq_lengths=seq_len, seq_axis=1, batch_axis=0)
    else:
        state = input_tensor
    # conv部分
    try:
        state = multi_width_cnn_block(state, conv_num_filters, conv_length_list,
                                      combine_mode=combine_mode, padding='LEFT_SAME', act=tf.nn.relu)
    except ValueError:
        state = state
    batch, maxlen, hidden_size = shape_list(state)  
    # position embedding部分
    if position_info:
        state = state + position_embedding(maxlen, hidden_size, seq_len)
    # Transformer block
    for layer in range(num_layers):
        state = transformer_block(state, *args, layer_name=f'transform2_block_l{layer}', **kwargs)
    # attempt to reduce output dimension
    if output_reduce_size < hidden_size and output_reduce_size != 0:
        # conv1d dim reduce
        state = my_conv_1d(state, 1, output_reduce_size, act=tf.identity)
        state = my_layer_norm(state, layer_name="layer_norm_reduce") 
        state = transformer_block(state, *args, layer_name=f'transform2_block_reduce', **kwargs)
        hidden_size = output_reduce_size
    # select
    flat_state = tf.reshape(state, [-1, hidden_size])
    gather_idx = tf.range(batch, dtype=tf.int32)*maxlen + \
        tf.cast(seq_len, tf.int32) - 1
    output = tf.gather(flat_state, gather_idx)
    # reverse the sequence
    if reverse:
        state = array_ops.reverse_sequence(
            state, seq_lengths=seq_len, seq_axis=1, batch_axis=0)
    # zero mask the seq
    mask = array_ops.sequence_mask(seq_len, maxlen, dtype=get_default_float_type())
    mask = array_ops.tile(array_ops.expand_dims(mask, [-1]), [1, 1, hidden_size])
    state *= mask
    return state, output


def bi_conv_transformer_layer(input_tensor, num_layers, seq_len, conv_num_filters,
                              conv_length_list, combine_mode="ADD", output_reduce_size=0, *args, **kwargs):
    with get_new_variable_scope('bidirectional_transformer') as rnn_scope:
        with get_new_variable_scope('transformer_fw') as rnn_scope:
            output_fw, output_state_fw = conv_transformer_layer(
                input_tensor, num_layers, seq_len, conv_num_filters,
                conv_length_list, combine_mode, output_reduce_size, reverse=False, *args, **kwargs)
        with get_new_variable_scope('transformer_bw') as rnn_scope:
            output_bw, output_state_bw = conv_transformer_layer(
                input_tensor, num_layers, seq_len, conv_num_filters,
                conv_length_list, combine_mode, output_reduce_size, reverse=True, *args, **kwargs)
        outputs = (output_fw, output_bw)
        output_states = (output_state_fw, output_state_bw)
        return (outputs, output_states)


################################################   Conv  block  ################################################
def multi_width_cnn_block(input_tensor, num_filters, conv_length_list=[2,3,4,5], combine_mode='ADD',
                          padding='VALID', act=tf.nn.relu, layer_name='mw_conv_block',
                          scope=None, reuse=False):

    vscope = get_new_variable_scope(layer_name, scope, reuse=reuse, custom_getter=fp32_storage_getter)
    outputs = []
    if isinstance(conv_length_list, int):
        conv_length_list = [conv_length_list]
    if isinstance(conv_length_list, str):
        conv_length_list = np.fromstring(conv_length_list, dtype=np.int32, sep=',')
    with vscope as scope:
        for conv_length in conv_length_list:
            outputs.append(my_conv_1d(input_tensor, conv_length,
                                      num_filters, add_bias=True, bn=False,
                                      padding=padding, act=act, layer_name=f"conv_1d_{conv_length}"))
        if padding != 'VALID':
            if combine_mode == 'ADD':
                return tf.add_n(outputs)
            elif combine_mode == 'CONCAT':
                return tf.concat(outputs, axis=2)
            elif combine_mode == 'POOL':
                return tf.reduce_max(outputs, axis=0)
            else:
                raise NotImplementedError
        else:
            return outputs

