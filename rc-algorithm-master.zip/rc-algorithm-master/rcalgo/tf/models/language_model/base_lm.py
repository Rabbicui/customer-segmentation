import tensorflow as tf
from rcalgo.tf.training.model import Model
from rcalgo.tf.module.layer.preprocessing import TFCharSequencePreprocessor
from rcalgo.tf.module.embedder.basic_embedding import my_embedding_layer
from rcalgo.tf.utils.tf_float_type import get_default_float_type
from rcalgo.tf.metric.accuracy import varibale_topk_accuracy
from rcalgo.tf.training import training_utils
from rcalgo.tf.utils.tf_func import get_new_variable_scope, shape_list
from rcalgo.tf.training.training_utils import get_or_create_is_training
from tensorflow.python.ops.candidate_sampling_ops import learned_unigram_candidate_sampler
from rcalgo.tf.metric.loss import my_sparse_cross_entropy_loss


class LanguageModel(Model):
    def __init__(self, config, word_dict, **kwargs):
        super(LanguageModel, self).__init__(config, **kwargs)

        self.oov_buckets = config.get("oov_buckets", 10)
        self.max_seq_len = config.get("max_seq_len", 128)
        self.embedding_size = config.get("embedding_size", 256)
        self.init_scale = config.get("init_scale", 1.0)
        self.init_std = config.get("init_std", 0.05)
        self.num_layers = config.get("num_layers", 2)
        self.num_sampled = config.get("num_sampled", 500)
        self.sampled_softmax = config.get("sampled_softmax", True)
        self.mark_boundary = config.get("mark_boundary", False)
        self.acc_k = config.get("acc_k", 1)

        self.preprocessor = TFCharSequencePreprocessor(
            word_dict, self.oov_buckets, self.mark_boundary)
        self.nb_words = self.preprocessor.nb_words

        self.ffn = tf.keras.layers.Dense(self.nb_words)
        self.is_training = get_or_create_is_training()

    def create_inputs(self):
        text = tf.compat.v1.placeholder(dtype=tf.string, shape=[None], name='input_text')
        return text

    def compute_metrics(self, outputs, labels):
        return varibale_topk_accuracy(outputs, labels, k=self.acc_k)


    def call(self, inputs):
        sequence, seq_lengths = self.preprocessor(self.inputs, max_length=self.max_seq_len)
        embedding = my_embedding_layer(
            sequence, self.nb_words, self.embedding_size,
            variables_collections="encoder_embedding",
            layer_name="embedding_layer",
            init_scale=self.init_scale,
            dtype=get_default_float_type())

        states, outputs, targets = self.build_lm_representation(sequence, embedding, seq_lengths)

        states, targets = self.convert_list(states, targets)
        logits = self.compute_logits(states)
        return [states, logits, targets], [states, logits, outputs]

    def compute_logits(self, inputs):
        inputs_shape = shape_list(inputs)
        inputs_flat = tf.reshape(inputs, [-1, inputs_shape[-1]])
        logits = self.ffn(inputs_flat)

        if len(inputs_shape) == 3:
            logits = tf.reshape(logits, [-1, inputs_shape[-2], self.nb_words])
        return logits

    def compute_loss(self, logits, labels):
        inputs_flat, raw_logits = logits
        with get_new_variable_scope('loss'):
            weights, bias = self.ffn.weights
            sampled_softmax_loss, full_softmax_loss = self._seq_sampled_softmax_loss(inputs_flat, raw_logits,
                                                                                     weights, bias, labels,
                                                                                     self.nb_words,
                                                                                     self.num_sampled)
        if self.sampled_softmax:
            loss = sampled_softmax_loss
        else:
            loss = full_softmax_loss

        loss = tf.reduce_mean(loss)
        return loss

    def add_extra_attrs(self, logits):
        states, raw_logits = logits[0], logits[1]
        self.add_extra_attr("states", states)
        self.add_extra_attr("logits", raw_logits)

    def _seq_sampled_softmax_loss(self, inputs, logits, weights, biases, labels, num_classes, num_sampled,
                                  sampler_func=learned_unigram_candidate_sampler,
                                  num_true=1, label_smooth=0.0, label_indices=None):
        """
        compute softmax loss
        Args:
            inputs: [None, hidden_size]
            logits:
            weights:
            biases:
            labels: [None]
            num_classes: vocab size
            num_sampled:
            sampler_func:
            num_true:
            label_smooth:
            label_indices:

        Returns:
            sampled softmax loss and full softmax loss

        """
        # 获取非0的位置，从而减少计算loss的时候的计算量
        if label_indices is None:
            label_mask = tf.cast(tf.sign(tf.abs(labels)), dtype=tf.int32)
            label_indices = tf.reshape(tf.compat.v2.where(tf.not_equal(label_mask, tf.constant(0, label_mask.dtype))),
                                       [-1])
        # 获取真实的需要计算的inputs和labels
        inputs_true = tf.gather(inputs, label_indices)
        labels_reshape = tf.reshape(tf.gather(labels, label_indices), [-1, 1])
        # sampler function
        # more details: https://www.orchome.com/1574
        sampled_values = sampler_func(
            labels_reshape, num_true, num_sampled, True, num_classes)
        sampled_softmax_loss = tf.nn.sampled_softmax_loss(tf.transpose(weights), biases, labels_reshape,
                                                          inputs_true, num_sampled, num_classes,
                                                          num_true, sampled_values)
        full_softmax_loss = my_sparse_cross_entropy_loss(
            labels, logits, num_classes, label_smooth)

        return sampled_softmax_loss, full_softmax_loss

    def build_forward(self, **kwargs):
        """Build forward propagation."""
        self.inputs = self.create_inputs()
        mid_tensors, self.outputs = self.call(self.inputs, **kwargs)
        states, logits, targets = mid_tensors

        inputs_shape = shape_list(states)
        inputs_flat = tf.reshape(states, [-1, inputs_shape[-1]])
        labels_flat = tf.reshape(targets, [-1])

        self.loss = self.compute_loss([inputs_flat, logits], labels_flat)
        self.metrics = self.compute_metrics(self.outputs[1], targets)
        self.add_extra_attrs(logits)

        training_utils.create_task_in_graph(
            self.inputs, self.outputs, self.labels, self.loss,
            self.metrics, name=self.name)

    def convert_list(self, states, targets):
        if isinstance(states, list) and len(states) == 2:  # bi-directional network
            states = tf.concat(states, axis=0)  # [2*bs, maxlen, hidden_size]
            targets = tf.concat(targets, axis=0)  # [2*bs, maxlen]
        return states, targets

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        """
        build forward network
        Args:
            sequence: input text with word_id
            embedding: input embedding
            seq_lengths: input sequence lengths

        Returns:
            states and outputs
        """
        raise NotImplementedError
