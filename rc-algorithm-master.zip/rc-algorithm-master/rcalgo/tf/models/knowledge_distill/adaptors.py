import re
import tensorflow as tf


class BaseAdaptor(object):
    def __call__(self, *args, **kwargs):
        return self.call(*args, **kwargs)

    def call(self, model):
        raise NotImplementedError


class BasicAdaptor(BaseAdaptor):
    def call(self, model):
        return {
            "logits": model.extra_attrs["logits"][0]
        }


class GoogleBertAdaptor(BaseAdaptor):
    def call(self, model):
        return {
            "loss": model.loss,
            "logits": model.extra_attrs["logits"][0],
            "embeddings": model.extra_attrs["embeddings"][0],
            "hidden_layers": model.extra_attrs["hidden_layers"],
            "attentions": model.extra_attrs["attentions"]
        }


class KwaiBertMetaGraphAdaptor(BaseAdaptor):
    def __init__(self, scope="", tower=None):
        self.tower_prefix = "Tower_%s" % tower if tower is not None else ""
        self.scope = scope

    def call(self, model):
        logits = model.extra_attrs["logits"]

        # emb_pattern = ".*Tower_0/gpu/embedding/embedding_layer/embedding_lookup:0"
        emb_pattern = "%s.*embedding_layer/embedding_table:0" % self.scope
        embeddings = [
            t
            for t in tf.contrib.graph_editor.get_tensors(tf.get_default_graph())
            if re.match(emb_pattern, t.name)]

        # hidden_pattern = "%s.*Tower_0/gpu/bidirectional_transformer/transformer_../transform2_block.*/ln_layer_1/add_1:0" % self.scope
        hidden_pattern = "%s/%s.*transform2_block.*/ln_layer_1/add_1:0" % (self.scope, self.tower_prefix)
        hidden_layers = [
            t
            for t in tf.contrib.graph_editor.get_tensors(tf.get_default_graph())
            if re.match(hidden_pattern, t.name)]

        # attn_pattern = "%s.*Tower_0/gpu/bidirectional_transformer/transformer_../transform2_block.*/multi_head_attention/truediv:0" % self.scope
        attn_pattern = "%s/%s.*transform2_block.*/multi_head_attention/truediv:0" % (self.scope, self.tower_prefix)
        attentions = [
            t
            for t in tf.contrib.graph_editor.get_tensors(tf.get_default_graph())
            if re.match(attn_pattern, t.name)]
        return {
            "loss": model.loss,
            "logits": logits[0],
            "embedding": embeddings[0],
            "hidden_layers": hidden_layers,
            "attentions": attentions
        }


class TransformerAdaptor(BaseAdaptor):
    def call(self, model):
        return {
            "loss": model.loss,
            "logits": model.extra_attrs["logits"][0]
        }
