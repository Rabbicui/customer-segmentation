import re
import tensorflow as tf

from rcalgo.tf.training import context
from rcalgo.tf.training.model import Model
from rcalgo.tf.training.training_utils import get_or_create_is_training
from rcalgo.tf.module.layer.basic import my_dropout, my_conv_1d, my_full_connected


class TransferModel(Model):
    def __init__(self, config={}, **kwargs):
        super(TransferModel, self).__init__(config=config, **kwargs)

        self.original_ckpt_path = config.get("original_ckpt_path", None)
        self.input_index = config.get("input_index", 0)
        self.output_index = config.get("output_index", 0)

        self.clear_devices = config.get("clear_devices", True)
        self.fix_lm_layer = config.get("fix_lm_layer", False)

        self.num_classes = config.get("num_classes", 2)
        self.learning_rate = config.get("learning_rate", 0.0001)

    def create_inputs(self):
        # here we use the placeholder of original model as input
        # if you need to use additional placeholder, just create it here
        input_text = tf.compat.v1.get_collection("input_dict")[self.input_index]
        label = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None], name='input_label')
        return input_text, label

    def call(self, inputs):
        original_output = tf.compat.v1.get_collection("output_dict")[self.output_index]
        return original_output, original_output

    def filter_trainable_variables(self, tvars):
        """Fix pretrained variables."""
        # filter variables in "finetune_prediction" variable scope
        if self.fix_lm_layer:
            regex = re.compile("finetune_prediction")
            tvars = [var for var in tvars if regex.match(var.name)]
        return tvars

    def build_model(self, **kwargs):
        saver = tf.train.import_meta_graph(
            "{}.meta".format(self.original_ckpt_path),
            import_scope="pretrained_model",
            clear_devices=self.clear_devices)
        sess = context.get_session() if self._distribute == "horovod" \
            else context.get_tmp_session()
        saver.restore(sess, self.original_ckpt_path)
        return super(TransferModel, self).build_model(**kwargs)


class KwaiBertClassificationModel(TransferModel):
    def __init__(self, config={}, **kwargs):
        super(KwaiBertClassificationModel, self).__init__(config=config, **kwargs)

        default_ckpt_path = "/home/web_server/antispam/project/" \
            "pretrained_models/bi_transformer_2l_photo_comment_1.ckpt"
        self.original_ckpt_path = config.get("original_ckpt_path", default_ckpt_path)
        self.input_index = config.get("input_index", 0)
        self.output_index = config.get("output_index", 0)

        self.dropout_rate = config.get("dropout_rate", 0.1)
        self.prediction_hidden_size = config.get("prediction_hidden_size", 256)

    def call(self, inputs):
        original_output = tf.compat.v1.get_collection("output_dict")[self.output_index]

        is_training = get_or_create_is_training()
        with tf.variable_scope("finetune_prediction"):
            conv = my_conv_1d(original_output, 1, self.prediction_hidden_size,
                              add_bias=True, bn=False, padding='VALID',
                              act=tf.nn.relu)
            pooled = tf.reduce_max(conv, axis=1)
            hidden = my_dropout(pooled, rate=self.dropout_rate, training=is_training)
            logits = my_full_connected(hidden, self.num_classes)
            prediction = tf.nn.softmax(logits)
        return logits, prediction

    def add_extra_attrs(self, hiddens):
        self.add_extra_attr("logits", hiddens[0])


class SpanBertClassificationModel(KwaiBertClassificationModel):
    """https://github.com/google-research/bert
    """
    def __init__(self, config, word_dict, **kwargs):
        super(SpanBertClassificationModel, self).__init__(config=config, **kwargs)
        default_ckpt_path = "/home/web_server/antispam/project/" \
            "pretrained_models/span_bert_5_v100-epoch3.ckpt"
        self.original_ckpt_path = config.get("original_ckpt_path", default_ckpt_path)
        self.input_index = config.get("input_index", 0)
        self.output_index = config.get("output_index", 3)
