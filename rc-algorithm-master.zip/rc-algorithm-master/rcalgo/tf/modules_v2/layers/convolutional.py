"""
Convolutional Layers

Note:
    * AtrousConv1d(my_atrous_conv_1d)因为其他代码中并没有用到，所以暂时没有实现，如有
    需要可以提出来
    * 为了跟旧版保持一致，这里很多参数的默认值跟keras是不一样的
"""

import tensorflow as tf

from rcalgo.tf.modules_v2.base_module import Module
from rcalgo.tf.modules_v2 import initializers, activations
from rcalgo.tf.modules_v2.layers.common import BatchNormalization


class Conv1d(Module):
    def __init__(self,
                 filters,
                 conv_length,
                 stride=1,
                 padding='SAME',
                 activation='tanh',
                 use_bias=True,
                 kernel_initializer='he_uniform',  # different from keras
                 bias_initializer='zeros',
                 use_bn=False,
                 name=None):
        super(Conv1d, self).__init__(name=name)
        self.filters = filters
        self.conv_length = conv_length
        self.stride = stride
        self.use_bias = use_bias
        self.padding = padding
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.bias_initializer = initializers.get(bias_initializer)
        self.batch_norm = BatchNormalization() if use_bn else None  # where should we put it

    def build(self, input_shape):
        """Create variables."""
        if not input_shape or input_shape[-1] is None:
            raise ValueError('The last dimension of the inputs to `Dense` '
                             'should be defined. Found `None`.')
        last_dim = input_shape[-1]
        self.kernel = tf.Variable(
            self.kernel_initializer(shape=[self.conv_length, last_dim, self.filters]),
            dtype=self.dtype,
            name='kernel')
        if self.use_bias:
            self.bias = tf.Variable(
                self.bias_initializer(shape=[self.filters]),
                dtype=self.dtype,
                name='bias')
        else:
            self.bias = None

    def _pad_conv_inputs(self, inputs, conv_length, padding):
        if len(inputs.shape) != 3:
            raise ValueError("inputs of conv1d should have ndim=3")
        # creat padding tensor
        pad_tensor = tf.zeros_like(
            tf.tile(inputs[:, 0:1, :], [1, (conv_length - 1), 1]))

        if padding == 'LEFT_SAME':
            outputs = tf.concat([pad_tensor, inputs], axis=1)
        elif padding == 'RIGHT_SAME':
            outputs = tf.concat([inputs, pad_tensor], axis=1)
        else:
            raise ValueError("Padding type {} not supportted".format(self.padding))
        return outputs

    def call(self, inputs, training=None):
        if self.conv_length == 1:
            # treat as dense layer when conv_length == 1, need to test equivalence
            # 旧代码里这里做了reshape, 感觉没有必要，所以删掉了
            outputs = tf.matmul(inputs, tf.squeeze(self.kernel, [0]))
        elif self.padding in ('LEFT_SAME', 'RIGHT_SAME'):
            conv_x = self._pad_conv_inputs(inputs, self.conv_length, self.padding)
            outputs = tf.nn.conv1d(conv_x, self.kernel, stride=self.stride,
                                   padding='VALID')
        else:
            outputs = tf.nn.conv1d(inputs, self.kernel, stride=self.stride,
                                   padding=self.padding)

        if self.use_bias:
            outputs = tf.nn.bias_add(outputs, self.bias)

        if self.batch_norm is not None:
            outputs = self.batch_norm(outputs, training=training)

        outputs = self.activation(outputs)
        return outputs


class Conv2d(Module):
    def __init__(self,
                 filters,
                 kernel_size,
                 strides=(1, 1),
                 padding='SAME',
                 activation='tanh',
                 use_bias=True,
                 kernel_initializer='xavier',  # different from keras
                 bias_initializer='zeros',
                 use_bn=False,
                 name=None):
        super(Conv2d, self).__init__(name=name)
        self.filters = filters
        if len(kernel_size) != 2:
            raise ValueError("kernel size should be list/tuple with length two")
        self.kernel_size = tuple(kernel_size)
        self.strides = strides
        self.use_bias = use_bias
        self.padding = padding
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.bias_initializer = initializers.get(bias_initializer)
        self.batch_norm = BatchNormalization() if use_bn else None  # where should we put it

    def build(self, input_shape):
        """Create variables."""
        if not input_shape or input_shape[-1] is None:
            raise ValueError('The last dimension of the inputs to `Dense` '
                             'should be defined. Found `None`.')
        last_dim = input_shape[-1]
        kernel_shape = self.kernel_size + (last_dim, self.filters)

        self.kernel = tf.Variable(
            self.kernel_initializer(shape=kernel_shape),
            dtype=self.dtype,
            name='kernel')
        if self.use_bias:
            self.bias = tf.Variable(
                self.bias_initializer(shape=[self.filters]),
                dtype=self.dtype,
                name='bias')
        else:
            self.bias = None

    def call(self, inputs, training=None):
        outputs = tf.nn.conv2d(inputs,
                               filters=self.kernel,
                               strides=self.strides,
                               padding=self.padding)

        if self.use_bias:
            outputs = tf.nn.bias_add(outputs, self.bias)

        if self.batch_norm is not None:
            outputs = self.batch_norm(outputs, training=training)

        outputs = self.activation(outputs)
        return outputs


def _deconv_output_length(input_length, filter_size, padding, stride):
    """Determines output length of a transposed convolution given input length.

    Arguments:
      input_length: integer.
      filter_size: integer.
      padding: one of "same", "valid", "full".
      stride: integer.

    Returns:
      The output length (integer).
    """
    if input_length is None:
        return None
    input_length *= stride
    if padding == 'VALID':
        input_length += max(filter_size - stride, 0)
    elif padding == 'FULL':
        input_length -= (stride + filter_size - 2)
    return input_length


class Conv2dTranspose(Module):
    """Transposed convolution layer (sometimes called Deconvolution)."""

    def __init__(self,
                 filters,
                 kernel_size,
                 strides=(1, 1),
                 padding='SAME',
                 activation='tanh',
                 use_bias=True,
                 kernel_initializer='xavier',  # different from keras
                 bias_initializer='zeros',
                 use_bn=False,
                 name=None):
        super(Conv2dTranspose, self).__init__(name=name)
        self.filters = filters
        if len(kernel_size) != 2:
            raise ValueError("kernel size should be list/tuple with length two")
        self.kernel_size = kernel_size
        self.strides = strides
        self.use_bias = use_bias
        self.padding = padding
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.bias_initializer = initializers.get(bias_initializer)
        self.batch_norm = BatchNormalization() if use_bn else None  # where should we put it

    def build(self, input_shape):
        """Create variables."""
        if not input_shape or input_shape[-1] is None:
            raise ValueError('The last dimension of the inputs to `Dense` '
                             'should be defined. Found `None`.')
        last_dim = input_shape[-1]
        kernel_shape = tuple(self.kernel_size) + (last_dim, self.filters)

        self.kernel = tf.Variable(
            self.kernel_initializer(shape=kernel_shape),
            dtype=self.dtype,
            name='kernel')
        if self.use_bias:
            self.bias = tf.Variable(
                self.bias_initializer(shape=[self.filters]),
                dtype=self.dtype,
                name='bias')
        else:
            self.bias = None

    def call(self, inputs, training=None):
        input_shape = tf.shape(inputs)
        batch_size = input_shape[0]

        height, width = input_shape[1], input_shape[2]
        kernel_h, kernel_w = self.kernel_size
        stride_h, stride_w = self.strides
        conv_strides = (1, stride_h, stride_w, 1)

        output_height = _deconv_output_length(height, kernel_h, self.padding, stride_h)
        output_width = _deconv_output_length(width, kernel_w, self.padding, stride_w)
        output_shape = (batch_size, output_height, output_width, self.filters)
        output_shape_tensor = tf.stack(output_shape)
        outputs = tf.nn.conv2d_transpose(
            inputs, self.kernel, output_shape_tensor,
            strides=conv_strides, padding=self.padding)

        if self.use_bias:
            outputs = tf.nn.bias_add(outputs, self.bias)

        if self.batch_norm is not None:
            outputs = self.batch_norm(outputs, training=training)

        outputs = self.activation(outputs)
        return outputs


class MultipleWidthConv1d(Module):
    """Multiple width cnn layer."""
    def __init__(self,
                 num_units,
                 conv_lengths=(1, 2, 3),
                 combine_mode='ADD',
                 activation="relu",
                 padding='VALID',
                 name=None):
        super(MultipleWidthConv1d, self).__init__(name=name)

        self.num_units = num_units
        self.combine_mode = combine_mode
        self.padding = padding
        self.conv_layers = [
            Conv1d(num_units,
                   conv_length=length,
                   activation='relu',
                   padding="VALID",
                   name="conv_length_{}".format(length))
            for length in conv_lengths]

    def call(self, inputs, training=None):
        conv_outputs = [conv(inputs) for conv in self.conv_layers]
        if self.padding != 'VALID':
            if self.combine_mode == 'ADD':
                outputs = tf.add_n(conv_outputs)
            elif self.combine_mode == 'CONCAT':
                outputs = tf.concat(conv_outputs, axis=-1)
            elif self.combine_mode == 'POOL':
                # 原来这里axis=0, 感觉应该是1
                outputs = tf.reduce_max(outputs, axis=1)
            else:
                raise NotImplementedError
        else:
            outputs = conv_outputs
        return outputs
