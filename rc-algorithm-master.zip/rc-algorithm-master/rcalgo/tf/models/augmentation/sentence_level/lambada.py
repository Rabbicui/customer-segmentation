from rcalgo.tf.tfmodels.texar_models.tx_transformerlm import *
from rcalgo.tf.tftraining.train_data import *
from rcalgo.tf.utils.train_config import *
from rcalgo.tf.tftraining.tf_object import *
from IPython.display import display
import os
import pickle


class GenerativeModel(object):
    def _build_model_args(self, model_dir, max_seq_len, gpu_num):
        if not os.path.exists(model_dir):
            model_dir = "lm_model"
        args = parse_initial_training_args(
            [
                '--learning-rate', '0.0001',
                '--n-epochs', '10',
                '--opt', 'adam',
                '--batch-size', '512',
                '--p-coef', '0',
                '--keep-prob', '0.9',
                '--embedding-size', '512',
                '--model-dir', model_dir,
                '--model-name', 'lm',
                '--num-layers', '4',
                '--gpu-id', '0',
                '--gpu-num', str(gpu_num),
                '--hidden-size', '512',
                '--maxlen', str(max_seq_len),
                '--epoch-save',
                '--use-residual',
                '--position-type', '2,3,4,5',
                '--beam-width', '200',
                '--sample-decay-factor', '5000',
                '--expand-input'
            ]
        )

        args.add_conv_flag = False
        return args

    def _build_lm_model(self, lm_func, term_id_map):
        graph_to_use = tf.Graph()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        self.lm_model = lm_func(self.train_args, graph_to_use, word_dict=term_id_map)
        self.lm_model.build_model()
        self.lm_model.build_model_summary()
        display(self.lm_model.model_summary())

    def build_data(self, train_data):
        data_size = len(train_data)
        print(">>>>> before, train data size:", data_size)
        if data_size % (self.train_args * self.gpu_num * 10) != 0:
            data_size = data_size - data_size % (self.train_args * self.gpu_num * 10)
        print(">>>>> after, train data size:", data_size)
        return train_data[:data_size]

    def pretrain(self, domain_corpus, lm_model_dir, max_seq_len, gpu_num=4, word_seg=False, freq_threshold=100,
                 lm_func=TxTransformerLMModel):
        word_freq = word_count(domain_corpus, word_seg)
        term_id_map = build_word2idx(word_freq, freq_threshold)
        id_term_map = {v: k for k, v in term_id_map.items()}
        print(">>>>> total term size:", len(id_term_map))

        id2term_path = os.path.join(lm_model_dir, 'id2term.pkl')
        with open(id2term_path, 'wb') as f:
            pickle.dump(id_term_map, f, protocol=4)
        print(">>>>> id2term saved:", id2term_path)

        self.train_args = self._build_model_args(lm_model_dir, max_seq_len, gpu_num)
        self.gpu_num = self.gpu_num

        self._build_lm_model(lm_func, term_id_map)
        self.train_data = self.build_data(domain_corpus)
        self.lm_model.run([self.train_data], test_size=0.1)


class LAMBADA(GenerativeModel):
    """
    https://arxiv.org/abs/1911.03118
    针对分类任务，生成指定label的文本
    1. finetune阶段的输入文本格式：label:text
    2. 文本生成阶段，以指定的label作为context，输入格式：label:
    """
    def __init__(self, id2term_path):
        with open(id2term_path, 'rb') as f:
            self.id_term_map = pickle.load(f)

    def finetune(self, texts, labels, model_out_dir, pretrain_model_dir, pretrain_ckpt, batch_size, lr_value=2e-5, n_epochs=10):
        assert len(texts) == len(labels)
        sentences = []
        for i in range(len(texts)):
            text = texts[i]
            label = labels[i]
            sentences.append('label_' + str(label) + ':' + str(text))
        self.sentences = self.build_data(sentences)

        job = IncrementalTraining(pretrain_model_dir, pretrain_ckpt, model_output_dir=model_out_dir,
                                  save_checkpoint=True)
        job._set_new_lr(lr_value)
        retrain_data = TrainingData([self.sentences], batch_size=batch_size, test_size=0.1)
        job.train(retrain_data, n_epochs=n_epochs, task_names=None)

    def _decode(self, num_arr, id_term_map):
        text = ''
        for i in num_arr:
            if i >= len(id_term_map) + 100 or i not in id_term_map:
                break
            text += id_term_map[i]
        return text

    def _generate(self, contexts, n, topk):
        results = []
        for i in range(n):
            samples = self.gen_job.session.run([self.sample_sample_id], feed_dict={self.input_var: [''] * len(contexts),
                                                                         self.context_var: contexts, self.top_k: topk})

            for j in range(len(samples[0])):
                cur_res = self._decode(samples[0][j][1:], self.id_term_map)
                results.append(cur_res)
        return results

    def generate(self, label_list, num_augs, model_dir, model_ckpt):
        """
        对于分类数据
        :param label_list: label list for classification
        :param num_augs: how many sentences do you want to augment
        :return:
        """
        assert len(label_list) == len(num_augs)
        contexts = []
        for i in range(len(label_list)):
            cur_context = ['label_' + str(label_list[i]) + ':'] * num_augs[i]
            contexts.extend(cur_context)

        self.gen_job = IncrementalTraining(model_dir, model_ckpt, model_output_dir=None)
        with self.gen_job.session.graph.as_default():
            input_var, context_var = tf.get_collection('input_dict')
            outputs = tf.get_collection('output_dict')[:5]
            greedy_logits, greedy_sample_id, sample_logits, sample_sample_id, beam_search_results = outputs
            top_k = tf.get_collection('top_k_sample')[0]

            self.input_var = input_var
            self.context_var = context_var
            self.top_k = top_k
            self.sample_sample_id = sample_sample_id

        data_augs = []
        batch_size = 128
        for i in range(0, len(contexts), batch_size):
            batch_data_augs = self._generate(contexts[i: i + batch_size], n=1, topk=10)
            data_augs.extend(batch_data_augs)
        return data_augs

    def class_pred(self, gen_texts, cls_model_dir, cls_model_ckpt):
        def predict(sentences, session, input_tensor, output_tensor, step=512):
            pred_labels = []
            pred_scores = []
            for i in tqdm(range(0, len(sentences), step)):
                outputs = session.run(output_tensor, feed_dict={input_tensor: sentences[i:i + step]})
                for j in range(len(outputs)):
                    pred_label = np.argmax(outputs[j])
                    pred_score = outputs[i][pred_label]

                    pred_labels.append(pred_label)
                    pred_scores.append(pred_score)
            return pred_labels, pred_labels

        gpu_options = tf.GPUOptions(allow_growth=True, per_process_gpu_memory_fraction=0.5)
        config = tf.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True)
        session = tf.Session(config=config, graph=tf.Graph())
        with session.graph.as_default():
            saver = tf.train.import_meta_graph("{}/{}.ckpt.meta".format(cls_model_dir, cls_model_ckpt),
                                               clear_devices=True)
            saver.restore(session, "{}/{}.ckpt".format(cls_model_dir, cls_model_ckpt))
            op_name = "init_all_tables"
            session.run(session.graph.get_operation_by_name(op_name))

            input_tensor_names = [var.name for var in tf.get_collection("input_dict")]
            output_tensor_names = [var.name for var in tf.get_collection("output_dict")]

        cls_pred_labels, cls_pred_scores = predict(gen_texts, session, input_tensor_names[0], output_tensor_names[-1])
        return cls_pred_labels, cls_pred_scores

    def filter(self, data_augs, cls_model_dir, cls_model_ckpt, num_keep):
        """
        对于生成的增强数据，使用分类器进行过滤, 论文中的过滤方法是：
        step1: 过滤掉指定label和分类器预测的label不一样
        step2: 对于每个label，按照分类器预测的置信结果进行排序，保留top个
        :param data_augs: 生成的增强数据
        :param cls_model_dir: 分类模型路径
        :param cls_model_ckpt: 分类模型checkpoint名称
        :param num_keep: 每个label要保留的top个数
        :return:
        """
        gen_texts = []
        gen_labels = []
        for sentence in data_augs:
            cols = sentence.split(":")
            label = cols[0].split("label_")[1]
            text = cols[1].strip()
            gen_labels.append(int(label))
            gen_texts.append(str(text))

        pred_labels, pred_scores = self.class_pred(gen_texts, cls_model_dir, cls_model_ckpt)
        assert len(pred_labels) == len(pred_scores) == len(gen_labels)

        gen_datas_dict = {}
        for i in range(len(pred_labels)):
            gen_label = gen_labels[i]
            gen_text = gen_texts[i]
            pred_label = pred_labels[i]
            pred_score = pred_scores[i]

            if pred_label != gen_label:
                continue
            if gen_label not in gen_datas_dict:
                gen_datas_dict[gen_label] = [(gen_text, pred_score)]
            else:
                gen_datas_dict[gen_label].append((gen_text, pred_score))

        filter_gen_texts = []
        filter_gen_labels = []
        for k, v in gen_datas_dict.items():
            cur_v = sorted(v, key=lambda x: float(x[1]), reverse=True)
            for item in cur_v[:num_keep]:
                filter_gen_texts.append(item[0])
                filter_gen_labels.append(k)
        return filter_gen_labels, filter_gen_texts

    def run(self, label_list, gen_model_dir, gen_model_ckpt, cls_model_dir, cls_model_ckpt, num_keep):
        num_augs = [10 * x for x in num_keep]
        data_augs = self.generate(label_list, num_augs, gen_model_dir, gen_model_ckpt)
        gen_labels, gen_texts = self.filter(data_augs, cls_model_dir, cls_model_ckpt, num_keep)
        return gen_labels, gen_texts
