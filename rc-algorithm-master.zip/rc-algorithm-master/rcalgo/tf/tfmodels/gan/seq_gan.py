#! /usr/bin/env python
# -*- coding: utf-8 -*-
import collections

from rcalgo.tf.metric.accuracy import varibale_topk_accuracy
from rcalgo.tf.metric.loss import variable_seq_loss
from rcalgo.tf.metric.texar_loss import sequence_sigmoid_cross_entropy
from .vanilla_gan import VanillaGAN
from rcalgo.tf.tfmodels.text_basic_model import TextModel
from rcalgo.tf.module.encoder.transformer import *
import texar as tx
from rcalgo.tf.module.layer.basic import my_full_connected
from rcalgo.tf.tftraining.multi_training import MultiTask
from rcalgo.tf.utils.tf_collections import *
from tensorflow.contrib.seq2seq.python.ops.helper import ScheduledEmbeddingTrainingHelper
from rcalgo.tf.utils.tf_func import inverse_sigmoid_sample_proba, replace_default_graph, my_compute_grad
from .helper import MultinomialSoftmaxEmbeddingHelper
from tensorflow.python.ops import rnn_cell


class EncoderOutput(
        collections.namedtuple("EncoderOutput",
                               ("outputs", "final_state"))):
    pass

class RNNEncoder(object):
    def __init__(self, cell, embedder):
        self.encoder = tx.modules.UnidirectionalRNNEncoder(cell=cell)
        self.embedder = embedder

    def __call__(self, encoder_input, sequence_length):
        embedding = self.embedder(encoder_input)
        conv_emb = multi_width_cnn_block(embedding, self.embedder.embedding_size, padding='LEFT_SAME')
        outputs, final_state = self.encoder(inputs=conv_emb, sequence_length=sequence_length)
        return EncoderOutput(outputs, final_state)

class EmbeddingEncoder(object):
    def __init__(self, embedder, state_output_size, num_layers):
        self.embedder = embedder
        self.state_output_size = state_output_size
        # used to convert embedding to state
        self.num_layers = num_layers

    def __call__(self, encoder_input, sequence_length):
        embedding = self.embedder(encoder_input)
        # try different strategy, add, average,
        expand_length = tf.expand_dims(sequence_length, -1)
        embedding = tf.reduce_sum(embedding, axis=1) / expand_length
        init_state = []
        for i in range(0, self.num_layers):
            temp = rnn_cell.LSTMStateTuple(
                c=my_full_connected(embedding, self.state_output_size, act=tf.nn.tanh),
                h=my_full_connected(embedding, self.state_output_size, act=tf.nn.tanh))
            init_state.append(temp)
        return EncoderOutput(None, tuple(init_state))

class Decoder(object):
    """
    A wrapper around the texar decoder
    """
    def __init__(self, cell, nb_words, embedder):
        self.decoder = tx.modules.BasicRNNDecoder(cell=cell, vocab_size=nb_words)
        self.embedder = embedder

    def __call__(self,
                 initial_state=None,
                 decoder_input=None,
                 sequence_length=None,
                 train_strategy='greedy',
                 sampling_probability=None,
                 infer_strategy='infer_greedy',
                 beam_with=1,
                 batch_size=None,
                 sos_token_id=None,
                 eos_token_id=None,
                 maxlen=None,
                 mode='train',
                 **kwargs):
        if mode == 'train':
            # train
            dec_outputs, state, dec_sequence_length = self.train_decode(decoder_input,
                                                                        initial_state,
                                                                        batch_size,
                                                                        train_strategy,
                                                                        sampling_probability,
                                                                        sequence_length)
        else:
            dec_outputs, state, dec_sequence_length = self.infer_decode(initial_state,
                                                                        batch_size,
                                                                        sos_token_id,
                                                                        eos_token_id,
                                                                        infer_strategy,
                                                                        maxlen,
                                                                        beam_with=beam_with)

        return dec_outputs, state, dec_sequence_length

    def zero_state(self, batch_size):
        return self.decoder.zero_state(batch_size=batch_size, dtype=tf.float32)

    def train_decode(self, inputs, initial_state, batch_size, train_strategy, sampling_probability,
                     sequence_length):
        # train
        embedding = self.embedder(inputs)
        # the default encoder
        # the max_time of dec_outputs is consistent with the max value in sequence_length

        if initial_state is None:
            initial_state = self.decoder.zero_state(batch_size=batch_size, dtype=tf.float32)
        if train_strategy == 'train_greedy':
            dec_outputs, state, dec_sequence_length = self.decoder(initial_state=initial_state,
                                                                   decoding_strategy="train_greedy",
                                                                   inputs=embedding,
                                                                   impute_finished=False,
                                                                   sequence_length=sequence_length)
        else:
            helper = ScheduledEmbeddingTrainingHelper(inputs=embedding,
                                                      sequence_length=sequence_length,
                                                      embedding=lambda ids: self.embedder(ids),
                                                      sampling_probability=sampling_probability)
            dec_outputs, state, dec_sequence_length = self.decoder(initial_state=initial_state,
                                                                   helper=helper,
                                                                   impute_finished=False)
        # no other options add later
        return dec_outputs, state, dec_sequence_length

    def infer_decode(self, initial_state, batch_size, sos_token_id, eos_token_id, infer_strategy,
                     maxlen, beam_with=1):
        # infer
        if initial_state is None:
            initial_state = self.decoder.zero_state(batch_size=batch_size, dtype=tf.float32)
        start_tokens = tf.cast(tf.fill([batch_size], sos_token_id), dtype=tf.int32)
        kwargs = {'start_tokens': start_tokens,
                  'end_token': eos_token_id,
                  'embedding': lambda ids: self.embedder(ids),
                  'initial_state': initial_state,
                  'max_decoding_length': maxlen,
                  'impute_finished': False}

        if infer_strategy != 'beam_search':
            if infer_strategy == 'infer_softmax':
                helper = MultinomialSoftmaxEmbeddingHelper(embedding=self.embedder.embedding_table,
                                                           start_tokens=start_tokens,
                                                           end_token=eos_token_id)
                dec_outputs, state, dec_sequence_length = self.decoder(initial_state=initial_state,
                                                                       helper=helper,
                                                                       max_decoding_length=maxlen,
                                                                       impute_finished=False,
                                                                       mode='infer')
            else:
                dec_outputs, state, dec_sequence_length = self.decoder(decoding_strategy=infer_strategy,
                                                                       **kwargs)
        else:
            # the beam search acts in a different way
            beam_outputs, state, beam_sequence_length = tx.modules.beam_search_decode(
                decoder_or_cell=self.decoder,
                beam_width=beam_with,
                **kwargs)
            dec_outputs = beam_outputs
            dec_sequence_length = beam_sequence_length

        return dec_outputs, state, dec_sequence_length


class SeqGAN(VanillaGAN, TextModel):
    """
    The SeqGAN model
    Training procedure is split into three parts:
        1. pre_train generator 2. pre_train discriminator 3 adversarial training (policy gradient train
        generator and train discriminator)
    """

    G_PRE_TRAIN_TASK = 'pretrain_generator'
    D_PRE_TRAIN_TASK = 'pretrain_discriminator'

    G_PRE_TRAIN_PRIORITY = 1
    D_PRE_TRAIN_PRIORITY = 2

    # we have pretrain_D, so run the G first
    G_PRIORITY = 1
    D_PRIORITY = 2

    def __init__(self, config, graph, word_dict, target_word_dict):
        # hack here: won't initialize the TextModel, both TextModel and VanillaGAN inherit the TFModelBase
        VanillaGAN.__init__(self, config, graph)
        self._init_text_model(config, word_dict, target_word_dict)
        self.encoder_keep_prob = config.encoder_keep_prob
        self.decoder_keep_prob = config.decoder_keep_prob
        self.hidden_size = config.rnn_hidden_size
        self.g_pre_train_learning_rate = config.g_pre_train_learning_rate
        self.d_pre_train_learning_rate = config.d_pre_train_learning_rate
        self.pretrain_strategy = config.pretrain_strategy
        self.adversarial_train_infer_strategy = config.adversarial_train_infer_strategy
        self.label_smooth = config.label_smooth
        self.beam_search_width = config.beam_search_width
        self.num_layers = config.num_layers
        self.input_english_style = config.input_english_style
        self.encoder_embedding_size = config.encoder_embedding_size
        self.decoder_embedding_size = config.decoder_embedding_size
        self.sampling_probability = 1.0 - inverse_sigmoid_sample_proba(config.schedule_decay_factor,
                                                                       self.global_step)

        g_pre_train_lr_params = tf.contrib.training.HParams(learning_rate=self.g_pre_train_learning_rate,
                                                            global_step=self.global_step,
                                                            decay_steps=config.total_update,
                                                            warmup=config.learning_rate_warmup)
        d_pre_train_lr_params = tf.contrib.training.HParams(learning_rate=self.d_pre_train_learning_rate,
                                                            global_step=self.global_step,
                                                            decay_steps=None)
        opt_params = tf.contrib.training.HParams(optimizer='adam',
                                                 adam_epsilon=config.adam_epsilon,
                                                 adam_beta1=config.adam_beta1,
                                                 adam_beta2=config.adam_beta2)
        self._add_optimizer(self.G_PRE_TRAIN_TASK, self.g_pre_train_learning_rate,
                            lr_params=g_pre_train_lr_params,
                            opt_params=opt_params)
        self._add_optimizer(self.D_PRE_TRAIN_TASK, self.d_pre_train_learning_rate,
                            lr_params=d_pre_train_lr_params,
                            opt_params=opt_params)

        self._add_pretrain_task()

        self.g_encoder = None
        self.g_decoder = None
        self.encoder_inputs = []
        self.encoder_input_sequence_lengths = []
        self.decoder_inputs = []
        self.decoder_targets = []
        self.decoder_input_sequence_lengths = []
        self.decoder_target_sequence_lengths = []
        self.inference_output = []

    @replace_default_graph
    def _add_pretrain_task(self):
        # add steps info into the collection
        # the steps for standalone task is useless just to be compatible with the function
        self._add_to_graph_collection('{}_{}'.format(self.G_PRE_TRAIN_TASK, tf.compat.v1.GraphKeys.TRAIN_STEPS), 1)
        self._add_to_graph_collection('{}_{}'.format(self.D_PRE_TRAIN_TASK, tf.compat.v1.GraphKeys.TRAIN_STEPS), 1)

        # add task type
        self._add_to_graph_collection('{}_{}'.format(self.G_PRE_TRAIN_TASK, tf.compat.v1.GraphKeys.TASK_TYPE),
                                      MultiTask.STANDALONE_TYPE)
        self._add_to_graph_collection('{}_{}'.format(self.D_PRE_TRAIN_TASK, tf.compat.v1.GraphKeys.TASK_TYPE),
                                      MultiTask.STANDALONE_TYPE)

        # set the priority
        self._add_to_graph_collection('{}_{}'.format(self.G_PRE_TRAIN_TASK, tf.compat.v1.GraphKeys.PRIORITY),
                                      self.G_PRE_TRAIN_PRIORITY)
        self._add_to_graph_collection('{}_{}'.format(self.D_PRE_TRAIN_TASK, tf.compat.v1.GraphKeys.PRIORITY),
                                      self.D_PRE_TRAIN_PRIORITY)

    def build_input(self):
        self.build_encoder_input()
        self.build_decoder_input()
        self.infer_maxlen = tf.compat.v1.placeholder_with_default(tf.constant(self.maxlen),
                                                         shape=[],
                                                         name='infer_maxlen')
        self.input_dict['infer_maxlen'] = self.infer_maxlen


    def build_encoder_input(self):
        # the default input is a word no need to do split
        self.split_inputX, self.split_seqLengths = self.build_text_input(expand_input=True,
                                                                         key='input')
        # the default decoder is a embedding don't need the sos and eos
        for split_in, split_length in zip(self.split_inputX, self.split_seqLengths):
            split_length = tf.cast(split_length, dtype=tf.int32)
            # remove sos and eos
            txt_inputs = split_in[:, 1:-1]
            self.encoder_inputs.append(txt_inputs)
            self.encoder_input_sequence_lengths.append(split_length - 2)
        inputs = tf.compat.v1.get_collection('{}_{}'.format(self.default_task_name, tf.compat.v1.GraphKeys.INPUTS))
        self.encoder_nb_words = self.nb_words
        self._add_to_graph_inputs(inputs, self.G_PRE_TRAIN_TASK)
        self._add_to_graph_inputs(inputs, self.D_PRE_TRAIN_TASK)
        self._add_to_graph_inputs(inputs, self.D_TASK)
        # when train G in adversarial manner, we still need the encoder input
        self._add_to_graph_inputs(inputs, self.G_TASK)

    def build_decoder_input(self):
        # if the sentence style is english no need to add space
        self.split_targetX, self.split_targetLengths = self.build_text_input(expand_input=True,
                                                                             key='target',
                                                                             sos_flag=True)
        # prepare decoder inputs, the targets
        for split_in, split_length in zip(self.split_targetX, self.split_targetLengths):
            # remove the eos
            split_length = tf.cast(split_length, dtype=tf.int32)
            txt_inputs = split_in[:, :-1]
            self.decoder_inputs.append(txt_inputs)
            self.decoder_input_sequence_lengths.append(split_length - 1)
            # remove sos
            label_inputs = split_in[:, 1:]
            self.decoder_targets.append(label_inputs)
            self.decoder_target_sequence_lengths.append(split_length - 1)

        targets = tf.compat.v1.get_collection('{}_{}'.format(self.default_task_name, tf.compat.v1.GraphKeys.TARGETS))
        self.decoder_nb_words = self.target_nb_words
        self._add_to_graph_targets(targets, self.G_PRE_TRAIN_TASK)
        self._add_to_graph_targets(targets, self.D_PRE_TRAIN_TASK)
        self._add_to_graph_targets(targets, self.D_TASK)
        self.decoder_go_value = tf.compat.v1.placeholder_with_default(
            tf.constant(self._sos_token_id(self.decoder_nb_words), dtype=tf.int32), shape=[],
            name='go_value')
        self._add_to_graph_collection('go_value', self.decoder_go_value)

    def build_encoder(self):
        cell = self.build_cell(self.hidden_size, self.encoder_keep_prob, self.num_layers)
        embedder = self.get_embedder(self.encoder_nb_words, embedding_size=self.encoder_embedding_size,
                                     variables_collections='encoder_embedding',
                                     layer_name='encoder_layer')
        self.encoder = RNNEncoder(cell, embedder)

    def build_decoder(self):
        cell = self.build_cell(self.hidden_size, self.decoder_keep_prob, self.num_layers)
        embedder = self.get_embedder(self.decoder_nb_words, embedding_size=self.decoder_embedding_size,
                                     variables_collections='decoder_embedding',
                                     layer_name='decoder_layer')
        self.decoder = Decoder(cell, self.decoder_nb_words, embedder)


    def lstm_state_to_tensor(self, state):
        return tf.concat([tf.stack(s, axis=1) for s in state], axis=1)

    def tensor_to_lstm_state(self, tensor):
        init_state = []
        for i in range(0, self.num_layers):
            temp = rnn_cell.LSTMStateTuple(c=tensor[:, i * 2, :],
                                           h=tensor[:, (i * 2 + 1), :])
            init_state.append(temp)
        return tuple(init_state)

    def build_pretrain_loss(self, gpu_id, dec_outputs, clip_type, accK=1):
        """
        Build the pre_train generator which will be updated in a teacher-forcing manner

        Args:
            dec_outputs:        The output from decoder
                                shape [batch_size * ? * emb_size] The sequence length is unknown
                                decided case by case
            clip_type:
        """
        # the labels here are also the inputs
        # it's possibly that all sequence in one batch are very short, split_seqLengths < maxlen
        targets = self.decoder_targets[gpu_id][:, 0: tf.shape(dec_outputs.logits)[1]]
        sequence_length = self.decoder_target_sequence_lengths[gpu_id]
        predictions = dec_outputs.logits
        # g_mle_loss = sequence_sparse_softmax_cross_entropy(
        #     labels=targets,
        #     logits=dec_outputs.logits,
        #     sequence_length=sequence_length)
        mle_loss = variable_seq_loss(
            predictions, targets,
            self.label_smooth, self.decoder_nb_words)

        mle_loss.set_shape(())
        mle_params = tf.compat.v1.trainable_variables()
        mle_grads, mle_capped_gvs = my_compute_grad(self.opt[self.G_PRE_TRAIN_TASK],
                                                    mle_loss, mle_params,
                                                    clip_type=clip_type,
                                                    max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            accuracy = varibale_topk_accuracy(predictions, targets, k=accK)
        self._add_to_tower_list(mle_grads, mle_capped_gvs, mle_loss, accuracy,
                                task=self.G_PRE_TRAIN_TASK)

    def build_inference(self, initial_state, batch_size):
        """
        Generate the fake inference (samples)
        """
        # build inference
        # build infer: the initial state can from the encoder or from the user inputs
        # the default is from the encoder
        import functools
        partial_decoder = functools.partial(self.decoder,
                                            initial_state=initial_state,
                                            batch_size=batch_size,
                                            sos_token_id=self.decoder_go_value,
                                            eos_token_id=self._eos_token_id(self.decoder_nb_words),
                                            maxlen=self.infer_maxlen,
                                            mode='infer')
        prob_infer_outputs, prob_state, prob_infer_sequence_length = partial_decoder(
            infer_strategy='infer_sample')
        greedy_infer_outputs, greedy_state, greedy_infer_sequence_length = partial_decoder(
            infer_strategy='infer_greedy')
        softmax_infer_outputs, softmax_state, sofmax_infer_sequence_length = partial_decoder(
            infer_strategy='infer_softmax')
        beam_infer_outputs, beam_state, beam_infer_sequence_length = partial_decoder(
            infer_strategy='beam_search', beam_with=self.beam_search_width)
        # the Softmax or GumbelSoftmax helper needs the embedder to inherit the EmbedderBase try later
        # store samples to output_dict
        self.output_dict['infer_prob_samples'] = prob_infer_outputs.sample_id
        self.output_dict['infer_greedy_samples'] = greedy_infer_outputs.sample_id
        self.output_dict['infer_beam_search_samples'] = beam_infer_outputs.predicted_ids
        self.output_dict['infer_softmax_samples'] = softmax_infer_outputs.sample_id
        self.output_dict['infer_prob_state'] = prob_state
        self.output_dict['infer_greedy_state'] = greedy_state
        self.output_dict['infer_softmax_state'] = softmax_state
        self.output_dict['infer_beam_state'] = beam_state
        self.output_dict['infer_prob_logits'] = prob_infer_outputs.logits
        self.output_dict['infer_greedy_logits'] = greedy_infer_outputs.logits
        self.output_dict['infer_softmax_logits'] = softmax_infer_outputs.logits

    def build_discriminator_loss(self, r_inputs, r_sequence_length, f_inputs, f_sequence_length, clip_type):
        """
        The discriminator
        Args:
            r_inputs:               real inputs shape [batch_size * max_time]
            r_sequence_length:      shape [batch_size]
            f_inputs:               fake inputs shape [batch_size * max_time]
            f_sequence_length:      shape [batch_size]
        """
        discriminator = tx.modules.UnidirectionalRNNClassifier(
            hparams={"clas_strategy": "time_wise", "num_classes": 1})

        # the labels will be used as the true samples (the sos has been removed)
        # r_logits shape [batch_size, max_time]
        r_logits, _ = discriminator(self.d_embedder(r_inputs),
                                    sequence_length=r_sequence_length)
        f_logits, _ = discriminator(self.d_embedder(f_inputs),
                                    sequence_length=f_sequence_length)

        # only apply label_smooth to real
        r_loss = sequence_sigmoid_cross_entropy(
            labels=tf.ones_like(r_inputs, dtype=tf.float32),
            logits=tf.squeeze(r_logits),
            sequence_length=r_sequence_length,
            label_smooth=self.label_smooth)  # r_preds -> 1.
        # stop gradients to G
        f_loss = sequence_sigmoid_cross_entropy(
            labels=tf.zeros_like(f_inputs, dtype=tf.float32),
            logits=tf.squeeze(f_logits),
            sequence_length=f_sequence_length)  # infer_logits -> 0.

        # the default average over batch and sum over steps are true so the dis_loss should be shape()
        d_loss = r_loss + f_loss
        # the output of the sequence_sigmoid_cross_entropy has no shape (set the shape here)
        d_loss.set_shape(())

        # Trick here:we utilize the Decoder in texar which don't provide the ability to set variables to
        # collections. But the infer_sample_ids ---> generator part is not differentiable, thus the
        # gradient is stopped
        d_params = tf.compat.v1.trainable_variables()
        d_grads, d_capped_gvs = my_compute_grad(self.opt[self.D_TASK], d_loss, d_params,
                                                clip_type=clip_type,
                                                max_clip_grad=self.clip_gradients)
        d_metric = -d_loss
        # here we add the train op to two tasks, since we want to pre_train D before start
        # the jointly adversarial training
        # a little tricky: the train op, final loss op are different, but the training variables are shared
        self._add_to_tower_list(d_grads, d_capped_gvs, d_loss, d_metric, task=self.D_PRE_TRAIN_TASK)
        self._add_to_tower_list(d_grads, d_capped_gvs, d_loss, d_metric, task=self.D_TASK)
        return r_logits, f_logits

    def build_pg_loss(self, infer_inputs, infer_logits, f_logits, f_sequence_length, batch_size, clip_type):
        """
        Build the policy gradient generator
        f_logits here is the output from discriminator
        infer_logits here is the output from generator
        """
        # clip by value
        infer_logits = tf.clip_by_value(
            tf.nn.softmax(infer_logits) *
            tf.one_hot(infer_inputs, self.decoder_nb_words), 1e-20, 1)

        # the baseline ... currently set to zero should be modified
        expected_reward = tf.Variable(tf.zeros((self.maxlen,)), trainable=False)
        reward = tf.reshape(f_logits, shape=(batch_size, -1)) - expected_reward[:tf.shape(f_logits)[1]]
        # TODO need mode discussion: stop gradients flows --> to discriminator
        reward = tf.stop_gradient(reward)
        # exp_reward_loss = -tf.reduce_mean(tf.abs(reward))
        # this loss is used to maximize the exp_reward which means maximize the f_logits
        # exp_reward_loss.set_shape(())

        # the policy gradient loss:  -reward * log(p)
        reward = tx.losses.discount_reward(
            reward, sequence_length=tf.squeeze(f_sequence_length), tensor_rank=2)

        # the pg update
        # TODO merge with the parent class
        g_pg_loss = -tf.reduce_mean(tf.log(infer_logits) * tf.expand_dims(reward, -1))
        g_pg_params = tf.compat.v1.trainable_variables()
        g_pg_grads, g_pg_capped_gvs = my_compute_grad(self.opt[self.G_TASK], g_pg_loss, g_pg_params,
                                                      clip_type=clip_type,
                                                      max_clip_grad=self.clip_gradients)
        g_pg_metric = -g_pg_loss
        self._add_to_tower_list(g_pg_grads, g_pg_capped_gvs, g_pg_loss, g_pg_metric,
                                task=self.G_TASK)

    def encode(self, gpu_id=0):
        enc_output = self.encoder(encoder_input=self.encoder_inputs[gpu_id],
                                  sequence_length=self.encoder_input_sequence_lengths[gpu_id])
        return enc_output

    def teacher_forcing_decode(self, initial_state, gpu_id):
        dec_output, final_state, _ = self.decoder(initial_state=initial_state,
                                                  decoder_input=self.decoder_inputs[gpu_id],
                                                  batch_size=tf.shape(self.decoder_inputs[gpu_id])[0],
                                                  sequence_length=self.decoder_input_sequence_lengths[gpu_id],
                                                  train_strategy=self.pretrain_strategy,
                                                  sampling_probability=self.sampling_probability,
                                                  mode='train')
        return dec_output, final_state

    def adversarial_inference_decode(self, initial_state, batch_size, infer_strategy):
        infer_outputs, infer_final_state, infer_sequence_length = self.decoder(
            initial_state=initial_state,
            batch_size=batch_size,
            sos_token_id=self._sos_token_id(self.decoder_nb_words),
            eos_token_id=self._eos_token_id(self.decoder_nb_words),
            maxlen=self.maxlen,
            infer_strategy=infer_strategy,
            mode='infer')
        return infer_outputs, infer_final_state, infer_sequence_length

    def build_gan(self, g_batch_size, gpu_id=0, reuse=False, clip_type='clip_value'):
        """
        A simplified version without the ROLLOUT and Oracle part of the original SeqGan
        """
        if gpu_id == 0:
            self.d_embedder = self.get_embedder(self.decoder_nb_words,
                                                variables_collections='discriminator_embedding')
            self.build_encoder()
            self.build_decoder()

        # apply encoder and get the initial_state of decoder
        enc_output = self.encode(gpu_id)
        # the dynamical size
        state_tensor = self.lstm_state_to_tensor(enc_output.final_state)
        batch_size = tf.shape(state_tensor)[0]

        # to support feed state in training
        state_tensor = tf.compat.v1.placeholder_with_default(state_tensor,
                                                   shape=[None, self.num_layers * 2,
                                                          self.hidden_size],
                                                   name='decoder_input_state')

        decoder_state_input = self.tensor_to_lstm_state(state_tensor)
        dec_output, final_state = self.teacher_forcing_decode(decoder_state_input, gpu_id)

        self.build_pretrain_loss(gpu_id, dec_output, clip_type)

        # create the adversarial output
        adversarial_infer_outputs, infer_final_state, adversarial_infer_sequence_length = self.adversarial_inference_decode(
            decoder_state_input,
            batch_size,
            self.adversarial_train_infer_strategy)

        if gpu_id == 0:
            self.input_dict['decoder_input_state'] = state_tensor
            self.output_dict['train_final_state'] = self.lstm_state_to_tensor(final_state)
            self.output_dict['adversarial_infer_final_state'] = self.lstm_state_to_tensor(infer_final_state)
            # don't use batch_size here, otherwise it will rely on the encoder input
            # build the output_inference
            self.build_inference(decoder_state_input, tf.shape(decoder_state_input[0].c)[0])

        infer_inputs = adversarial_infer_outputs.sample_id
        infer_logits = adversarial_infer_outputs.logits

        # build discriminator
        r_logits, f_logits = self.build_discriminator_loss(self.decoder_targets[gpu_id],
                                                           self.decoder_target_sequence_lengths[gpu_id],
                                                           infer_inputs,
                                                           adversarial_infer_sequence_length,
                                                           clip_type)

        # build generator by policy gradient
        self.build_pg_loss(infer_inputs,
                           infer_logits,
                           f_logits,
                           adversarial_infer_sequence_length,
                           batch_size,
                           clip_type)
















