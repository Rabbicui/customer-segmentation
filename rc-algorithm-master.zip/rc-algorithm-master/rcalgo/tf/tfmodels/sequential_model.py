import os
import sys
# sys.path.insert(0,'..')
sys.path.append(os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "../"))
from .rnnlm import *
import numpy as np


class SequentialModel(RNNLMModel):
    def __init__(self, config, graph):
        super(SequentialModel, self).__init__(config, graph)

    def build_single_prediction(self, task, gpu_id=0, accK=5, nb_class=None):
        self.params_1 = None
        if nb_class is None:
            nb_class = self.nb_words
        with get_new_variable_scope('prediction') as pred_scope:
            prediction = my_full_connected(self.output_list[gpu_id], nb_class,
                                           add_bias=True, act=tf.identity, init_std=self.init_std)
            self.tower_prediction_results.append(tf.nn.softmax(prediction))
        with tf.name_scope('loss'):
            loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.split_label[gpu_id],
                                                                  logits=prediction)
            self.params_1 = [param for param in self.input_params]
            self.params_1.extend(tf.compat.v1.trainable_variables()[-2:])
            grads, capped_gvs = my_compute_grad(self.opt, loss, self.params_1,
                                                clip_type='clip_norm', task=task,
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            accuracy = tf.to_float(tf.nn.in_top_k(
                prediction, self.split_label[gpu_id], k=accK))
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task)

    def build_single_output(self, task):
        with tf.name_scope('output'):
            label = tf.compat.v1.placeholder(tf.int64, [None], name="label")
            self._add_to_graph_inputs(tf.compat.v1.get_collection('{}_{}'.format(
                self.default_task_name, tf.compat.v1.GraphKeys.INPUTS)), task)
            self._add_to_graph_targets(label, task)
            self.split_label = tf.split(label, self.gpu_num, 0)
        self._update_optimizer(task)

    def build_output(self, task='default'):
        if isinstance(task, list):
            super(SequentialModel, self).build_output(task[0])
            self.build_single_output(task[1])
        else:
            if task != self.default_task_name:

                self.build_single_output(task)
            else:
                super(SequentialModel, self).build_output(task)

    def split_parameter(self, param):
        if isinstance(param, list):
            if len(param) > 1:
                return param[0], param[1]
            else:
                return param[0], param[0]
        else:
            return param, param

    @replace_default_graph
    def build_model(self, task=['default', 'single'], accK=5, nb_class=None):
        self.build_input()
        self.build_output(task)
        accK1, accK2 = self.split_parameter(accK)
        nb_class1, nb_class2 = self.split_parameter(nb_class)
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_input_sequence(
                            gpu_id=idx, reuse=reuse)
                        if isinstance(task, list):
                            self.build_sequence_prediction(
                                task=task[0], gpu_id=idx, accK=accK1, nb_class=nb_class1)
                            self.build_single_prediction(
                                task=task[1], gpu_id=idx, accK=accK2, nb_class=nb_class2)
                        else:
                            if task != self.default_task_name:
                                self.build_single_prediction(
                                    task, gpu_id=idx, accK=accK2, nb_class=nb_class2)
                            else:
                                self.build_sequence_prediction(
                                    task, gpu_id=idx, accK=accK1, nb_class=nb_class1)

        if task == self.default_task_name or task[0] == self.default_task_name:
            self._dump_rnn_output()
        if isinstance(task, list):
            self._add_to_graph_outputs([prediction for idx, prediction in enumerate(
                self.prediction_results) if idx != 1], task[0])
            self._add_to_graph_outputs(self.prediction_results[1], task[1])
        else:
            self._add_to_graph_outputs(self.prediction_results, task)
