import numpy as np
import tensorflow as tf
from rcalgo.tf.training import context
from rcalgo.tf.training.data.tf_dataset import TFDataset
from sklearn.metrics import precision_score, recall_score, accuracy_score
from tqdm import tqdm


def convert_to_tfdataset(data):
    """
    convert tf.data.Dataset or numpy array to TFDataset
    Args:
        data: tf.data.Dataset (usually TFRecord), python list or numpy array

    Returns: TFDataset

    """
    if isinstance(data, tf.data.Dataset):
        dataset = TFDataset.from_tf_dataset(data)
    elif isinstance(data, TFDataset):
        dataset = data
    else:
        data = [np.array(feature) if isinstance(feature, list) else feature for feature in data]
        dataset = TFDataset.from_numpy(data)
    return dataset


def get_labels(data, batch_size=256):
    """
    get labels from data
    :param data: tf.data.Dataset (usually TFRecord), python list or numpy array
    :param batch_size: batch size
    :return: labels, type: numpy array
    """
    data = convert_to_tfdataset(data)  # whatever the data type is, first convert it to TFDataset
    data = data.split(1, 0)  # it seems that this is useless since we fix it in TFDataset
    test_data = data.batch(batch_size, drop_remainder=False)
    test_iterator = test_data.make_iterator()
    test_iterator.reinitialize()
    next_element = test_iterator.next_element()
    tqdm_iter = tqdm(range(test_data.get_num_steps(ceil=True)), position=0, leave=True)
    sess = context.get_session()
    labels = []
    for item in tqdm_iter:
        # according to the data format that rcalgo requires, label is always the last element in the data list
        labels.append(sess.run(next_element)[-1])
    return np.concatenate(labels, axis=0)


def get_recall(left, right, true_labels, pred_probs, precision_th):
    """
    get recall at some precision threshold by binary search
    this assumes that precision = f(threshold) is a increasing function
    and recall = g(threshold) is a decreasing function
    Args:
        left: lower bound
        right: higher bound
        true_labels: true labels, a list of 1 or 0
        pred_probs: a list of predict probabilities like [0.9, 0.8, ..., 0.02]
        precision_th: precision threshold when calculate recall

    Returns:
        recall at precision_th

    """
    p = len(str(precision_th).split('.')[1])
    for i in range(5, 0, -1):
        while left <= right:
            mid = (left + right) / 2
            pred_labels = [1 if pred_score > mid else 0 for pred_score in pred_probs]
            precision = precision_score(true_labels, pred_labels)
            # the actual precision may not be as exact as expected, so we use the trick
            # for example: if the expected precision is 0.7, we think the actual precision ∈ [0.695, 0.705] is just the
            # same as 0.7
            if abs(precision - precision_th) < 5 / 10 ** (p + i):
                return recall_score(true_labels, pred_labels)
            elif abs(right - left) < 1e-7:
                # if l and r is very close but the actual precision is always higher than the expected precision
                # we just calculate the recall, or else return 0.0
                if precision > precision_th:
                    return recall_score(true_labels, pred_labels)
                break
            elif precision < precision_th:
                left = mid
            elif precision > precision_th:
                right = mid
            else:
                break
    return 0.0


def get_top1_acc(true_labels, preds):
    """
    get top1 accuracy
    Args:
        true_labels: true labels
        preds: predict results, a list of predict distribution like [[0.1, 0.2, 0.7], ..., [0.05, 0.75, 0.2]]

    Returns:
        top1 accuracy

    """

    pred_labels = np.argmax(preds, axis=1)
    return accuracy_score(true_labels, pred_labels)

