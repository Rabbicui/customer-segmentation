import tensorflow as tf
from rcalgo.tf.training.model import Model
from rcalgo.tf.module.encoder.bert_encoder import BertModel, BertConfig
from rcalgo.tf.utils.tf_func import gather_indexes
import module.encoder.bert_encoder as bert_encoder


class ConditionalBERT(Model):
    """
    Conditional BERT Contextual Augmentation
    https://arxiv.org/pdf/1812.06705.pdf
    """
    def __init__(self, config, **kwargs):
        super(ConditionalBERT, self).__init__(config=config, **kwargs)

        self.max_seq_length = config.get("max_seq_length", 128)
        self.use_one_hot_embeddings = config.get("use_one_hot_embeddings", False)
        self.learning_rate = config.get("learning_rate", 0.00003)
        self.max_predictions_per_seq = config.get("max_predictions_per_seq", 10)
        self.acc_k = config.get("acc_k", 1)
        self.pred_top_k = config.get("pred_top_k", 100)

        self.num_train_steps = config.get("num_train_steps", 10000)
        self.num_warmup_steps = config.get("num_warmup_steps", 100)

        self.bert_config = BertConfig(
            attention_probs_dropout_prob=config.get("attention_probs_dropout_prob", 0.1),
            hidden_act=config.get("hidden_act", "gelu"),
            hidden_dropout_prob=config.get("hidden_dropout_prob", 0.1),
            hidden_size=config.get("hidden_size", 768),
            initializer_range=config.get("initializer_range", 0.02),
            intermediate_size=config.get("intermediate_size", 3072),
            max_position_embeddings=config.get("max_position_embeddings", 512),
            num_attention_heads=config.get("num_attention_heads", 12),
            num_hidden_layers=config.get("num_hidden_layers", 12),
            type_vocab_size=config.get("type_vocab_size", 2),
            vocab_size=config.get("vocab_size", 21128)
        )

    def create_inputs(self):
        input_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="input_ids")
        input_mask = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="input_mask")
        label_type_ids = tf.compat.v1.placeholder(
            dtype=tf.int32, shape=[None, self.max_seq_length], name="label_type_ids")

        masked_lm_positions = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None, self.max_predictions_per_seq],
                                                       name="masked_lm_positions")
        masked_lm_ids = tf.compat.v1.placeholder(dtype=tf.int32, shape=[None, self.max_predictions_per_seq],
                                                 name="masked_lm_ids")
        masked_lm_weights = tf.compat.v1.placeholder(dtype=tf.float32, shape=[None, self.max_predictions_per_seq],
                                                     name="masked_lm_weights")

        return [input_ids, input_mask, label_type_ids, masked_lm_positions], [masked_lm_ids, masked_lm_weights]

    def call(self, inputs):
        input_ids, input_mask, label_type_ids, masked_lm_positions = inputs
        bert_model = BertModel(config=self.bert_config,
                               input_ids=input_ids,
                               input_mask=input_mask,
                               token_type_ids=label_type_ids,
                               use_one_hot_embeddings=self.use_one_hot_embeddings)

        logits = self.get_masked_lm_output(input_tensor=bert_model.get_sequence_output(),
                                           output_weights=bert_model.get_embedding_table(),
                                           positions=masked_lm_positions)
        outputs = tf.argmax(tf.nn.log_softmax(logits), axis=-1, output_type=tf.int32)
        predictions = tf.argsort(-tf.nn.softmax(logits))[:, :self.pred_top_k]
        return logits, [outputs, predictions]

    def get_masked_lm_output(self, input_tensor, output_weights, positions):
        input_tensor = gather_indexes(input_tensor, positions)
        with tf.variable_scope("masked_lm"):
            # We apply one more non-linear transformation before the output layer.
            # This matrix is not used after pre-training.
            with tf.variable_scope("transform"):
                input_tensor = tf.layers.dense(
                    input_tensor,
                    units=self.bert_config.hidden_size,
                    activation=bert_encoder.get_activation(self.bert_config.hidden_act),
                    kernel_initializer=bert_encoder.create_initializer(
                        self.bert_config.initializer_range))
                input_tensor = bert_encoder.layer_norm(input_tensor)

            # The output weights are the same as the input embeddings, but there is
            # an output-only bias for each token.
            output_bias = tf.get_variable(
                "output_bias",
                shape=[self.bert_config.vocab_size],
                initializer=tf.zeros_initializer())
            logits = tf.matmul(input_tensor, output_weights, transpose_b=True)
            logits = tf.nn.bias_add(logits, output_bias)

            return logits

    def compute_loss(self, logits, labels):
        log_probs = tf.nn.log_softmax(logits, axis=-1)
        label_ids, label_weights = labels
        label_ids = tf.reshape(label_ids, [-1])
        label_weights = tf.reshape(label_weights, [-1])

        one_hot_labels = tf.one_hot(
            label_ids, depth=self.bert_config.vocab_size, dtype=tf.float32)
        # The `positions` tensor might be zero-padded (if the sequence is too
        # short to have the maximum number of predictions). The `label_weights`
        # tensor has a value of 1.0 for every real prediction and 0.0 for the
        # padding predictions.
        per_example_loss = -tf.reduce_sum(log_probs * one_hot_labels, axis=[-1])
        numerator = tf.reduce_sum(label_weights * per_example_loss)
        denominator = tf.reduce_sum(label_weights) + 1e-5
        loss = numerator / denominator
        return loss

    def compute_metrics(self, outputs, labels):
        label_ids, label_weights = labels
        label_ids = tf.reshape(label_ids, [-1])
        label_weights = tf.reshape(label_weights, [-1])
        accuracy = tf.cast(tf.math.equal(outputs[0], label_ids), dtype=tf.float32)
        numerator = tf.reduce_sum(label_weights * accuracy)
        denominator = tf.reduce_sum(label_weights) + 1e-5
        accuracy = numerator / denominator
        return accuracy

