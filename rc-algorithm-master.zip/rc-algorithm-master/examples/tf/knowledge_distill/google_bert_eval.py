import pandas as pd
import tensorflow as tf
import horovod.tensorflow as hvd
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, accuracy_score

from rcalgo.tf.utils.preprocessors import BertSentencePreprocessor
from rcalgo.tf.training import Model


def calc_metrics(probs, labels, threshold=0.5):
    preds = (probs > threshold)
    accuracy = accuracy_score(labels, preds)
    precision = precision_score(labels, preds)
    recall = recall_score(labels, preds)
    f1 = f1_score(labels, preds)
    auc = roc_auc_score(labels, probs)
    print("positive num: %s" % sum(preds))
    print(f"accuracy: {accuracy}\nprecision: {precision}\nrecall: {recall}"
          f"\nf1_score: {f1}\nauc: {auc}\n")


config = {
    "batch_size": 128,
    "max_seq_length": 128,
    "vocab_file": "/home/web_server/antispam/project/pretrained_models/"
                  "chinese_L-12_H-768_A-12/vocab.txt",
}


def main(_):
    # 1. load train data
    input_file = "/home/web_server/antispam/project/datasets/female_vulgar/test.csv"
    test_data = pd.read_csv(input_file)
    preprocessor = BertSentencePreprocessor(config["vocab_file"])
    test_data['input_ids'] = test_data['text'].map(
        lambda x: preprocessor.convert_text_to_ids_string(x))
    """
    input_ids, input_mask, segment_ids = preprocessor.process(
        test_data["text"], max_seq_length=config["max_seq_length"])
    """

    # model = Model.from_checkpoint("./saved_models/distilled_model-epoch35.ckpt")
    # model = Model.from_checkpoint("./saved_models/google_bert-epoch1.ckpt", name="default")
    # model = Model.from_checkpoint("./saved_models/distilled_model_3-epoch39.ckpt", name="student")
    # model = Model.from_checkpoint("./saved_models/distill_4_256-epoch39.ckpt", name="student")
    # model = Model.from_checkpoint("./saved_models/distilled_model_3-epoch39.ckpt", name="student")
    # model = Model.from_checkpoint("./saved_models/first_4_layers-epoch3.ckpt", name="default")
    # model = Model.from_checkpoint("./saved_models/first_2_layers-epoch4.ckpt", name="default")
    # model = Model.from_checkpoint("./saved_models/distill_4_768-epoch36.ckpt", name="student")
    # model = Model.from_checkpoint("./saved_models/task_distill_4_312-epoch5.ckpt", name="student")
    # model = Model.from_checkpoint("./saved_models/basic_distill_4_312-epoch19.ckpt", name="student")
    model = Model.from_checkpoint("./saved_models/task_distill_4_312_da-epoch4.ckpt", name="student")

    if hvd.rank() == 0:
        print(model.model_summary(scope="student"))

    # model.export_freeze_graph("./frozen_models", "distill_4_256")
    # results = model.predict([input_ids, input_mask, segment_ids],
    results = model.predict([test_data['input_ids']],
                            batch_size=config["batch_size"],
                            hooks=[])

    if hvd.rank() == 0:
        calc_metrics(results[0][:, 1], test_data['label'], 0.5)


if __name__ == '__main__':
    tf.app.run()
