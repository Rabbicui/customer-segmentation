import os
import operator
import time
import math
import sys
import pprint
import pandas as pd
from tqdm import tqdm
from IPython.display import display

from .tf_collections import *
from .tf_layer import *


class TFModel(object):
    def __init__(self, config, sess):
        self.sess = sess

        self.learning_rate = config.learning_rate  # learning rate
        self.batch_size = config.batch_size  # batch size to use during training
        self.clip_gradients = config.clip_gradients  # max clip gradients

        self.n_epochs = config.n_epochs  # number of epoch to use during training
        self.epoch_save = config.epoch_save  # save checkpoint or not in each epoch
        self.print_step = config.print_step  # print step duraing training
        self.logs_dir = config.logs_dir
        self.model_dir = config.model_dir
        self.serving_dir = config.serving_dir
        self.model_name = 'tf_models'
        #self.model_name = config.model_name
        if not os.path.isdir(self.logs_dir):
            os.makedirs(self.logs_dir)
        if not os.path.isdir(self.model_dir):
            os.makedirs(self.model_dir)

        self.dir_clear = config.dir_clear
        if self.dir_clear:
            model_logger_dir_prepare(
                self.logs_dir, self.model_dir, self.model_name)
        self.train_writer = tf.compat.v1.summary.FileWriter(self.logs_dir + self.model_name + '/train',
                                                  self.sess.graph)
        self.test_writer = tf.compat.v1.summary.FileWriter(
            self.logs_dir + self.model_name + '/test')
        self.step_train = 0
        self.step_test = 0
        self.summary_step = 0
        self.saver = None
        self.metric_name = 'accuracy'
        self.gpu_option = config.gpu_id
        self.device_str = '/gpu:'
        self.gpu_num = config.gpu_num
        self.gpus = range(0, self.gpu_num)

        # tqdm for print log
        self.sleep_for_tqdm = 1.5

        if hasattr(config, 'opt'):
            self.opt_str = config.opt.lower()
        else:
            self.opt_str = 'adam'

        # learning rate
        self.lr_annealing = True if self.opt_str == 'sgd' else config.lr_annealing
        self.lr_annealing_value = 1.5
        self.lr_stop_value = 1e-5

        # for summary
        self.loss_list = []
        self.optim_list = []
        self.grad_list = []
        self.capped_grad_list = []
        self.metrics_list = []
        self.log_loss = []
        # for multiple gpus
        self.tower_grads = {}
        self.tower_capped_gvs = {}
        self.tower_loss = {}
        self.tower_metrics = {}
        self.tower_prediction_results = []
        self.params = None
        self.prediction_results = None
        # can be used default
        self.lr = {}
        self.lr_value_dict = {}
        self.opt = {}
        # depends on tasks
        self.fetch_dict = {}

        self.op_dict = {'<': operator.lt, '<=': operator.le,
                        '>=': operator.ge, '>': operator.gt}
        self.op_set = set(self.op_dict.values())

        self.best_train_metric = None
        self.best_test_metric = None
        self.run_type = None

        self.default_task_name = config.task_name if hasattr(
            config, 'task_name') else 'default'

        self.input_dict = {}
        self.output_dict = {}

        self.training = tf.compat.v1.placeholder_with_default(tf.constant(False),
                                                    tf.TensorShape(None), name='training')
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.IS_TRAINING, self.training)
        # build dafault setting
        self._build_global_setting(self.default_task_name)

    def _add_optimizer(self, task=None, learning_rate=0.0):
        """
        add default learning_rate and optimizer
        """
        if task is None:
            task = self.default_task_name
        if learning_rate == 0.0:
            learning_rate = self.learning_rate
        # set learning rate
        self.lr_value_dict[task] = learning_rate
        self.lr[task] = tf.Variable(learning_rate, trainable=False)
        # set optimizer
        if self.opt_str == 'sgd':
            self.opt[task] = tf.train.GradientDescentOptimizer(self.lr[task])
        elif self.opt == 'rmsprop':
            self.opt[task] = tf.train.RMSPropOptimizer(
                self.lr[task], momentum=0.9)
        else:
            self.opt[task] = tf.compat.v1.train.AdamOptimizer(self.lr[task])
        # add to collection
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.LR_VARIABLES, self.lr[task])

    def _build_global_setting(self, task=None):
        """
        basic global setting for all dl models
        """
        with tf.name_scope('global'):
            self.global_step = tf.Variable(
                0.0, trainable=False, name='global_step')
        self._add_optimizer(task)

    def _update_optimizer(self, task, old_task=None, learning_rate=0.0):
        if old_task in self.lr_value_dict:
            self.lr_value_dict[task] = self.lr_value_dict.pop(old_task)
            self.lr[task] = self.lr.pop(old_task)
            self.opt[task] = self.opt.pop(old_task)
        else:
            self._add_optimizer(task, learning_rate)

    def _add_to_graph_collection(self, key, var_list):
        """
        add var_list to tensorflow collection via given key
        """
        if not isinstance(var_list, list):
            tf.compat.v1.add_to_collection(key, var_list)
        else:
            for each_input in var_list:
                tf.compat.v1.add_to_collection(key, each_input)

    def _add_to_graph_inputs(self, var_list, task=None):
        if task is None:
            task = self.default_task_name
        self._add_to_graph_collection('{}_{}'.format(
            task, tf.compat.v1.GraphKeys.INPUTS), var_list)

    def _add_to_graph_targets(self, var_list, task=None):
        if task is None:
            task = self.default_task_name
        self._add_to_graph_collection('{}_{}'.format(
            task, tf.compat.v1.GraphKeys.TARGETS), var_list)

    def _add_to_graph_outputs(self, var_list, task=None):
        if task is None:
            task = self.default_task_name
        self._add_to_graph_collection('{}_{}'.format(
            task, tf.compat.v1.GraphKeys.OUTPUTS), var_list)

    def _get_parameters_num(self, shape_list):
        return np.prod(shape_list)

    def _init_tower_list(self, task):
        self.tower_grads[task] = []
        self.tower_capped_gvs[task] = []
        self.tower_loss[task] = []
        self.tower_metrics[task] = []

    def _add_to_tower_list(self, grads, capped_gvs, loss, metric, task=None):
        if task is None:
            task = self.default_task_name
        if task not in self.tower_grads:
            self._init_tower_list(task)
        self.tower_grads[task].append(grads)
        self.tower_capped_gvs[task].append(capped_gvs)
        self.tower_loss[task].append(loss)
        self.tower_metrics[task].append(metric)

    def _add_details(self, loss, optim, grads, capped_gvs, metric):
        self.loss_list.append(loss)
        self.optim_list.append(optim)
        self.grad_list.append(grads)
        self.capped_grad_list.append(capped_gvs)
        self.metrics_list.append(metric)

    def _prediction_ggregation(self):
        # merge prediction results
        if len(self.tower_prediction_results) != 0:
            self.prediction_results = []
            for i in range(0, int(len(self.tower_prediction_results)/self.gpu_num)):
                temp = [self.tower_prediction_results[i] for i in range(i, len(
                    self.tower_prediction_results), int(len(self.tower_prediction_results)/self.gpu_num))]
                self.prediction_results.append(tf.concat(temp, 0))
                self.output_dict['prediction_{}'.format(
                    i)] = tf.saved_model.utils.build_tensor_info(temp[0])
            if len(self.prediction_results) == 1:
                self.prediction_results = self.prediction_results[0]

    # aggregate the gradient, loass, metrics
    def build_model_aggregation(self):
        for key in self.tower_grads.keys():
            grads_avg = average_gradients(self.tower_grads[key])
            capped_gvs_avg = average_gradients(self.tower_capped_gvs[key])
            # each tower has reduce_mean
            if len(self.tower_loss[key][0].shape) == 0:
                #loss = tf.reduce_mean(self.tower_loss[key])
                loss = tf.stack(self.tower_loss[key])
            else:  # each tower has a loss list
                #loss = tf.concat(self.tower_loss[key], 0)
                loss = tf.reduce_mean(tf.stack(self.tower_loss[key]), -1)
            if len(self.tower_metrics[key][0].shape) == 0:
                metric = tf.reduce_mean(self.tower_metrics[key])
            else:
                metric = tf.concat(self.tower_metrics[key], 0)
            tmp_key = key if key in self.opt else self.default_task_name
            train_op = self.opt[tmp_key].apply_gradients(
                capped_gvs_avg, global_step=self.global_step)
            # add to collection
            for graph_key, graph_var in zip([tf.compat.v1.GraphKeys.TRAIN_OPS, tf.compat.v1.GraphKeys.LOSS, tf.compat.v1.GraphKeys.METRICS, tf.compat.v1.GraphKeys.TASKS], [train_op, loss, metric, key]):
                self._add_to_graph_collection(graph_key, graph_var)
            self._add_details(loss, train_op, grads_avg,
                              capped_gvs_avg, metric)
            self.fetch_dict['{}_prediction'.format(key)] = [
                train_op, loss, metric]

        self._prediction_ggregation()
        # dump dict
        self._add_to_graph_collection(
            tf.compat.v1.GraphKeys.INPUT_DICT, list(self.input_dict.values()))
        self._add_to_graph_collection(
            tf.compat.v1.GraphKeys.OUTPUT_DICT, list(self.output_dict.values()))

##############################################################################################################

    def _sleep(self, flag=False):
        if flag:
            time.sleep(self.sleep_for_tqdm)

    # for multiple metric names
    def _set_metric_name(self, name, run_type=None):
        if run_type is None:
            self.metric_name = name
        else:
            self.metric_name = {}
            if isinstance(name, str):
                name = [name] * len(run_type)
            for idx, k in enumerate(run_type):
                self.metric_name[k] = name[idx]

    def get_display_metric_name(self, current_run_type=None):
        if isinstance(self.metric_name, dict):
            if current_run_type is not None:
                return self.metric_name[current_run_type]
            else:
                name_list = list(self.metric_name.values())
                if len(set(name_list)) == 1:
                    return name_list[0]
                else:
                    return '&'.join(name_list)
        else:
            return self.metric_name

    # for multiple metrics
    def _worst_metric(self, worst_metrics=0.0):
        if isinstance(worst_metrics, list):
            return worst_metrics[0]
        else:
            return worst_metrics

    def _multiple_worst_metric(self, run_type, worst_metrics=0.0):
        self.run_type = run_type
        if isinstance(run_type, list):
            if isinstance(worst_metrics, list):
                return dict([(k, worst_metrics[idx]) for idx, k in enumerate(run_type)])
            else:
                return dict([(k, worst_metrics) for k in run_type])
        else:
            return self._worst_metric(worst_metrics)

    # for multiple comparison
    def _better(self, current_metric, best_metric, op=None):
        if isinstance(op, list):
            op = op[0]
        if isinstance(op, str):
            op = self.op_dict[op]
        if op is None or op not in self.op_set:
            op = operator.ge  # deafault op
        return op(current_metric, best_metric)

    def _multiple_better(self, current_metric, best_metric, op=operator.or_, keys=None, keys_op=None):
        if isinstance(current_metric, dict):
            if keys is None:
                keys = current_metric.keys()
            flag = not op(True, False)
            for idx, key in enumerate(keys):
                # the op for current key
                tmp_key_op = keys_op if keys_op is None else keys_op[idx]
                tmp_flag = self._better(
                    current_metric[key], best_metric[key], tmp_key_op)
                if not tmp_flag:
                    current_metric[key] = best_metric[key]
                flag = op(flag, tmp_flag)
            return flag
        else:
            return self._better(current_metric, best_metric, keys_op)

    # set default keys: 'self'
    def _lr_annealing(self, current_loss, last_loss, run_type, split=False):
        keys = self.lr.keys()
        if isinstance(run_type, list):
            if run_type[0] in self.lr.keys():
                keys = run_type
        lr_value_set = set([self.lr_value_dict[k] for k in keys])
        if (split or len(lr_value_set) != 1) and len(run_type) != 1:
            flag = True
            for key in keys:
                # for key in self.lr.keys():
                if self._better(current_loss[key], last_loss[key]*0.9999, '>'):
                    self.lr_value_dict[key] = self.lr_value_dict[key] / \
                        self.lr_annealing_value
                    self.lr[key].assign(self.lr_value_dict[key]).eval()
                flag = operator.and_(flag, self._better(
                    self.lr_value_dict[key], self.lr_stop_value, '<'))
            return flag
        else:
            if self._loss_compare(current_loss, last_loss):
                self.learning_rate = self.learning_rate / self.lr_annealing_value
                for key in keys:
                    # for key in self.lr.keys():
                    self.lr_value_dict[key] = self.learning_rate
                    self.lr[key].assign(self.learning_rate).eval()
            return self._better(self.learning_rate, self.lr_stop_value, '<')

    def _loss_compare(self, current_loss, last_loss):
        if isinstance(current_loss, dict):
            return self._better(np.sum(list(current_loss.values())),
                                np.sum(list(last_loss.values()))*0.9999, '>')
        else:
            return self._better(current_loss, last_loss*0.9999, '>')

    # set default keys: 'self'
    def get_display_learning_rate(self, current_run_type=None):
        if isinstance(self.lr_value_dict, dict):
            if current_run_type is None:
                current_run_type = list(self.lr_value_dict.keys())
            if isinstance(current_run_type, str):
                return self.lr_value_dict[current_run_type]
            else:
                res_dict = dict(
                    {(k, self.lr_value_dict[k]) if k in self.lr_value_dict else self.lr_value_dict[self.default_task_name] for k in current_run_type})
                if len(set(res_dict.values())) == 1:
                    return list(res_dict.values())[0]
                else:
                    return my_format(res_dict)
        else:
            return self.learning_rate

##############################################################################################################

    def _get_feed_dict(self, input_list, input_var, batch_idx, mode):
        feedDict = {}
        for j in range(len(input_var)):
            feedDict[input_var[j]] = input_list[j][batch_idx]
        is_training_var = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.IS_TRAINING)[0]
        feedDict[is_training_var] = (mode == 'train')
        return feedDict

    def _init_metric_loss(self, run_type):
        batchMetrics = {}
        batchLoss = {}
        for each_run_type in run_type:
            batchMetrics[each_run_type] = []
            batchLoss[each_run_type] = []
        return batchMetrics, batchLoss

    def _sess_run(self, mode, run_type, summary_flag, feedDict):
        result = self.sess.run(
            self.fetch_dict['{}_prediction'.format(run_type)][mode == 'test': len(
                self.fetch_dict['{}_prediction'.format(run_type)]) + summary_flag - 1],
            feed_dict=feedDict)
        return result[mode != 'test':]

###############################################################################################################################
    def dump_model(self, model_version):
        export_path_base = self.serving_dir
        export_path = os.path.join(tf.compat.as_bytes(
            export_path_base), tf.compat.as_bytes(str(model_version)))
        legacy_init_op = tf.group(
            tf.compat.v1.tables_initializer(), name='legacy_init_op')
        prediction_signature = (
            tf.compat.v1.saved_model.signature_def_utils.build_signature_def(
                inputs=self.input_dict,
                outputs=self.output_dict,
                method_name=tf.saved_model.PREDICT_METHOD_NAME))
        builder = tf.compat.v1.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            sess=self.sess,
            tags=[tf.saved_model.tag_constants.SERVING],
            #clear_devices = True,
            signature_def_map={
                tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:
                prediction_signature
            },
            legacy_init_op=legacy_init_op
            # main_op=tf.saved_model.main_op.main_op()
        )
        builder.save()

    def build_model_summary(self, summary_step=0):
        for var in tf.compat.v1.trainable_variables():
            tf.compat.v1.summary.histogram(var.name.replace(':', '_'), var)
        for loss in self.loss_list:
            tf.compat.v1.summary.scalar(loss.name.replace(':', '_'), loss)
        for metric in self.metrics_list:
            tf.compat.v1.summary.scalar(metric.name.replace(':', '_'), metric)
        for grads in self.grad_list:
            for grad, var in grads:
                tf.compat.v1.summary.histogram(var.name.replace(
                    ':', '_') + '/gradient', grad)
        for capped_gvs in self.capped_grad_list:
            for grad, var in capped_gvs:
                tf.compat.v1.summary.histogram(var.name.replace(
                    ':', '_') + '/clip_gradient', grad)
        self.merged = tf.compat.v1.summary.merge_all()
        for key in self.fetch_dict.keys():
            self.fetch_dict[key].append(self.merged)
        print('Initializing')
        self.saver = tf.compat.v1.train.Saver()
        self.summary_step = summary_step
        tf.compat.v1.global_variables_initializer().run()
        tf.compat.v1.local_variables_initializer().run()
        tf.compat.v1.tables_initializer().run()

    def model_summary(self):
        columns = ['variable_name', 'variable_shape', 'parameters']
        df_summary = pd.DataFrame(columns=columns)
        for i, var in enumerate(tf.compat.v1.trainable_variables()):
            sl = var.get_shape().as_list()
            df_summary.loc[i] = [var.name, sl, np.prod(sl)]
            #df_summary.loc[i] = [var.name, sl, self._get_parameters_num(sl)]
        return df_summary

    def model_restore(self, model_path=None):
        if model_path == None:
            self.saver.restore(self.sess, '{}{}.ckpt'.format(
                self.model_dir, self.model_name))
        else:
            self.saver.restore(self.sess, model_path)
        print('Load Model ...')

    #training and evaluation
    # support multiple task training !!
    def model_run(self, input_list, idxs, run_type, mode='train', shuffle=True,
                  save_metric=False, type_ratio=None, process_bar=False):
        if len(idxs) % self.gpu_num != 0:
            idxs = idxs[:-(len(idxs) % self.gpu_num)]
        if isinstance(run_type, str):
            run_type = [run_type]
        id_idxs = np.arange(0, len(idxs))
        if shuffle:
            np.random.shuffle(id_idxs)
        # if isinstance(run_type, str):
        #    run_type = [run_type]
        batchMetrics, batchLoss = self._init_metric_loss(run_type)
        samplePreds = []
        self._sleep(process_bar)
        proc_range = range(0, len(idxs), self.batch_size)
        if process_bar:
            proc_range = tqdm(proc_range, desc='training process', leave=True)
        for i, idx in enumerate(proc_range):
            summary_flag = not(self.summary_step == 0 or i %
                               self.summary_step != 0)
            print_str = '\rMinibatch {}: '.format(i)
            for type_i, each_run_type in enumerate(run_type):
                input_var = tf.compat.v1.get_collection('{}_{}'.format(
                    each_run_type, tf.compat.v1.GraphKeys.INPUTS)) + tf.compat.v1.get_collection('{}_{}'.format(each_run_type, tf.compat.v1.GraphKeys.TARGETS))
                if mode == 'train' and type_ratio != None and len(type_ratio) == len(run_type):
                    current_type_ratio = type_ratio[type_i]
                else:
                    current_type_ratio = 1
                start = idx * current_type_ratio % len(idxs)
                for sub_i in range(0, current_type_ratio):
                    sub_start = (start+self.batch_size*sub_i) % len(idxs)
                    batch_idx = np.sort(
                        idxs[id_idxs[sub_start:sub_start+self.batch_size]]).tolist()
                    feedDict = self._get_feed_dict(
                        input_list, input_var, batch_idx, mode)
                    result = self._sess_run(
                        mode, each_run_type, summary_flag, feedDict)
                    l, metr = result[0:2]
                # [mode!='test':(mode!='test')+2]
                # record the loss and metric for current task
                if (not isinstance(metr, np.float32)) or (not math.isnan(metr)):
                    batchMetrics[each_run_type].append(
                        metr*len(batch_idx) if isinstance(metr, np.float32) else np.mean(metr)*len(batch_idx))
                batchLoss[each_run_type].append(
                    l*len(batch_idx) if isinstance(l, np.float32) else np.mean(l)*len(batch_idx))
                # print the current task value of
                if i >= 1 and i % self.print_step == 0:
                    name = '' if each_run_type == self.default_task_name else '{}_task'.format(
                        each_run_type)
                    print_str += '{} / loss:{:.4f} / {}:{:.4f} \t '.format(name,
                                                                           l if isinstance(
                                                                               l, np.float32) else np.mean(l),
                                                                           self.get_display_metric_name(each_run_type), metr if isinstance(metr, np.float32) else np.mean(metr))
                # write the summary
                if summary_flag:
                    if mode == 'train':
                        self.train_writer.add_summary(
                            result[-1], self.step_train)
                    else:
                        self.test_writer.add_summary(
                            result[-1], self.step_test)
                # save the prediction results
                if mode == 'test' and (not shuffle) and save_metric:
                    #print('get results...')
                    if self.prediction_results is not None:
                        preds = self.sess.run(
                            self.prediction_results, feed_dict=feedDict)
                        # here we assume that only one run_type in 'test' period
                        samplePreds.append(preds)
            if i >= 1 and i % self.print_step == 0:
                if process_bar:
                    proc_range.set_description(print_str)
                    proc_range.refresh()
                else:
                    # print(print_str)
                    print(print_str, end="")
                    sys.stdout.flush()
            if summary_flag:
                if mode == 'train':
                    self.step_train += 1
                else:
                    self.step_test += 1

        epochLoss = dict((k, np.array(v).sum() / len(id_idxs))
                         for (k, v) in batchLoss.items())
        epochMetrics = dict((k, np.array(v).sum() / len(id_idxs))
                            for (k, v) in batchMetrics.items())
        # reshape to single task, mainly for easy prediction
        if len(run_type) == 1:
            epochLoss = list(epochLoss.values())[0]
            epochMetrics = list(epochMetrics.values())[0]
        self._sleep(process_bar)
        return epochLoss, epochMetrics, samplePreds

    def run(self, input_list, train_idxs, test_idxs, run_type=None, shuffle=True, type_ratio=None, process_bar=False):
        if run_type is None:
            run_type = self.default_task_name
        if self.run_type is None or self.run_type != run_type:
            self.best_train_metric = self._multiple_worst_metric(run_type)
            self.best_test_metric = self._multiple_worst_metric(run_type)
        self.log_loss = []
        if isinstance(run_type, str):
            run_type = [run_type]
        for epoch in range(self.n_epochs):
            print('Epoch {} ... training ...'.format(epoch+1))
            t1 = time.time()
            epochLoss, epochMetric, _ = self.model_run(input_list, train_idxs, run_type,
                                                       mode='train', shuffle=shuffle, type_ratio=type_ratio,
                                                       process_bar=process_bar)
            t2 = time.time()
            print('{}epoch time: {:.4f}'.format(
                '' if process_bar else '\n', (t2-t1)/60))
            print('Epoch {} training {}: {}'.format(
                epoch+1, self.get_display_metric_name(), my_format(epochMetric)))
            if self._multiple_better(epochMetric, self.best_train_metric, keys=run_type):
                self.best_train_metric = epochMetric

            print('Epoch {} ... test ...'.format(epoch+1))
            epochTestLoss, epochTestMetric, _ = self.model_run(input_list, test_idxs, run_type,
                                                               mode='test', shuffle=False, process_bar=process_bar)

            print('{}Epoch {} test {}: {}'.format('' if process_bar else '\n',
                                                  epoch+1, self.get_display_metric_name(), my_format(epochTestMetric)))
            if self._multiple_better(epochTestMetric, self.best_test_metric, keys=run_type):
                self.best_test_metric = epochTestMetric
                if self.epoch_save:
                    save_path = self.saver.save(self.sess, '{}{}.ckpt'.format(
                        self.model_dir, self.model_name))
                    print("Model saved in file: {}".format(save_path))

            self.log_loss.append([epochLoss, epochTestLoss])
            state = {
                'loss': my_format(epochLoss),
                'valid_los': my_format(epochTestLoss),
                'best_{}'.format(self.get_display_metric_name()): my_format(self.best_train_metric),
                'best_test_{}'.format(self.get_display_metric_name()): my_format(self.best_test_metric),
                'epoch': epoch,
                # self.learning_rate
                'learning_rate': self.get_display_learning_rate(run_type)
                # 'valid_perplexity': math.exp(epochTestLoss)
            }
            pprint.pprint(state)

            if self.lr_annealing and len(self.log_loss) > 1 and self._lr_annealing(self.log_loss[epoch][1], self.log_loss[epoch-1][1], run_type):
                break
