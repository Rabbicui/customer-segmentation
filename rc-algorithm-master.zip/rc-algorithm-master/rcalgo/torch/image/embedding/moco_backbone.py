import torch
import torch.nn as nn
import numpy as np


class MoCo(nn.Module):
    """
    Build a MoCo model with: a query encoder, a key encoder, and a queue
    https://arxiv.org/abs/1911.05722
    """

    def __init__(self, base_encoder, dim=128, K=65536, m=0.999, T=0.07, mlp=True, mlp_layers=3,
                 dim_hid_list=[2048, 512]):
        """
        dim: feature dimension (default: 128)
        K: queue size; number of negative keys (default: 65536)
        m: moco momentum of updating key encoder (default: 0.999)
        T: softmax temperature (default: 0.07)
        """
        super(MoCo, self).__init__()

        self.K = K
        self.m = m
        self.T = T

        # create the encoders
        # num_classes is the output fc dimension
        tmp_model = base_encoder(pretrained=False)
        fc_features = tmp_model.fc.in_features
        tmp_model.fc = nn.Linear(fc_features, dim)

        tmp_model_k = base_encoder(pretrained=False)
        fc_features_k = tmp_model_k.fc.in_features
        tmp_model_k.fc = nn.Linear(fc_features_k, dim)

        self.encoder_q = tmp_model
        self.encoder_k = tmp_model_k

        if mlp:  # hack: brute-force replacement
            dim_mlp = self.encoder_q.fc.weight.shape[1]
            dim_hid = list()
            dim_hid.append(dim_mlp)
            dim_hid += dim_hid_list
            q_mlp = build_mlp(mlp_layers, dim_hid, dim)
            k_mlp = build_mlp(mlp_layers, dim_hid, dim)

            self.encoder_q.fc = nn.Sequential(*q_mlp)
            self.encoder_k.fc = nn.Sequential(*k_mlp)

        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data.copy_(param_q.data)  # initialize
            param_k.requires_grad = False  # not update by gradient

        # create the queue
        self.register_buffer("queue", torch.randn(dim, K))
        self.queue = nn.functional.normalize(self.queue, dim=0)

        self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long))

    @torch.no_grad()
    def _momentum_update_key_encoder(self):
        """
        Momentum update of the key encoder
        """
        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)

    @torch.no_grad()
    def _dequeue_and_enqueue(self, keys):
        # gather keys before updating queue
        keys = concat_all_gather(keys)

        batch_size = keys.shape[0]

        ptr = int(self.queue_ptr)
        assert self.K % batch_size == 0  # for simplicity

        # replace the keys at ptr (dequeue and enqueue)
        self.queue[:, ptr:ptr + batch_size] = keys.T
        ptr = (ptr + batch_size) % self.K  # move pointer

        self.queue_ptr[0] = ptr

    @torch.no_grad()
    def _batch_shuffle_ddp(self, x):
        """
        Batch shuffle, for making use of BatchNorm.
        *** Only support DistributedDataParallel (DDP) model. ***
        """
        # gather from all gpus
        batch_size_this = x.shape[0]
        x_gather = concat_all_gather(x)
        batch_size_all = x_gather.shape[0]

        num_gpus = batch_size_all // batch_size_this

        # random shuffle index
        idx_shuffle = torch.randperm(batch_size_all).cuda()

        # broadcast to all gpus
        torch.distributed.broadcast(idx_shuffle, src=0)

        # index for restoring
        idx_unshuffle = torch.argsort(idx_shuffle)

        # shuffled index for this gpu
        gpu_idx = torch.distributed.get_rank()
        idx_this = idx_shuffle.view(num_gpus, -1)[gpu_idx]

        return x_gather[idx_this], idx_unshuffle

    @torch.no_grad()
    def _batch_unshuffle_ddp(self, x, idx_unshuffle):
        """
        Undo batch shuffle.
        *** Only support DistributedDataParallel (DDP) model. ***
        """
        # gather from all gpus
        batch_size_this = x.shape[0]
        x_gather = concat_all_gather(x)
        batch_size_all = x_gather.shape[0]

        num_gpus = batch_size_all // batch_size_this

        # restored index for this gpu
        gpu_idx = torch.distributed.get_rank()
        idx_this = idx_unshuffle.view(num_gpus, -1)[gpu_idx]

        return x_gather[idx_this]

    def contrastive_loss(self, im_q, im_k):
        # compute query features
        q = self.encoder_q(im_q)  # queries: NxC
        q = nn.functional.normalize(q, dim=1)  # already normalized

        # compute key features
        with torch.no_grad():  # no gradient to keys

            # shuffle for making use of BN
            im_k, idx_unshuffle = self._batch_shuffle_ddp(im_k)

            k = self.encoder_k(im_k)  # keys: NxC
            k = nn.functional.normalize(k, dim=1)

            # undo shuffle
            k = self._batch_unshuffle_ddp(k, idx_unshuffle)

        # compute logits
        # Einstein sum is more intuitive
        # positive logits: Nx1
        l_pos = torch.einsum('nc,nc->n', [q, k]).unsqueeze(-1)
        # negative logits: NxK
        l_neg = torch.einsum('nc,ck->nk', [q, self.queue.clone().detach()])

        # logits: Nx(1+K)
        logits = torch.cat([l_pos, l_neg], dim=1)

        # apply temperature
        logits /= self.T

        # labels: positive key indicators
        labels = torch.zeros(logits.shape[0], dtype=torch.long).cuda()

        loss = nn.CrossEntropyLoss().cuda()(logits, labels)

        return loss, q, k, logits, labels

    def forward(self, im_q, im_k):
        """
        Input:
            im_q: a batch of query images
            im_k: a batch of key images
        Output:
            logits, targets
        """
        # update the key encoder
        with torch.no_grad():  # no gradient to keys
            self._momentum_update_key_encoder()

        loss_12, q1, k2, logits_1, label_1 = self.contrastive_loss(im_q, im_k)
        loss_21, q2, k1, logits_2, label_2 = self.contrastive_loss(im_k, im_q)
        loss = loss_12 + loss_21
        k = torch.cat([k1, k2], dim=0)

        # dequeue and enqueue
        self._dequeue_and_enqueue(k)

        return loss, logits_1, label_1


class MoCoWithMixup(MoCo):

    def __init__(self, base_encoder, mix_prob=0.1, symmetric=True):
        super(MoCoWithMixup, self).__init__(base_encoder)
        self.mix_prob = mix_prob
        self.symmetric = symmetric


    def my_cross_entropy(self, input, target, probs, reduction="mean"):

        exp = torch.exp(input)
        tmp1 = exp.gather(1, target[0].unsqueeze(-1)).squeeze()
        tmp2 = exp.sum(1)
        softmax_1 = tmp1 / tmp2

        log_1 = -torch.log(softmax_1)
        log_1 *= probs[0]

        tmp1 = exp.gather(1, target[1].unsqueeze(-1)).squeeze()
        tmp2 = exp.sum(1)
        softmax_2 = tmp1 / tmp2

        log_2 = -torch.log(softmax_2)
        log_2 *= probs[1]

        if reduction == "mean":
            return log_1.mean() + log_2.mean()
        else:
            return log_1.sum() + log_2.sum()

    def my_contrastive_loss(self, im_q, im_k, label_pos):
        # compute query features
        q = self.encoder_q(im_q)  # queries: NxC
        q = nn.functional.normalize(q, dim=1)  # already normalized

        # compute key features
        with torch.no_grad():  # no gradient to keys

            # shuffle for making use of BN
            im_k, idx_unshuffle = self._batch_shuffle_ddp(im_k)

            k = self.encoder_k(im_k)  # keys: NxC
            k = nn.functional.normalize(k, dim=1)

            # undo shuffle
            k = self._batch_unshuffle_ddp(k, idx_unshuffle)

        # compute logits
        # Einstein sum is more intuitive
        # positive logits: NxN
        l_pos = torch.einsum('ij,kj->ik', [q, k])
        # negative logits: NxK
        l_neg = torch.einsum('nc,ck->nk', [q, self.queue.clone().detach()])

        # logits: Nx(N+K)
        logits = torch.cat([l_pos, l_neg], dim=1)

        # apply temperature
        logits /= self.T

        # labels: positive key indicators
        label_neg = torch.zeros((logits.shape[0], self.K), dtype=torch.long).cuda()
        labels = torch.cat([label_pos, label_neg], dim=1)

        labels = labels.type(torch.FloatTensor).cuda()
        label_values, label_idx = labels.topk(max((1, 2)), 1, True, True)

        loss = self.my_cross_entropy(logits, label_idx.t(), label_values.t())

        return loss, q, k, logits, labels

    @torch.no_grad()
    def mixup(self, im):
        """
        Input:
            im: a batch of query images
        Output:
            mixup imgs, label_pos
        """
        batch_size = len(im)
        prob = torch.rand(batch_size).cuda()
        mix_mask = (prob < self.mix_prob)
        lam = np.random.beta(1, 1, batch_size)
        mixup = torch.from_numpy(lam).cuda() * mix_mask
        mixup = mixup.cuda()
        shuffle_idx = torch.randperm(batch_size)
        newim = im[shuffle_idx]
        res0 = torch.einsum("ijkq,i->ijkq", [im, 1 - mixup])
        res1 = torch.einsum("ijkq,i->ijkq", [newim, mixup])
        res_all = res0 + res1
        res_all = res_all.type(torch.FloatTensor).cuda()
        label_pos_part1 = torch.diag_embed(1 - mixup)
        unshuffle_idx = torch.argsort(shuffle_idx)
        mixup_unshuffle = mixup[unshuffle_idx].cuda()
        shuffle_one_hot = torch.nn.functional.one_hot(shuffle_idx).cuda()
        label_pos_part2 = shuffle_one_hot * mixup_unshuffle
        label_pos = label_pos_part1 + label_pos_part2

        return res_all, label_pos

    def forward(self, im_q, im_k):
        """
        Input:
            im_q: a batch of query images
            im_k: a batch of key images
        Output:
            logits, targets
        """

        # update the key encoder
        with torch.no_grad():  # no gradient to keys
            self._momentum_update_key_encoder()

        res_im_q, label_pos_q = self.mixup(im_q)
        loss_12, q1, k2, logits_1, label_1 = self.my_contrastive_loss(res_im_q, im_k, label_pos_q)
        if not self.symmetric:
            # dequeue and enqueue
            self._dequeue_and_enqueue(k2)
            return loss_12, logits_1, label_1
        else:
            res_im_k, label_pos_k = self.mixup(im_k)
            loss_21, q2, k1, logits_2, label_2 = self.my_contrastive_loss(res_im_k, im_q, label_pos_k)
            loss = 0.5 * loss_12 + 0.5 * loss_21
            # dequeue and enqueue
            self._dequeue_and_enqueue(k2)
            return loss, logits_1, label_1


# utils
@torch.no_grad()
def concat_all_gather(tensor):
    """
    Performs all_gather operation on the provided tensors.
    *** Warning ***: torch.distributed.all_gather has no gradient.
    """
    tensors_gather = [torch.ones_like(tensor)
                      for _ in range(torch.distributed.get_world_size())]
    torch.distributed.all_gather(tensors_gather, tensor, async_op=False)

    output = torch.cat(tensors_gather, dim=0)
    return output


def build_mlp(mlp_layers, dim_hid, dim):
    layers = []
    for i in range(mlp_layers - 1):
        layers.append(nn.Linear(dim_hid[i], dim_hid[i + 1]))
        layers.append(nn.ReLU())
    layers.append(nn.Linear(dim_hid[-1], dim))
    return layers
