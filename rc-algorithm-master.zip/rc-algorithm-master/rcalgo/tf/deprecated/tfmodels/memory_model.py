import sys
import os
import math
#sys.path.insert(0,'..')
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))
from rcalgo.tf.tftraining.tf_object import *
import tensorflow as tf

#random_uniform or truncated_normal? it's a question.. sigh..
class MemN2NModel(TFModel):
    def __init__(self, config, graph):
        super(MemN2NModel, self).__init__(config, graph)
        self.nb_words = config.nb_words
        self.init_hid = config.init_hid
        self.init_std = config.init_std
        self.init_scale = config.init_std
        self.mem_size = config.mem_size #the mem_size (max length) of input sequence
        self.embedding_size = config.embedding_size #embedding size
        self.nhop = config.nhop
        self.lindim = int(math.floor(config.linear_ratio * self.embedding_size))
        self.tower_attentions = [[] for i in range(0,self.gpu_num)]

    def build_input(self):
        with tf.name_scope('input'):
            input_context = tf.compat.v1.placeholder(tf.int32, [None, self.mem_size], name="context")
            output_target = tf.compat.v1.placeholder(tf.int32, [None], name="target")
            self.input_dict['text'] = tf.saved_model.utils.build_tensor_info(input_context)
            self._add_to_graph_inputs([input_context])
            self._add_to_graph_targets(output_target)
            self.split_input_context = tf.split(input_context, self.gpu_num, 0)
            self.split_output_target = tf.split(output_target, self.gpu_num, 0)
        self._build_global_setting()
        with tf.name_scope('state_array'):
            self.hid_list = [[] for i in range(0,self.gpu_num)]


    def build_memory(self, gpu_id=0):
        with get_new_variable_scope('memory') as memory_scope:
            Ain_c = my_embedding_layer(self.split_input_context[gpu_id], self.nb_words, self.embedding_size, layer_name='Ain_c', init_scale=self.init_scale)
            with get_new_variable_scope('Ain_t') as scope:
                Ain_t = tf.compat.v1.get_variable('W', [self.mem_size, self.embedding_size],
                                        initializer = tf.random_uniform_initializer(-self.init_scale,self.init_scale))
                                        #initializer=tf.truncated_normal_initializer(0.0, self.init_std))
            Ain = tf.add(Ain_c, Ain_t)
            input_q = tf.ones_like(Ain[:,0])/10
            Cin_c = my_embedding_layer(self.split_input_context[gpu_id], self.nb_words, self.embedding_size, layer_name='Cin_c',init_scale=self.init_scale)
            with get_new_variable_scope('Cin_t') as scope:
                Cin_t = tf.compat.v1.get_variable('W', [self.mem_size, self.embedding_size],
                                        initializer = tf.random_uniform_initializer(-self.init_scale,self.init_scale))
                                        #initializer=tf.truncated_normal_initializer(0.0, self.init_std))
            Cin = tf.add(Cin_c, Cin_t)
        with tf.name_scope('hidden_state'):
            #self.hid = []
            #self.hid.append(input_q)
            self.hid_list[gpu_id].append(input_q)
        with get_new_variable_scope('momory_hops') as hops_scope:
            with get_new_variable_scope('hops_h') as scope:
                H = tf.compat.v1.get_variable('W',[self.embedding_size, self.embedding_size],
                                    initializer = tf.random_normal_initializer(0.0,self.init_std))
            for h in range(self.nhop):
                hid3dim = tf.reshape(self.hid_list[gpu_id][-1], [-1, 1, self.embedding_size])
                Aout = tf.matmul(hid3dim, Ain, adjoint_b=True)
                Aout_norm = tf.nn.softmax(Aout)
                #add the attention_distribution
                self.tower_attentions[gpu_id] = Aout_norm
                Cout = tf.matmul(Aout_norm, Cin)
                Cout2dim = tf.reshape(Cout, [-1, self.embedding_size])
                Dout = tf.add(tf.matmul(self.hid_list[gpu_id][-1], H), Cout2dim)
                #linear relu for a part of hidden unit
                if self.lindim == self.embedding_size:
                    self.hid_list[gpu_id].append(Dout)
                elif self.lindim == 0:
                    self.hid_list[gpu_id].append(tf.nn.relu(Dout))
                else:
                    F = tf.slice(Dout, [0, 0], [-1, self.lindim])
                    G = tf.slice(Dout, [0, self.lindim], [-1, self.embedding_size-self.lindim])
                    K = tf.nn.relu(G)
                    self.hid_list[gpu_id].append(tf.concat([F, K],1))


    def build_prediction(self, type='self', accK=5, nb_class=None, gpu_id=0):
        if type == 'self':
            nb_class = self.nb_words
        elif nb_class == None:
            raise Exception("nb_class must be given")
        with get_new_variable_scope('prediction') as pred_scope:
            prediction = my_full_connected(self.hid_list[gpu_id][-1], nb_class,
                                           add_bias=False, layer_name='fc',
                                           act=tf.identity, init_std=self.init_std)
            self.tower_prediction_results.append(tf.nn.softmax(prediction))
            #self.params = tf.compat.v1.trainable_variables()[1:]
            self.params = tf.compat.v1.trainable_variables()
        with tf.name_scope('train'):
            ce_loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.split_output_target[gpu_id], logits=prediction)
            grads, capped_gvs = my_compute_grad(self.opt, ce_loss, self.params,
                                                clip_type = 'clip_norm',
                                                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
                accuracy = tf.to_float(tf.nn.in_top_k(prediction, self.split_output_target[gpu_id],k=accK))
        self._add_to_tower_list(grads, capped_gvs, ce_loss, accuracy)

    @replace_default_graph
    def build_model(self, type='self', accK=5, nb_class=None, export_attention=False):
        self.build_input()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=(idx!=0))
                    with gpu_scope as gpu_scope:
                        self.build_memory(gpu_id=idx)
                        self.build_prediction(type=type,accK=accK,nb_class=nb_class,gpu_id=idx)
        self.build_model_aggregation()
        if export_attention:
            self.prediction_results = [self.prediction_results, tf.concat(self.tower_attentions,0)]
        self._add_to_graph_outputs(self.prediction_results)
        self.output_dict['attention'] = tf.saved_model.utils.build_tensor_info(self.tower_attentions[0])
        self._add_to_graph_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT, self.output_dict['attention'])

