import sys

#sys.path.insert(0,'..')
import os
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../"))
from rcalgo.tf.tfmodels.rnnlm import *
from tftools.tf_float_type import get_default_float_type

import tensorflow.contrib.seq2seq as seq2seq
from tensorflow.python.util import nest
from tensorflow.python.layers.core import Dense
from tensorflow.contrib.seq2seq.python.ops import attention_wrapper
from tensorflow.contrib.seq2seq.python.ops import beam_search_decoder
from tensorflow.python.ops.rnn_cell_impl import _zero_state_tensors


"""
Set up the decoder components
    - Embedding
    - Decoder cell
    - Dense output layer
    - Training decoder
    - Inference decoder
"""


class Seq2SeqModel(RNNLMModel):
    def __init__(self, config, graph, word_dict=None, target_word_dict=None):
        super(Seq2SeqModel, self).__init__(config, graph, word_dict)
        self.output_maxlen = config.output_maxlen
        self.output_hidden_size = config.output_hidden_size if hasattr(
            config, 'output_hidden_size') else self.hidden_size
        self.output_keep_prob = config.output_keep_prob if hasattr(
            config, 'output_keep_prob') else self.keep_prob
        self.output_num_layers = config.output_num_layers if hasattr(
            config, 'output_num_layers') else self.num_layers
        self.num_decoder_symbols = config.num_decoder_symbols if hasattr(
            config, 'num_decoder_symbols') else self.nb_words
        self.beam_width = config.beam_width
        #self.go_value = config.go_value
        self.sampling_probability = config.sample_prob
        self.scheduled_sampling = True if self.sampling_probability == 1.0 else False
        self.eos_value = 0 #config.eos_value if hasattr(
        #    config, 'eos_value') else 0
        self.attention_type = config.attention_type
        self.attention_size = config.attention_size
        self.use_beamsearch_decode = True if self.beam_width > 1 else False
        self.use_residual = False if self.attention_size > 0 else self.use_residual
        self.target_word_dict = target_word_dict if word_dict is None else word_dict
        if self.raw_text and self.target_word_dict is not None:
            self.target_word_table, self.num_decoder_symbols = self._init_word_table(self.target_word_dict)
        else:
            self.target_word_table = None

    def _get_target_text_parameters(self, expand_input=False):
        return self.target_word_table, self.output_maxlen, self.num_decoder_symbols

    def build_input(self, expand_input=True):
        super(Seq2SeqModel, self).build_input(expand_input)
        with tf.name_scope('states_array'):
            self.training_decoder_output = [[] for i in range(0, self.gpu_num)]
            self.inference_decoder_output = [[] for i in range(0, self.gpu_num)]
            #self.output_embedding = [[] for i in range(0,self.gpu_num)]

    def build_input_sequence(self, gpu_id=0):
        super(Seq2SeqModel, self).build_input_sequence(gpu_id=gpu_id)

    def build_output(self, expand_input=True, key='target'):
        if expand_input:
            self.num_decoder_symbols = self.num_decoder_symbols + 4
            self.go_value = self.num_decoder_symbols - 2
        split_targets, split_targets_seqLengths = self.build_text_input(expand_input=expand_input,key=key)
        self.split_targets = [tf.cast(t, tf.int32) for t in split_targets]
        self.split_targets_seqLengths = [tf.cast(t, tf.int32) for t in split_targets_seqLengths]
        #self.max_target_sequence_length = tf.reduce_max(tf.concat(self.split_targets_seqLengths, axis=0), name='max_target_len')

    def build_decoder_cell(self, gpu_id, reuse):

        batch_size = self.dynamic_batch_size

        encoder_outputs = self.state_list[gpu_id]
        encoder_last_state = self.rnn_output_list[gpu_id][0]
        encoder_inputs_length = self.split_seqLengths[gpu_id]

        # if True:
        if self.use_beamsearch_decode and reuse:
            print("use beamsearch decoding..")
            encoder_outputs = seq2seq.tile_batch(
                encoder_outputs, multiplier=self.beam_width)
            encoder_last_state = nest.map_structure(
                lambda s: seq2seq.tile_batch(s, self.beam_width), encoder_last_state)
            #有的时候会报小于0的error，不清楚why
            encoder_inputs_length = seq2seq.tile_batch(
                encoder_inputs_length, multiplier=self.beam_width)
            #print(encoder_inputs_length)
            batch_size = self.dynamic_batch_size * self.beam_width

        # define attention mechanism
        if self.attention_size > 0:
            # 'Luong' style attention: https://arxiv.org/abs/1508.04025
            if self.attention_type.lower() == 'luong':
                attention_mechanism = attention_wrapper.LuongAttention(
                    num_units=self.output_hidden_size,
                    memory=encoder_outputs,
                    memory_sequence_length=encoder_inputs_length)
            else:
                attention_mechanism = attention_wrapper.BahdanauAttention(
                    num_units=self.output_hidden_size,
                    memory=encoder_outputs,
                    memory_sequence_length=encoder_inputs_length)

        decoder_cell_list = [rnn_cell.DropoutWrapper(rnn_cell.LSTMCell(self.output_hidden_size, use_peepholes=False),
                                       input_keep_prob=self.keep_prob, output_keep_prob=self.keep_prob) for _ in range(self.num_layers)]
        decoder_initial_state = encoder_last_state

        # if not self.use_beamsearch_decode \
        #             else self.dynamic_batch_size * self.beam_width
        initial_state = [state for state in encoder_last_state]

        # add attention wrapper
        if self.attention_size > 0:
            decoder_cell_list[-1] = attention_wrapper.AttentionWrapper(
                cell=decoder_cell_list[-1],
                attention_mechanism=attention_mechanism,
                attention_layer_size=self.attention_size,
                initial_cell_state=decoder_initial_state[-1],
                alignment_history=False,
                name='Attention_Wrapper')
            initial_state[-1] = decoder_cell_list[-1].zero_state(
                batch_size=batch_size, dtype=get_default_float_type()).clone(
                cell_state=initial_state[-1])
            decoder_initial_state = tuple(initial_state)
        return rnn_cell.MultiRNNCell(decoder_cell_list), decoder_initial_state

    def build_training_decoder(self, gpu_id, dec_embed_input, dec_embeddings, output_layer):
                               # dec_cell, initial_state, output_layer):
        with tf.compat.v1.variable_scope("decode"):
            dec_cell, initial_state = self.build_decoder_cell(
                gpu_id, False)
            if self.scheduled_sampling:
                training_helper = tf.contrib.seq2seq.ScheduledEmbeddingTrainingHelper(
                    inputs=dec_embed_input,
                    sequence_length=self.split_targets_seqLengths[gpu_id],
                    embedding=dec_embeddings,
                    sampling_probability=self.sampling_probability,
                    time_major=False)
            else:
                training_helper = tf.contrib.seq2seq.TrainingHelper(
                    inputs=dec_embed_input,
                    sequence_length=self.split_targets_seqLengths[gpu_id],
                    time_major=False)
            # Basic decoder
            training_decoder = tf.contrib.seq2seq.BasicDecoder(
                dec_cell,
                training_helper,
                initial_state,
                # self.rnn_output_list[gpu_id],
                output_layer)

            return tf.contrib.seq2seq.dynamic_decode(
                training_decoder,
                impute_finished=True,
                maximum_iterations=self.output_maxlen)[0]

    def build_inference_decoder(self, gpu_id, dec_embeddings, output_layer):
                                # dec_cell, initial_state, output_layer):
        with tf.compat.v1.variable_scope("decode", reuse=True):
            dec_cell, initial_state = self.build_decoder_cell(
                gpu_id, True)
            start_tokens = tf.ones_like(
                self.split_inputX[gpu_id][:, 0],
                dtype=tf.int32) * self.go_value
            if self.use_beamsearch_decode:
                # initial_state = tf.contrib.seq2seq.tile_batch(
                #    initial_state, multiplier=self.beam_width)
                # end_token = tf.ones_like(
                #    self.split_targets[gpu_id][:, 0],
                #    dtype=tf.int32) * self.eos_value
                inference_decoder = beam_search_decoder.BeamSearchDecoder(
                    cell=dec_cell,
                    embedding=dec_embeddings,
                    start_tokens=start_tokens,
                    end_token=self.eos_value,
                    initial_state=initial_state,
                    beam_width=self.beam_width,
                    output_layer=output_layer)
            else:
                if self.scheduled_sampling:
                    inference_helper = tf.contrib.seq2seq.SampleEmbeddingHelper(
                        dec_embeddings, start_tokens, self.eos_value)
                else:
                    # Helper for the inference process.
                    inference_helper = tf.contrib.seq2seq.GreedyEmbeddingHelper(
                        dec_embeddings, start_tokens, self.eos_value)

                inference_decoder = tf.contrib.seq2seq.BasicDecoder(
                    dec_cell,
                    inference_helper,
                    initial_state,
                    # self.rnn_output_list[gpu_id],
                    output_layer)

            # Perform dynamic decoding using the decoder
            return tf.contrib.seq2seq.dynamic_decode(
                inference_decoder,
                #impute_finished=True,
                maximum_iterations=self.output_maxlen)[0]

    def build_output_sequence(self, gpu_id):

        # 0. Decoder Input
        decoder_start_token = tf.ones_like(
            self.split_inputX[gpu_id][:, 0:1], dtype=tf.int32) * self.go_value
        dec_input = tf.concat(
            [decoder_start_token, self.split_targets[gpu_id][:, 0:-1]], axis=1)
        # print(dec_input)
        # 1. Decoder Embedding
        dec_embed_input = my_embedding_layer(
            dec_input,
            self.num_decoder_symbols,
            self.embedding_size,
            variables_collections='decoder_embedding',
            layer_name='decoder_embedding_layer',
            init_scale=self.init_scale)
        dec_embeddings = tf.compat.v1.get_collection('decoder_embedding')[0]
        # 2. Construct the decoder cell
        #dec_cell, decoder_initial_state = self.build_decoder_cell(gpu_id, layer_norm)
        # print(decoder_initial_state)

        # 3. Dense output layer
        output_layer = Dense(
            self.num_decoder_symbols,
            kernel_initializer=tf.truncated_normal_initializer(
                mean=0.0, stddev=0.1))
        # training_decoder
        self.training_decoder_output[gpu_id] = self.build_training_decoder(
            gpu_id, dec_embed_input, dec_embeddings,  # dec_cell, decoder_initial_state,
            output_layer)
        # inference_decoder
        self.inference_decoder_output[gpu_id] = self.build_inference_decoder(
            0, dec_embeddings,  # dec_cell, decoder_initial_state,
            output_layer)

    def build_output_sequence_prediction(self, gpu_id, task=None, accK=1):
        if task is None:
            task = self.default_task_name
        paddings = tf.constant([[0, 0], [0, self.output_maxlen]])
        if self.use_beamsearch_decode:
            predictions = self.training_decoder_output[gpu_id].rnn_output
            logits = tf.where(self.training,
                              tf.pad(self.training_decoder_output[gpu_id].sample_id, paddings, "CONSTANT")[:,0:self.output_maxlen],
                              tf.pad(self.inference_decoder_output[gpu_id].predicted_ids[:, :, 0], paddings, "CONSTANT")[:,0:self.output_maxlen])
        else:
            predictions = tf.where(
                self.training, self.training_decoder_output[gpu_id].rnn_output,
                self.inference_decoder_output[gpu_id].rnn_output)
            logits = tf.where(self.training,
                              self.training_decoder_output[gpu_id].sample_id,
                              self.inference_decoder_output[gpu_id].sample_id)
        #self.tower_prediction_results.append(predictions)
        self.tower_prediction_results.append(logits)
        if self.use_beamsearch_decode:
            self.tower_prediction_results.append(
                self.inference_decoder_output[gpu_id].predicted_ids)
            #self.tower_prediction_results.append(
            #    self.inference_decoder_output[gpu_id].beam_search_decoder_output.scores)
            #self.tower_prediction_results.append(
            #    self.inference_decoder_output[gpu_id].beam_search_decoder_output.predicted_ids)
        if self.params is None:
            self.params = tf.compat.v1.trainable_variables()
        with tf.name_scope('loss'):
            paddings = tf.constant([[0, 0], [0, self.output_maxlen], [0,0]])
            predictions_paddings = tf.pad(predictions, paddings, "CONSTANT")[:,0:self.output_maxlen,:]
            loss = variable_seq_loss(
                predictions_paddings, self.split_targets[gpu_id], self.label_smooth, self.num_decoder_symbols)
            grads = self.opt[task].compute_gradients(loss, self.params)
            grads, capped_gvs = my_compute_grad(
                self.opt,
                loss,
                self.params,
                clip_type='clip_value', task=task,
                max_clip_grad=self.clip_gradients)
        with tf.name_scope('accuracy'):
            accuracy = varibale_accuracy(
                logits, self.split_targets[gpu_id])
            """
            accuracy2 = varibale_topk_accuracy(
                predictions, self.split_targets[gpu_id], k=accK)
            if self.use_beamsearch_decode:
                accuracy = tf.where(self.training, accuracy2, accuracy1)
            else:
                accuracy = accuracy2
            """
        self._add_to_tower_list(grads, capped_gvs, loss, accuracy, task)

    @replace_default_graph
    def build_model(self, task=None, accK=1, nb_class=None):
        self.build_input()
        self.build_output()
        for idx, gpu_id in enumerate(self.gpus):
            with tf.device('/gpu:%d' % gpu_id):
                with tf.name_scope('Tower_%d' % (idx)) as tower_scope:
                    reuse = (idx != 0)
                    gpu_scope = tf.compat.v1.variable_scope('gpu', reuse=reuse)
                    with gpu_scope as gpu_scope:
                        self.build_input_sequence(
                            gpu_id=idx)
                        self.build_output_sequence(
                            gpu_id=idx)
                        self.build_output_sequence_prediction(
                            gpu_id=idx, accK=accK)
        self._dump_rnn_output()
        self._add_to_graph_outputs(self.prediction_results)