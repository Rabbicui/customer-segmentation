"""
Subclassing API Demo

运行脚本的命令:
单卡:
    PYTHONPATH=.. python horovod_subclassing_demo.py
单机8卡:
    PYTHONPATH=.. horovodrun -np 8 python horovod_subclassing_demo.py
多机多卡:
    PYTHONPATH=.. horovodrun -np 16 -H server1:8,server2:8 python horovod_subclassing_demo.py
"""

import pandas as pd
import tensorflow as tf

from rcalgo.tf.training import Model
from rcalgo.tf.models.knowledge_distill.distiller import GeneralDistiller, TinyBertDistiller
from rcalgo.tf.models.knowledge_distill.adaptors import GoogleBertAdaptor
from rcalgo.tf.models.knowledge_distill.losses import TinyBertLoss
from rcalgo.tf.models.finetune.google_bert import BertClassificationModel
from util.preprocessors import GoogleBertPreprocessor


student_config = {
    "num_classes": 2,
    "max_seq_length": 128,
    # "num_attention_heads": 12,
    "num_hidden_layers": 4,
    "hidden_size": 312,
    "intermediate_size": 1200,
}


distiller_config = {
    "learning_rate": 0.0005,
}


def main(_):
    # 1. load data
    data_dir = "/home/web_server/antispam/project/datasets/female_vulgar/"
    train_data = pd.read_csv(data_dir + 'train.csv')
    test_data = pd.read_csv(data_dir + 'test.csv')
    # count word dict
    preprocessor = GoogleBertPreprocessor()
    input_ids, input_mask, segment_ids = preprocessor.process(train_data['text'])
    input_ids_t, input_mask_t, segment_ids_t = preprocessor.process(test_data['text'])

    # 2. create and load teacher model
    teacher = Model.from_checkpoint(
        "/home/web_server/antispam/project/zhouyalin/model_checkpoints/"
        "google_bert_female_vulgar/google_bert-epoch3.ckpt", name="default")
    # teacher.evaluate([input_ids_t, input_mask_t, segment_ids_t,
    #                   test_data['label']], batch_size=256)

    # 3. create student model
    # 需要获取student的trainable_variables, 所以建一个variable_scope
    with tf.variable_scope("student_scope"):
        student = BertClassificationModel(config=student_config, name="student").build_model()
        print(student.model_summary())

    # 4. create distiller
    distiller = GeneralDistiller(
        config=distiller_config, teacher=teacher, student=student,
        student_variable_scope="student_scope",
        adaptor_t=GoogleBertAdaptor(), adaptor_s=GoogleBertAdaptor(),
        loss_func=TinyBertLoss(emb_loss_weights=0.0, attn_loss_weights=0.0,
                               hidden_loss_weights=0.0),
        name="distiller").build_model()
    distiller.restore_weights("./saved_models/general_distill_4_312-epoch4.ckpt")

    # 5. distill
    distiller.train(
        [input_ids, input_mask, segment_ids,
            input_ids, input_mask, segment_ids, train_data['label']],
        batch_size=256, test_size=0.1, epochs=40,
        checkpoint_dir="./saved_models",
        checkpoint_name="task_distill_4_312")

    # 6. evaluate
    student.evaluate([input_ids_t, input_mask_t, segment_ids_t, test_data['label']],
                     batch_size=128)


if __name__ == '__main__':
    tf.app.run()
