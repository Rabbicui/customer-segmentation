import numpy as np
import tensorflow as tf

from rcalgo.tf.training import context
from rcalgo.tf.training.data.tf_dataset import TFDataset


class TFDatasetTest(tf.test.TestCase):
    def setUp(self):
        context.clear_session()

    def test_shard(self):
        test_data = np.array([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])

        test_dataset = TFDataset.from_numpy([test_data])
        shard_dataset = test_dataset.shard(4, 3).batch(100)
        iterator = shard_dataset.make_iterator()
        iterator.reinitialize()
        shard_data = context.get_session().run(iterator.next_element())
        self.assertAllEqual(shard_data[0], [5, 9])

    def test_split(self):
        test_data = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])

        test_dataset = TFDataset.from_numpy([test_data])
        shard_dataset = test_dataset.split(4, 3).batch(100)
        iterator = shard_dataset.make_iterator()
        iterator.reinitialize()
        split_data = context.get_session().run(iterator.next_element())
        self.assertAllEqual(split_data[0], [7, 8, 9, 10, 11])


if __name__ == "__main__":
    tf.test.main()
