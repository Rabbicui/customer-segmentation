import os
import tensorflow as tf
import collections
import pandas as pd
import numpy as np
import re

from rcalgo.tf.training.training_utils import get_from_task_collection


class Task(object):
    def __init__(self, task_name, task_index=0):
        self.task_name = task_name
        self.task_index = task_index
        self.inputs = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.INPUTS))
        self.targets = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.TARGETS))
        self.outputs = tf.compat.v1.get_collection("{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.OUTPUTS))
        self.input_iters = tf.compat.v1.get_collection("{}_{}".format(
            self.task_name, tf.compat.v1.GraphKeys.INPUT_ITER))
        self.input_iter_incarnation_ids = \
            tf.compat.v1.get_collection(
                "{}_{}".format(self.task_name, tf.compat.v1.GraphKeys.INPUT_ITER_INCARNATION_ID))

        self.lr_variables = self._compatible_get_collection(tf.compat.v1.GraphKeys.LR_VARIABLES)
        self.lr_annealing_variables = self._compatible_get_collection(tf.compat.v1.GraphKeys.LR_ANNEALING_VARIABLES)
        self.train_ops = self._compatible_get_collection(tf.compat.v1.GraphKeys.TRAIN_OPS)
        self.loss_list = self._compatible_get_collection(tf.compat.v1.GraphKeys.LOSS)
        self.metric_list = self._compatible_get_collection(tf.compat.v1.GraphKeys.METRICS)
        self.tvar_list = self._compatible_get_collection(tf.compat.v1.GraphKeys.TVARS)
        # 避免metric_list为空时报错
        if not self.metric_list:
            self.metric_list = self.loss_list
        self.lr_index = 0  # also for train_op_index

    @property
    def input_iter(self):
        return self.input_iters[0]

    @property
    def input_iter_incarnation_id(self):
        return self.input_iter_incarnation_ids[0]

    @property
    def lr_variable(self):
        return self.lr_variables[self.lr_index]

    @property
    def lr_annealing_variable(self):
        return self.lr_annealing_variables[self.lr_index]

    @property
    def train_op(self):
        return self.train_ops[self.lr_index]

    @property
    def loss(self):
        return self.loss_list[0]

    @property
    def metric(self):
        return self.metric_list

    @property
    def tvars(self):
        return self.tvar_list

    def _compatible_get_collection(self, collection_name):
        new_name = "{}_{}".format(self.task_name, collection_name)
        items = tf.compat.v1.get_collection(new_name)
        if not items:
            items = tf.compat.v1.get_collection(collection_name)[self.task_index: self.task_index + 1]
            for item in items:
                tf.compat.v1.add_to_collection(new_name, item)
        return items

    def _get_op_from_collection(self, collection_name, index):
        ops = tf.compat.v1.get_collection(collection_name)
        if index > 0 and len(ops) == 1:
            return ops[0]
        else:
            return ops[index]

    def __hash__(self):
        return hash(self.task_index)

    def __eq__(self, other):
        return other is not None and isinstance(other, Task) and self.task_index == other.task_index

    def __ne__(self, other):
        return not(self == other)

    def __str__(self):
        return self.task_name


class Trainer(object):
    def __init__(self, config={}, session=None, default_task_name="default", **kwargs):
        self.default_task_name = default_task_name

        self.session = None
        self.graph = session.graph if session else tf.compat.v1.get_default_graph()
        self.all_tasks = None

        self.max_to_keep = config.get('max_to_keep', 5)
        self.model_output_dir = config.get("model_output_dir", "./saved_models")
        self.model_name = config.get("model_name", default_task_name)
        self.save_checkpoint = config.get("save_checkpoint", True)

    def train(self, data, task_names, epochs, hooks=[], reinitialize=False):
        raise NotImplementedError

    def evaluate(self, data, task_names, hooks=[]):
        raise NotImplementedError

    def predict(self, data, task_name, output_indexes=None, hooks=[]):
        raise NotImplementedError

    def _get_tasks(self, task_names):
        task_collection = [
            name.decode()
            if isinstance(name, bytes)
            else name
            for name in tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TASKS)]
        if not task_names:
            task_names = [task_collection[0]]  # None treated as default, the 0th of task_names
        elif not isinstance(task_names, list):
            task_names = [task_names]
        return [Task(task_name=name, task_index=task_collection.index(name)) for name in task_names]

    def _filter_task(self, task_names=None):
        if not task_names:
            # return [self.all_tasks[0]]
            task_names = [self.default_task_name]
        tasks = []
        for name in task_names:
            # too lazy to create a dict
            for task in self.all_tasks:
                if task.task_name == name:
                    tasks.append(task)
        return tasks

    def _filter_collection(self, task_name, collection_name, index=None):
        nodes = get_from_task_collection(task_name, collection_name)
        if index is None:
            return nodes
        if not isinstance(index, list):
            index = [index]
        nodes = [nodes[idx] for idx in index]
        return nodes

    def _get_all_tasks(self):
        task_collection = [
            name.decode() if isinstance(name, bytes) else name
            for name in tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TASKS)]
        return [Task(task_name=name, task_index=task_collection.index(name)) for name in task_collection]

    def export_freeze_graph(self, graph_dir, model_version, task_name="default",
                            input_index=None, output_index=0, clear_devices=True,
                            as_text=False, export_mata_graph=True):
        """
        Export frozen graph. Note that this function fetches nodes from
        tf.compat.v1.GraphKeys.INPUTS instead of tf.compat.v1.GraphKeys.INPUT_DICT,
        which is different from its old version
        """
        export_path = os.path.join(graph_dir, str(model_version), "frozen.pb")
        input_nodes = self._filter_collection(
            task_name, tf.compat.v1.GraphKeys.INPUTS, input_index)
        self.graph.clear_collection(tf.compat.v1.GraphKeys.INPUT_DICT)
        [tf.compat.v1.add_to_collection(tf.compat.v1.GraphKeys.INPUT_DICT, node) for node in input_nodes]
        output_nodes = self._filter_collection(
            task_name, tf.compat.v1.GraphKeys.OUTPUTS, output_index)
        self.graph.clear_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT)
        [tf.compat.v1.add_to_collection(tf.compat.v1.GraphKeys.OUTPUT_DICT, node) for node in output_nodes]

        OUTPUT_NODE = [node.op.name for node in output_nodes]
        table_init_op = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TABLE_INITIALIZERS)
        for op in table_init_op:
            OUTPUT_NODE.append(op.name)
        graphdef_def = self.graph.as_graph_def()
        # tf.graph_util.remove_training_nodes(graphdef_def.as_graph_def())
        graphdef_frozen = tf.compat.v1.graph_util.convert_variables_to_constants(
            self.session, graphdef_def, OUTPUT_NODE)
        if export_mata_graph:
            tf.compat.v1.train.export_meta_graph(
                filename=export_path, graph_def=graphdef_frozen,
                collection_list=[
                    tf.compat.v1.GraphKeys.TABLE_INITIALIZERS,
                    tf.compat.v1.GraphKeys.INPUT_DICT,
                    tf.compat.v1.GraphKeys.OUTPUT_DICT],
                as_text=as_text,
                clear_devices=clear_devices)
        else:
            if not os.path.isdir(os.path.join(graph_dir, str(model_version))):
                os.makedirs(os.path.join(graph_dir, str(model_version)))
            tf.train.write_graph(graphdef_frozen, './',
                                 export_path, as_text=as_text)

    def _build_dict(self, key_prefix, values):
        keys = ["{}_{}".format(key_prefix, index) for index in range(len(values))]
        values = [
            value
            if isinstance(value, tf.compat.v1.TensorInfo)
            else tf.saved_model.utils.build_tensor_info(value)
            for value in values]
        return dict(zip(keys, values))

    def dump_model(self, serving_dir, model_version, task_name="default",
                   input_index=None, output_index=None, clear_devices=True):
        # here we use tf.compat.v1.GraphKeys.INPUTS instead of tf.compat.v1.GraphKeys.INPUT_DICT
        input_nodes = self._filter_collection(task_name, tf.compat.v1.GraphKeys.INPUTS, input_index)
        output_nodes = self._filter_collection(task_name, tf.compat.v1.GraphKeys.OUTPUTS, output_index)

        export_path = os.path.join(serving_dir, str(model_version))
        legacy_init_op = tf.group(
            tf.compat.v1.tables_initializer(), name="legacy_init_op")
        prediction_signature = (
            tf.compat.v1.saved_model.signature_def_utils.build_signature_def(
                inputs=self._build_dict("input", input_nodes),
                outputs=self._build_dict("output", output_nodes),
                method_name=tf.saved_model.PREDICT_METHOD_NAME))
        builder = tf.compat.v1.saved_model.builder.SavedModelBuilder(export_path)
        builder.add_meta_graph_and_variables(
            sess=self.session,
            tags=[tf.saved_model.tag_constants.SERVING],
            clear_devices=clear_devices,
            signature_def_map={
                tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:
                prediction_signature
            },
            main_op=legacy_init_op
            # legacy_init_op=legacy_init_op
        )
        builder.save()

    def restore_checkpoint_from_output(self, model_path=None):
        saver = tf.compat.v1.train.Saver()
        if model_path is None:
            saver.restore(self.session, os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name)))
        else:
            saver.restore(self.session, model_path)
        print("Reload Model ...")

    def restore_variables_from_output(self, model_path=None, tvars=None):
        if not model_path:
            model_path = os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name))
        tvars = tf.trainable_variables() if tvars is None else tvars
        (assignment_map, _) = self.get_assignment_map_from_checkpoint(tvars, model_path)
        tf.train.init_from_checkpoint(model_path, assignment_map)
        self.session.run(tf.compat.v1.global_variables_initializer())

    @staticmethod
    def get_assignment_map_from_checkpoint(tvars, init_checkpoint):
        """Compute the union of the current variables and checkpoint variables."""
        initialized_variable_names = {}

        name_to_variable = collections.OrderedDict()
        for var in tvars:
            name = var.name
            m = re.match("^(.*):\\d+$", name)
            if m is not None:
                name = m.group(1)
            name_to_variable[name] = var

        init_vars = tf.train.list_variables(init_checkpoint)
        # print(f"init_vars : {init_vars} from ckpt: {init_checkpoint}")

        assignment_map = collections.OrderedDict()
        for x in init_vars:
            (name, var) = (x[0], x[1])
            if name not in name_to_variable:
                continue
            assignment_map[name] = name_to_variable[name]
            initialized_variable_names[name] = 1
            initialized_variable_names[name + ":0"] = 1

        return assignment_map, initialized_variable_names

    def dump_checkpoint(self, model_path=None):
        saver = tf.compat.v1.train.Saver()
        # TODO: fix the hacky code
        saver._max_to_keep = 0
        saver.saver_def.max_to_keep = 0
        if model_path is None:
            model_path = self._get_dump_path()
        directory = os.path.dirname(model_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        save_path = saver.save(self.session, model_path)
        print("Model checkpoint saved in file: {}".format(save_path))

    def _get_dump_path(self, epoch=None):
        if epoch is None:
            return os.path.join(self.model_output_dir, "{}.ckpt".format(self.model_name))
        else:
            return os.path.join(self.model_output_dir, "{}-epoch{}.ckpt".format(self.model_name, epoch))

    def export_graph_def(self, path):
        graphdef_inf = tf.graph_util.remove_training_nodes(self.graph.as_graph_def())
        with open(path, 'w') as f:
            f.write(str(graphdef_inf))

    def model_summary(self, scope=None):
        columns = ['variable_name', 'variable_shape', 'parameters']
        df_summary = pd.DataFrame(columns=columns)
        parameter_count = 0
        for i, var in enumerate(tf.compat.v1.trainable_variables(scope=scope)):
            if var.get_shape().dims is None:
                sl = 'unknown'
                para_num = 0
            else:
                sl = var.get_shape().as_list()
                para_num = np.prod(sl)
            df_summary.loc[i] = [var.name, sl, para_num]
            parameter_count += para_num
        print("total parameter number:", parameter_count)
        return df_summary
