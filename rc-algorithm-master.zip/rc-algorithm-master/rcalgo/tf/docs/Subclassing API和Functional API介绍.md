## Functional API和Subclassing API



### 1. Functional API

#### 要解决的问题

tensorflow新用户经常碰到的一个问题就是：网络结构都定义好了，下一步要怎么训练呢？这时候他有几种选择：

1. 用最底层的session.run自己编写for循环
2. 使用tf.estimator
3. 使用keras
4. 使用其他包含训练功能的第三方库

但是这些选择都存在一些缺点，比如上手困难，接口不灵活，不支持分布式训练等，functional api就是希望能为模型训练提供一个更好的工具。

#### 设计思路

在构建好graph以后，我们在训练使用到的节点大致可以分为以下几类：

* inputs: 模型输入
* outputs: 模型输出
* metrics: 模型评估指标
* labels: 输入数据的label
* loss: 模型要最小化的loss
* train_op：更新模型参数

训练、预测、评估等场景，其实就是把一批数据放入input(, labels)中，执行outputs、metrics、train_op中的一个或多个。

|          | train | predict | evaluate | train_and_evaluate |
| -------- | ----- | ------- | -------- | ------------------ |
| inputs   | ✔     | ✔       | ✔        | ✔                  |
| outputs  |       | ✔       |          |                    |
| metrics  |       |         | ✔        | ✔                  |
| labels   | ✔     |         | ✔        | ✔                  |
| loss     |       |         |          |                    |
| train_op | ✔     |         |          | ✔                  |

同时需要做到：

* 支持多种输入：list, numpy, tf.dataset等
* 多卡并行：支持单机多卡和多机多卡

Functional api就是上面这些场景最直观的实现，具体接口为：

```python
def functional_model(inputs=None,
                     outputs=None,
                     labels=None,
                     loss=None,
                     metrics=[],
                     train_op=None,
                     **kwargs):
  
# example
model = functional_model(inputs=xx, outputs=xx, labels=xx, loss=xx, metrics=xx, train_op=xx)
mode.train(..)
model.predict(..)
model.evaluate(..)
```

只要指定好模型的inputs、outputs、labels、train_op等节点对应graph中的哪些节点，就可以得到一个model的实例。model实例具体支持的功能包括：

* 构图相关
  * set_optimizer：为模型设置或更新optimizer (模型的train_op将会被替换成新optimizer对应的train_op)
  * model_sumamry：打印模型的trainable_variables相关的信息
  * add_extra_attr：添加额外的attributes并保存到graph collection中
* 训练相关
  * train
  * train_and_evaluate
  * evaluate
  * predict
  * train_on_batch
  * predict_on_batch
  * evaluate_on_batch
* 模型保存相关
  * restore_weights
  * restore_checkpoint
  * dump_checkpoint
  * dump_model
  * export_freeze_graph
  * from_checkpoint
  * from_meta_graph
  
  


### 2. Subclassing API

Functional api的目标是把灵活性发挥到极致，但是这也带来了一个缺点，就是不利于模块的复用，因为我们提供了另外一套subclassing api来提高模块的复用性。它把模型构建划分成了多个相互独立的阶段：

* build_model: 构建整个模型
  * build_forward: 构建前向图
    * create_inputs: 定义模型输入和label
    * call: 定义模型前向传播的逻辑
    * compute_loss: 定义模型的loss
    * compute_metrics: 定义模型的metrics
  * build_optimization: 构建反向传播图
    * create_optimizer: 定义模型的optimizer

具体的接口为：

```python
class Model(Module):
  def __init__(config):
  	# 解析config
    # 初始化layer
    
  def create_inputs(self):
    # 定义inputs和labels
    return inputs, labels
  
  def call(self, inputs):
    # 定义前向传播的逻辑
    # logits: 计算loss需要用到的tensor
    # outputs：模型predict时的输出
    return logits, outputs
  
  def compute_loss(self, logits, labels):
    # 定义模型的loss
    return loss
  
  def compute_metrics(self, outputs, labels):
    # 定义模型的metrics
    return metrics
  
  def create_optimizer(self):
    # 定义模型的optimizer
    return optimizer
  
# 使用
model = YourModel(config=config, name="your_model_name")
model.build_model()
model.train(..)
```

如果要实现某个模型，只需要重写其中的某个接口即可，实现完以后，用户就可以一键调用定义好的模型了。

> 注意: 接口中的inputs, outputs, labels, logits, metrics都可以是单个tensor，也可以是list of tensor，用list of tensor可以实现多输入、多输出。
>
> 注意: compute_metrics返回的是per_example_metric，也就是reduce_mean之前的tensor，这一点跟loss不太一样，loss是reduce_mean之后的tensor



上面的所有接口都会在build_model时按顺序调用，具体的调用顺序和参数的含义可以直接看build_forward的这段代码：

```python
def build_forward(self, **kwargs):
  """Build forward propagation."""
  self.inputs, self.labels = self.create_inputs()
  logits, self.outputs = self.call(self.inputs, **kwargs)
  self.loss = self.compute_loss(logits, self.labels)
  self.metrics = self.compute_metrics(self.outputs, self.labels)
  self.add_extra_attrs(logits) # 在graph collection中添加额外的attributes

  # 将inputs、outputs、labels、loss、metrics等节点通过graph collection传递给trainer
  training_utils.create_task_in_graph(
    self.inputs, self.outputs, self.labels, self.loss,
    self.metrics, name=self.name)
```

其中最核心的是training_utils.create_task_in_graph这行，它将模型的输入输出等信息写入到graph collection中，trainer会直接从graph collection中拿到这些信息，并开始训练。

> 如果subclassing api定义的接口或参数无法满足需求，可以直接重写build_forward()函数，按照自己的需要定义新的接口即可。
>
> 注意：在定义新的接口时，为了支持Model当作Module来使用，最好将主要逻辑依然保留在call()函数中



#### 从Module的角度看待Subclassing API

Subclassing api包含了构图的逻辑，从某种意义上说，它实现了一部分Module的功能，因此我们在定义Model类的时候将Module作为它的基类。这样用户在实现代码的时候不需要再纠结要实现到module里还是实现到model里，如果仅用来构图，两者可以认为是等价的。

对比一下Module类的接口：

```python
class Module(tf.Module):
  def __init__():
    # 解析config
    # 初始化layer
    
  def build(input_shape):
    # 依赖input_shape的layer，在这里初始化
    
  def call(inputs):
    return outputs
```

可以看出Model类增加了create_inputs, compute_loss, compute_metrics等接口，这些正是模型训练需要额外提供的信息。

所以Model可以看作是Module的一个扩充版，它将Module欠缺的功能全部补齐，从而得到了一个可以独立训练的模型。

> Model继承自Module，所以也有build()接口，只是一般Model类都知道输入的shape，所以不太用得到build()，也就没有显式的定义出来。
