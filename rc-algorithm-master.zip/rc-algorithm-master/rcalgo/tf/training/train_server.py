from tensorflow.core.protobuf import config_pb2
from tensorflow.python.training import server_lib
import argparse
import tensorflow as tf
import json
import sys, os

sys.path.append(os.path.join(os.path.abspath(
    os.path.dirname(__file__)), "../"))

from rcalgo.tf.utils.train_config import set_cuda_environment

FLAGS = None


def main(*args):
    worker_config = config_pb2.ConfigProto()
    worker_config.gpu_options.allow_growth = True
    worker_config.experimental.collective_group_leader = ('/job:chief/replica:0/task:0')
    worker_config.allow_soft_placement = True
    worker_config.log_device_placement = True
    with open(FLAGS.cluster_spec_path) as json_file:
        cluster_spec_json = json.load(json_file)
        num_gpu_per_worker = cluster_spec_json.get('num_gpu_per_worker')
        cluster_spec_json.pop('num_gpu_per_worker', None)
    # 少配置一个输入参数，和cluster_config对齐
    FLAGS.gpu_num = num_gpu_per_worker
    set_cuda_environment(FLAGS)
    cluster_spec = server_lib.ClusterSpec(cluster_spec_json)

    server = server_lib.Server(cluster_spec,
                               job_name=FLAGS.task_type,
                               protocol='grpc+mpi',
                               task_index=FLAGS.task_index,
                               config=worker_config,
                               start=True)
    server.join()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cluster_spec_path",
        type=str,
        default="",
        help="file path of cluster spec"
    )
    parser.add_argument(
        "--task_type",
        type=str,
        default="",
        help="One of 'chief', 'worker'"
    )
    parser.add_argument(
        "--task_index",
        type=int,
        default=0,
        help="Index of task within the job"
    )
    parser.add_argument(
        "--gpu_id",
        type=int,
        default=0,
        help="num of gpus per worker"
    )
    FLAGS, unparsed = parser.parse_known_args()
    tf.app.run(main=main)
