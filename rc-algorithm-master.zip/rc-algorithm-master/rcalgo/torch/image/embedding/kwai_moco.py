import os
import math
import torch
import random
import builtins

from torch import nn
from torchvision import models
import torch.multiprocessing as mp
import torch.distributed as dist
import torch.backends.cudnn as cudnn
import torchvision.transforms as transforms
from PIL import ImageFilter
from rcalgo.torch.image.embedding.moco_backbone import MoCoWithMixup
from rcalgo.torch.image.embedding.mixture import ImageMixture
from rcalgo.torch.image.classification.dataset import CustomImageFolder
from rcalgo.torch.image.classification import utils


class TwoCropsTransform:
    """Take two random crops of one image as the query and key."""

    def __init__(self, base_transform):
        self.base_transform = base_transform

    def __call__(self, x):
        q = self.base_transform(x)
        k = self.base_transform(x)
        return [q, k]


class GaussianBlur(object):

    def __init__(self, sigma=[.1, 2.]):
        self.sigma = sigma

    def __call__(self, x):
        sigma = random.uniform(self.sigma[0], self.sigma[1])
        x = x.filter(ImageFilter.GaussianBlur(radius=sigma))
        return x

train_tx = TwoCropsTransform(transforms.Compose([
    transforms.RandomResizedCrop(224, scale=(0.2, 1.)),
    transforms.RandomApply([
        transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)  # not strengthened
    ], p=0.8),
    transforms.RandomGrayscale(p=0.2),
    transforms.RandomApply([GaussianBlur([.1, 2.])], p=0.5),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
]))

class ModelWrapper(nn.Module):
    def __init__(self, model):
        # 这边会去掉最后的mlp， 只保留到模型pooling后的emb
        super().__init__()
        self.layers = nn.Sequential(*list(model.children())[:-1])

    def forward(self, x):
        self.layers.eval()
        x = self.layers(x)
        x = x.squeeze(2)
        x = x.squeeze(2)
        x_norm = torch.norm(x, dim=1, keepdim=True)
        x_normed = x / x_norm
        self.layers.train()
        return x_normed


class KwaiMocoSSL(object):
    def __init__(self, config):
        self.config = config

    def train(self, train_data, batch_size, checkpoint_dir, checkpoint_name, epochs=None):
        self.config['ckpt_dir'] = checkpoint_dir
        self.config['ckpt_name'] = checkpoint_name
        self.config['batch_size'] = batch_size
        self.config['world_size'] = torch.cuda.device_count()
        if epochs is not None:
            self.config['epochs'] = epochs

        torch.multiprocessing.freeze_support()

        # do train
        mp.spawn(self.node_run, nprocs=torch.cuda.device_count(), args=(self.config, train_data))


    def node_run(self, gpu, config, train_data):
        cudnn.benchmark = True

        dist_url = config.get('dist_url', 'tcp://localhost:10002')
        world_size = config['world_size']
        batch_size = config['batch_size']
        lr = config.get('lr', 0.03)
        weight_decay = config.get('weight_decay', 1e-4)
        pretrain_path = config.get('pretrain_path', '/home/web_server/antispam/project/multimodal/image/moco.pth.tar')
        # two arguments must be provided
        ckpt_dir = config['ckpt_dir']
        ckpt_name = config['ckpt_name']
        logdir = config.get('logdir', './')
        logname = config.get('logname', 'embedding_train')

        savename = ckpt_dir + '/' + ckpt_name

        logger = utils.setup_logger(logdir, logname)

        # default epoch is set by given dataset size
        train_size = len(train_data['image'])
        if train_size < 10 * 10000:
            default_epoch = 20
        elif train_size < 50 * 10000:
            default_epoch = 40
        else:
            default_epoch = 100
        epochs = config.get('epochs', default_epoch)

        if gpu != 0:
            def print_pass(*args):
                pass

            builtins.print = print_pass

        workers = 4

        rank = gpu
        dist.init_process_group(backend='nccl', init_method=dist_url,
                                world_size=world_size, rank=rank)

        # create model
        model = MoCoWithMixup(models.__dict__['resnet50'])

        # 设置model 到对应 process  的gpu
        torch.cuda.set_device(gpu)
        model.cuda(gpu)
        # 调整原batch_size, 多个进程均分
        batch_size = int(batch_size / world_size)
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[gpu])

        opt = torch.optim.SGD(model.parameters(), lr,
                                    momentum=0.9,
                                    weight_decay=weight_decay)

        # Map model to be loaded to specified single gpu.
        loc = 'cuda:{}'.format(gpu)
        checkpoint = torch.load(pretrain_path, map_location=loc)
        #args.start_epoch = checkpoint['epoch']
        model.load_state_dict(checkpoint['state_dict'])
        # 这个地方 需要续 之前的opt 状态么？
        opt.load_state_dict(checkpoint['optimizer'])
        self.printf(gpu, logger, "=> model build successfully with checkpoint '{}' (epoch {})".format(
            pretrain_path, checkpoint['epoch']))

        # custom dataset
        # use custom data
        train_set = CustomImageFolder(data=train_data, transform=train_tx)

        self.printf(gpu, logger, "Using a training set with {} images.".format(len(train_set)))

        # use default mixture cutmix
        train_set = ImageMixture(train_set)

        train_sampler = torch.utils.data.distributed.DistributedSampler(train_set)
        train_loader = torch.utils.data.DataLoader(
            train_set, batch_size=batch_size, shuffle=(train_sampler is None),
            num_workers=workers, pin_memory=True, sampler=train_sampler, drop_last=True)


        ## TODO: 这块的逻辑和 classification 有点不同，没有仔细去调整
        for epoch in range(0, epochs):
            train_sampler.set_epoch(epoch)
            # train for one epoch
            self.train_one_epoch(model, opt, epoch, epochs, gpu, train_loader, lr, logger)
            if gpu == 0:
                # 只有一个process 可以保存
                path = os.path.dirname(savename)
                if not os.path.exists(path):
                    os.makedirs(path)

                # 和分类不同这里我们会保存每个epoch
                utils.dump(model, opt, -1, savename)
                # save tracing
                utils.script_tracing(ModelWrapper(model.module.encoder_q), savename,
                                     example=torch.rand([1, 3, 224, 224]))

    def train_one_epoch(self, model, opt, epoch, epochs, gpu, train_loader, last_epoch_lr, logger):
        # self train的方式一般都是训练时间越长越好 ，好像没有必要存中间值 ？
        step = 0
        steps_one_epoch = len(train_loader)
        for i, (images, _) in enumerate(train_loader):
            # Schedule sending to GPU(s)
            new_lr = self.new_learning_rate(last_epoch_lr, epoch, epochs, step, steps_one_epoch)
            self.set_learning_rate(opt, new_lr)
            images[0] = images[0].cuda(gpu, non_blocking=True)
            images[1] = images[1].cuda(gpu, non_blocking=True)

            # compute output
            loss, output, target = model(im_q=images[0], im_k=images[1])
            # acc1/acc5 are (K+1)-way contrast classifier accuracy
            # measure accuracy and record loss
            loss_num = float(loss.data.cpu().numpy())  # Also ensures a sync point.
            acc1, acc5 = self.accuracy_for_mixup(output, target, topk=(1, 5))
            acc1 = float(acc1.data.cpu().numpy())
            acc5 = float(acc5.data.cpu().numpy())
            # print info
            if step % 10 == 0 and gpu == 0:
                logger.info(
                    f"epoch: {epoch} step: {step} loss={loss_num:.5f}  acc@1={acc1:.5f} acc@5={acc5:.5f} "
                    f"(lr={new_lr:.1e}) ")  # pylint: disable=logging-format-interpolation
                logger.flush()

            # Update params
            opt.zero_grad()
            loss.backward()
            opt.step()

            step += 1

    def new_learning_rate(self, lr, epoch, epochs, step, steps_one_epoch):
        # 这里采用默认的cosine decay 不过因为是做finetune所以先对第一个epoch 做 warmup
        if epoch == 0:
            # linear warmup
            lr = lr * (step + 1) / steps_one_epoch
        else:
            lr *= 0.5 * (1. + math.cos(math.pi * (epoch - 1) / (epochs - 1)))
        return lr

    def set_learning_rate(self, opt, lr):
        for param_group in opt.param_groups:
            param_group['lr'] = lr

    def accuracy_for_mixup(self, output, target, topk=(1,)):
        with torch.no_grad():
            maxk = max(topk)
            _, pred = output.topk(maxk, 1, True, True)
            pred = pred.t()
            _, target_new = target.topk(max((1,)), 1, True, True)
            target_new = target_new.squeeze(1)
            correct = pred.eq(target_new.view(1, -1).expand_as(pred))
            batch_size = target_new.size(0)
            res = []
            for k in topk:
                correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
                res.append(correct_k.mul_(100.0 / batch_size))
            return res

    def printf(self, gpu, logger, info):
        if gpu == 0:
            logger.info(info)
