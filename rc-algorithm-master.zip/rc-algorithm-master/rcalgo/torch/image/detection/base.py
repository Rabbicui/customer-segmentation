import os
import sys
import glob
import time
import math
import torch
import numpy as np

from torch.cuda import amp
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from pathlib import Path

from rcalgo.torch.image.detection.utils.torch_utils import ModelEMA
from rcalgo.torch.image.detection.utils.test import test
from rcalgo.torch.image.detection.utils.model_tracing import script_tracing
from rcalgo.torch.image.detection.utils.general import setup_logger, fitness, \
    labels_to_class_weights, check_img_size, plot_images, strip_optimizer


class ObjectDetection(object):
    def __init__(self, config):
        self.config = config
        self.classes = config.get('num_classes', -1)
        if self.classes < 0:
            raise Exception('num_classes not set')
        self.names = config.get('class_names', -1)
        self.single_cls = config.get('single_cls', False)

        self.lr = config.get('lr', 0.003)
        self.logdir = config.get('logdir', './')
        self.logname = config.get('logname', 'train')
        self.img_size = config.get('img_size', [640, 640])

        self.weight_path = None  # pretrain model path
        self.opt = None  # model config
        self.hyp = None  # model hyperparameters
        self.cri = None
        self.lr_scheduler = None
        self.model = None
        self.optim = None
        self.batch_size = None
        self.freeze_list = []
        self.logger = None

    def init_model(self):
        raise NotImplementedError

    def create_optimizer(self):
        raise NotImplementedError

    def create_dataloader(self, train_data, val_data):
        raise NotImplementedError

    def criterion(self, pred, targets):
        raise NotImplementedError

    def create_scheduler(self, epoch):
        lr_scheduler = torch.optim.lr_scheduler.StepLR(self.optim, step_size=2)
        return lr_scheduler

    def optional_resume(self, epochs, weights_dir, results_file):
        return None

    def optional_freeze(self):
        if any(self.freeze_list):
            for k, v in self.model.named_parameters():
                if any(x in k for x in self.freeze_list):
                    print('freezing %s' % k)
                    v.requires_grad = False
        return None

    def new_batch(self, x, y, train_size):
        return x, y

    def train(self, train_data, val_data, ckpt_dir, ckpt_name, batch_size=16, total_epoch=None):
        self.logger = setup_logger(self.logdir, self.logname)
        # save model config and model hyperparameters
        self.logger.info(f'model config {self.opt}')
        self.logger.info(f'model hyperparameters {self.hyp}')

        self.batch_size = batch_size
        # nominal batch size
        nbs = 64
        # accumulate loss before optimizing
        accumulate = max(round(nbs / batch_size), 1)

        # set ckpt and conf path
        ckpt_dir = Path(ckpt_dir) / ckpt_name
        wdir = ckpt_dir / 'weights'  # weights directory
        os.makedirs(wdir, exist_ok=True)
        last = wdir / 'last.pt'
        best = wdir / 'best.pt'
        results_file = str(ckpt_dir / 'results.txt')
        tb_writer = SummaryWriter(log_dir=ckpt_dir)

        # model parallel
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        model = self.init_model()
        self.model = model

        # freeze optional params
        self.optional_freeze()

        # build opt
        optim = self.create_optimizer()
        self.optim = optim

        # resume train
        resume_params = self.optional_resume(total_epoch, wdir, results_file)
        start_epoch, best_fitness = resume_params if resume_params else (
            0, 0.0)

        # build
        self.lr_scheduler = self.create_scheduler(total_epoch)

        # build cri
        cri = torch.nn.CrossEntropyLoss().to(device)
        self.cri = cri

        # build data loader
        train_loader, train_set, valid_loader, valid_set = self.create_dataloader(train_data, val_data)
        mlc = np.concatenate(train_set.labels, 0)[
            :, 0].max()  # max label class
        nb = len(train_loader)  # number of batches
        assert mlc < self.classes, 'Label class %g exceeds nc=%g in config file. Possible class labels are 0-%g' % (
            mlc, self.classes, self.classes - 1)

        # Image sizes
        gs = int(max(self.model.stride))  # grid size (max stride)
        # verify imgsz are gs-multiples
        imgsz, imgsz_test = [check_img_size(x, gs) for x in self.img_size]

        # Model parameters
        self.hyp['cls'] *= self.classes / \
            80.  # scale coco-tuned hyp['cls'] to current dataset
        model.nc = self.classes  # attach number of classes to model
        model.hyp = self.hyp  # attach hyperparameters to model
        model.gr = 1.0  # giou loss ratio (obj_loss = 1.0 or giou)
        model.class_weights = labels_to_class_weights(
            train_set.labels, self.classes).to(device)  # attach class weights
        model.names = self.names

        # Start training
        model = torch.nn.DataParallel(model)
        model = model.to(device)
        ema = ModelEMA(model)   # Exponential moving average
        ema.updates = start_epoch * nb // accumulate    # set EMA updates

        t0 = time.time()
        cuda = device.type != 'cpu'
        # number of warmup iterations, max(3 epochs, 1k iterations)
        nw = max(3 * nb, 1e3)

        # 'P', 'R', 'mAP', 'F1', 'val GIoU', 'val Objectness', 'val Classification'
        results = (0, 0, 0, 0, 0, 0, 0)
        self.lr_scheduler.last_epoch = start_epoch - 1  # do not move
        scaler = amp.GradScaler(enabled=cuda)

        def lf(x): return ((1 + math.cos(x * math.pi / total_epoch)) /
                           2) * (1 - self.hyp['lrf']) + self.hyp['lrf']  # cosine
        self.logger.info(
            'Image sizes %g train, %g test\nUsing %g dataloader workers\nLogging results to %s\n'
            'Starting training for %g epochs...' %
            (imgsz, imgsz_test, train_loader.num_workers, ckpt_dir, total_epoch))

        with open(results_file, 'a') as f:
            column_name = ('%10s' * 15) % ('epoch', 'mem', 'lbox', 'lobj', 'lcls',
                                           'loss', 'targets', 'imgs', 'mp', 'mr',
                                           'map50', 'map', 'val_lbox', 'val_lobj',
                                           'val_lcls')
            f.write(column_name + '\n')

        for epoch in range(start_epoch, total_epoch):
            model.train()
            mloss = torch.zeros(4, device=device)  # mean losses
            pbar = enumerate(train_loader)
            self.logger.info(
                ('\n' + '%10s' * 8) %
                ('Epoch', 'gpu_mem', 'GIoU', 'obj', 'cls', 'total', 'targets', 'img_size'))

            pbar = tqdm(pbar, total=nb)  # progress bar
            optim.zero_grad()

            for i, (imgs, targets, paths, _) in pbar:  # batch
                # number integrated batches (since train start)
                ni = i + nb * epoch
                # uint8 to float32, 0-255 to 0.0-1.0
                imgs = imgs.to(device, non_blocking=True).float() / 255.0

                # Warmup
                if ni <= nw:
                    xi = [0, nw]  # x interp
                    accumulate = max(
                        1, np.interp(
                            ni, xi, [
                                1, nbs / batch_size]).round())
                    for j, x in enumerate(optim.param_groups):
                        # bias lr falls from 0.1 to lr0, all other lrs rise
                        # from 0.0 to lr0
                        x['lr'] = np.interp(
                            ni, xi, [
                                0.1 if j == 2 else 0.0, x['initial_lr'] * lf(epoch)])
                        if 'momentum' in x:
                            x['momentum'] = np.interp(
                                ni, xi, [0.9, self.hyp['momentum']])

                # Forward
                with amp.autocast(enabled=cuda):
                    pred = model(imgs)  # forward
                    loss, loss_items = self.criterion(
                        pred, targets.to(device))  # loss scaled by batch_size

                # Backward
                scaler.scale(loss).backward()

                # Optimize
                if ni % accumulate == 0:
                    scaler.step(optim)  # optimizer.step
                    scaler.update()
                    optim.zero_grad()
                    ema.update(model)

                # Print
                mloss = (mloss * i + loss_items) / \
                    (i + 1)  # update mean losses
                mem = '%.3gG' % (torch.cuda.memory_reserved(
                ) / 1E9 if torch.cuda.is_available() else 0)  # (GB)
                s = ('%10s' * 2 + '%10.4g' * 6) % (
                    '%g/%g' % (epoch, total_epoch - 1), mem, *mloss, targets.shape[0], imgs.shape[-1])
                pbar.set_description(s)

                # Plot
                if ni < 3:
                    f = str(ckpt_dir / ('train_batch%g.jpg' % ni))  # filename
                    result = plot_images(
                        images=imgs, targets=targets, paths=paths, fname=f)
                    if tb_writer and result is not None:
                        tb_writer.add_image(
                            f, result, dataformats='HWC', global_step=epoch)

                # end batch

            # Scheduler
            self.lr_scheduler.step()

            # mAP
            if ema:
                ema.update_attr(
                    model,
                    include=[
                        'yaml',
                        'nc',
                        'hyp',
                        'gr',
                        'names',
                        'stride'])
            final_epoch = epoch + 1 == total_epoch
            if not self.opt.notest or final_epoch:  # Calculate mAP
                if final_epoch:  # replot predictions
                    [os.remove(x) for x in glob.glob(
                        str(ckpt_dir / 'test_batch*_pred.jpg')) if os.path.exists(x)]
                results, maps, times = test(self.opt,
                                            batch_size=batch_size,
                                            imgsz=imgsz_test,
                                            model=ema.ema,
                                            single_cls=self.opt.single_cls,
                                            dataloader=valid_loader,
                                            save_dir=ckpt_dir)

            # Write
            with open(results_file, 'a') as f:
                # P, R, mAP, F1, test_losses=(GIoU, obj, cls)
                f.write(s + '%10.4g' * 7 % results + '\n')

            # Update best mAP
            # fitness_i = weighted combination of [P, R, mAP, F1]
            fi = fitness(np.array(results).reshape(1, -1))
            if fi > best_fitness:
                best_fitness = fi

            # Save model
            save = not self.opt.nosave or final_epoch
            if save:
                with open(results_file, 'r') as f:  # create checkpoint
                    ckpt = {
                        'epoch': epoch,
                        'best_fitness': best_fitness,
                        'training_results': f.read(),
                        'model': ema.ema,
                        'optimizer': None if final_epoch else optim.state_dict()}

                # Save last, best and delete
                torch.save(ckpt, last)
                if best_fitness == fi:
                    torch.save(ckpt, best)
                del ckpt
            # end epoch
        # end training

        # tracing model
        if os.path.isfile(best):
            script_tracing(best)

        # Strip optimizers
        fresults = ckpt_dir / f'results_{ckpt_name}.txt'
        flast = wdir / f'last_{ckpt_name}.pt'
        fbest = wdir / f'best_{ckpt_name}.pt'
        for f1, f2 in zip([wdir / 'last.pt', wdir / 'best.pt',
                          results_file], [flast, fbest, fresults]):
            if os.path.exists(f1):
                os.rename(f1, f2)  # rename
                if str(f2).endswith('.pt'):  # is *.pt
                    strip_optimizer(f2)  # strip optimizer

        # Finish
        self.logger.info(
            '%g epochs completed in %.3f hours.\n' %
            (epoch - start_epoch + 1, (time.time() - t0) / 3600))
