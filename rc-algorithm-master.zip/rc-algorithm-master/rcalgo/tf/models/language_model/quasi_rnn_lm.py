import tensorflow as tf
from rcalgo.tf.utils.tf_func import get_new_variable_scope
from rcalgo.tf.module.layer.rnn import MultiBiQRNNLayer, MultiQRNNLayer
from rcalgo.tf.models.language_model.rnn_lm import RNNLM, BiRNNLM


class QuasiRNNLM(RNNLM):
    def __init__(self, config, word_dict, **kwargs):
        super(QuasiRNNLM, self).__init__(config, word_dict, **kwargs)
        self.zoneout = config.get("zoneout", 0.0)
        self.conv_length = config.get("conv_length", 2)
        self.pool_type = config.get("pool_type", "ifo")  # must be in ['f', 'o', 'ifo']
        self.activation = config.get("activation", 'tanh')

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        with get_new_variable_scope('qrnn') as scope:
            m_qrnn = MultiQRNNLayer(self.num_layers, self.hidden_size, self.conv_length,
                                    pool_type=self.pool_type,
                                    zoneout=self.zoneout,
                                    training=self.is_training,
                                    use_residual=self.use_residual)

            states, rnn_outputs = m_qrnn(embedding, seq_lengths)
        targets = tf.concat([sequence[:, 1:], tf.zeros_like(sequence[:, 0:1])], 1)
        return states, rnn_outputs, targets


class BiQuasiRNNLM(QuasiRNNLM):
    def __init__(self, config, word_dict, **kwargs):
        super(BiQuasiRNNLM, self).__init__(config, word_dict, **kwargs)

    def build_lm_representation(self, sequence, embedding, seq_lengths):
        with get_new_variable_scope('qrnn') as scope:
            bi_m_qrnn = MultiBiQRNNLayer(self.num_layers, self.hidden_size, self.conv_length,
                                         pool_type=self.pool_type,
                                         zoneout=self.zoneout,
                                         training=self.is_training,
                                         use_residual=self.use_residual)
            bi_states, bi_outputs = bi_m_qrnn(embedding, seq_lengths)
        states = [bi_states[0], bi_states[1]]
        outputs = tf.concat(bi_outputs, axis=1)
        targets_fw = tf.concat([sequence[:, 1:], tf.zeros_like(sequence[:, 0:1])], 1)
        targets_bw = tf.concat([tf.zeros_like(sequence[:, 0:1]), sequence[:, 0:-1]], 1)
        targets = [targets_fw, targets_bw]
        return states, outputs, targets
