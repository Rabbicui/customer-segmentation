# -*- coding: utf-8 -*-
# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.6.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # 基于graph copy的分布式训练demo
#
# 本demo用于演示在使用基于graph copy的分布式训练时，如何加载之前保存的checkpoint，并继续训练。
#
# 注意在恢复参数的时候，graph结构没有变化。如果需要重新加载graph，请参考`GraphCopyCheckpointDemo.ipynb`。

# %%
import os
import pandas as pd
import tensorflow as tf
import sys
sys.path.insert(0, "../../")

from rcalgo.tf.models.classifier.text_classifier import TransformerClassifier
from rcalgo.tf.utils.tokenizers import CharTokenizer

# %%
config = {
    "learning_rate": 0.0001,

    "num_classes": 2,
    "max_seq_len": 100,
    "embedding_size": 256,
    "num_layers": 2,
    "conv_num_filters": 256,
    # "keep_prob": 0.5,

    "gpu_id": 0,
    "gpu_num": 2,

    "model_output_dir": "./saved_models",
    "model_name": "transformer",

    "clip_type": "clip_value",
    "clip_gradient": 1.0
}

# %%
# 1. load data
data_dir = "/home/web_server/antispam/project/datasets/female_vulgar_small/"
train_data = pd.read_csv(data_dir + 'train.csv')

# %%
# count word dict
tokenizer = CharTokenizer.build_from_corpus(train_data['text'], freq_threshold=1)
word_dict = tokenizer.word2idx

# %%
# 2. create model
model = TransformerClassifier(config, word_dict, name="default",
                         distribute="tf_distribute")
model.build_model()
print(model.model_summary())

# %%
# 3. train
model.train(
    [train_data['text'], train_data['label']],
    batch_size=1024,
    test_size=0.5,
    epochs=1,
    hooks=[])


# %%
model_path = "./saved_models/manually_saved_checkpoint.ckpt"
# 保存模型checkpoint的时候会同时保存原图对应的checkpoint: ./saved_models/single_graph/manually_saved_checkpoint.ckpt
# 和graph copy后multi_replica对应的checkpoint: ./saved_models/manually_saved_checkpoint.ckpt
model.dump_checkpoint(model_path)

# 从多图的checkpoint中恢复参数
multi_replica_path = model_path
model.trainer.load_multi_replica_checkpoint(multi_replica_path)

# %%
# 继续训练
print("continue training ...")
model.train(
      [train_data['text'], train_data['label']],
      batch_size=1024,
      test_size=0.5,
      epochs=1,
      hooks=[])

# %%
# 从单图的checkpoint中恢复参数
single_model_path = os.path.join(os.path.dirname(model_path), "single_graph", os.path.basename(model_path))
model.trainer.load_single_graph_checkpoint(single_model_path)

# %%
# 继续训练
print("continue training ...")
model.train(
      [train_data['text'], train_data['label']],
      batch_size=1024,
      test_size=0.5,
      epochs=1,
      hooks=[])

# %%
