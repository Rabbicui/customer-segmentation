import collections
import numpy as np
import jieba
import copy
from rcalgo.tf.models.augmentation.token_level.base_token_replace import TokenReplace
np.seterr(divide='ignore', invalid='ignore')


# TODO: support custom idf dict
class TfIdfWordReplace(TokenReplace):
    """TF-IDF Based Word Replacement."""
    def __init__(self, sentences, need_cut):
        super(TfIdfWordReplace, self).__init__(sentences, need_cut)
        self.sentences = sentences
        self.idf = self.data_stats['idf']
        self.tf_idf = self.data_stats['tf_idf']

        data_stats = copy.deepcopy(self.data_stats)
        tf_idf_items = data_stats["tf_idf"].items()
        tf_idf_items = sorted(tf_idf_items, key=lambda item: -item[1])
        self.tf_idf_keys = []
        self.tf_idf_values = []
        for key, value in tf_idf_items:
            self.tf_idf_keys += [key]
            self.tf_idf_values += [value]
        self.normalized_tf_idf = np.array(self.tf_idf_values)
        self.normalized_tf_idf = (self.normalized_tf_idf.max()- self.normalized_tf_idf)
        self.normalized_tf_idf = (self.normalized_tf_idf / self.normalized_tf_idf.sum())
        self.reset_token_list()
        self.reset_random_prob()

    def _replace_tokens(self, tokens, token_prob, times):
        ret_tokens = []
        for i in range(times):
            new_tokens = []
            replace_probs = self.get_replace_probs(tokens, token_prob)
            for j in range(len(tokens)):
                if self.get_random_prob() < replace_probs[j]:
                    new_tokens.append(self.get_random_token())
                else:
                    new_tokens.append(tokens[j])
            ret_tokens.append("".join(new_tokens))
        return ret_tokens

    def get_replace_probs(self, tokens, token_prob):
        """Compute the probability of replacing tokens in a sentence."""
        cur_tf_idf = collections.defaultdict(int)
        for word in tokens:
            cur_tf_idf[word] += 1. / len(tokens) * self.idf[word]
        replace_prob = []
        for word in tokens:
            replace_prob += [cur_tf_idf[word]]
        replace_prob = np.array(replace_prob)
        replace_prob = np.max(replace_prob) - replace_prob
        replace_prob = (replace_prob / replace_prob.sum() * token_prob * len(tokens))
        return replace_prob

    def replace(self, token_prob=0.1, times=1):
        """
        :param token_prob: probability of token being replaced
        :param times: how many times do you want to augment
        :return:
        """
        ret_texts = []
        for i, text in enumerate(self.sentences):
            aug_texts = []
            if self.need_cut:
                tokens = list(jieba.cut(text))
            else:
                tokens = list(text)
            aug_texts.extend(self._replace_tokens(tokens, token_prob, times))
            ret_texts.append(aug_texts)
        return ret_texts

    def reset_token_list(self):
        cache_len = len(self.tf_idf_keys)
        token_list_idx = np.random.choice(
            cache_len, (cache_len,), p=self.normalized_tf_idf)
        self.token_list = []
        for idx in token_list_idx:
            self.token_list += [self.tf_idf_keys[idx]]
        self.token_ptr = len(self.token_list) - 1


def test():
    sentences = ['为什么屏蔽我', '怎样才能上热门', '我买的东西卖家不给退货怎么办', '不要屏蔽我好不好', '感谢官方']

    tfidf_rep = TfIdfWordReplace(sentences, need_cut=False)
    texts = tfidf_rep.replace(0.1, 2)
    print(texts)

if __name__ == '__main__':
    test()